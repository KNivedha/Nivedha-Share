// Author: Gene Loparco

Modernizr.load
	([
	{
	test: Modernizr.touch && !Modernizr.overflowscrolling,
	yep: './js/libs/scrollability.js'
	}
	]);


/*
window.onload = function()
	{
	updateOrientation();
	};

window.onorientationchange = updateOrientation();
//window.setTimeout(updateOrientation, 0);

function updateOrientation()
	{alert('hellob');
	if (window.innerWidth != currentWidth)
		{
		var portrait = (window.orientation % 180 === 0);
		currentWidth = window.innerWidth;
		if (currentWidth == 320 && portrait)
			{
			document.body.setAttribute("orient", 'iPhonePortrait');
			}
		else if (currentWidth == 480 && !portrait)
			{
			document.body.setAttribute("orient", 'iPhoneLandscape');
			}
		window.scrollTo(0, 1);
		}
	}



function updateOrientation()
            {
                var displayStr = "Orientation : ";
 
                switch(window.orientation)
                {
                    case 0:
                        displayStr += "Portrait";
                    break;
 
                    case -90:
                        displayStr += "Landscape (right, screen turned clockwise)";
                    break;
 
                    case 90:
                        displayStr += "Landscape (left, screen turned counterclockwise)";
                    break;
 
                    case 180:
                        displayStr += "Portrait (upside-down portrait)";
                    break;
 
                }
                document.getElementById("output").innerHTML = displayStr;
            }

$(document).ready(function () {
  function reorient(e) {
    var portrait = (window.orientation % 180 == 0);
    $("body > div").css("-webkit-transform", !portrait ? "rotate(-90deg)" : "");
  }
  window.onorientationchange = reorient;
  window.setTimeout(reorient, 0);
});
*/
// body > div { -webkit-transition: all 1s ease-in-out; }