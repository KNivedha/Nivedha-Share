paycor.timeOff = {
    "From" : "Apr 01 2011",
    "To" : "Dec 31 2012",
    "Type" : "Type",
    "Status" : "Status",
    "timeOff" : [
     {
         "id" : "1",        
         "name" : "timeOff data 1",
         "leftData" : "Oct 11, 2011 to Oct 12, 2011",
         "rightData" : "Approved",
         "id" : "1",
         "plan" : "Earned Leave",
         "from" : "Oct 11, 2011",
         "to" : "Oct 12, 2011",
         "reason" : "Personal Reason",
         "status" : "Approved",
          "noofhrs" : "9.00"        
     },
     {
         "id" : "2",         
         "name" : "timeOff data 2",
         "leftData" : "Jan 3, 2012 to Jan 5, 2012",
         "rightData" : "Approved",
         "id" : "2",
         "plan" : "Earned Leave",
         "from" : "Jan 3, 2012",
         "to" : "Jan 5, 2012",
         "reason" : "Personal Reason",
         "status" : "Approved",
         "noofhrs" : "9.00" 
     },
     {
         "id" : "3",         
         "name" : "timeOff data 2",
         "leftData" : "Feb 23, 2012 to Feb 23, 2012",
         "rightData" : "Pending",
         "id" : "3",
         "plan" : "Compensatory Leave",
         "from" : "Feb 23, 2012",
         "to" : "Feb 23, 2012",
         "reason" : "Attend a function",
         "status" : "Pending",
         "noofhrs" : "9.00" 
     }
    ]
}


paycor.timeOffListData = {
    "timeOff" : [
    {
        "id" : "1",
        "plan" : "Earned Leave",
        "from" : "Oct 11, 2011",
        "to" : "Oct 12, 2011",
        "reason" : "Medical Leave",
        "status" : "Approved"
    },
    {
        "id" : "2",
        "plan" : "Medical Leave",
        "from" : "Jan 3, 2012",
        "to" : "Jan 5, 2012",
        "reason" : "Medical Leave",
        "status" : "Approved"
    },
    {
        "id" : "3",
        "plan" : "Compensatory Leave",
        "from" : "Feb 23, 2012",
        "to" : "Feb 23, 2012",
        "reason" : "Attend a function",
        "status" : "Pending"
    }
    ]
}

paycor.TrainingData= {
    "items":[{'CourseName':'Open STA','StartDate':'Jan 05, 2012','time':'09:20 AM','Status':'Completed','CourseDesc':'Test automation','Seats':'10','Location':'Jawaharlal Nehru Road, Thiru Vi Ka Indl Estate, Saidapet Chennai'},
             {'CourseName':'Windows 7','StartDate':'Feb 27, 2012','time':'17:20 PM','Status':'Available','CourseDesc':'OS','Seats':'20','Location':'Manapakkam, Chennai, Tamil Nadu, India'},
             {'CourseName':'Open STA V2','StartDate':'Mar 05, 2012','time':'14:20 PM','Status':'Available','CourseDesc':'Test Automation','Seats':'30','Location':'Tambaram, Chennai, TamilNadu, India '}
             ] 
}

paycor.TrainingDataAddress = {
    "items" : [
    {
               "Address" : "Jawaharlal Nehru Road, Thiru Vi Ka Indl Estate, Saidapet Chennai"
    },
               {
               "Address" : "Manapakkam, Chennai, Tamil Nadu, India",
               },
               {
               "Address" : "Tambaram, Chennai, TamilNadu, India",
               },
    ]
}


paycor.jobOpenening = {
    "items" : [
               {title: 'Senior Engineer',   technology: 'JAVA/J2EE', position:'Senior Engineer',keyskills:'JAVA/J2EE',Experience: '5 years',Location:'Chennai',id:'1'},
               {title: 'Senior Architect',    technology: 'JAVA/J2EE',position:'Senior Architect',keyskills:'JAVA/J2EE , Spring ,Hibernate',Experience: '10 years',Location:'Chennai',id:'2'},
               {title: 'Senior Engineer',      technology: 'dotnet',position:'Senior Engineer',keyskills:'ASP Dotnet',Experience: '4 years',Location:'Chennai',id:'3'},
               {title: 'Engineer',   technology: 'PEGA',position:'Engineer',keyskills:'PEGA',Experience: '2 years',Location:'Chennai',id:'4'},
               {title: 'Senior Engineer',   technology: 'Sencha touch',position:'Senior Engineer',keyskills:'JavaScript ,Sencha touch',Experience: '5 years',Location:'Chennai',id:'5'},
               {title: 'Senior Engineer',    technology: 'Jquery Mobile',position:'Senior Engineer',keyskills:'Jquery/Jquery mobile',Experience: '5 years',Location:'Chennai',id:'6'},
               {title: 'Architect', technology: 'PHP',position:'Architect',keyskills:'PHP',Experience: '8 years',Location:'Chennai',id:'7'},
               {title: 'Engineer', technology: 'Oracle',position:' Engineer',keyskills:'Oracle 10',Experience: '2 years',Location:'Chennai',id:'8'},
               {title: 'Senior Engineer',     technology: 'JavaScript',position:'Senior Engineer',keyskills:'JavaScript,ExtJS',Experience: '5 years',Location:'Chennai',id:'9'},
               {title: 'Senior Engineer',   technology: 'PHP',position:'Senior Engineer',keyskills:'JAVA/J2EE',Experience: '5 years',Location:'Chennai',id:'10'},
               {title: 'Senior Engineer',     technology: 'EXT JS',position:'Senior Engineer',keyskills:'ExtJS',Experience: '6 years',Location:'Chennai',id:'11'}
               
               ]
}
paycor.jobOpeningDescription = {
    "1" : 
    {
               "description" : [{"name" : "Good Communication skills both verbal and written"},
                                {"name" : "Good Experience in developing Java and J2EE web applications. Spring, Hibernate, DWH and extra plus"}]
    },
          "2":     {
               "description" : [{"name" : "Good Communication skills both verbal and written"},
                                {"name" : "Good Experience in developing Java and J2EE web applications. Spring, Hibernate, DWH and extra plus"}]
               },
           "3":   {
           "description" : [{"name" : "Good Communication skills both verbal and written"},
                            {"name" : "Should have good knowledge in developing applications using .NET Framework"}]
           },
            "4":   {
               "description" : [{"name" : "Good Communication skills both verbal and written"},
                                {"name" : "Should have good knowledge in PEGA"}]
               },
             "5":  {
               "description" : [{"name" : "Good Communication skills both verbal and written"},
                                {"name" : "Should have good knowledge in developing Webapplications using EXT JS framework and Sencha touch 1.x and above"}]
               },
           "6":{
               "description" : [{"name" : "Good Communication skills both verbal and written"},
                                {"name" : "Should have good knowledge in developing Webapplications using jQuery, jQueryMobile"}]
               },
             "7":  {
               "description" : [{"name" : "Good Communication skills both verbal and written"},
                                {"name" : "Should have good knowledge of scripting and writing server side programming using PHP"}]
               },
               "8":{
               "description" : [{"name" : "Good Communication skills both verbal and written"},
                                {"name" : "Should have good knowledge of the concepts in DWH"}]
               },
              "9": {
               "description" : [{"name" : "Good Communication skills both verbal and written"},
                                {"name" : "Should have good knowledge in developing Webapplications using jQuery, jQueryMobile, Sencha , Sencha Touch1.x and above"}]
               },
              "10": {
                                "description" : [{"name" : "Good Communication skills both verbal and written"},
                                                 {"name" : "Should have good knowledge of scripting and writing server side programming using PHP"}]
               },
              "11": {
                                "description" : [{"name" : "Good Communication skills both verbal and written"},
                                                 {"name" : "Should have good knowledge in developing Webapplications using jQuery, jQueryMobile, Sencha , Sencha Touch1.x and above"}]
               },
               
    
}

paycor.payrollDetails = {
    "items": [
    {
              paydate: 'Feb 23, 2012 ',   period: 'Feb 02, 2012', hoursworked:'40 hours',netpay:'$ 4578.00',
              regular: '$ 4537.00', others :'$ 2389.00', federalincometax : '$ 5677.00', socialsecuritytax :'$ 344.00',
              medicaretax: '$ 56.00',stateincometax:'$7879.00',localtax : '$ 647.00', others1:'$ 808.00',fromdate:'Jan 01 2011',
              todate:'Mar 31, 2011',earnings:'$ 34848.00',deducations:'$ 589.00'
    },
              {
              paydate: 'Feb 23, 2012 ',   period: 'Feb 02, 2012', hoursworked:'40 hours',netpay:'$ 5578.00',
              regular: '$ 4537.00', others :'$ 2389.00', federalincometax : '$ 5677.00', socialsecuritytax :'$ 344.00',
              medicaretax: '$ 56.00',stateincometax:'$7879.00',localtax : '$ 647.00', others1:'$ 808.00',fromdate:'Apr 01, 2011',
              todate:'Jun 30, 2011',earnings:'$ 35848.00',deducations:'-$ 789.00'
              },
              {
              paydate: 'Feb 23, 2012 ',   period: 'Feb 02, 2012', hoursworked:'40 hours',netpay:'$ 7578.00',
              regular: '$ 4537.00', others :'$ 2389.00', federalincometax : '$ 5677.00', socialsecuritytax :'$ 344.00',
              medicaretax: '$ 56.00',stateincometax:'$7879.00',localtax : '$ 647.00', others1:'$ 808.00',fromdate:'Jul 01, 2011',
              todate:'Sep 31, 2011',earnings:'$ 55848.00',deducations:'-$ 489.00'
              },
              {
              paydate: 'Feb 23, 2012 ',   period: 'Feb 02, 2012', hoursworked:'40 hours',netpay:'$ 6578.00',
              regular: '$ 4537.00', others :'$ 2389.00', federalincometax : '$ 5677.00', socialsecuritytax :'$ 344.00',
              medicaretax: '$ 56.00',stateincometax:'$7879.00',localtax : '$ 647.00', others1:'$ 808.00',fromdate:'Oct 01, 2011',
              todate:'Dec 31, 2011',earnings:'$ 45848.00',deducations:'-$ 589.00'
              },
    ]

}




paycor.payrollListDetails = {
    "items" : [
    {
               "title" : "Deductions",
               "Name" : "Federal Income Tax",
               "Amount" : "$ 77.00"
    },
               {
               "title" : "Earnings",
               "Name" : "Regular",
               "Amount" : "$ 4537.00"
               },
               {
               "title" : "Earnings",
               "Name" : "Others",
               "Amount" : "$ 2389.00"
               },
               {
               "title" : "Deductions",
               "Name" : "Social Security Tax",
               "Amount" : "$ 44.00"
               }
    ]
}