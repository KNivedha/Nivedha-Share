/**
 * Actions related to Login use-cases.
 *
 * @return - Singleton instance of Login controller.
 * Use this to call the controller methods directly. TODO: Test this
 */
paycor.controllers.loginController = Ext.regController('Login', {
  
/*
 * displays the first view (login view) of the application
 */	
	showLoginView : function()
	{
       //paycor.views.viewport.addDocked(paycor.views.mainToolBar); 
       paycor.views.mainToolBar.setTitle('iHRMS'); 
       paycor.views.loginView = new paycor.views.LoginView();
	   paycor.views.viewport.setActiveItem(paycor.views.loginView); 
       //location.href="paycor#eventName=displayWebView";                                              
	},
/*
 * displays the grid view 
 */
   showGridView : function()
   {
       //paycor.views.viewport.addDocked(paycor.views.mainToolBar);                                                
       paycor.views.gridView = new paycor.views.GridView();
       paycor.views.viewport.setActiveItem(paycor.views.gridView);
       paycor.views.mainToolBar.setTitle('iHRMS');                                                 
   }
                                                       
});