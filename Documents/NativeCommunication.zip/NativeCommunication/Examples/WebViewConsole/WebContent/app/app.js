/**
 * Starting point for this application.
 */
Ext.regApplication({
  name: 'paycor',
  /**
   * Called immediately after Ext.onReady() event
   */
  launch: function() {
	  paycor.views.viewport = new paycor.views.Viewport();
    
    Ext.dispatch({
      controller: paycor.controllers.loginController,
      action: 'showLoginView'
    });
  }
});
