Ext.Router.draw(function(map) {
  map.connect(':controller/:action');
});