paycor.views.mainToolBar = new Ext.Toolbar({
                                           cls : 'toolbar',                                                                                             
     height : 44,
     
                                           items : [
              {
              xtype : 'button',
              height : 30,
              id : 'cancel',
              text : 'Cancel',
              ui : 'button',
              hidden : true,
              handler: function() {
              
              Ext.dispatch({
                           controller: healthStream.controllers.navigationButtonController,
                           action: 'cancel'
                           }); 
              }
              },
              {
              xtype : 'button',
              height : 30,
              id : 'back',
              text : 'Back',	        	
              ui : 'back',
              hidden : true,
              handler : function()
              {
              Ext.dispatch({
                           controller: paycor.controllers.navigationController,
                           action: 'back'
                           }); 
              }   
              },
              
              {
              xtype : 'spacer' 
              },
              {
              xtype : 'button',
              height : 30,
              iconCls : 'filter',
              iconMask: true,
              ui : 'button',
              id : 'filter',
              hidden : true,
              handler : function()
              {
              
              Ext.dispatch({
                           controller: healthStream.controllers.navigationButtonController,
                           action: 'filter'
                           }); 
              }
              },
              {
              xtype : 'button',
              id : 'add',
                                                    text : 'Add',
              //iconCls : 'add',
              ui : 'button',
              //iconMask: true,
              height : 30,
              hidden : true,
              handler : function()
              {
              
              Ext.dispatch({
                           controller: paycor.controllers.navigationController,
                           action: 'add'
                           }); 
              }
              
              },
              {
              xtype : 'button',
                                                    ui : 'positive',                                     
              id : 'done',
              height : 30,
              text : 'Done',
              //ui : 'button',
              hidden : true,
              handler : function()
              {
              
              Ext.dispatch({
                           controller: paycor.controllers.navigationController,
                           action: 'done'
                           }); 
              }
              },
              {
              xtype : 'button',
              id : 'edit',
              height : 30,
              text : 'Edit',
              ui : 'button',
              hidden : true,
              handler : function()
              {
              
              Ext.dispatch({
                           controller: paycor.controllers.navigationController,
                           action: 'add',
                           edit : true
                           }); 
              }
              },
              {
              xtype : 'button',
              id : 'enroll',
              height : 30,
              text : 'Enroll',
                                                    ui : 'positive',
              //ui : 'button',
              hidden : true,
              handler : function()
              {
              
              Ext.dispatch({
                           controller: paycor.controllers.navigationController,
                           action: 'enroll',
                           
                           }); 
              }
                                                    },
                                                    {
                                                    xtype : 'button',
                                                    id : 'details',
                                                    height : 30,
                                                    text : 'Summary',
                                                    ui : 'button',
                                                    hidden : true,
                                                    handler : function()
                                                    {
                                                    
                                                    Ext.dispatch({
                                                                 controller: paycor.controllers.navigationController,
                                                                 action: 'details',
                                                                 
                                                                 }); 
                                                    }
                                                    }
              
              ]
     
     });










paycor.views.logoToolBar = new Ext.Toolbar({
                                           cls : 'toolbar',                                                                                             
                                           height : 44,
                                           items : [
                                           {
                                                    xtype : 'spacer'
                                           },
                                                    {
                                                    xtype : 'panel',
                                                    //cls : 'panel',
                                                   // height : 44,
                                                    //width : 200,
                                                    html : '<center><img src="images/logo.png" height="44" width="200"/></center>'
                                                    },
                                                    {
                                                    xtype : 'spacer',
                                                    
                                                    }]

});