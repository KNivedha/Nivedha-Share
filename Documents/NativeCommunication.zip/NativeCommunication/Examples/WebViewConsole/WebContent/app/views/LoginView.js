/**
 * Panel represent the login page
 */

paycor.views.myCallback1 = function()
{
    alert('MyFirst callback1');
}
paycor.views.myCallback2 = function()
{
    alert('MyFirst callback2');
},
paycor.views.LoginView = Ext.extend(Ext.form.FormPanel, {

    baseCls : 'theme',                                
	title : 'loginView',
    
	initComponent: function() {
	
	var loginButton, useridField, passwordField ;
		
	

	loginButton = new Ext.Button(
    {
                                 cls : 'loginButton',                          
	   ui : 'button',          
	   text : 'Login',
	   width : '60%',
       id:'loginButton',
       listeners : 
        {
          tap : function()
          { 

               nativeCommunication.callNativeMethod("paycor#eventName=data1");
              nativeCommunication.callNativeMethod("paycor#eventName=data2");                   
                 
//              Ext.dispatch(
//              {
//                  controller: paycor.controllers.loginController,
//                  action: 'showGridView'
//              }); 
          }
         }
	   
	});	
        
	
	
	useridField = new  Ext.form.Text({
                                     //width : '80%',                            
		name : 'userid',
        inputCls : 'textfield',
		placeHolder : 'User ID',
		id : 'Useridfield'
	});
	
	passwordField = new  Ext.form.Password({
                                           
		name : 'password',
		inputCls : 'textfield',
		placeHolder : 'Password',
		id : 'passwordfield'
	});
	var mainToolBar = new Ext.Toolbar({
                                      cls : 'toolbar',                                                                                             
                                      height : 44,
                                      items : [
                                               {
                                               xtype : 'spacer'
                                               },{
                                               xtype : 'panel',
                                               cls : 'panel',
                                               height : 44,
                                               width : 200,
                                               html : '<center><img src="images/logo.png" height="44" width="200"/></center>'
                                               },
                                               {
                                               xtype : 'spacer'
                                               }
                                      ]
                                      
                                    });
	
	Ext.apply(this, {
             // dockedItems : [
                             //mainToolBar
//                             {
//                                                                   xtype : 'spacer'
//                                                                   },{
//                                                                   xtype : 'panel',
//                                                                   html : '<center><img src="images/logo.png" height="44" width="200"/></center>'
//                                                                   },
//                                                                   {
//                                                                   xtype : 'spacer'
//                                                                   }
////                             {
////                             xtype : 'toolbar',
////                             cls : 'toolbar',                                                                                             
////                             height : 44,
////
////                             items : [
////                                      {
////                                      xtype : 'spacer'
////                                      },{
////                                      xtype : 'panel',
////                                      html : '<center><img src="images/logo.png" height="44" width="200"/></center>'
////                                      },
////                                      {
////                                      xtype : 'spacer'
////                                      }
////                             ]
////                             }
             // ],      
    	items : [
    	         //mainToolBar,
                 {
                 html : '<center><img src="images/logo.png" height="80" width="200"/></center>'
                 },
    	         {
    	        	 xtype : 'spacer',
                     height : '5%'
    	         },
                  useridField,
    	         {
    		         xtype : 'spacer',
                     height : '5%'
    	         },
	              passwordField,
	              {
	    		         xtype : 'spacer',
	    		         height : '5%'
	    	       },
                 {
                 cls:'textfield',
                 width:'98%',
                 xtype:'togglefield',
                 name : 'rememberme',
                 label:'Remember Me',
                 labelWidth : '45%',
                 inputType:'onofftoggle'
                 },
                 {
                 xtype : 'spacer',
                 height : '5%'
    	         },
	     loginButton
//	    	       {
//                   //baseCls : 'theme', 
//	    	       layout : {type : 'vbox'},
//	    	       items : [loginButton]
//    	  
//	}
      ]
    });
	paycor.views.LoginView.superclass.initComponent.apply(this, arguments);
    }
});