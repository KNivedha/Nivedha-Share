/**
 * Represents the outermost UI shell of this application. Every other UI component regardless of
 * whether it is a container or widget is a child of this Viewport.
 *
 * Every screen in this application will be a Container that will be a direct child of Viewport.
 * That way every screen in this application can be considered to be a card in the Viewport.
 *
 * @return Viewport class. Create a new instance of this viewport at launch()
 */
paycor.views.Viewport = Ext.extend(Ext.Panel, {
  fullscreen: true,              // Occupies entire device's screen real-estate even when run directly in the browser
  layout: 'card',                // Every screen in the application will be a card in this Viewport
  cardSwitchAnimation: 'slide',  // Every card (screen) in this application will slide into view by default

  initComponent: function() {
	
	
	Ext.apply(this, {
      items: [
            
      ]
    });
	 
	paycor.views.Viewport.superclass.initComponent.apply(this, arguments);
  }

});

