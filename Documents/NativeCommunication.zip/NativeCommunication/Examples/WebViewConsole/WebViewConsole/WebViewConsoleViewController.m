//
//  paycorViewController.m
//  paycor
//
//  Created by Nagendra Srinivas on 13/02/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "WebViewConsoleViewController.h"

@implementation WebViewConsoleViewController
@synthesize webView;
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    //self.webView.hidden = YES;
    NSURL *fileUrl=[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"index" ofType:@"html" inDirectory:@"WebContent"]];
    NSLog(@"fileurl %@",fileUrl);
    NSMutableURLRequest* req=[[NSMutableURLRequest alloc]initWithURL:fileUrl];
    //req=[[NSMutableURLRequest alloc]initWithURL:url];
    [self.webView loadRequest:req];
    [req release];
    
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma -mark UIWebView delegate functions
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSLog(@"inside shouldStartLoadWithRequest");
    BOOL returnType;
    NSLog(@"delegate methode");
    NSString* url=[[request URL] absoluteString];
    NSLog(@"url : %@",url);
    
    @try 
    {
        NSArray* urlArray=[url componentsSeparatedByString:@"#"];
        if([urlArray count]>1)
        {
            NSArray* paramArray=[[urlArray objectAtIndex:1]componentsSeparatedByString:@"&"];
            int paramcount=[paramArray count];
            NSString* eventname=[[[paramArray objectAtIndex:0] componentsSeparatedByString:@"="]objectAtIndex:1];
            if (paramcount==1)
            {
                if ([eventname isEqualToString:@"displayWebView"]){
                    NSLog(@"inside displayview");
                    //bgImage.hidden = YES;
                    //self.webView.hidden = NO;
                } 
                else if ([eventname isEqualToString:@"data1"]){
                    NSLog(@"inside data1");
                    //bgImage.hidden = YES;
                    //self.webView.hidden = NO;
                    [self.webView stringByEvaluatingJavaScriptFromString:@"paycor.views.myCallback1()"];
                } 
                else if ([eventname isEqualToString:@"data2"]){
                    NSLog(@"inside data2");
                    //bgImage.hidden = YES;
                    //self.webView.hidden = NO;
                    [self.webView stringByEvaluatingJavaScriptFromString:@"paycor.views.myCallback2()"];
                } 
                
                
                returnType=NO;
            }
            
        }
        else
        {
            returnType=YES;
        }
        
    }
    @catch (NSException *exception) 
    {
        returnType=NO;
        NSLog(@"thrown execption %@",exception);
    }
    
    return returnType;
}
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"inside webViewDidStartLoad");
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    
    NSLog(@"inside webViewDidFinishLoad");
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"inside didFailLoadWithError");
}

@end
