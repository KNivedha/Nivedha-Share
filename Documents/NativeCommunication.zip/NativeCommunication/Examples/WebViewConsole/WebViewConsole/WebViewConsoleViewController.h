//
//  WebViewConsoleViewController.h
//  WebViewConsole
//
//  Created by Nagendra Srinivas on 23/02/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebViewConsoleViewController : UIViewController
@property(nonatomic,retain) IBOutlet UIWebView * webView;
@end
