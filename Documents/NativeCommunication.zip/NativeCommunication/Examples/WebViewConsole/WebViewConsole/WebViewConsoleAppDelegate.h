//
//  WebViewConsoleAppDelegate.h
//  WebViewConsole
//
//  Created by Nagendra Srinivas on 23/02/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WebViewConsoleViewController;

@interface WebViewConsoleAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet WebViewConsoleViewController *viewController;

@end
