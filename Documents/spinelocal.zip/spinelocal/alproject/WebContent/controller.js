

var cnt1;
var cnt2;


var  mpController= Spine.Controller.create({

  el:"body",

  events: {
    "click #icon1": "func1",
    "click #icon2": "func2",
    "click #icon3": "func3",
    "click #icon4": "func4"  
  },
  
init:function(){
  },
func1: function(){

$.mobile.changePage("#dbque",null,true,true);      
},

func2 : function(){


  $.mobile.changePage("#asque",null,true,true);       
  },

func3 : function(){
    $.mobile.changePage("#activeque",null,true,true);  
},

func4:function(){
  alert("j");
}
});


var  qaController1 = Spine.Controller.create({

  el:"#dbque",

  events: {
  "click #dbque #prev1": "prevfunc",
  "click #dbque #next1": "nextfunc"

  },
  elements:{
    "#script1":"script","#space1":"space","#pbar1":"pbar","#next1":"next","#prev1":"prev"
  },
  init:function(){
    
   qa = qaModel1.all();
   len=qa.length ;  
   inc=(100/len);
   cnt=0;
   x=0;
  this.pbar.progressBar(x);
   p=_.template(this.script.html(),{qa : qa[cnt]});
   this.space.html(p);
   this.prev.css('visibility','hidden');
   //this.el.trigger('create');
  },

  nextfunc: function(){
    
    $("#dbque #prev1").css('visibility','visible');
    alert("helloss"); 
   
    if(cnt==(len-1))      
    {
      alert("hi your task is finished");
    }
    if(cnt<(len-1))      
    {         
      cnt=cnt+1;  
           if(cnt==(len-1))   
           {   
             this.next.text('finish');
           }      
      x= x+inc;
      p=_.template(this.script.html(),{qa : qa[cnt]});
      this.space.html(p);  
      this.pbar.progressBar(x); 
      this.el.trigger('create');  
    }     
  },
  
  prevfunc : function(){
    
    this.next.text('next');
    if(cnt > 0)
    { 
      //alert(cnt);   
      cnt=cnt-1;
      x= x-inc;
      p=_.template(this.script.html(),{qa : qa[cnt]});
      this.space.html(p);  
      this.pbar.progressBar(x);
      this.el.trigger('create');
     // alert(cnt);
    } 
    if(cnt==0)
      {
      this.prev.css('visibility','hidden');     
      }
  }
  
});


var  qaController2= Spine.Controller.create({

  el:"body",
  
  events: {
    "click #prev2": "prevfunc",
    "click #next2": "nextfunc",
    "click #button": "buttonfunc"
  },
  elements:{
    "#script2":"script","#space2":"space","#pbar2":"pbar","#prev2":"prev","#next2":"next"
 },
 
init:function(){
  
   qamod = qaModel2.all();
   len=qamod.length ;  
   inc=(100/len);
   ind=0;
   this.pbar.progressBar((ind)*inc);
   this.prev.css('visibility','hidden');
   p=_.template(this.script.html(),{qa : qamod[ind]});
   this.space.html(p);
   this.el.trigger('create');
  
 },
 nextfunc: function(){

   if(ind<=len)
    {     
          if(ind==(len-2))   
           {   
             $('.next').text('finish');
           }
          if(ind==(len-1))
           {
            alert("finished");
            break;
           }
           ind=ind+1;
    this.pbar.progressBar((ind)*inc);
    p=_.template(this.script.html(),{qa : qamod[ind]});
    this.space.html(p);
    this.prev.css('visibility','visible'); 
    this.el.trigger('create'); 
    }
   
  },
    
  prevfunc: function(){
      //alert("previous"); 
      this.next.html('next');
      if(ind>0)
      { 
         ind= ind-1;
        this.pbar.progressBar((ind)*inc);
        p=_.template(this.script.html(),{qa : qamod[ind]});
        this.space.html(p);
        $(".prev").css('visibility','visible');
        $("input[type='radio']").checkboxradio();
        if(ind<1)
        {
         this.prev.css('visibility','hidden');
        }      
      } this.el.trigger('create');  
    },
    
    buttonfunc: function(){

      $.mobile.changePage("#descpage",null,true,true); 
      as = asModel.all();
      alert(as);
      p=_.template($('#script3').html(),{qa : as[0]}); 
      $("#space3").html(p);
  $("#descpage").trigger('create');  
    }


});







