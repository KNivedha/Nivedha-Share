// diabetes question  model
var qaModel1 = Spine.Model.setup("qaModel1", ["que","ans","title"]);

qaTable1.all().list(function(results){
//alert("in");
  qa_list = _.map(results, function(val,key){
  
    var qa = qaModel1.init({
       que:val.que,
       ans:val.ans,
       title:val.title    
     });
    qa.create();
  }); 
 });

//asthma question model

var qaModel2 = Spine.Model.setup("qaModel2", ["que","ans","title"]);

qaTable2.all().list(function(results){
//alert("in");
  qa_list = _.map(results, function(val,key){
  
    var qa = qaModel2.init({
       que:val.que,
       ans:val.ans,
       title:val.title    
     });
    qa.create();
    //alert(qa.que);
  }); 
 });


// assessment model

var asModel= Spine.Model.setup("asModel", ["img","title","desc","con","credits","button"]);

asTable.all().list(function(results){

  as_list = _.map(results, function(val,key){
   
     var as = asModel.init({
        img:val.img,
        title:val.title,
        desc:val.desc,
        con:val.con,
        credits:val.credits,
        button:val.button      
      });
     as.create();
// alert(as.img);
   }); 
  }); 
