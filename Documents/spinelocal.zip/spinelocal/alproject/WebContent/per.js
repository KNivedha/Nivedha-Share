persistence.store.websql.config(persistence,'Tableb','details',5*1024*1024);

var qaTable1 = persistence.define("qaTable1", {
  que:"TEXT",
  ans:"JSON",
  title:"TEXT"
  });

var qa1 = new qaTable1({ 
  que: "Are you currently affected by diabets? if so of which type",
  ans:{"a1":"no","a2":"type1","a3":"type2","a4":"type3","a5":"type4" },
  title:"Diabets Assesment"
});
var qa2 = new qaTable1({ 
  que: "What gulcometer do you predominately use?",
  ans:{"a1":"A11","a2":"A22","a3":"A33","A44":"type3","A55":"type4" },
  title:"Diabets Assesment"
});
var qa3 = new qaTable1({ 
  que: "How do you manage your diabets ? ",
  ans:{"a1":"typea","a2":"typeb","a3":"typec","a4":"typed","a5":"typee" },
  title:"Diabets Assesment"
});


//persistence.add(qa1);
//persistence.add(qa2);
//persistence.add(qa3);

var qaTable2 = persistence.define("qaTable2", {
  que:"TEXT",
  ans:"JSON",
  title:"TEXT"
  });

var qaTab1 = new qaTable2({ 
  que: "During past four weeks how often your asthma symptoms wake you up?",
  ans:{"a1":"4 or more nights a week","a2":"2 0r more nights a week ","a3":"once a week","a4":"once or twice","a5":"Not at all" },
  title:"Asthma assesment" 
});
var qaTab2 = new qaTable2({ 
  que: "In the past four weeks how much of the time did your asthma keep you from getting as much as work done at work school or at home?",
 ans:{"a1":"all of the time","a2":"most of the time","a3":"none of the time","a4":"some of the rime","a5":"a little of the time" },
  title:"Asthma assesment"
});
var qaTab3 = new qaTable2({ 
  que: "How wouldd you rate your asthma control during past four weeks?",
  ans:{"a1":"Not controlled","a2":"Poorly controlled","a3":"Somewhat controlled","a4":"Well controlled","a5":"Completely controlled" },
  title:"Asthma assesment"
});
var qaTab4 = new qaTable2({ 
  que: "4 are you currently affected by diabets? if so of which type",
  ans:{"a1":"no","a2":"type1","a3":"type2","a4":"type3","a5":"type4" },
  title:"Asthma assesment"
});
var qaTab5 = new qaTable2({ 
  que: "5 are you currently affected by diabets? if so of which type",
  ans:{"a1":"no","a2":"type1","a3":"type2","a4":"type3","a5":"type4" },
  title:"Asthma assesment"
});

//persistence.add(qaTab1);
//persistence.add(qaTab2);
//persistence.add(qaTab3);
//persistence.add(qaTab4);
//persistence.add(qaTab5);



var asTable = persistence.define("asTable", {
    img:"TEXT",
    title:"TEXT",
    desc:"TEXT",
    con:"TEXT",
    credits:"TEXT",
    button:"TEXT"   
  });

var asTab1 = new asTable({ 
  img: "img\\Asthma_Assessment.png",
  title:"Asthma Assesment",
  desc:"1 the purpose of this alert is help you in asthma assesment",
  con: "By default I'm open and displayed on the page, but you can click the header to hide me",
  credits:"no",
  button:"no"
});

var asTab2 = new asTable({
  img: "img\\Challenge_Get_Active.png",
  title:"Active Challenge Assesment",
  desc:" The purpose of this alert is help you in Active challenge",
  con: " ",
  credits:"3 Credits",  
  button:"no"
}); 

var asTab3 = new asTable({
  img: "img\\Click_To_Call.png",
  title:"Call to nurse",
  desc:"2 the purpose of this alert is help you in asthma assesment",
  con: "2 By default I'm open and displayed on the page, but you can click the header to hide me",
  credits:"no",
  button:"Press to call"
});


//persistence.add(asTab1);
//persistence.add(asTab2);
//persistence.add(asTab3);


persistence.schemaSync();
persistence.flush();

