/**
 * @author Nivedha
 */

assignment.models.EmployeeModel = Spine.Model.sub();
assignment.models.EmployeeModel.configure('EmployeeModel', 'Username', 'Passwd', 'FirstName', 'LastName', 'DateOfBirth', 'Email', 'Gender', 'Address', 'ZipCode', 'MobileNo', 'Photo', 'AdditionalInfo', 'EmployeeID', 'DateOfJoining', 'Designation', 'DepartmentName', 'DepartmentID');
