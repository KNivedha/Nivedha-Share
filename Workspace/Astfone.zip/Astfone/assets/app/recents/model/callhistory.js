/**
 * @author Nivedha Kaliaperumal
 */

astfone.models.CallHistory = Spine.Model.sub();
astfone.models.CallHistory.configure('CallHistory', 'CountryName', 'Rate');