/**
 * @author Nivedha Kaliaperumal
 */

astfone.models.CountryRateModel = Spine.Model.sub();
astfone.models.CountryRateModel.configure('CountryRateModel', 'CountryName', 'Rate');


