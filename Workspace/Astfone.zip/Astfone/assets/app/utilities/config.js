/**
 * @author Nivedha Kaliaperumal
 */

astfone = {};
astfone.models = {};
astfone.controllers = {};
astfone.service = {};
astfone.util = {};
astfone.config = {};
astfone.config.url={
	loginUrl:'http://72.22.77.62/dev.astfone.com/api-mob/login.php?key=K3L29H0R1CS7W9KG6B2NP90&username=nazrul.islam@capanicus.com&passwd=111111',
	countryRateUrl:'',
	profileUrl:'http://72.22.77.62/dev.astfone.com/api-mob/profile.php?key=K3L29H0R1CS7W9KG6B2NP90',
	changePwdUrl:'http://72.22.77.62/dev.astfone.com/api-mob/change-passwd.php?key=K3L29H0R1CS7W9KG6B2NP90',
	callHistoryUrl:'http://72.22.77.62/dev.astfone.com/api-mob/call-history.php?key=K3L29H0R1CS7W9KG6B2NP90'
};
astfone.config.credentials={	
	userid : '',
	password : ''
};
