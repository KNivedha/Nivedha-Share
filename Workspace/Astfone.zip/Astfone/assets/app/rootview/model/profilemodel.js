/**
 * @author Nivedha Kaliaperumal
 */

astfone.models.ProfileModel = Spine.Model.sub();
astfone.models.ProfileModel.configure('ProfileModel', 'UserID', 'Passwd', 'UserName', 'Email', 'Phone', 'Country', 'Balance', 'JoinDate');
