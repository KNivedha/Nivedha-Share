//
//  TabBar.h
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DeviceDelegate.h"
#import "AlereAppDelegate.h"
@interface TabBar : NSObject<DeviceDelegate>
{
UIGestureRecognizer *webViewFingerTap;
UIPanGestureRecognizer *webViewFingerPan;    
}
@end
