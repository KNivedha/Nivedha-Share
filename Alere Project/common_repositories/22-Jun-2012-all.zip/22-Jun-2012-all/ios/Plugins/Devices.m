//
//  Devices.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Devices.h"
#import "AlereAppDelegate.h"
#import "AlereViewController.h"
#import "Logging.h"
@implementation Devices
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{ AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    UIDevice *myDevice=[UIDevice currentDevice];
    NSString* osversion=[myDevice systemVersion];
    NSString* deviceName=[myDevice name];
    NSString* osName=[myDevice systemName];
    NSString* osId=@"1";   // defined in Apollo database
    NSString* devMake=@"Apple";
    NSString* devModel=[myDevice model];
    NSString* devCustomId= [NSString  stringWithFormat:@"%@%@", deviceName,osName];
    
    //read the following from info.plist
    NSDictionary* infoDict = [[NSBundle mainBundle] infoDictionary];
    NSString* appName = [infoDict objectForKey:@"CFBundleDisplayName"]; // bundle display name as application name
    NSString* appVersion = [infoDict objectForKey:@"CFBundleVersion"]; // bundle version short string as build version
    NSString* appReleasedVer = [infoDict objectForKey:@"CFBundleShortVersionString"]; // Bundle version as release version
    
    NSString* appNameandVersion = [appName stringByAppendingString:appVersion];

    AlereAppDelegate *obj=[AlereAppDelegate getInstance];  
    NSData* devicetoken = obj.devicetoken;
    
    DLog(@"********** osversion: %@ ,deviceName: %@ , osId: %@, osName: %@, devMake: %@, devModel: %@, devCustomId: %@, devicetoken:  %@, appName: %@ , appVersion: %@ , appReleasedVer: %@ , appVersion: %@", 
          osversion, deviceName, osId, osName, devMake, devModel, devCustomId, devicetoken, appName, appVersion, appReleasedVer,appNameandVersion);
    
    //osName,osVersion,deviceMake,deviceModel,deviceId, deviceToken,deviceName,appName
    [ app.viewController.webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"getDeviceInfo([\"%@\"],[\"%@\"],[\"%@\"],[\"%@\"],[\"%@\"],[\"%@\"],[\"%@\"],[\"%@\"])",osId, osversion,devMake, devModel,devCustomId,devicetoken ,deviceName,appNameandVersion]];
}
@end