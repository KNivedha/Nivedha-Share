//
//  Log.m
//  Alere
//
//  Created by virtusa on 12/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Log.h"
#import "AlereAppDelegate.h"
#import "Logging.h"

@implementation Log
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    if ([action isEqualToString:@"logMessage"]) {
        NSInteger count=[parameters count];
        NSString* messageString=[parameters objectForKey:@"message"];
        if(count == 1){
           NSLog(@"%@",messageString);
        }
    }
}
@end
