//
//  OpenUrl.m
//  Alere
//
//  Created by virtusa on 09/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OpenUrl.h"

@implementation OpenUrl
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
       [[UIApplication sharedApplication]openURL:[NSURL URLWithString:action]];
   
}
@end
