//
//  Log.h
//  Alere
//
//  Created by virtusa on 12/06/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DeviceDelegate.h"
@interface Log : NSObject<DeviceDelegate>

@end
