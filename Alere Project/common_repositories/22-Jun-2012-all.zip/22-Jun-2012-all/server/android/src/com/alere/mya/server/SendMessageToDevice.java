package com.alere.mya.server;

import java.io.IOException;


public class SendMessageToDevice {
	public static final String USER = "alere.mya@gmail.com";
	
	public static final String PASSWORD = "MyaHealth22";
	public static final String AUTHENTICATION_TOKEN = "DQAAAMkAAAABOAk22tKHfZx9lOm_TYS821kE8QKSTYftqoIiHwyX0WS8KouMhS8yJbUWNJlVMWzhZGb1g8UI1_qvo0iqJcTUVZdmuKIfQCcGxsmg0lavtCnQSEl00-Ixbd4_GcHv6cek9vbci6-eooC0NOZQKSC1h5RHjENiDKbOc8v9DWLZfJuQEoG4qzk_PT9UoVS8JWQgzrnp8bgCGmOzd7D7sCLQHBWbqDKl2mzBNVaHG1zXtRGOsV6oIRhIsAzGaui7Cn3tw8M-XIsIpEPovyTie8Lo";
	
	//alere.mya@gmail.com
	public static final String AUTHENTICATION_TOKEN1 = "DQAAALYAAAAJoAwffpb7cYIR5RU4InyU7GAh-peCKOn0l45yrSNzber3A6u9W_kzP9nWh_RZnAngQI-pFq8Uz85rv3_3jW0VE4HMwXQXbYplRrahqJivu3KYFQ8aiGRCVDNq2QUUW4Iw7Htr11kF-4hKJhj-ooNGU4Kx1Hh0p02NTB-wIZfCjynNtjUrnVUIzO9J53nXcOactwzho4fX8mJaKVKYXrHpz7m8DNocqdsgpa6eWPxDmck_rCSC33esq5XtBy546U8";
	//Mark's phone
	//public static final String REGISTRATION_ID = "APA91bG85vdDUfV0hAd0VootZLtpyKVW4436Pk1A4_a7UjKlVGQZiVwzzRmyJ567USxljhhxhCy-qO3MWNynmYl1e9qnk8s7TKuzxgBwiBwWZ_gXH-a3bgz8vFem3OngTJpFzSl6QEzu0T8yumIBUkqAgMypIl0NOw";
	
	//Emulator
	public static final String REGISTRATION_ID = "APA91bGpQoYXIfWqTfAAYMJDgc8v3mgNGfMQ-i-n-gl5tCHkhef1as21JZrL9LctOr509e1USFSdevXBatZmrTIZVhv7f_l6SotZ7nKhs_IZJY1dBXr7qQJyjt9Hkp26xjRoeuovf0qxnRldrKpLJ5BfM15Px7ecfA";
	
	
	//Ameya's phone
	//public static final String REGISTRATION_ID = "APA91bHvCoFyerrmvuudl39sm3a7fS28FPLvJHlnsqjlGtm7PwQNH9yTPEupJ1MeyrX1ZaxaLY-Sp3g6DsMIlkW3bKmhA4UzOimxaPrrqFz4dRp_vjL-uxAQJSlsHTlhMatnX26U3E0lkaNLustRanE1inFjMAhpYw";
	
	
	//tablet
	//public static final String REGISTRATION_ID = "APA91bGc-0gQWtKohVNcXXb6f1m__YJWIp4aGAfeeQ_gV-gdmHxTt0v2vSCm7WxJ7VIAt08Z55tNpfwuvjRi9kGdvySVLW-UA-kMrnWwcbeMd2KUlGsW4Na9ZT99lCssjTdWw3RhkMBEnDGeLK-5fsXIKszwxT9Dng";

	public static void main(String[] args) throws IOException {
		// "Message to your device." is the message we will send to the Android app
		String authToken = AuthenticationUtil.getToken(USER, PASSWORD);
		//System.out.println("authToken == " + authToken);
		int responseCode = MessageUtil.sendMessage(
				authToken,
				REGISTRATION_ID, "You have 4 new messages");
		System.out.println(responseCode);
	}

}
