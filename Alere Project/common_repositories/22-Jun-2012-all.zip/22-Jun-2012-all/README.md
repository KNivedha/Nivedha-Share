mya-dev-all
===========

code for all supported platforms