/**
 * Controller : SettingsController
 * Controller to do logic of settings
 **/
mHealth.controllers.SettingsController = Spine.Controller.sub({
	el : 'body',
	hwarticleID : null,
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	deviceInfo : null,
	events : {
		'click #logoutId' : 'doLogout',
		'click #showAbout' : 'getFeatures',
		'click #sendFeedBack' : 'sendMail',
		'pagebeforeshow #aboutsDetail' : 'showDetail',
		'change #HeightUnit' : 'getHeightUnits',
		'change #WeightUnit' : 'getWeightUnits',
		'pagebeforeshow #settingsPage' : 'showSettings',
		'pageshow #settingsPage' : 'viewTabbar',
		'click #debugId' : 'debug',
		'click #measurementUnits' : 'setDocHeight'
	},
	
	/**
	 * Name    : viewTabbar
	 * Purpose : Method to viewTabbar
	 * Params  : --
	 * Return  : --
	 **/
	viewTabbar : function() {
		if (isAndroid ) {
		    Android.showTab();
		}
		else if(isIOS){
			mHealth.util.unloadChart();
			mHealth.util.showTabBar();
		} 
		else{
		//Browser Implementation	
		}
		
	},

	/**
	 * Name    : setDocHeight
	 * Purpose : Method to set document height to fix white strip.
	 * Params  : --
	 * Return  : --
	 **/
	setDocHeight : function() {

		$('#settingsPage').css({
			'height' : 'auto'
		});
		$('#settingsPage').trigger('create');
	},
	/**
	 * Name    : debug
	 * Purpose : Method to do Debug.
	 * Params  : --
	 * Return  : --
	 **/
	debug : function() {
		$.mobile.changePage('../../debug/view/debugindex.html');
	},
	/**
	 * Name    : doLogout
	 * Purpose : Method to do required actions while logout.
	 * Params  : --
	 * Return  : --
	 **/
	doLogout : function() {
		mHealth.util.customPrompt(mHealth.SettingsController.logoutConfirm, function() {
		}, function() {
			var splashMessage = mHealth.SettingsLogin.logout;
			mHealth.models.ConditionModel.destroyAll();
			mHealth.models.MessageModel.destroyAll();
			mHealth.models.MedicationModel.destroyAll();
			mHealth.models.ParticipantModel.destroyAll();
			mHealth.models.HealthDataModel.destroyAll();
			mHealth.models.FeatureGroupModel.destroyAll();
			mHealth.models.ChallengeResponseModel.destroyAll();
			mHealth.models.QuestionResponsesModel.destroyAll();
			$('#loginPage').detach();
			//Removing the different mobile.changepage to single statement for the all the platform 
			mHealth.util.splashMessage=splashMessage;
			$.mobile.changePage("../../rootview/view/login.html");
			mHealth.util.removeNativeBar();
			mHealth.MessageControllerObject.tabbarloaded = false;
		});
	},
	/**
	 * Name    : getHeightUnits
	 * Purpose : Method to get the selected value of height units field on change of the select menu
	 * Params  : --
	 * Return  : --
	 **/
	getHeightUnits : function() {
		mHealth.util.selUnits = $('select#HeightUnit option:selected').val();
	},
	/**
	 * Name:WeightUnits
	 *Purpose:Method to get the selected value of weight units field
	 on change of the select menu
	 **/

	getWeightUnits : function() {
		mHealth.util.selWeightUnits = $('select#WeightUnit option:selected').val();
	},
	/**
	 * Name    : showSettings
	 * Purpose : Method to render the selected value of height units field on load of the page
	 * Params  : --
	 * Return  : --
	 **/
	showSettings : function() {
		var hasDebug=false;
		var response = mHealth.models.FeatureGroupModel.findByAttribute("groupId", "misc");
		
		if ( typeof response.feature != "undefined" && response.feature != "") {
			var length = response.feature.length
			for(var i = 0; i < length; i++) {
				if(response.feature[i].id != undefined) {
					if(response.feature[i].id == 'debug') {
						hasDebug = true;
						break;
					}
				}
			}
		}
	
		$('#debug').html(_.template($('#debug_script').html(), {
			hasDebug : hasDebug
		}));
		$('#settingsPage').trigger('create');

		if(mHealth.util.selUnits == 'cm') {
			$("select#HeightUnit option[value='cm']").attr("selected", "selected");
			$('select').selectmenu('refresh');
		}
		if(mHealth.util.selWeightUnits == 'Kg') {
			$("select#WeightUnit option[value='Kg']").attr("selected", "selected");
			$('select').selectmenu('refresh');
		}

	},
	/**
	 * Name    : showDetail
	 * Purpose : Method to render the values of device details
	 * Params  : --
	 * Return  : settingsDetail, deviceInfo
	 **/
	showDetail : function() {
		var settingsDetail;
		settingsDetail = mHealth.SettingsAbout;
		$('#settingsHeader').html(_.template($('#headerScript').html(), {
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').html(_.template($('#deviceDetails').html(), {
			deviceInfo : deviceInfo,
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').trigger('create');
		$('#settingsHeader').trigger('create');

	},
	/**
	 * Name    : getFeatures
	 * Purpose : Method to call the webview to get Device Features
	 * Params  : --
	 * Return  : --
	 **/
	getFeatures : function() {
		mHealth.util.getDeviceFeatures(); // This Method is define in Native Bridge
		$.mobile.changePage("about.html");
	},
	/**
	 * Name    : sendMail
	 * Purpose : Method to call the webview to call native email
	 * Params  : --
	 * Return  : --
	 **/
	sendMail : function() {
		mHealth.util.sendEmail(mHealth.env.emailTo, mHealth.env.emailCC, mHealth.env.emailSubject);
	}
});

mHealth.controllers.SettingsController.extend({
	/**
	 * Name    : getDeviceGlobalSettings
	 * Purpose : Method to call from webview to get device features
	 * Params  : --
	 * Return  : --
	 * Comments: This method is been called from nativeBridge getDeviceInfo()
	 **/
		getDeviceGlobalSettings : function( osId,osVersion,deviceMake,deviceModel,deviceId, deviceToken,deviceName,appName) {  
			mHealth.util.logMessage('getDeviceGlobalSettings in settingscontroller');
			mHealth.util.osId 	     = osId;
		 	mHealth.util.osVersion 	 = osVersion;
		 	mHealth.util.devMake 	 = deviceMake; 
		 	mHealth.util.devModel 	 = deviceModel;
	        mHealth.util.devCustId 	 = deviceId; 
	        mHealth.util.devicetoken = deviceToken;
	        mHealth.util.deviceName  = deviceName; 
	        mHealth.util.appName 	 = appName;
	        mHealth.util.appVersion  = appName;
	        
		 	if(isIOS){
	        	mHealth.util.platform = 'Apple';
	        }else if(isAndroid){
	        	mHealth.util.platform = 'Android';
	        }else{
	        	mHealth.util.platform = 'Browser';
	        }
	       // TODO CLEAN UP THE FOLLOWING OBJECT LOTS OF UNWANTED
	        deviceInfo = [{
	        	'osId' 		    : mHealth.util.osId,
	        	'osVersion' 	: mHealth.util.osVersion,
	        	'deviceMake'	: mHealth.util.devMake,
	        	'deviceModel'	: mHealth.util.devModel,
	        	'deviceId' 		: mHealth.util.udid,
	        	'deviceTokenId' : mHealth.util.devicetoken,
				'deviceName' 	: mHealth.util.deviceName,//device specific name - Setting/General/About/Name
				'appName' 		: mHealth.util.appName,
				'regUser' 		: mHealth.util.participantEmail,
                'appVersion' 	: mHealth.util.appName,
				'devCustId' 	: mHealth.util.devCustId,     //Custom ID, combo as deviceName+osName
	            'platform' 		: mHealth.util.platform
			}];
		}	
});