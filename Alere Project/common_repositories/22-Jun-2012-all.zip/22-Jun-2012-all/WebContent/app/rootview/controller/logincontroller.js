/**
 *Controller : LoginController
 *Controller to do login functionality.
 **/
mHealth.controllers.LoginController = Spine.Controller.sub({
	el : 'body',
	environment : null,
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		// 'click #loginbutton' : 'validateLogin',
		'click #loginbutton' : 'doLogin',
		'submit #login-form' : 'onSubmit',
		'click #debugToggle' : 'toggleDebugOptions',
		'click #sendMail' : 'sendEmail',
        'pageshow div[data-role="page"]' : 'setPrevLogin',
        'pageshow #loginPage' : 'callDeviceFeatures',
		'click #contactEmail' : 'sendContactMail',
		'click #mailToCreig' : 'mailToCreig',
		'click #clientAccessButton' : 'clientRegistration',
		'pagebeforeshow div[data-role="page"]' : 'setDocumentHeight',
		'pagebeforeshow #home' : 'setHomeShortcuts',
		'click #showDebug' : 'showDebugPage',
		'click #callNurseId' : 'callNursePrompt'
	},
	
	/**
	 *Name    : callDeviceFeatures
	 *Purpose : Method to call getDeviceFeatures
	 *Params  : --
	 *Return  : --
	 **/
	callDeviceFeatures : function() {
		mHealth.util.logMessage('callDeviceFeatures method called');
		mHealth.util.getDeviceFeatures();
	},
	
	/**
	 *Name    : toggleDebugOptions
	 *Purpose : Method to toggle debug options
	 *Params  : --
	 *Return  : --
	 **/
	toggleDebugOptions : function() {
		mHealth.util.logMessage('Debug Button has been clicked');
		if(!($('#loginDiv').css('display') == 'none')) {
			$("#debug-options").slideToggle("slow", "linear", function() {
				$('#loginPage').css({
					'height' : 'auto'
				});
				$('#loginPage').trigger('create');
				$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');

			});
		}
	},
	/**
	 *Name    : setHomeShortcuts
	 *Purpose : Method to set shortcuts in home
	 *Params  : --
	 *Return  : --
	 **/
	setHomeShortcuts : function() {
		if(mHealth.util.messageCenter==true)
		{
			$('#messagesPanel').show();
			$('#home').css({
				'height' : 'auto'
			});
		}else
		{
			$('#messagesPanel').hide();
			$('#home').css({
				'height' : 'auto'
			});
		}
        $('#showHomeShortcut').html(_.template($('#homeScript').html(), {
			homeFeature : mHealth.util.homeFeatures
            
		}));
		$('#showHomeShortcut').trigger('create');
		$('#home').css({
				'height' : 'auto'
			});

	},
	/**
	 *Name    : showDebugPage
	 *Purpose : Method to show debug page
	 *Params  : --
	 *Return  : --
	 **/
	showDebugPage : function() {
		$.mobile.changePage('../../debug/view/debugindex.html');
	},
	/**
	 *Name    : setDocumentHeight
	 *Purpose : Method to set the document height dynamically to avoid white strip.
	 *Params  : --
	 *Return  : --
	 **/
	setDocumentHeight : function() {
		if(isAndroid || isIOS) {
			$('.ui-footer').hide();
		} else {
			$('.ui-footer').show();
			$('.globalFooter').attr('data-position', 'fixed');
			$('.globalFooter').addClass('ui-footer-fixed fade ui-fixed-overlay');
			$('.globalFooter').trigger('create');
			$('.globalFooter').trigger('updatelayout');
		}

		$('div[data-role="page"]').css({
			'height' : document.height
		});

		$('div[data-role="page"]').trigger('create');

	},
	/**
	 *Name    : callNursePrompt
	 *Purpose : Method to alert the custom prompt for calling nurse.
	 *Params  : --
	 *Return  : --
	 **/
	callNursePrompt : function() {
		mHealth.util.logMessage('Call Nurse has been prompt');
		mHealth.util.callNursecustomPrompt(mHealth.GuiHelper.callNurseAlert, mHealth.HomeFeatures.call_nurse_number, function() {
			mHealth.util.callNurse();
		}, function() {
		});
	},
	/**
	 *Name    : clientRegistration
	 *Purpose : Method to register a new user.
	 *Params  : --
	 *Return  : --
	 **/
	clientRegistration : function() {
		environment = $('select#server option:selected').val();
		if(environment == undefined) {// if this is undefined select the enviroment from Config
			environment = mHealth.environment;
		}
		mHealth.util.setEnvironment(environment);
		var clientAcess = $('#clientAccess').val().trim();
		//Current using mHealth.uat as we get undefined
		var registrationURL = mHealth.env.registration_url + '?keycode=' + clientAcess;
		//URL DEFINED IN config.js
        //FOR IOS WE REQUIRE openurl://external?url= which is defined in config and we are prefixing overe here
        if(isIOS) {
       	  window.open(mHealth.IOSURL+registrationURL, '_blank');
		} else if(isAndroid) {
			Android.openHref(registrationURL);
		}
        mHealth.util.logMessage('Client Registration has been clicked');
	},
	/**
	 *Name    : validateLogin
	 *Purpose : Method to validate login credentials.
	 *Params  : --
	 *Return  : --
	 **/
	validateLogin : function() {

		var username = $('#username').val().trim();
		var password = $('#password').val().trim();
		if((username == '') || (password == '')) {
			$('#username').val("");
			$('#password').val("");
			$('#errorMessage').html(mHealth.Login.msgEmptyField);
			$('#errorMessage').show();
			$('#loginPage').css({
				'height' : 'auto'
			});
			mHealth.util.logMessage('Login validation failed');
			$('#loginPage').trigger('create');
		}
		mHealth.util.logMessage('Login validation Success');
	},
	/**
	 *Name    : mailToCreig
	 *Purpose : Method to Send email to the Craig.Apolinsky of the Alere
	 *Params  : --
	 *Return  : --
	 **/
	mailToCreig : function() {
		mHealth.util.logMessage('Sending mail to Craig');
		mHealth.util.sendEmail('Craig.Apolinsky@alere.com', '');
	}, 
	/**
	 *Name    : sendContactMail
	 *Purpose : Method to Send email to the corp feedback of the Alere
	 *Params  : --
	 *Return  : --
	 **/
	sendContactMail : function() {
		mHealth.util.logMessage('Sending mail to corpfeedback');
		mHealth.util.sendEmail('Corpfeedback@alere.com', '');
	},
	/**
	 *Name   : setPrevLogin
	 *Purpose: Method to set the previous User Id and Setting the splash message.
	 *Params : --
	 *Return : --
	 **/
	setPrevLogin : function() {
		mHealth.util.logMessage('Page Before show of the current page');
		if($('.ui-page-active').attr('id') == "loginPage") {
			$('#loginPage').css({
				'height' : 'auto'
			});
			var rememberMe = mHealth.models.RememberMeModel.first();
			if(rememberMe != undefined) {
				$('#username').val(rememberMe.username);
                 if(rememberMe.flag) {
                    var decryptedPassword = $.base64Decode(rememberMe.password);
                    $('#password').val(decryptedPassword); 
                    $('#checkbox-mini-0').attr('checked',true);
                    $('input:checkbox').checkboxradio('refresh');
                 }
			}
                                             
			var activePage = $('.ui-page-active').attr('data-url');
			var splashMessage = mHealth.util.splashMessage;
			if(splashMessage !== null) {

				$('#errorMessage').text(splashMessage);
			}

			if($('#username').val().length > 0) {
				$('#loginDiv').show();
			}
			
			
			$('#loginFormButton').click(function() {
				$('#loginDiv').show();
				$('#loginFormButtondiv').hide();
				$('#clientAccessFormButtondiv').show();
				$('#registerDiv').hide();
				$('#donthaveanAccountDiv').show();
				$('#dregisterbuttonDiv').hide();
				$('#registerbuttonDiv').hide();
				$('#clientAccess').val(null);
				// This is for resetting the Client Access Code textbox
				$('#clientAccessDiv').hide();

				$('#loginPage').css({
					'height' : 'auto'
				});
				$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
			});

			$('#clientAccessFormButton').click(function() {
				$('#loginDiv').hide();
				$('#loginFormButtondiv').show();
				$('#clientAccessDiv').show();
				$('#registerbuttonDiv').show();
				$('#registerDiv').show();
				$('#donthaveanAccountDiv').hide();
				$('#clientAccessFormButtondiv').hide();
				$('#errorMessage').hide();
				$('#loginPage').css({
					'height' : 'auto'
				});
				$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
			});
			// This is for Displaying the Register Button when we enter some data in the Client Acess Code
			//		$('#clientAccess').keyup(function() {
			//			if($('#clientAccess').val().length > 0) {
			//				$('#registerbuttonDiv').show();
			//			}else{
			//				$('#registerbuttonDiv').hide();
			//			}
			//		});

			// This is for enabling the DIV for login
			$('#clientAccessButton').click(function() {
				$('#loginDiv').show();
				$('#loginFormButtondiv').show();
				$('#dregisterbuttonDiv').hide();
				$('#registerbuttonDiv').hide();
				$('#registerDiv').hide();
				$('#clientAccessDiv').hide();
				//$('#clientAccess').val(null); // This is for resetting the Client Access Code textbox
				$('#clientAccessFormButtondiv').show();
				$('#donthaveanAccountDiv').show();
				$('#loginFormButtondiv').hide();
				$('#errorMessage').hide();

			});
			$('#loginPage').trigger('create');

		} else {

			$('div[data-role="page"]').css({
				'height' : document.height
			});

			$('div[data-role="page"]').trigger('create');
		}
	},
	/**
	 *Name   : sendEmail
	 *Purpose: Method to send email.
	 *Params : --
	 *Return : --
	 **/
	sendEmail : function() {
		mHealth.util.logMessage('Sending Email');
		var subject = "";
		if(mHealth.SettingsLogin.emailSubject != undefined) {
			subject = mHealth.SettingsLogin.emailSubject;
		}
		mHealth.util.sendEmail(mHealth.SettingsLogin.email, '', subject);
	},
	/**
	 *Name   : loginSuccess
	 *Purpose: Success callback to authenticate user.
	 *Params : output - response from the server
	 *Return : --
	 **/
	loginSuccess : function(output) {
		mHealth.util.logMessage('Login Success');
        if(isIOS){
            mHealth.delay =0;
           }else if(isAndroid){
            mHealth.delay =500; //Time in ms
           }else{
           // For Browser                                                   
           }
		// Get features
		this.proxy(this.service.getSyncResponse(mHealth.env.mobile_app_config_url, this.proxy(this.featureListSuccess), this.proxy(this.featureListFailure), false));
		// URL for Profile
		this.proxy(this.service.getResponse(mHealth.env.profile_url, this.proxy(this.participantSuccess), null, false));
		
		// URL for Messages
		// Call Message header service only if the msg-centre exists in home-screen and tab
		if(mHealth.util.messageCenter){
		this.proxy(this.service.getSyncResponse(mHealth.env.messageheaders_url, mHealth.MessageControllerObject.messageSuccess, mHealth.MessageControllerObject.showHome, true));
		}
		else
			mHealth.MessageControllerObject.showHome();
	},
	/**
	 * Name    : featureListFailure
	 * Purpose : Get list of enabled features for the user
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	featureListFailure : function(output) {
		mHealth.util.logMessage('App Configuration failed');
		// Hard coded configuration
		var appConfig = [ { "mobileAppFeaturesConfig":{ "featureGroup":[ { "groupId":"home-screen" }, { "groupId":"tabs" }, 
		{ "groupId":"trackers" }, { "groupId":"misc" }, { "groupId":"standard" } ] } } ];
		/*var appConfig =[{ 
			"mobileAppFeaturesConfig":
			{ "featureGroup":[ 
			{"groupId":"home-screen", 
				"feature":[ { "id":"msg-center", "intraGroupRank":100 }, 
				{ "id":"profile", "intraGroupRank":950 },
				{ "id":"med-history", "intraGroupRank":900 }, 
				{ "id":"call-nurse", "intraGroupRank":800 }, 
				{ "id":"tracker-bg", "intraGroupRank":750 } ] }, 
			{ "groupId":"tabs", 
				"feature":[ { "id":"msg-center", "intraGroupRank":900 }, 
				{ "id":"trackers", "intraGroupRank":700 } ] }, 
			{ "groupId":"trackers", 
			"feature":[ { "id":"tracker-bg", "intraGroupRank":900 }, 
			{ "id":"tracker-wtbmi", "intraGroupRank":850 }, 
			{ "id":"tracker-bp", "intraGroupRank":800 }, 
			{ "id":"tracker-a1c", "intraGroupRank":750 }, 
			{ "id":"tracker-cholesterol", "intraGroupRank":700 }, 
			{ "id":"tracker-exam-mau", "intraGroupRank":650 },
			 { "id":"tracker-exam-dre", "intraGroupRank":600 }, 
			 { "id":"tracker-exam-footsores", "intraGroupRank":550 }, 
			 { "id":"tracker-exam-foot-provider", "intraGroupRank":500 } ] }, 
		{ "groupId":"misc", 
		"feature":[ { "id":"debug", "intraGroupRank":1000 } ] }, 
		
		{ "groupId":"standard", "feature":[ { "id":"msg-center", "intraGroupRank":100 },
		 { "id":"profile", "intraGroupRank":950 }, { "id":"med-history", "intraGroupRank":900 },
		  { "id":"call-nurse", "intraGroupRank":800 }, { "id":"tracker-bg", "intraGroupRank":750 } ] } ] } } ];
		  */
		this.buildFeatureList(appConfig);
	},
	/**
	 * Name    : buildFeatureList
	 * Purpose : Biuld list of enabled features for the user
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	buildFeatureList : function(appConfig) {
		mHealth.util.logMessage('building the app configuration');
		var length = appConfig[0].mobileAppFeaturesConfig.featureGroup.length;
		mHealth.models.FeatureGroupModel.destroyAll();
		for(var i = 0; i < length; i++) {
			mHealth.models.FeatureGroupModel.customFromJSON(appConfig[0].mobileAppFeaturesConfig.featureGroup[i]);
		}
		var homeFeature = mHealth.models.FeatureGroupModel.findByAttribute('groupId', 'home-screen');
		var tabFeature = mHealth.models.FeatureGroupModel.findByAttribute('groupId', 'tabs');
		if(homeFeature.feature!=undefined || homeFeature.feature!=null) {
		var homeFeatureLength = homeFeature.feature.length;
		var homeFeatures = [];
		for(var i = 0; i < homeFeatureLength; i++) {
			if(homeFeature.feature[i].id != 'debug' && homeFeature.feature[i].id != 'msg-center') {
				homeFeatures.push(homeFeature.feature[i]);
				//homeFeatures.splice(i, 1);
			}
			if(homeFeature.feature[i].id == 'call_nurse' && homeFeature.feature[i].phone != null) {
				mHealth.HomeFeatures.call_nurse_number = homeFeature.feature[i].phone;
			}
			if(homeFeature.feature[i].id == 'msg-center')
			{
				mHealth.util.messageCenter=true;	
			}	
		}
		}
		if(tabFeature.feature!=null ||tabFeature.feature!=undefined){
		for(var i = 0; i < tabFeature.feature.length; i++) {
			if(tabFeature.feature[i].id == 'msg-center') {
				mHealth.util.messageCenter=true;	
			}			
		}
		}
		//msg-center
		//Removing the logic to display the trackers with highest rank on home screen
		// if(homeFeatureLength < 5) {
			// var sortData = mHealth.util.getSortData(trackerFeature.feature);
			// for(var j = 0; j < trackerFeatureLength; j++) {
				// //if(trackerFeatureLength)
				// if(j == 2) {// this is for displaying only 2 trackers on the home screen as it can accomodate 6 icons only (Profile,Med,Challenge,Call Nurse are the default 4 icons
					// break;
				// }
				// homeFeatures.push(sortData[j]);
			// }
		// }
		mHealth.util.homeFeatures = homeFeatures;

	},
	/**
	 * Name    : featureListSuccess
	 * Purpose : Get list of enabled features for the user
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	featureListSuccess : function(output) {
		mHealth.util.logMessage('app configuration Success');
		var appConfig = output.responseText;
		if(appConfig != '') {
			this.buildFeatureList(JSON.parse(output.responseText));
		} else {
			this.featureListFailure();
		}
	},
	/**
	 * Name    : participantSuccess
	 * Purpose : Success callback for getting participant data.
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	participantSuccess : function(output) {
		mHealth.util.logMessage('Success Get the participant value');
		var response = output.responseText;
		mHealth.models.ParticipantModel.customFromJSON(response);
	},
	/**
	 *Name   : loginFailure
	 *Purpose: Failure callback to authenticate user.
	 *Params : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server.
	 *Return : Displays error message.
	 **/
	loginFailure : function(errorThrown) {
		mHealth.util.logMessage('Login Failure');
		var splashMessage = null;
		if(errorThrown == mHealth.SettingsController.timeOut) {
			splashMessage = mHealth.SettingsController.errTimeout;
		} else if(errorThrown == mHealth.SettingsController.unauthorized) {
			splashMessage = mHealth.Login.msgEmptyField;
		} else {
			splashMessage = mHealth.SettingsController.msgErrorCommunication;
		}
		
		mHealth.util.splashMessage=splashMessage;
		
		$('#loginPage').detach();
		
		$.mobile.changePage("../../rootview/view/login.html");

	},
	
	onSubmit : function(event)
	{
		if(isAndroid){
		 event.preventDefault();
		}
		this.doLogin();
	},
	/**
	 *Name   : doLogin
	 *Purpose: Method to encode user credential to base64 encoding.
	 *Params : --
	 *Return : --
	 **/
	doLogin : function() {
		mHealth.util.logMessage('Login button Clicked');
		this.validateLogin();
		var username = $('#username').val();
		var password = $('#password').val(); 
        var encryptedPassword = $.base64Encode(password);
        var decryptedPassword = $.base64Decode(encryptedPassword);
        //var rememberPasswordFlag =  $('#checkbox-mini-0').attr('checked'); 
        var rememberPasswordFlag =  $('#checkbox-mini-0').is(':checked'); 
		if((username != '') && (password != '')) {
			$.mobile.changePage("../../rootview/view/wait.html");
			environment = $('select#server option:selected').val();
			mHealth.util.setEnvironment(environment);
			// var mobileConfigUrl = mHealth.env.mobile_app_config_url;
			// this.proxy(this.service.getResponse(mobileConfigUrl, this.proxy(this.configSuccess),this.proxy(this.configFailure),true));
			mHealth.util.participantEmail = username;
			mHealth.models.RememberMeModel.destroyAll();
            var rememberMe;
            if(rememberPasswordFlag){
                rememberMe = new mHealth.models.RememberMeModel({
                "username" : username,
                "password" : encryptedPassword,
                "flag"     : true,
               });
            }else{
			  rememberMe = new mHealth.models.RememberMeModel({
				"username" : username,
                "flag"     : false,
			  });
            }
			rememberMe.save();
                                                           
//            var rememberMe1 = mHealth.models.RememberMeModel.first();
//            if(rememberMe1 != undefined) {
//                alert("rememberMe1 Flag"+rememberMe1.flag); 
//                alert("USER NAME"+rememberMe1.username+"PASSWORD "+rememberMe1.password);
//            }

			var credentials = $.base64Encode(username + ":" + password);
			
			if(isIOS){
				//mHealth.util.getDeviceFeatures();
				// makes vars avail in dom

				//Get values from DOM to pass to the getToken
				var osVersion = (mHealth.util.osVersion == undefined) ? "1.0" : mHealth.util.osVersion;
				var deviceName = (mHealth.util.deviceName == undefined) ? "NA" : mHealth.util.deviceName;
//                var osName = (mHealth.util.osName == undefined) ? "NA" : mHealth.util.osName;
                var osId = (mHealth.util.osId == undefined) ? "NA" : mHealth.util.osId;
				var devMake = (mHealth.util.devMake == undefined) ? "NA" : mHealth.util.devMake;
				var devModel = (mHealth.util.devModel == undefined) ? "NA" : mHealth.util.devModel;
				var devCustomId = (mHealth.util.devCustId == undefined) ? "NA" : mHealth.util.devCustId;
				var devicetoken = (mHealth.util.devicetoken == undefined) ? "NA" : mHealth.util.devicetoken;
				var appName = (mHealth.util.appName == undefined) ? "NA" : mHealth.util.appName;
				var appVersion = (mHealth.util.appVersion == undefined) ? "NA" : mHealth.util.appVersion;
				var appReleasedVer = (mHealth.util.appReleasedVer == undefined) ? "NA" : mHealth.util.appReleasedVer;
				
				//this.service.getNewToken(mHealth.env.authtoken_get_url,
				// <TODO> Scope for optimization AGT
				this.service.getToken(mHealth.env.authtoken_get_url,
						credentials,
						devicetoken,
						osVersion,
						deviceName,
						osId,
						devMake,
						devModel,
						devCustomId,
						appName,
						appVersion, 
						appReleasedVer,
						this.proxy(this.loginSuccess), this.proxy(this.loginFailure));
				
				
				
			}else if(isAndroid){
				//Get values from DOM to pass to the getToken
				//mHealth.util.getDeviceFeatures();
		           var osVersion =  mHealth.util.osVersion;
		           var deviceName = mHealth.util.deviceName;
//                   var osName = mHealth.util.osName;
                   var osId = mHealth.util.osId;
		           var devMake = mHealth.util.devMake;
		           var devModel = mHealth.util.devModel;
		           var devCustomId = mHealth.util.devCustId;
		           var devicetoken = mHealth.util.devicetoken;                                        
		           
		           this.service.getToken(mHealth.env.authtoken_get_url,
		        		   credentials,
		        		   devicetoken,
		        		   osVersion,
		        		   deviceName,
		        		   osId,
		        		   devMake,
		        		   devModel,
		        		   devCustomId,
		        		   "NA","NA","NA",
		        		   this.proxy(this.loginSuccess), this.proxy(this.loginFailure));                                            

			}
			else{
			  //Service Call for Browser
				this.service.getToken(mHealth.env.authtoken_get_url,credentials,"NA","NA","NA","NA","NA","NA","NA", "NA","NA","NA",this.proxy(this.loginSuccess), this.proxy(this.loginFailure));  
			}

		} else {
			$('errorMessage').html(mHealth.Login.msgEmptyField);
			$('#loginPage').css({
				'height' : 'auto'
			});
			$('#loginPage').trigger('create');
		}

	}
});
