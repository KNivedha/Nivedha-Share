/**
 * Native Functions
 **/

/**
 * Name : removeMask Purpose : Method to call the native removeMask url Params : --
 * Returns : --
 */
mHealth.util.removeMask = function() {
	mHealth.util.logMessage('remove mask called');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("tabbar://removeMask?");
	} else {
		// code to work on a browser
	}

};

/**
 * Name : logMessage Purpose : Method to call the Log Message Returns : --
 */
mHealth.util.logMessage = function(message) {
	if (isAndroid) {
		Android.logMessage(message);
	} else if (isIOS) {
		nativeCommunication.callNativeMethod("log://logMessage?message=" + message);
	} else {
		// code to work on a browser
		console.log(message);
	}

};

/**
 * Name : addMask Purpose : Method to call the native addMask url Params : --
 * Returns : --
 */
mHealth.util.addMask = function() {
	mHealth.util.logMessage('add mask called');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("tabbar://addMask?");
		$("input:focus, textarea:focus, select:focus").blur();
	} else {
		// code to work on a browser
	}

};

/**
 * Name : hideTabBar Purpose : Method to call the native hide tab bar url Params : --
 * Returns : --
 */
mHealth.util.hideTabBar = function() {
	mHealth.util.logMessage('Hide tab bar called');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("tabbar://hideTabBar?");
	} else {
		// code to work on a browser
	}

};

/**
 * Name : showTabBar Purpose : Method to call the native show tab bar url Params : --
 * Returns : --
 */
mHealth.util.showTabBar = function() {
	mHealth.util.logMessage('Show tabbar called');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("tabbar://showTabBar?");
	} else {
		// code to work on a browser
	}
};

/**
 * Name : unloadChart Purpose : Method to call the native unload chart url
 * Params : -- Returns : --
 */
mHealth.util.unloadChart = function() {
	mHealth.util.logMessage('unloadChart called');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("gyro://unLoadChart?");
	} else {
		// code to work on a browser
	}
};

/**
 * Name : loadChart Purpose : Method to call the native load chart url Params : --
 * Returns : --
 */
mHealth.util.loadChart = function() {
	mHealth.util.logMessage('loadChart called');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("gyro://loadChart?");
	} else {
		// code to work on a browser
	}
};

/**
 * Name : getCurrentOrientation Purpose : Method to call the native current
 * orientation url Params : -- Returns : --
 */
mHealth.util.getCurrentOrientation = function() {
	mHealth.util.logMessage('getCurrentOrientation called');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("gyro://getCurrentOrientation?");
	} else {
		// code to work on a browser
	}
};
/**
 * Name : getCurrentConditionOrientation Purpose : Method to call the native
 * current orientation url in medical condition page Params : -- Returns : --
 */
mHealth.util.getCurrentConditionOrientation = function() {
	mHealth.util.logMessage('getCurrentConditionOrientation called');
	if (isAndroid || isIOS) {
		nativeCommunication
				.callNativeMethod("gyro://getCurrentConditionOrientation?");
	} else {
		// code to work on a browser
	}
};

/**
 * Name : callNurse Purpose : Method to make a call to nurse Params : -- Returns : --
 */
mHealth.util.callNurse = function() {
	mHealth.util.logMessage('call Nurse called');
	if (isAndroid) {
		nativeCommunication.callNativeMethod("tel://"
				+ mHealth.HomeFeatures.call_nurse_number);
	} else if (isIOS) {
		nativeCommunication.callNativeMethod("tel://callNumber?number="
				+ mHealth.HomeFeatures.call_nurse_number);

	} else {
		// code to work on a browser
	}
};

/**
 * Name : forceQuit Purpose : Method to call the native force quit url Params : --
 * Returns : --
 */
mHealth.util.forceQuit = function() {
	mHealth.util.logMessage('application force quitted');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("forcequit://Accepted?");
	} else {
		// code to work on a browser
	}
};

/**
 * Name : setCalendarEvent Purpose : Method to call the native calendar Params :
 * Start Date, End Date, Title Returns : dateString
 */
mHealth.util.callCalendar = function(title, sDate, eDate) {
	mHealth.util.logMessage('Calendar has been called');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("cal://setEvent?eventTitle="
				+ title + "&startDate=" + sDate + "&endDate=" + eDate);
	} else {
		// code to work on a browser
	}
};
/**
 * Name : sendEmail Purpose: Method to send email. Params : -- Return : --
 */
mHealth.util.sendEmail = function(to, toCopy, subject) {
	mHealth.util.logMessage('Sending email');
	if (isIOS) {
		if (toCopy == '' || toCopy == null) {
			nativeCommunication.callNativeMethod("email://sendEmail?mailto="
					+ to + "?subject=" + subject);
		} else {
			nativeCommunication.callNativeMethod("email://sendEmail?mailto="
					+ to + "&cc=" + toCopy + "&subject=" + subject);
		}
		$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
	}
	else if(isAndroid){
			if (toCopy == '' || toCopy == null) {
			nativeCommunication.callNativeMethod("email://sendEmail?mailto:"
					+ to + "?subject=" + subject);
		} else {
			nativeCommunication.callNativeMethod("email://sendEmail?mailto:"
					+ to + "&cc=" + toCopy + "&subject=" + subject);
		}
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
	}
	else {
		// code to work on a browser
	}
};
/**
 * Name : callNativeBarEvent Purpose: Method to call native bars on login Params : --
 * Return : --
 */
mHealth.util.callNativeBar = function() {
	mHealth.util.logMessage('Setting the native tab bar');
	var tabs = "tab0=Home";
	var count = 1;
	var hasTab = mHealth.models.FeatureGroupModel.findByAttribute("groupId", "tabs");
	if(hasTab.feature!=undefined || hasTab.feature!=null){
	var length = hasTab.feature.length

  // check if messages is configured &include Messages tab
	for ( var i = 0; i <= length; i++) {
		if (hasTab.feature[i] != undefined
				&& hasTab.feature[i].id == 'msg-center') {
			tabs = tabs + '&tab' + count + '=Messages';
			count = count + 1;
			break;
		}
	}

	
	// check if challenges is configured and include it in tab
	for ( var i = 0; i <= length; i++) {
		if (hasTab.feature[i] != undefined
				&& hasTab.feature[i].id == 'challenges') {
			tabs = tabs + '&tab' + count + '=Challenges';
			count = count + 1;
			break;
		}
	}

	// check if trackers length is greater than 0
	for ( var i = 0; i <= length; i++) {
		if (hasTab.feature[i] != undefined
				&& hasTab.feature[i].id == 'trackers') {
			tabs = tabs + '&tab' + count + '=Trackers';
			count = count + 1;
			break;
		}
	}
	}
	tabs = tabs + '&tab' + count + '=Settings';
	if (isAndroid || isIOS) {

		nativeCommunication.callNativeMethod("tabbar://login?" + tabs);
	} else {
		// code to work on a browser
	}
};
/**
 * Name : removeNativeBarEvent Purpose: Method to remove native bars on logout
 * Params : -- Return : --
 */
mHealth.util.removeNativeBar = function() {
	mHealth.util.logMessage('Application Logout');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("tabbar://logout?");
	} else {
		// code to work on a browser
	}
};
/**
 * Name : getDeviceFeatures Purpose: Method to get the device feature like
 * version,device id,... Params : -- Return : Device features like
 * version,device id,...
 */
mHealth.util.getDeviceFeatures = function() {
	mHealth.util.logMessage('get the Device features');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("about://getdevicefeatures?");
	} else {
		mHealth.controllers.SettingsController.getDeviceGlobalSettings(
				'osVersion', 'deviceName', 'osId', 'devMake', 'devModel',
				'devCustomId', 'devicetoken', 'appName', 'appVersion',
				'appReleasedVer');
		// code to work on a browser
	}
};

mHealth.util.loadTrackerbar = function() {
	mHealth.util.logMessage('Load the Tracker Page');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("tabbar://Trackers?");
	} else {
		// code to work on a browser
	}
}
/**
 * Name : loadHomeBar Purpose: Method to hightlight home tab Params : -- Return : --
 */
mHealth.util.loadHomeBar = function() {
	mHealth.util.logMessage('load the Home Page');
	if (isAndroid) {
		nativeCommunication.callNativeMethod("tabbar://loadHome?");
	} else if (isIOS) {
		nativeCommunication.callNativeMethod("tabbar://Home?");

	} else {
		// code to work on a browser
	}
};

mHealth.util.loadChallengesBar = function() {
	mHealth.util.logMessage('Load the Challenges Page');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("tabbar://Challenges?");
	} else {
		// code to work on a browser
	}
};
/**
 * Name : loadMessageBar Purpose: Method to hightlight Message tab Params : --
 * Return : --
 */
mHealth.util.loadMessagesBar = function() {
	mHealth.util.logMessage('Load the Message Page');
	if (isAndroid || isIOS) {
		nativeCommunication.callNativeMethod("tabbar://Messages?");
	} else {
		// code to work on a browser
	}
};
/**
 * Call back of native functions
 */

/**
 * Name : loadHome Purpose: Callback method of native tabbar Params : -- Return : --
 */
loadHome = function() {
	mHealth.util.logMessage('redirected to the Home page');
	$('.dw').detach();
	$('.dwo').detach();
	$("#conditionName").autocomplete("close").focus();
	$.mobile.changePage("../../home/view/home.html");
};
/**
 * Name : loadActivities Purpose: Method to call Activities web view on clicking
 * the activities tab Params : -- Return : --
 */
loadActivities = function() {
	mHealth.util.logMessage('redirected to the Challenges page');
	$('.dw').detach();
	$('.dwo').detach();

	$("#conditionName").autocomplete("close").focus();
	mHealth.util.loadChallengesBar();
	mHealth.ActivityControllerObject.getActivity();
	// $.mobile.changePage("../../activities/view/showactivity.html");

};
/**
 * Name : loadMessages Purpose: Method to call Messages web view on clicking the
 * messages tab Params : -- Return : --
 */
loadMessages = function() {
	mHealth.util.logMessage('redirected to the Messages page');
	$('.dw').detach();
	$('.dwo').detach();
	$("#conditionName").autocomplete("close").focus();
	// $.mobile.changePage("../../messages/view/showmessage.html");
	mHealth.MessageControllerObject.loadMessageTabBar();
};
/**
 * Name : loadTrackers Purpose: Method to call trackers web view on clicking the
 * trackers tab Params : -- Return : --
 */
loadTrackers = function() {
	mHealth.util.logMessage('redirected to the Trackers page');
	$('.dw').detach();
	$('.dwo').detach();
	$("#conditionName").autocomplete("close").focus();
	mHealth.HealthDataControllerObject.getTrackers();
	// $.mobile.changePage("../../trackers/view/showtracker.html");
};
sessionExpired = function() {
	mHealth.util.logMessage('Application Session Expired');
	setTimeout(
			function() {
				mHealth.util
						.customAlert(
								mHealth.SettingsController.sessionTimeoutLogout,
								function() {
									mHealth.util.showMask();
									$('.dw').detach();
									$('.dwo').detach();
									$('.ui-alert-wallpaper').detach();
									$('#loginPage').detach();
									mHealth.util.removeNativeBar();
									mHealth.MessageControllerObject.tabbarloaded = false;
									mHealth.util.splashMessage=mHealth.SettingsController.sessionTimeoutLogout;
									$.mobile.changePage("../../rootview/view/login.html");
									mHealth.models.ConditionModel.destroyAll();
									mHealth.models.MessageModel.destroyAll();
									mHealth.models.MedicationModel.destroyAll();
									mHealth.models.ParticipantModel
											.destroyAll();
									mHealth.models.HealthDataModel.destroyAll();
									mHealth.models.FeatureGroupModel
											.destroyAll();
									mHealth.models.ChallengeResponseModel
											.destroyAll();
									mHealth.models.QuestionResponsesModel
											.destroyAll();
									// mHealth.HealthDataControllerObject.healthDataFlag
									// = false;
								});
			}, mHealth.delay);
};
/**
 * Name : currentOrientationGraph Purpose: Params : -- Return : --
 */
currentOrientationGraph = function(orientation) {
	mHealth.util.logMessage('Get the Current Orientation on the Graph');
	if (mHealth.GraphControllerObject.currentView == 'Day'
			|| mHealth.GraphControllerObject.healthDataTracker == 'Blood Glucose') {
		if (orientation == 'portrait') {
			mHealth.GraphControllerObject.plotOptions.xaxis.labelWidth = 0;
		} else if (orientation == 'landscape') {
			mHealth.GraphControllerObject.plotOptions.xaxis.labelWidth = -25;
		}
	}
	if ($('.ui-page-active').attr('id') == "add_condition") {

		if (orientation == 'portrait') {

			$('.ui-autocomplete').css({
				'top' : '126px !important',
				'left' : '10% !important'
			});
		} else if (orientation == 'landscape') {

			$('.ui-autocomplete').css({
				'top' : '118px !important',
				'left' : '26% !important'
			});
		}
	}
};

/**
 * Name : currentOrientation Purpose: Params : -- Return : --
 */
currentOrientation = function(orientation) {
	mHealth.util.logMessage('Get the Current Orientation');
	if ($('body').children().is('#tandcPage') == true) {
		setTimeout(function() {
			mHealth.util.tcScroll.scroll.stop();
			$('#tandcPage').css({
				'height' : '100%'
			});
		}, mHealth.delay);
	} else {

		$('.ui-page-active').not('#show_journal').css({
			'height' : document.height
		});

		if ($('.ui-page-active').attr('id') == "show_journal") {

			setTimeout(function() {
				var windowHeight = window.innerHeight;
				var journalHeight = windowHeight - 44;
				$('#journalScroll').css({
					'height' : journalHeight
				});
				mHealth.util.journalScroll.refresh();
			}, mHealth.delay);

		}

	}

	if (orientation == 'portrait') {

		if ($('.ui-page-active').attr('id') == "add_condition") {
			setTimeout(function() {
				$('.ui-autocomplete').css({
					'top' : '126px !important',
					'left' : '10% !important',
					'width' : '80% !important'
				});
			}, mHealth.delay);
		} else if ($('body').children().is('#tandcPage') == true) {
			setTimeout(function() {
				if (isAndroid) {
					$('#tc').height(5750); // 7400 for IOS
				} else if (isIOS) {
					$('#tc').height(7400);
				} else {
					// CODE FOR BROWSER
				}
				mHealth.util.tcScroll.refresh();
			}, mHealth.delay);

		}

		else if ($('.ui-page-active').attr('id') == "show_journal") {
			//
			// var windowHeight=window.innerHeight;
			// var journalHeight=windowHeight-44;
			// $('#journalScroll').css({
			// 'height':journalHeight
			// });
			// mHealth.util.journalScroll.refresh();
		}

		setTimeout(function() {
			$('.alertable').css({
				'height' : '420px',// 460px.
				'width' : '320px',
				'top' : document.body.scrollTop + 'px'
			});
			$('.back_container').css({
				'height' : '100%',
				'width' : '100%'
			});
			$('.ui-alert-wallpaper').css({
				'height' : '100%',
				'width' : '100%'
			});

		}, mHealth.delay);
	}

	if (orientation == 'landscape') {
		setTimeout(function() {
			if ($('.ui-page-active').attr('id') == "show_tracker_track") {
				window.scrollTo(0, 0);
			}

			if ($('.ui-page-active').attr('id') == "detailMessage") {
				window.scrollTo(0, 0);
			}
		}, mHealth.delay);

		if ($('.ui-page-active').attr('id') == "add_condition") {
			setTimeout(function() {
				$('.ui-autocomplete').css({
					'top' : '118px !important',
					'left' : '26% !important',
					'width' : '55% !important'
				});
			}, mHealth.delay);
		} else if ($('body').children().is('#tandcPage') == true) {
			setTimeout(function() {
				if (isAndroid) {
					$('#tc').height(3800); // 5240.
				} else if (isIOS) {
					$('#tc').height(5240);
				}
				mHealth.util.tcScroll.refresh();
			}, mHealth.delay);

		}
		// else if ($('.ui-page-active').attr('id') == "show_journal") {
		//
		// $('#journalScroll').css({
		// 'height' : '46.5%'
		// });
		// mHealth.util.journalScroll.refresh();
		// }

		setTimeout(function() {
			$('.alertable').css({
				'height' : '230px', // 300px.//230px.
				'width' : '533px', // 480px.
				'top' : document.body.scrollTop + 'px'
			});
			$('.back_container').css({
				'height' : '100%',
				'width' : '100%'
			});
			$('.ui-alert-wallpaper').css({
				'height' : '100%',
				'width' : '100%'
			});
		}, mHealth.delay);

	}
	if ($('.ui-page-active').attr('id') == "multiplehealthdatapage"
			|| $('.ui-page-active').attr('id') == "singlehealthdatapage") {
		/* code for graph buttons and graph orientation change */
		setTimeout(function() {
			mHealth.GraphControllerObject.drawMultipleHealthDataGraph();
			$('#daybutton').click(function() {
				mHealth.GraphControllerObject.dayButtonClick();
			});
			$('#weekbutton').click(function() {
				mHealth.GraphControllerObject.weekButtonClick();
			});
			$('#monthbutton').click(function() {
				mHealth.GraphControllerObject.monthButtonClick();
			});
			$('#showLabel').click(function() {
				mHealth.GraphControllerObject.showLabels();
			});
			$('#previousbutton').click(function() {
				mHealth.GraphControllerObject.previousButton();
			});
			$('#nextbutton').click(function() {
				mHealth.GraphControllerObject.nextButton();
			});
			$('#yearbutton').click(function() {
				mHealth.GraphControllerObject.yearButtonClick();
			});
			if (mHealth.GraphControllerObject.showLabel) {
				mHealth.GraphControllerObject.showLabel = false;
				mHealth.GraphControllerObject.showLabels();
			}
		}, mHealth.delay);

	}
};
/**
 * Name : loadSettings Purpose: Method to call setings web view on clicking the
 * settings tab Params : -- Return : --
 */
loadSettings = function() {
	mHealth.util.logMessage('redirected to the Settings page');
	$('.dw').detach();
	$('.dwo').detach();
	$("#conditionName").autocomplete("close").focus();
	$.mobile.changePage("../../settings/view/index.html");
};
networkStatus = function(status) {
	mHealth.util.logMessage('Mobile network Status Changed');
	mHealth.SettingsAbout.networkStatus = status;
	if (mHealth.SettingsAbout.networkStatus == 'false') {
		mHealth.util.customAlert(
				mHealth.SyncProcessController.msgConnectionError, '');
	}
};
/**
 * Name : handleDeviceBack Purpose: Method to handle device back button Params : --
 * Return : --
 */
handleDeviceBack = function(status) {
	mHealth.util.logMessage('On device Back');
	var historyBack = {
		"home" : "page",
		"loginPage" : "page",
		"welcomeMsg" : "page"
	};
	var moduleIndex = {

		"showActivity" : "../../home/view/home.html",
		"showMessage" : "../../home/view/home.html",
		"show_tracker" : "../../home/view/home.html",
		"settingsPage" : "../../home/view/home.html"
	};
	var graphPages = {
		"singlehealthdatapage" : "page",
		"multiplehealthdatapage" : "page"
	};
	var otherShortcuts = {
		"show_tracker_view" : "../../trackers/view/showtracker.html",
		"detailMessage" : "../../messages/view/showmessage.html",
		"alfrescoDIV" : "../../messages/view/showmessage.html"
	};
	// var exitAppCriteria={ "home" : "page","loginPage" : "page","welcomeMsg" :
	// "page"};

	if (historyBack[$('.ui-page-active').attr('id')]
			|| $('body').children().is('#tandcPage')) {
		Android.finishActivity();
	} else if (moduleIndex[$('.ui-page-active').attr('id')]) {
		Android.highlightHome();
		$('.ui-alert-wallpaper').detach();
		$.mobile.changePage(moduleIndex[$('.ui-page-active').attr('id')]);

	} else if (graphPages[$('.ui-page-active').attr('id')]) {
		Android.showTab();
		Android.pageHistory();
	} else if (otherShortcuts[$('.ui-page-active').attr('id')]) {
		$.mobile.changePage(otherShortcuts[$('.ui-page-active').attr('id')]);
	} else {

		$('.dw').detach();
		$('.dwo').detach();
		$('.dw').detach();
		$('.ui-alert-wallpaper').detach();
		Android.showTab();
		Android.pageHistory();
	}
};

/**
 * Name : handleDeviceHome Purpose: Method to handleDeviceHome button Params : --
 * Return : --
 */
handleDeviceHome = function() {
	mHealth.util.logMessage('On device Home');
	Android.finishActivity();
};
/**
 * Name : getDeviceInfo Purpose: Method to getDeviceInfo Params : appName --
 * This woudl Hold the version as well Return : -- Comments This method is
 * called from WEBCONTAINER ACTIVITY (NATIVE)
 */
getDeviceInfo = function(osId, osVersion, deviceMake, deviceModel, deviceId,
		deviceToken, deviceName, appName) {
	mHealth.util.logMessage('Get the device Info');
	// Rename-ing the method name from getDevicesFeature to
	// getDeviceGlobalSettings
	mHealth.controllers.SettingsController.getDeviceGlobalSettings(osId,
			osVersion, deviceMake, deviceModel, deviceId, deviceToken,
			deviceName, appName);
};

/**
 * Name : nativeCalendar Purpose: Method to send email. Params : -- Return : --
 */
mHealth.util.nativeCalendar = function(eventTitle) {
	mHealth.util.logMessage('On the native Calendar');
	if (isAndroid) {
		nativeCommunication.callNativeMethod("cal://eventTitle?" + eventTitle);
		$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
	} else {
		// code to work on a browser
	}
};
