/**
 * Class : RemoteServiceProxy
 * Utility class for making ajax calls to the server.
 **/
mHealth.util.RemoteServiceProxy = Spine.Class.sub({
	/**
	 * Name    : init
	 * Purpose : Initialize the oontroller.
	 * Params  : --
	 * Returns : --
	 **/
	init : function() {
	},
	/**
	 * Name    : getToken
	 * Purpose : Method to make service call for user authentication.
	 * Params  : url - The service url to call,
	 credentials - base64 encoded username and password combination.
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	getToken : function(url, credentials, devicetoken, osVersion, deviceName, osId, devMake, devModel, devCustomId, appName, appVersion, appReleasedVer, successCallback, errorCallback) {
		mHealth.util.logMessage('Service getToken Invoked');
		$.ajax({
			url : url,
			async : true,
			type : 'GET',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				if(mHealth.LoginControllerObject.environment == "dev") {
					mHealth.util.RemoteServiceProxy.alSecToken = jqXHR.getResponseHeader('Pragma');
				} else {
					mHealth.util.RemoteServiceProxy.alSecToken = jqXHR.getResponseHeader('ALSECTOKEN');
				}
				
				successCallback();
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				if(isIOS){
               
					if(errorCallback!= null ){
							errorCallback(errorThrown);
					}
				}
				if(isAndroid){
               
					if (errorCallback != null) {
						if (errorThrown == mHealth.SettingsController.timeOut
								&& indicatorFlag === true) {
							mHealth.util.hideMask();
							mHealth.util.customAlert(
									mHealth.SettingsController.errTimeout, '');
						} else {
							errorCallback(errorThrown);
						}
					}
				}
			},
			beforeSend : function(xhr) {
               
                //need to escape any special characters (encode)
                //and then re-build the string to preserve special char (unescape)
                deviceName = unescape(encodeURIComponent(deviceName));
                devCustomId = unescape(encodeURIComponent(devCustomId));
               
				xhr.withCredentials = true;
				xhr.setRequestHeader('Authorization', 'Basic ' + credentials);
                xhr.setRequestHeader('Device_PushNotificationToken', devicetoken);
                xhr.setRequestHeader('Device_OSVersion', osVersion);
                xhr.setRequestHeader('Device_Name', deviceName);
                xhr.setRequestHeader('Device_OSID', osId); 
                xhr.setRequestHeader('Device_Make', devMake);
                xhr.setRequestHeader('Device_Model', devModel);
                xhr.setRequestHeader('Device_CustomId', devCustomId);
                if(isIOS){
                	 xhr.setRequestHeader('Application_Name', appName);
                     xhr.setRequestHeader('Application_BuildVer', appVersion);
                     xhr.setRequestHeader('Application_ReleaseVer', appReleasedVer);
                }
			}
		});
	},
	/**
	 * Name    : getResponse
	 * Purpose : Method for making the GET request service call.
	 * Params  : url - The service url to call,
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	getResponse : function(url, successCallback, errorCallback, indicatorFlag) {
		mHealth.util.logMessage('Service getResponse Invoked');
		$.ajax({
			url : url,
			async : true,
			type : 'GET',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				successCallback(jqXHR);
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				if(errorCallback!=null){
				if(errorThrown == mHealth.SettingsController.timeOut && indicatorFlag === true) {
					mHealth.util.hideMask();
					mHealth.util.customAlert(mHealth.SettingsController.errTimeout, '');
				} else {
					errorCallback( errorThrown);
				}
				}
			},
			beforeSend : function(xhr) {
				xhr.setRequestHeader('ALSECTOKEN', mHealth.util.RemoteServiceProxy.alSecToken);
			}
		});
	},


	/**
	 * Name    : getSyncResponse
	 * Purpose : Method for making the GET request service call.
	 * Params  : url - The service url to call,
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	getSyncResponse : function(url, successCallback, errorCallback, indicatorFlag) {
		mHealth.util.logMessage('Service getSyncResponse Invoked');
//alert('url == ' + url);
		$.ajax({
			url : url,
			async : false,
			type : 'GET',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				successCallback(jqXHR);
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				if(errorCallback!=null){
				if(errorThrown == mHealth.SettingsController.timeOut && indicatorFlag === true) {
					mHealth.util.hideMask();
					mHealth.util.customAlert(mHealth.SettingsController.errTimeout, '');
				} else {
					errorCallback( errorThrown);
				}
				}
			},
			beforeSend : function(xhr) {
				xhr.setRequestHeader('ALSECTOKEN', mHealth.util.RemoteServiceProxy.alSecToken);
			}
		});
	},


	/**
	 * Name    : authenticateUser
	 * Purpose : Method for making the POST request service call
	 * Params  : url - The service url to call,
	 body - Request body to be sent to the server
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	postRequest : function(url, body, postSuccessCallback, errorCallback, indicatorFlag) {
		mHealth.util.logMessage('Service postRequest Invoked');
		
		$.ajax({
			url : url,
			async : true,
			data : body,
			type : 'POST',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
               if (postSuccessCallback != null) {
				  postSuccessCallback(jqXHR);
               } 
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				if(errorCallback!=null){
				if(errorThrown == mHealth.SettingsController.timeOut && indicatorFlag === true) {
					mHealth.util.hideMask();
					mHealth.util.customAlert(mHealth.SettingsController.errTimeout, '');
				} else {
					errorCallback( errorThrown);
				}
				}
			},
			beforeSend : function(xhr) {
				xhr.setRequestHeader('ALSECTOKEN', mHealth.util.RemoteServiceProxy.alSecToken);
			}
		});
	},
		/**
	 * Name    : authenticateUser
	 * Purpose : Method for making the POST request service call
	 * Params  : url - The service url to call,
	 body - Request body to be sent to the server
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	putRequest : function(url, body, putSuccessCallback, errorCallback, indicatorFlag) {
		mHealth.util.logMessage('Service putRequest Invoked');
		
		$.ajax({
			url : url,
			async : true,
			data : body,
			type : 'PUT',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				putSuccessCallback(jqXHR);
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				if(errorCallback!=null){
				if(errorThrown == mHealth.SettingsController.timeOut && indicatorFlag === true) {
					mHealth.util.hideMask();
					mHealth.util.customAlert(mHealth.SettingsController.errTimeout, '', false);
				} else {
					errorCallback( errorThrown);
				}
				}
			},
			beforeSend : function(xhr) {
				xhr.setRequestHeader('ALSECTOKEN', mHealth.util.RemoteServiceProxy.alSecToken);
			}
		});
	}
});

mHealth.util.RemoteServiceProxy.extend({

	alSecToken : null,

	/**
	 * Name    : getInstance
	 * Purpose : Method to create Singleton object for RemoteServiceProxy class
	 * Params  : --
	 * Returns : --
	 **/
	getInstance : function() {

		if(mHealth.util.RemoteServiceProxy.instance == null) {

			mHealth.util.RemoteServiceProxy.instance = new mHealth.util.RemoteServiceProxy();
		}
		return mHealth.util.RemoteServiceProxy.instance;
	}
});
