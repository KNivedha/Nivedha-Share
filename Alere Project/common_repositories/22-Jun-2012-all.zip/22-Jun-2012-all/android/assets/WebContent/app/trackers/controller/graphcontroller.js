mHealth.controllers.GraphController = Spine.Controller.sub({
	healthDataTracker : '',
	showLabel : false,
	currentView : "Month",
	currentTime : new Date(),
	cyear : new Date().getFullYear(),
	cmonth : new Date().getMonth() + 1,
	graphDataFlag : false,
	seriesDataSet1 : '',
	seriesDataSet2 : '',
	plotData : '',
	plotOptions : '',
	graphPlot : '',
	dataSeries1 : '',
	dataSeries2 : '',
	plotxMin : '',
	plotxMax : '',
	xTickInterval : '',
	xTimeformat : '',
	yTickInterval : '',
	threshMin : '',
	threshMax : '',
	seriesOnePointShow : '',
	seriesTwoPointShow : '',
	seriesOneLineShow : '',
	seriesTwoLineShow : '',
	seriesOneLabel : '',
	seriesTwoLabel : '',
	seriesOneColor : '',
	seriesTwoColor : '',
	legendShow : '',
	healthDataCount : '',
	maxHealthDataValue : 0,
	intervalCount : 0,
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #viewGraph' : 'viewGraph',
		'pageshow #singlehealthdatapage' : 'drawMultipleHealthDataGraph',
		'pageshow #multiplehealthdatapage' : 'drawMultipleHealthDataGraph',
		'click .chotype' : 'setChoType',
		'click #ibutton' : 'infoMsg',
		'pagebeforeshow #multiplehealthdatapage' : 'setDocHeight',
		'pagebeforeshow #singlehealthdatapage' : 'setDocHeight'
	},
	
	
	
	setDocHeight:function(){
		mHealth.util.logMessage('Set the Doc Hieght');
		mHealth.util.loadChart();
		
		$('#show_tracker_view').css({
			'height' : document.height
		});
		
		$('#detailsCholesterol').css({
			'height' : document.height
		});
		
		
		$('#multiplehealthdatapage').css({
			'height' : document.height
		});
		
		$('#singlehealthdatapage').css({
			'height' : document.height
		});
	},

	/**
	 *Name: setChoType
	 *Purpose: Sets Cholesterol type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setChoType : function(e) {
		mHealth.util.logMessage('Set the ChoType');
		this.healthDataTracker = $(e.target).parents(".chotype").attr('name');
		mHealth.HealthDataControllerObject.healthDataTracker = this.healthDataTracker;
		this.getGraphData();
	},
	/**
	 *Name: infoMsg
	 *Purpose:
	 *Params:
	 *Returns: doesn't return
	 **/
	infoMsg : function(e) {
		mHealth.util.logMessage('On the Info Msg Function');
		mHealth.util.customAlert(mHealth.GlucoseInfo.glucoseInfo, '');
	},
	/**
	 *Name: setHealthData
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setHealthData : function(output) {
		mHealth.util.logMessage('On the Set Health Data Function');
		var response = JSON.parse(output.responseText);
		var modelData = JSON.stringify(response);
		mHealth.models.HealthDataModel.customFromJSON(modelData);
	},
	
	/**
	 *Name: setTrackerId
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setTrackerId : function() {
		mHealth.util.logMessage('On the Set Tracker IDFunction');
		var trackerId = '';
		if(this.healthDataTracker == 'Blood Glucose') {
			trackerId = 'Bloodglucose';
		} else if(this.healthDataTracker == 'Dilated Retinal Exam') {
			trackerId = 'RetinalExam';
		} else if(this.healthDataTracker == 'Foot Sores') {
			trackerId = 'FootSores';
		} else if(this.healthDataTracker == 'Foot Exam - Provider') {
			trackerId = 'FootExam';
		} else if(this.healthDataTracker == 'Microalbumin') {
			trackerId = 'MAU';
		} else if(this.healthDataTracker == 'A1c') {
			trackerId = 'A1C';
		} else if(this.healthDataTracker == 'Weight & BMI') {
			trackerId = 'Weight';
		} else if(this.healthDataTracker == 'Blood Pressure') {
			trackerId = 'BPS';
		} else if(this.healthDataTracker == 'Cholesterol') {
			trackerId = 'Cholesterol';
		}
		return trackerId;
	},
	/**
	 *Name: getHealthTrackerData
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	getHealthTrackerData : function(healthDataType) {
		mHealth.util.logMessage('On the get Health tracker data Function');
        //alert("healthDataType :"+healthDataType);
		var healthDataResponse = [];
		var modelResponse = mHealth.models.HealthDataModel.findAllByAttribute("healthDataType", healthDataType);
		var prevYearDate = mHealth.util.getPrevYearDate();
		modelResponse.map(function(response) {
			if(response.measurementDate >= prevYearDate)
				healthDataResponse.push(response);
		});
		var sortedData = mHealth.HealthDataControllerObject.getSortedData(healthDataResponse);
		if(this.healthDataTracker=='A1c'|| this.healthDataTracker=='LDL'|| this.healthDataTracker=='HDL'|| this.healthDataTracker=='TotalCholesterol'|| this.healthDataTracker=='Triglycerides')
		{	
			var j=0;
			for(var i=0;i<sortedData.length;i++){
				if(sortedData[i]['measurementDate']!=sortedData[j]['measurementDate']){
					j++;
					sortedData[j]=sortedData[i];
				}
				else
				{
					sortedData[j]=sortedData[i];
				}
			}
			sortedData=sortedData.slice(0,j+1);
		}
		
		return sortedData;
	},
	/**
	 *Name: plotMultipleLineGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	plotMultipleLineGraph : function(healthDataValue1, healthDataValue2) {
		mHealth.util.logMessage('On the Plot MultiLine Graph Function');
		this.seriesDataSet1 = healthDataValue1;
		this.seriesDataSet2 = healthDataValue2;
		
		this.weekView();
		$.mobile.changePage('multiplehealthdata.html');
	},
	/**
	 *Name: plotSingleLineGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	plotSingleLineGraph : function(healthDataValue) {
		mHealth.util.logMessage('On the Plot Single Graph Function');
		this.seriesDataSet1 = healthDataValue;
		
		if(this.healthDataTracker == "Blood Glucose") {
			this.dayView();
			$.mobile.changePage('bloodglucose.html');
		} else {
			this.yearView();
			$.mobile.changePage('singlehealthdata.html');
		}

	},
	/**
	 *Name: viewGraph
	 *Purpose:  Calls a getResponse service call for the very first time, calls getGraphdata otherwise.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	viewGraph : function() {
		mHealth.util.logMessage('On the View Graph Function');
		this.graphDataFlag=true;
		mHealth.HealthDataControllerObject.healthDataServiceCount=0;
		this.getGraphData();
	},
	/**
	 *Name: getGraphDataSuccess
	 *Purpose:  Service call success callback function. Calls getGraphdata that will eventually set the data for graph plotting and hides mask.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getGraphDataSuccess : function(output) {
		mHealth.util.logMessage('On the Graph Service data success Function');
		this.getGraphData();
		mHealth.util.hideMask();
	},
	/**
	 *Name: getGraphDataFailure
	 *Purpose: Service  call failure callback function. Calls getGraphdata that will eventually set the data for graph plotting and hides mask.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getGraphDataFailure : function() {
		mHealth.util.logMessage('On the Graph Service data Failure Function');
		this.getGraphData();
		mHealth.util.hideMask();
	},
	/**
	 *Name: getGraphData
	 *Purpose:  gets the Graph Data using getResponse service call. Called on view my graph click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getGraphData : function() {
		mHealth.util.logMessage('On the Graph data Function');
		this.cmonth = new Date().getMonth() + 1;
		this.cyear = new Date().getFullYear();
		this.currentTime = new Date();
		var healthDataResponse = [];
		var healthDataResponseDouble = [];
		var trackerId = this.setTrackerId();
        if(this.healthDataTracker == "Cholesterol") {
			$.mobile.changePage('detailscholesterol.html');
		} else {
			if(trackerId == 'Bloodglucose') {
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotSingleLineGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'Weight & BMI') {
				trackerId1 = "Weight";
				trackerId2 = "BMI";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotMultipleLineGraph(healthDataResponse, healthDataResponseDouble);
			} else if(this.healthDataTracker == 'Blood Pressure') {
				trackerId1 = "BPS";
				trackerId2 = "BPD";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotMultipleLineGraph(healthDataResponse, healthDataResponseDouble);
			} else if(this.healthDataTracker == 'LDL') {
				trackerId1 = "LDL";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				this.plotSingleLineGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'HDL') {
				trackerId1 = "HDL";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				this.plotSingleLineGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'Triglycerides') {
				healthDataResponse = this.getHealthTrackerData(this.healthDataTracker);
				this.plotSingleLineGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'TotalCholesterol') {
				trackerId = 'TotalCholesterol';
				healthDataResponse = this.getHealthTrackerData(trackerId);
                //alert(":: healthDataResponse ::"+healthDataResponse);
				this.plotSingleLineGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'A1c') {
				trackerId = 'A1C';
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotSingleLineGraph(healthDataResponse);
			}
			return;
		}

	},
	/**
	 *Name: yearView
	 *Purpose:sets the year view for the graph when landing on the graph for the first time, and when clicked on the year button
	 *Params:
	 *Returns:
	 **/
	yearView : function() {
		mHealth.util.logMessage('On the Year view of the graph Function');
		$("#nextbutton").css("display", "none");
		$("#previousbutton").css("display", "none");
		this.currentView = "Year";
		var lastDateM = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), 23, 59);
		var xMaxDate = this.calculateDate(lastDateM, 2);
		var firstDateM = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate() - 364);
		var xMinDate = this.calculateDate(firstDateM, 1);
		this.dataSeries1 = this.calculateSingleLineDataPoints(this.seriesDataSet1, xMinDate, xMaxDate);
		this.plotxMax = lastDateM.getTime() - ((new Date()).getTimezoneOffset() * 60 * 1000);
		this.plotxMin = firstDateM.getTime() - ((new Date()).getTimezoneOffset() * 60 * 1000);
		if(this.healthDataTracker == "Blood Glucose") {
			this.threshMin = 80;
			this.threshMax = 120;
			this.glucoseGraph(this.dataSeries1);
		} else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure") {
			this.dataSeries2 = this.calculateSingleLineDataPoints(this.seriesDataSet2, xMinDate, xMaxDate);
			this.getOptions([1, "month"], "%b", null, null, null);
			if(this.healthDataTracker == "Weight & BMI")
				this.getOptions([1, "month"], "%b", 40, null, null, false, true, true, false, "Weight", "BMI", 'green', 'orange', true);
			else
				this.getOptions([1, "month"], "%b", 40, null, null, false, false, true, true, "Systolic", "Diastolic", 'orange', 'green', true);

			this.multipleLineGraph();
		} else {
			this.dataSeries2 = null;
			if(this.healthDataTracker == "A1c")
				this.getOptions([1, "month"], "%b", 1, 0, 6, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "LDL")
				this.getOptions([1, "month"], "%b", 40, 0, 100, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "HDL")
				this.getOptions([1, "month"], "%b", 40, 0, 50, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "TotalCholesterol")
				this.getOptions([1, "month"], "%b", 40, 0, 200, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "Triglycerides")
				this.getOptions([1, "month"], "%b", 40, 0, 150, true, false, false, false, null, null, '#FFA01B', null, false);

			this.multipleLineGraph();
		}

	},
	/**
	 *Name: monthView
	 *Purpose:sets the month view for the graph when landing on the graph for the first time, and when clicked on the month button
	 *Params:
	 *Returns:
	 **/
	monthView : function() {
		mHealth.util.logMessage('On the Month view of the graph Function');
		if(this.currentTime.getMonth() == new Date().getMonth() && this.currentTime.getFullYear() == new Date().getFullYear())
			$("#nextbutton").css("display", "none");
		this.currentView = "Month";
		var lastDateM = new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate(), 23, 59);
		var xMaxDate = this.calculateDate(lastDateM, 2);
		var firstDateM = new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate() - 29);
		var xMinDate = this.calculateDate(firstDateM, 1);
		this.dataSeries1 = this.calculateSingleLineDataPoints(this.seriesDataSet1, xMinDate, xMaxDate);
		this.plotxMax = lastDateM.getTime() - ((new Date()).getTimezoneOffset() * 60 * 1000);
		this.plotxMin = firstDateM.getTime() - ((new Date()).getTimezoneOffset() * 60 * 1000);
		if(this.healthDataTracker == "Blood Glucose") {
			this.threshMin = 80;
			this.threshMax = 120;
			this.yTickInterval = 50;
			this.glucoseGraph(this.dataSeries1);
		} else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure") {
			this.dataSeries2 = this.calculateSingleLineDataPoints(this.seriesDataSet2, xMinDate, xMaxDate);

			if(this.healthDataTracker == "Weight & BMI")
				this.getOptions([7, "day"], "%d", 40, null, null, false, true, true, false, "Weight", "BMI", '#92C83E', '#FFA01B', true);
			else
				this.getOptions([7, "day"], "%d", 40, 60, 120, false, false, true, true, "Systolic", "Diastolic", '#FFA01B', '#92C83E', true);

			this.multipleLineGraph();
		} else {
			this.dataSeries2 = null;
			if(this.healthDataTracker == "A1c")
				this.getOptions([7, "day"], "%d", 1, 0, 6, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "LDL")
				this.getOptions([7, "day"], "%d", 40, 0, 100, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "HDL")
				this.getOptions([7, "day"], "%d", 40, 0, 50, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "TotalCholesterol")
				this.getOptions([7, "day"], "%d", 40, 0, 200, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "Triglycerides")
				this.getOptions([7, "day"], "%d", 40, 0, 150, true, false, false, false, null, null, '#FFA01B', null, false);

			this.multipleLineGraph();
		}
	},
	/**
	 *Name: weekView
	 *Purpose:sets the week view for the graph
	 *Params:
	 *Returns:
	 **/
	weekView : function() {
		mHealth.util.logMessage('On the Week view of the graph Function');
		this.currentView = "Week";
		if((this.currentTime.getFullYear()) == (new Date().getFullYear()) && (this.currentTime.getMonth()) == (new Date().getMonth()) && (this.currentTime.getDate()) == (new Date().getDate()))
			$("#nextbutton").css("display", "none");
		var wday = this.currentTime.getDay();
		var minWeekDate = new Date(this.currentTime.getTime() - (6 * 24 * 60 * 60 * 1000));
		var minDateW = this.calculateDate(minWeekDate, 1);
		var maxWeekDate = new Date(this.currentTime.getTime());
		var maxDateW = this.calculateDate(maxWeekDate, 2);
		this.dataSeries1 = this.calculateSingleLineDataPoints(this.seriesDataSet1, minDateW, maxDateW);
		this.plotxMin = new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate()).getTime() - (6 * 24 * 60 * 60 * 1000) - ((new Date()).getTimezoneOffset() * 60 * 1000);
		this.plotxMax = new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate(), 23, 59).getTime() - ((new Date()).getTimezoneOffset() * 60 * 1000);

		if(this.healthDataTracker == "Blood Glucose") {
			this.threshMin = 80;
			this.threshMax = 120;
			this.yTickInterval = 50;
			this.glucoseGraph(this.dataSeries1);
		} else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure") {
			this.dataSeries2 = this.calculateSingleLineDataPoints(this.seriesDataSet2, minDateW, maxDateW);
			if(this.healthDataTracker == "Weight & BMI")
				this.getOptions([1, "day"], "%d", 40, null, null, false, true, true, false, "Weight", "BMI", '#92C83E', '#FFA01B', true);
			else
				this.getOptions([1, "day"], "%d", 40, 60, 120, false, false, true, true, "Systolic", "Diastolic", '#FFA01B', '#92C83E', true);

			this.multipleLineGraph();
		} else {
			this.dataSeries2 = null;
			if(this.healthDataTracker == "A1c")
				this.getOptions([1, "day"], "%d", 1, 0, 6, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "LDL")
				this.getOptions([1, "day"], "%d", 40, 0, 100, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "HDL")
				this.getOptions([1, "day"], "%d", 40, 0, 50, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "TotalCholesterol")
				this.getOptions([1, "day"], "%d", 40, 0, 200, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "Triglycerides")
				this.getOptions([1, "day"], "%d", 40, 0, 150, true, false, false, false, null, null, '#FFA01B', null, false);

			this.multipleLineGraph();
		}
	},
	/**
	 *Name: dayView
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	dayView : function(e) {
		mHealth.util.logMessage('On the Day view of the graph Function');
		this.currentView = "Day";
		if((this.currentTime.getFullYear()) == (new Date().getFullYear()) && (this.currentTime.getMonth()) == (new Date().getMonth()) && (this.currentTime.getDate()) == (new Date().getDate()))
			$("#nextbutton").css("display", "none");
		var minDayDate = new Date(this.currentTime.getTime());
		var minDateD = this.calculateDate(minDayDate, 1);
		var maxDayDate = new Date(this.currentTime.getTime() + (24 * 60 * 60 * 1000));
		var maxDateD = this.calculateDate(maxDayDate, 1);

		this.dataSeries1 = this.calculateSingleLineDataPoints(this.seriesDataSet1, minDateD, maxDateD);
		this.plotxMin = new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate(), 00, 00).getTime() - ((new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate())).getTimezoneOffset() * 60 * 1000);
		this.plotxMax = new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate(), 00, 00).getTime() + (24 * 60 * 60 * 1000) - ((new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate())).getTimezoneOffset() * 60 * 1000);

		if(this.healthDataTracker == "Blood Glucose") {
			this.threshMin = 80;
			this.threshMax = 120;
			this.yTickInterval = 50;
			this.glucoseGraph(this.dataSeries1);
		} else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure") {
			this.dataSeries2 = this.calculateSingleLineDataPoints(this.seriesDataSet2, minDateD, maxDateD);
			if(this.healthDataTracker == "Weight & BMI")
				this.getOptions([4, "hour"], "%H:%M", 40, null, null, false, true, true, false, "Weight", "BMI", '#92C83E', '#FFA01B', true);
			else
				this.getOptions([4, "hour"], "%H:%M", 40, 60, 120, false, false, true, true, "Systolic", "Diastolic", '#FFA01B', '#92C83E', true);

			this.lineGraphDay(this.dataSeries1, this.dataSeries2);
		} else {
			this.dataSeries2 = null;
			if(this.healthDataTracker == "A1c")
				this.getOptions([4, "hour"], "%H:%M", 1, 0, 6, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "LDL")
				this.getOptions([4, "hour"], "%H:%M", 40, 0, 100, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "HDL")
				this.getOptions([4, "hour"], "%H:%M", 40, 0, 55, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "TotalCholesterol")
				this.getOptions([4, "hour"], "%H:%M", 40, 0, 200, true, false, false, false, null, null, '#FFA01B', null, false);
			else if(this.healthDataTracker == "Triglycerides")
				this.getOptions([4, "hour"], "%H:%M", 40, 0, 150, true, false, false, false, null, null, '#FFA01B', null, false);

			this.lineGraphDay(this.dataSeries1, this.dataSeries2);
		}
	},
	/**
	 *Name: getOptions
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	getOptions : function(xTickInterval, xTimeformat, yTickInterval, threshMin, threshMax, seriesOnePointShow, seriesTwoPointShow, seriesOneLineShow, seriesTwoLineShow, seriesOneLabel, seriesTwoLabel, seriesOneColor, seriesTwoColor, legendShow) {
		mHealth.util.logMessage('On the get the options for the graph Function');
		this.xTickInterval = xTickInterval;
		this.xTimeformat = xTimeformat;
		this.yTickInterval = yTickInterval;
		this.threshMin = threshMin;
		this.threshMax = threshMax;
		this.seriesOnePointShow = seriesOnePointShow;
		this.seriesTwoPointShow = seriesTwoPointShow;
		this.seriesOneLineShow = seriesOneLineShow;
		this.seriesTwoLineShow = seriesTwoLineShow;
		this.seriesOneLabel = seriesOneLabel;
		this.seriesTwoLabel = seriesTwoLabel;
		this.seriesOneColor = seriesOneColor;
		this.seriesTwoColor = seriesTwoColor;
		this.legendShow = legendShow;
		if(this.healthDataCount == 1) {
			this.seriesOnePointShow = true;
			this.seriesTwoPointShow = true;
		}
	},
	/**
	 *Name: multipleLineGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	multipleLineGraph : function() {
		mHealth.util.logMessage('On the multiline graph Function');
		var markings = [{
			color : '#ff8c00',
			lineWidth : 1,
			xaxis : {
				from : new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).getTime() - ((new Date()).getTimezoneOffset() * 60 * 1000) + 1000000,
				to : new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).getTime() - ((new Date()).getTimezoneOffset() * 60 * 1000) + 1000000
			}
		}];
		if(this.currentView == "Day")
			markings = null;
		this.plotData = [{//$('#DIV NAME'), data
			data : this.dataSeries1,
			label : this.seriesOneLabel,
			color : this.seriesOneColor,
			points : {
				show : this.seriesOnePointShow,
				fillColor : this.seriesOneColor,
				fill : true,
				radius : 3
			},
			lines : {
				show : this.seriesOneLineShow,
				lineWidth : 2, // in pixels
				fill : false,
				fillColor : null,
				steps : false
			}
		}, {//$('#DIV NAME'), data
			data : this.dataSeries2,
			label : this.seriesTwoLabel,
			color : this.seriesTwoColor,
			points : {
				show : this.seriesTwoPointShow,
				fillColor : this.seriesTwoColor,
				fill : true,
				radius : 3
			},
			lines : {
				show : this.seriesTwoLineShow,
				lineWidth : 2, // in pixels
				fill : false,
				fillColor : null,
				steps : false
			}

		}];
		if(this.healthDataTracker == "A1c") {
			if(this.maxHealthDataValue > 15)
				this.yTickInterval = 2;
		}
		this.intervalCount = 0;
		while(this.maxHealthDataValue >= this.intervalCount) {
			this.intervalCount = this.intervalCount + this.yTickInterval;
		}
		this.intervalCount = this.intervalCount + 3 * this.yTickInterval;
		this.plotOptions = {
			xaxis : {
				mode : "time",
				tickSize : this.xTickInterval,
				min : this.plotxMin,
				max : this.plotxMax,
				timeformat : this.xTimeformat,
				tickColor : '#574F52',
				color : '#574F52'
			},
			yaxis : {
				min : 0,
				max : this.intervalCount,
				tickSize : this.yTickInterval,
				decimal : 0,
				tickColor : '#574F52',
				color : '#574F52'
			},
			series : {
				grow : {
					active : true,
					valueIndex : 1,
					// stepDelay: 20,
					steps : 5,
					stepMode : "maximum",
					stepDirection : "up"
				}

			},
			grid : {
				hoverable : false,
				backgroundColor : '#463E41',
				color : '#FFFFFF',
				borderColor : '#463E41'
				//markings: markings
			},
			legend : {
				show : this.legendShow,
				position : "ne",
				margin : 2,
				backgroundOpacity : 0
			},
			selection : {
				mode : "y",
				color : '#C38EC7'
			}
		};
		if(this.maxHealthDataValue<10 && this.healthDataTracker == "A1c")
		{
			 this.plotOptions.yaxis.max=this.maxHealthDataValue?this.maxHealthDataValue+4:10;
			 this.plotOptions.yaxis.ticks=this.tickGenerator;
		}
		this.maxHealthDataValue = 0;
	},
	
	/**
	 *Name: tickGenerator
	 *Purpose: For data series with maximum y-axis value less than 10, flot generates decimal ticklabels, this function is used to generate non decimal points in that case
	 *Params:implicit axis object is passed
	 *Returns: two dimensional array.
	 **/
	tickGenerator : function(axis){
		mHealth.util.logMessage('On the Tick generator Function');
		var ticksArray=[];
		for(var i=0;i<=axis.max;i++){
			ticksArray.push([i,parseInt(i)]);
		}
		return ticksArray;
	},
	/**
	 *Name: lineGraphDay
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	lineGraphDay : function(dataSeries1, dataSeries2) {
		mHealth.util.logMessage('On the Line graph day Function');
		var dataSeries1Cords = new Array();
		var dataSeries2Cords = new Array();
		var counter = 0;
		var userTime;
		var healthData;
		for( counter = 0; counter < dataSeries1.length; counter++) {
			userTime = parseInt((dataSeries1[counter].measurementDate).substr(9, 2), 10);
			if(this.healthDataTracker == "Blood Glucose" || this.healthDataTracker == "Blood Pressure")
				healthData = parseInt(dataSeries1[counter].value);
			else
				healthData = parseFloat(dataSeries1[counter].value).toFixed(2);
			if(!isNaN(healthData)) {
				dataSeries1Cords[counter] = new Array(2);
				if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure") {
					if(userTime >= 00 && userTime < 6)
						dataSeries1Cords[counter][0] = 2;
					else if(userTime >= 6 && userTime < 9)
						dataSeries1Cords[counter][0] = 6;
					else if(userTime >= 9 && userTime < 11)
						dataSeries1Cords[counter][0] = 10;
					else if(userTime >= 11 && userTime < 14)
						dataSeries1Cords[counter][0] = 14;
					else if(userTime >= 14 && userTime < 17)
						dataSeries1Cords[counter][0] = 18;
					else if(userTime >= 17 && userTime < 20)
						dataSeries1Cords[counter][0] = 22;
					else if(userTime >= 20 || userTime < 00)
						dataSeries1Cords[counter][0] = 26;
				} else {
					dataSeries1Cords[counter][0] = 14;
				}
				dataSeries1Cords[counter][1] = healthData;
			} else {
				dataSeries1Cords[counter] = new Array(2);
				dataSeries1Cords[counter][0] = null;
				dataSeries1Cords[counter][1] = null;
			}
		}
		this.dataSeries1 = dataSeries1Cords;
		counter = 0;
		if(dataSeries2 != null) {
			for( counter = 0; counter < dataSeries2.length; counter++) {
				userTime = parseInt((dataSeries2[counter].measurementDate).substr(9, 2), 10);
				if(this.healthDataTracker == "Blood Glucose" || this.healthDataTracker == "Blood Pressure")
					healthData = parseInt(dataSeries2[counter].value);
				else
					healthData = parseFloat(dataSeries2[counter].value).toFixed(2);
				// healthData = parseInt(dataSeries2[counter].value);
				dataSeries2Cords[counter] = new Array(2)
				if(userTime >= 00 && userTime < 6)
					dataSeries2Cords[counter][0] = 2;
				else if(userTime >= 6 && userTime < 9)
					dataSeries2Cords[counter][0] = 6;
				else if(userTime >= 9 && userTime < 11)
					dataSeries2Cords[counter][0] = 10;
				else if(userTime >= 11 && userTime < 14)
					dataSeries2Cords[counter][0] = 14;
				else if(userTime >= 14 && userTime < 17)
					dataSeries2Cords[counter][0] = 18;
				else if(userTime >= 17 && userTime < 20)
					dataSeries2Cords[counter][0] = 22;
				else if(userTime >= 20 || userTime < 00)
					dataSeries2Cords[counter][0] = 26;

				dataSeries2Cords[counter][1] = healthData;
			}
			this.dataSeries2 = dataSeries2Cords;
		}
		this.plotData = [{
			data : dataSeries1Cords,
			label : this.seriesOneLabel,
			color : this.seriesOneColor,
			points : {
				show : this.seriesOnePointShow,
				fillColor : this.seriesOneColor,
				fill : true,
				radius : 3
			},
			lines : {
				show : this.seriesOneLineShow,
				lineWidth : 2, // in pixels
				fill : false,
				fillColor : null,
				steps : false
			}
		}, {//$('#DIV NAME'), data
			data : dataSeries2Cords,
			label : this.seriesTwoLabel,
			color : this.seriesTwoColor,
			points : {
				show : this.seriesTwoPointShow,
				fillColor : this.seriesTwoColor,
				fill : true,
				radius : 3
			},
			lines : {
				show : this.seriesTwoLineShow,
				lineWidth : 2, // in pixels
				fill : false,
				fillColor : null,
				steps : false
			}
		}];
		if(this.healthDataTracker == "A1c") {
			if(this.maxHealthDataValue > 15)
				this.yTickInterval = 2;
		}
		this.intervalCount = 0;
		while(this.maxHealthDataValue >= this.intervalCount) {
			this.intervalCount = this.intervalCount + this.yTickInterval;
		}
		this.intervalCount = this.intervalCount + 3 * this.yTickInterval;
		this.plotOptions = {
			xaxis : {
				min : 0,
				max : 28,
				tickSize : 4,
				labelWidth : 0, //this.labelWidth,
				ticks : [[0, "12am-6am"], [4, "6am-9am"], [8, "9am-11am"], [12, "11am-2pm"], [16, "2pm-5pm"], [20, "5pm-8pm"], [24, "8pm-12am"], [28, ""]]
			},
			yaxis : {
				min : 0,
				max : this.intervalCount,
				tickSize : this.yTickInterval,
				decimal : 0
			},
			series : {
				grow : {
					active : true,
					valueIndex : 1,
					// stepDelay: 20,
					steps : 5,
					stepMode : "maximum",
					stepDirection : "up"
				}
			},
			grid : {
				hoverable: false,
				color : '#FFFFFF',
				backgroundColor : '#463E41',
				borderColor : '#463E41'
				//tickColor: '#FFFFFF'
			},
			selection : {
				mode : "y",
				color : '#C38EC7'
			},
			legend : {
				show : this.legendShow,
				position : "ne",
				margin : 2,
				backgroundOpacity : 0
			}
		};
		if(this.maxHealthDataValue<10 && this.healthDataTracker == "A1c")
		{
			this.plotOptions.yaxis.max=this.maxHealthDataValue?this.maxHealthDataValue+4:10;
			this.plotOptions.yaxis.ticks=this.tickGenerator;
		}
		this.maxHealthDataValue = 0;
	},
	/**
	 *Name: glucoseGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	glucoseGraph : function(glucosedata) {
		mHealth.util.logMessage('On the Glucose graph Function');
		var storeCords = new Array();
		for(var counter = 0; counter < glucosedata.length; counter++) {
			var userTime = parseInt((glucosedata[counter].measurementDate).substr(9, 2), 10);
			var healthData = parseInt(glucosedata[counter].value);
			storeCords[counter] = new Array(2)
			if(userTime >= 00 && userTime < 6)
				storeCords[counter][0] = 2;
			else if(userTime >= 6 && userTime < 9)
				storeCords[counter][0] = 6;
			else if(userTime >= 9 && userTime < 11)
				storeCords[counter][0] = 10;
			else if(userTime >= 11 && userTime < 14)
				storeCords[counter][0] = 14;
			else if(userTime >= 14 && userTime < 17)
				storeCords[counter][0] = 18;
			else if(userTime >= 17 && userTime < 20)
				storeCords[counter][0] = 22;
			else if(userTime >= 20 || userTime < 00)
				storeCords[counter][0] = 26;

			storeCords[counter][1] = healthData;
		}
		var groupSixAm = 0, groupNineAm = 0, groupElevenAm = 0, groupTwoPm = 0, groupSixPm = 0, groupEightPm = 0, groupElevenPm = 0;
		var countGroupSixAm = 0, countGroupNineAm = 0, countGroupElevenAm = 0, countGroupTwoPm = 0, countGroupSixPm = 0, countGroupEightPm = 0, countGroupElevenPm = 0;
		var plotCords_length = storeCords.length;
		for(var i = 0; i < plotCords_length; i++) {
			if(!isNaN(storeCords[i][1])) {
				if(storeCords[i][0] == 2) {
					groupSixAm = groupSixAm + storeCords[i][1];
					countGroupSixAm = countGroupSixAm + 1;
				} else if(storeCords[i][0] == 6) {
					groupNineAm = groupNineAm + storeCords[i][1];
					countGroupNineAm = countGroupNineAm + 1;
				} else if(storeCords[i][0] == 10) {
					groupElevenAm = groupElevenAm + storeCords[i][1];
					countGroupElevenAm = countGroupElevenAm + 1;
				} else if(storeCords[i][0] == 14) {
					groupTwoPm = groupTwoPm + storeCords[i][1];
					countGroupTwoPm = countGroupTwoPm + 1;
				} else if(storeCords[i][0] == 18) {
					groupSixPm = groupSixPm + storeCords[i][1];
					countGroupSixPm = countGroupSixPm + 1;
				} else if(storeCords[i][0] == 22) {
					groupEightPm = groupEightPm + storeCords[i][1];
					countGroupEightPm = countGroupEightPm + 1;
				} else {
					groupElevenPm = groupElevenPm + storeCords[i][1];
					countGroupElevenPm = countGroupElevenPm + 1;
				}
			}
		}
		var avgCords = [[2, parseFloat(groupSixAm / countGroupSixAm).toFixed(2)], [6, parseFloat(groupNineAm / countGroupNineAm).toFixed(2)], [10, parseFloat(groupElevenAm / countGroupElevenAm).toFixed(2)], [14, parseFloat(groupTwoPm / countGroupTwoPm).toFixed(2)], [18, parseFloat(groupSixPm / countGroupSixPm).toFixed(2)], [22, parseFloat(groupEightPm / countGroupEightPm).toFixed(2)], [26, parseFloat(groupElevenPm / countGroupElevenPm).toFixed(2)]];
		this.dataSeries1 = avgCords;
		this.dataSeries2 = storeCords;
		this.plotData = [{
			data : avgCords,
			//label: 'Average',
			color : 'orange',
			points : {
				symbol : "square",
				fill : true,
				fillColor : 'orange',
				show : true,
				radius : 5
			}
		}, {
			data : storeCords,
			//label: 'Data',
			color : 'white',
			points : {
				symbol : "cross",
				show : true,
				radius : 3
			}
		}];
		this.intervalCount = 0;
		while(this.maxHealthDataValue >= this.intervalCount) {
			this.intervalCount = this.intervalCount + this.yTickInterval;
		}
		this.intervalCount = this.intervalCount + 3 * this.yTickInterval;
		this.maxHealthDataValue = 0;
		this.plotOptions = {
			xaxis : {
				min : 0,
				max : 28,
				tickSize : 4,
				labelWidth : 0, //this.labelWidth,
				ticks : [[0, "12am-6am"], [4, "6am-9am"], [8, "9am-11am"], [12, "11am-2pm"], [16, "2pm-5pm"], [20, "5pm-8pm"], [24, "8pm-12am"], [28, ""]]
			},
			yaxis : {
				min : 0,
				max : this.intervalCount,
				tickSize : this.yTickInterval
			},
			legend : {
				show : false,
				//container : '#legendcontainer',
				backgroundOpacity : 0
			},
			series : {
				grow : {
					active : true,
					valueIndex : 1,
					// stepDelay: 20,
					steps : 5,
					stepMode : "maximum",
					stepDirection : "up"
				}
			},
			grid : {
				//hoverable: true
				color : '#FFFFFF',
				backgroundColor : '#463E41',
				borderColor : '#463E41'
				//tickColor: '#FFFFFF'
			},
			selection : {
				mode : "y",
				color : '#C38EC7'
			}
		};
	},
	/**
	 *Name: drawMultipleHealthDataGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	drawMultipleHealthDataGraph : function() {
		mHealth.util.logMessage('On the drawMultipleHealthDataGraph Function');
		mHealth.util.getCurrentOrientation();
		$('.ui-page-active').css({
			'height' : document.height
		});
		if(this.healthDataTracker == "Blood Glucose") {
			if(this.currentView == "Day")
				$("#daybutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Day.png");
			$('#yearbutton').css('display', 'none');
		} else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure") {
			if(this.currentView == "Week")
				$("#weekbutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Week.png");
		} else {
			if(this.currentView == "Year")
				$("#yearbutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Year.png");
			$('#ibutton').css('display', 'none');
		}
		if(this.healthDataTracker == "A1c" || this.healthDataTracker == "LDL" || this.healthDataTracker == "HDL") {
			if(this.currentView == "Year")
				$('#previousbutton').css('display', 'none');
			else
				$('#previousbutton').css('display', 'block');
		}
		$('#monthbutton').unbind('click');
		$('#weekbutton').unbind('click');
		$('#daybutton').unbind('click');
		$('#showLabel').unbind('click');
		$('#previousbutton').unbind('click');
		$('#nextbutton').unbind('click');
		$('#yearbutton').unbind('click');
		this.graphPlot = $.plot($("#graphdiv"), this.plotData, this.plotOptions);
		this.showDate();
		this.plotOptions.series.grow = true;

		if(this.healthDataTracker == "HDL") {
			var gend = (mHealth.models.ParticipantModel.first()).gender;
			if(gend == "M") {
				this.threshMin = 40;
				this.threshMax = this.intervalCount;
			} else {
				this.threshMin = 50;
				this.threshMax = this.intervalCount;
			}
		}
		this.graphPlot.setSelection({
			yaxis : {
				from : this.threshMin,
				to : this.threshMax
			}
		});

	},
	/**
	 *Name: previousButton
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	previousButton : function() {
		mHealth.util.logMessage('On the previousButton Function');
		this.showLabel = false;
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ShowValues.png");
		$("#nextbutton").css("display", "block");
		if(this.cmonth == "1" || this.cmonth == '01') {
			this.cmonth = '12';
			this.cyear = String(parseInt(this.cyear, 10) - 1);
		} else
			this.cmonth = String(parseInt(this.cmonth, 10) - 1);
		if(this.currentView == "Week") {
			//alert(this.currentTime);
			this.currentTime = new Date(this.currentTime.getTime() - (7 * 24 * 60 * 60 * 1000));
			// alert(this.currentTime);
			this.weekView();
		} else if(this.currentView == "Day") {
			this.currentTime = new Date(this.currentTime.getTime() - (1 * 24 * 60 * 60 * 1000));
			// alert(this.currentTime);
			this.dayView();
		} else {
			this.currentTime = new Date(this.currentTime.getTime() - (30 * 24 * 60 * 60 * 1000));
			//alert(this.currentTime+' is the current time');
			this.monthView();
		}
		this.drawMultipleHealthDataGraph();
	},
	/**
	 *Name: nextButton
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	nextButton : function() {
		this.showLabel = false;
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ShowValues.png");
		if(this.cmonth == "12") {
			this.cmonth = '1';
			this.cyear = String(parseInt(this.cyear, 10) + 1);
		} else
			this.cmonth = String(parseInt(this.cmonth, 10) + 1);
		if(this.currentView == "Week") {
			this.currentTime = new Date(this.currentTime.getTime() + (7 * 24 * 60 * 60 * 1000));
			this.weekView();
		} else if(this.currentView == "Day") {
			this.currentTime = new Date(this.currentTime.getTime() + (1 * 24 * 60 * 60 * 1000));
			this.dayView();
		} else {
			this.currentTime = new Date(this.currentTime.getTime() + (30 * 24 * 60 * 60 * 1000));
			this.monthView();
		}
		this.drawMultipleHealthDataGraph();
	},
	/**
	 *Name: showDate
	 *Purpose: displays date on top of graph depending on the view ie., Month, Week or Daily
	 *Params: --
	 *Returns: --
	 **/
	showDate : function() {
		var placeholder = $('#graphdiv');
		var dateTitle = (new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate())).format('mmm dd, yyyy');
		var mfactor = 29 * 24 * 60 * 60 * 1000;
		var xOffset = new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate()).getTime() - mfactor;
		//var dateString=(new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).format('mmmm dd, yyyy');
		var trackerTitle = this.healthDataTracker;
		if(this.currentView == "Month") {
			dateTitle = mHealth.util.getDateWithMonth(this.currentTime);
		}
		if(this.currentView == 'Week') {
			mfactor = 5.8 * 24 * 60 * 60 * 1000;
			xOffset = (new Date(new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate()).getTime() - mfactor)).getTime();
			dateTitle = mHealth.util.getDateWithWeek(this.currentTime);
		} else if(this.currentView == 'Day') {
			mfactor = 0;
			xOffset = mfactor;
		} else if(this.currentView == "Year") {
			dateTitle = mHealth.util.getYearWithMonth(this.currentTime);
			mfactor = 364 * 24 * 60 * 60 * 1000;
			xOffset = new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate()).getTime() - mfactor;
		}
		var yOffset = this.graphPlot.getAxes().yaxis.max;
		if(this.healthDataTracker == "Blood Glucose") {
			xOffset = 0;
		}
		var o = this.graphPlot.pointOffset({
			x : xOffset,
			y : yOffset
		});
		placeholder.append('<div style="position:absolute;left:28px;top:' + o.top + 'px;color:#CCCCCC;font-size:bigger">' + trackerTitle + '</div>');
		$("#trackerbuttons span").text(dateTitle);
	},
	/**
	 *Name: showLabels
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	showLabels : function() {
		mHealth.util.logMessage('On the showLabels Function');
		if(!this.showLabel) {
			$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Orange_HideValues.png");
			var o = this.graphPlot.pointOffset({
				x : new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).getTime() - ((new Date()).getTimezoneOffset() * 60 * 1000) + 1000000,
				y : 0
			});
			var ctx = this.graphPlot.getCanvas().getContext("2d");
			ctx.fillStyle = "#FFA01B";
			ctx.strokeStyle = "#FFA01B";
			// if(this.currentView != "Day")
			// {
			// ctx.beginPath();
			// o.left -= 7;
			// ctx.moveTo(o.left, o.top);
			// ctx.lineTo(o.left+7, o.top - 5);
			// ctx.lineTo(o.left+14 , o.top);
			// ctx.lineTo(o.left, o.top);
			// ctx.fillStyle = "#FFA01B";
			// ctx.strokeStyle = "#FFA01B";
			// ctx.fill();
			// }
			this.drawLabel();
			this.showLabel = true;
		} else {
			this.plotOptions.series.grow = false;
			$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ShowValues.png");
			this.drawMultipleHealthDataGraph();
			$('#daybutton').click(function() {
				mHealth.GraphControllerObject.dayButtonClick();
			});
			$('#weekbutton').click(function() {
				mHealth.GraphControllerObject.weekButtonClick();
			});
			$('#monthbutton').click(function() {
				mHealth.GraphControllerObject.monthButtonClick();
			});
			$('#showLabel').click(function() {
				mHealth.GraphControllerObject.showLabels();
			});
			$('#previousbutton').click(function() {
				mHealth.GraphControllerObject.previousButton();
			});
			$('#nextbutton').click(function() {
				mHealth.GraphControllerObject.nextButton();
			});
			$('#yearbutton').click(function() {
				mHealth.GraphControllerObject.yearButtonClick();
			});
			this.showLabel = false;
		}
	},
	/**
	 *Name: drawLabel
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	drawLabel : function() {
		mHealth.util.logMessage('On the drawLabel Function');
		var placeholder = $('#graphdiv');
		var ctx = this.graphPlot.getCanvas().getContext("2d");
		ctx.globalAlpha = 1;
		if(this.healthDataTracker != "Blood Pressure") {
			if(this.healthDataTracker == 'Weight & BMI') {
				ctx.fillStyle = "#92C83E";
				ctx.strokeStyle = "#92C83E";
			}
			for(var i = 0; i < this.dataSeries1.length; i++) {
				if(!isNaN(this.dataSeries1[i][1])) {
					var o = this.graphPlot.pointOffset({
						x : this.dataSeries1[i][0],
						y : this.dataSeries1[i][1]
					});
					if(this.healthDataTracker != 'Weight & BMI')
						o.top = o.top - 3;
					placeholder.append('<div style=opacity:' + (1) + ';filter:alpha(opacity=60);background-color:#333333;position:absolute;z-index:1000;left:' + (o.left - 15) + 'px;top:' + (o.top - 23) + 'px;color:#cccccc;font-size:smaller">&nbsp;&nbsp;' + this.dataSeries1[i][1] + '&nbsp;&nbsp;</div>');
					ctx.beginPath();
					ctx.moveTo(o.left, o.top);
					ctx.lineTo(o.left - 7, o.top - 7);
					ctx.lineTo(o.left + 7, o.top - 7);
					ctx.lineTo(o.left, o.top);
					ctx.fill();
				}
			}
			if(this.healthDataTracker == 'Weight & BMI' || this.healthDataTracker == 'Blood Glucose') {
				ctx.fillStyle = "#FFA01B";
				ctx.strokeStyle = "#FFA01B";
				for(var i = 0; i < this.dataSeries2.length; i++) {
					if(!isNaN(this.dataSeries2[i][1])) {
						var o = this.graphPlot.pointOffset({
							x : this.dataSeries2[i][0],
							y : this.dataSeries2[i][1]
						});
						if(this.healthDataTracker == 'Weight & BMI')
							o.top = o.top - 3;
						placeholder.append('<div style=opacity:' + (1) + ';filter:alpha(opacity=60);background-color:#333333;position:absolute;z-index:1000;left:' + (o.left - 15) + 'px;top:' + (o.top - 23) + 'px;color:#cccccc;font-size:smaller">&nbsp;&nbsp;' + this.dataSeries2[i][1] + '&nbsp;&nbsp;</div>');
						ctx.beginPath();
						ctx.moveTo(o.left, o.top);
						ctx.lineTo(o.left - 7, o.top - 7);
						ctx.lineTo(o.left + 7, o.top - 7);
						ctx.lineTo(o.left, o.top);
						ctx.fill();
					}
				}
			}
		} else {
			// var moonPoints=[];
			// var sunPoints=[];
			// var moonCounter=0;
			// var sunCounter=0;
			for(var i = 0; i < this.dataSeries1.length; i++) {
				var o = this.graphPlot.pointOffset({
					x : this.dataSeries1[i][0],
					y : this.dataSeries1[i][1]
				});
				var o1 = this.graphPlot.pointOffset({
					x : this.dataSeries2[i][0],
					y : this.dataSeries2[i][1]
				});
				ctx.beginPath();
				ctx.moveTo(o.left, o.top);
				ctx.lineTo(o1.left, o1.top);
				ctx.stroke();
				var y = (o.top + o1.top) / 2;
				var x = o.left;
				// if(new Date(this.dataSeries1[i][0]).getHours() > 6 && new Date(this.dataSeries1[i][0]).getHours() < 18)
				// {
				// sunPoints[sunCounter]=new Array(2);
				// sunPoints[sunCounter][0]=o.left -5;
				// if(y-15 < o.top)
				// sunPoints[sunCounter][1]=y-25;
				// else
				// sunPoints[sunCounter][1]=o.top -10;
				// sunCounter++;
				// }
				// else
				// {
				// moonPoints[moonCounter]=new Array(2);
				// moonPoints[moonCounter][0]=o.left -5;
				// if(y-15 < o.top)
				// moonPoints[moonCounter][1]=y-25;
				// else
				// moonPoints[moonCounter][1]=o.top -10;
				// moonCounter++;
				// }
				placeholder.append('<div style=opacity:' + (1) + ';filter:alpha(opacity=60);background-color:#333333;position:absolute;z-index:1000;left:' + (x - 20) + 'px;top:' + (y - 5) + 'px;color:#cccccc;font-size:smaller">' + this.dataSeries1[i][1] + '/' + this.dataSeries2[i][1] + '</div>');
				ctx.moveTo(x, y - 15);
				ctx.lineTo(x - 10, y - 5);
				ctx.lineTo(x + 10, y - 5);
				ctx.lineTo(x, y - 15);
				ctx.fillStyle = "#ff8c00";
				ctx.fill();
				y = y + 5;
				ctx.moveTo(x, y + 15);
				ctx.lineTo(x - 10, y + 5);
				ctx.lineTo(x + 10, y + 5);
				ctx.lineTo(x, y + 15);
				ctx.fillStyle = "#ff8c00";
				ctx.fill();

			}
			// var moonObj = new Image();
			// var sunObj = new Image();
			// moonObj.onload = function(){
			// for(var j=0;j<moonCounter;j++)
			// ctx.drawImage(moonObj, moonPoints[j][0], moonPoints[j][1]);
			// };
			// sunObj.onload = function(){
			// for(var j=0;j<sunCounter;j++)
			// ctx.drawImage(sunObj, sunPoints[j][0], sunPoints[j][1]);
			// };
			// moonObj.src = "../../../assets/images/trackerimages_new/MOON.png";
			// sunObj.src = "../../../assets/images/trackerimages_new/SUN.png";
		}
	},
	/**
	 *Name: yearButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	yearButtonClick : function() {
		mHealth.util.logMessage('On the yearButtonClick Function');
		this.showLabel = false;
		this.cmonth = new Date().getMonth() + 1;
		this.cyear = new Date().getFullYear();
		this.currentTime = new Date();
		//alert("monthButtonClick");
		$("#yearbutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Year.png");
		$("#monthbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Month.png");
		$("#weekbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Week.png");
		$("#daybutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Day.png");
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ShowValues.png");
		this.yearView();
		this.drawMultipleHealthDataGraph();
	},
	/**
	 *Name: monthButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	monthButtonClick : function() {
		mHealth.util.logMessage('On the monthButtonClick Function');
		$('#previousbutton').css('display', 'block');
		this.showLabel = false;
		this.cmonth = new Date().getMonth() + 1;
		this.cyear = new Date().getFullYear();
		this.currentTime = new Date();
		//alert("monthButtonClick");
		$("#yearbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Year.png");
		$("#monthbutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Month.png");
		$("#weekbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Week.png");
		$("#daybutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Day.png");
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ShowValues.png");
		this.monthView();
		this.drawMultipleHealthDataGraph();
	},
	/**
	 *Name: weekButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	weekButtonClick : function() {
		mHealth.util.logMessage('On the weekButtonClick Function');
		$('#previousbutton').css('display', 'block');
		this.showLabel = false;
		this.currentTime = new Date();
		//alert("weekButtonClick");
		$("#yearbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Year.png");
		$("#monthbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Month.png");
		$("#weekbutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Week.png");
		$("#daybutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Day.png");
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ShowValues.png");
		this.weekView();
		this.drawMultipleHealthDataGraph();
	},
	/**
	 *Name: dayButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	dayButtonClick : function() {
		mHealth.util.logMessage('On the dayButtonClick Function');
		$('#previousbutton').css('display', 'block');
		//setTimeout("$('#previousbutton').css('visibility','visible');",800);
		this.showLabel = false;
		this.currentTime = new Date();
		//alert("dayButtonClick");
		$("#yearbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Year.png");
		$("#monthbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Month.png");
		$("#weekbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Week.png");
		$("#daybutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Day.png");
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ShowValues.png");
		this.dayView();
		this.drawMultipleHealthDataGraph();

	},
	/**
	 *Name: calculateDate
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	calculateDate : function(currentTime, minmax) {
		mHealth.util.logMessage('On the calculateDate Function');
		var month = currentTime.getMonth() + 1;
		var day = currentTime.getDate();
		var year = currentTime.getFullYear();
		var hours = currentTime.getHours();
		var minutes = currentTime.getMinutes();
		var seconds = currentTime.getSeconds();
		if(month <= 9)
			month = "0" + month;
		if(day <= 9)
			day = "0" + day;

		if(minmax == 1)
			return year + "-" + month + "-" + day + " " + "00" + ":" + "00";
		else
			return year + "-" + month + "-" + day + " " + "23" + ":" + "59";
	},
	/**
	 *Name: calculateSingleLineDataPoints
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	calculateSingleLineDataPoints : function(trackerData, xMinDate, xMaxDate) {
		mHealth.util.logMessage('On the calculateSingleLineDataPoints Function');
		//alert("xmindate: "+xMinDate+"xmaxdate: "+xMaxDate);
		//alert("inside calculateSingleLineDataPoints");
		this.healthDataCount = 0;
		var dataGlucose = new Array();
		var counterTrackerData = 0;
		var dataSeries1 = [];
		var usrtmeYear, usrtmeMonth, usrtmeDay1, usrtmeHours, usrtmeMinutes, usrtmeSeconds, hlthData;
		if(trackerData) {

			for(var counter = 0; counter < trackerData.length; counter++) {
				usrtmeYear = parseInt((trackerData[counter].measurementDate).substr(0, 4), 10);
				usrtmeMonth = parseInt((trackerData[counter].measurementDate).substr(4, 2), 10);
				usrtmeDay1 = parseInt((trackerData[counter].measurementDate).substr(6, 2), 10);
				usrtmeHours = parseInt((trackerData[counter].measurementDate).substr(9, 2), 10);
				usrtmeMinutes = parseInt((trackerData[counter].measurementDate).substr(11, 2), 10);
				usrtmeSeconds = parseInt((trackerData[counter].measurementDate).substr(13, 2), 10);
				hlthData = parseFloat(trackerData[counter].value).toFixed(2);
				if(usrtmeMonth <= 9)
					usrtmeMonth = "0" + usrtmeMonth;
				if(usrtmeDay1 <= 9)
					usrtmeDay1 = "0" + usrtmeDay1;
				if(usrtmeHours <= 9)
					usrtmeHours = "0" + usrtmeHours;
				if(usrtmeMinutes <= 9)
					usrtmeMinutes = "0" + usrtmeMinutes;
				usrtmeDay = usrtmeYear + '-' + usrtmeMonth + '-' + usrtmeDay1 + ' ' + usrtmeHours + ':' + usrtmeMinutes;

				if(usrtmeDay >= xMinDate && usrtmeDay < xMaxDate) {
					this.healthDataCount = this.healthDataCount + 1;
					if(this.healthDataTracker == "Blood Glucose") {
						if(this.maxHealthDataValue < parseInt(hlthData, 10))
							this.maxHealthDataValue = parseInt(hlthData, 10);
						dataGlucose[counterTrackerData] = new Array();
						dataGlucose[counterTrackerData] = trackerData[counter];
					} else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure") {
						if(hlthData < 1000) {
							if(this.maxHealthDataValue < parseInt(hlthData, 10))
								this.maxHealthDataValue = parseInt(hlthData, 10);
							if(this.currentView != "Day") {
								dataSeries1[counterTrackerData] = new Array(2);
								dataSeries1[counterTrackerData][0] = (new Date(usrtmeYear, parseInt(usrtmeMonth, 10) - 1, parseInt(usrtmeDay1, 10), usrtmeHours, usrtmeMinutes).getTime()) - ((new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate())).getTimezoneOffset() * 60 * 1000);
								dataSeries1[counterTrackerData][1] = hlthData;
							} else {
								dataSeries1[counterTrackerData] = new Array();
								dataSeries1[counterTrackerData] = trackerData[counter];
							}
						} else
							counterTrackerData--;
					} else if(this.healthDataTracker == "A1c") {
						if(hlthData < 31) {
							if(this.maxHealthDataValue < parseInt(hlthData, 10))
								this.maxHealthDataValue = parseInt(hlthData, 10);
							if(this.currentView != "Day") {
								dataSeries1[counterTrackerData] = new Array(2);
								dataSeries1[counterTrackerData][0] = (new Date(usrtmeYear, parseInt(usrtmeMonth, 10) - 1, parseInt(usrtmeDay1, 10), usrtmeHours, usrtmeMinutes).getTime()) - ((new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate())).getTimezoneOffset() * 60 * 1000);
								dataSeries1[counterTrackerData][1] = hlthData;
							} else {
								dataSeries1[counterTrackerData] = new Array();
								dataSeries1[counterTrackerData] = trackerData[counter];
							}
						} else
							counterTrackerData--;
					} else {
						if(this.maxHealthDataValue < parseInt(hlthData, 10))
							this.maxHealthDataValue = parseInt(hlthData, 10);
						if(this.currentView != "Day") {
							dataSeries1[counterTrackerData] = new Array(2);
							dataSeries1[counterTrackerData][0] = (new Date(usrtmeYear, parseInt(usrtmeMonth, 10) - 1, parseInt(usrtmeDay1, 10), usrtmeHours, usrtmeMinutes).getTime()) - ((new Date(this.currentTime.getFullYear(), this.currentTime.getMonth(), this.currentTime.getDate())).getTimezoneOffset() * 60 * 1000);
							dataSeries1[counterTrackerData][1] = hlthData;
						} else {
							dataSeries1[counterTrackerData] = new Array();
							dataSeries1[counterTrackerData] = trackerData[counter];
						}

					}
					counterTrackerData = counterTrackerData + 1;
				}
			}
		}
		if(this.healthDataTracker == "Blood Glucose") {
			return dataGlucose;
		} else
			return dataSeries1;
	}
});
