/**
 * Controller : MessageController
 * This is the controller to do the  logic of message
 **/
mHealth.controllers.MessageController = Spine.Controller.sub({
	el : 'body',
	tabbarloaded : false,
	summarySection : "",
	msgFolderId : "",	
	isSubmitted : false,
	messageTypeValue : "",
	updateTypeValue : "",
	messageIdVal : ""	,
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'pageshow #home' : 'showMessages',
		'pageshow #showMessage' : 'showTabbar',
		'click #messageCenter' : 'loadMessageTab',
		'click #displayMessage' : 'loadMessage',
		'pagebeforeshow #detailMessage' : 'renderMessage',
		'pageshow #detailMessage' : 'processMessage',
		'pagebeforeshow #showMessage' : 'getMessages',
		'click #submitButton' : 'submitAssessment',
		'click #submit1Button' : 'submitAssessment',
		'click #detailsMessageBack' : 'loadMessageBar',
		'change #answerA1cId' : 'changeFields',
		'change #answerDiaId' : 'changeFields',
		'change #answerDiaFootId' : 'changeFields',
		'change #answerMicroId' : 'changeFields',
		'change #answerChoId' : 'changeFields',
		'pagebeforeshow #messageCalendarPage' : 'showCalendar',
		'click #saveMessageCalendar' : 'saveCalendar',
		'click #cancelMessageCalender' : 'cancelCalendar',
		'click #calendarId' : 'showCalendarPage',
		'pagebeforeshow #summaryMessage' : 'showSummary',
		'vclick .video' : 'showVideo',
		 'vclick .healthArticle' : 'parseArticle',
		'click #archiveButton' : 'archiveMessage',
		'change #msgHeader' : 'changeMsgList',
		'pagebeforeshow #showArchive' : 'getArchives',
		'pagebeforeshow #video' : 'hideTab',
		'pagebeforehide #video' : 'showTab',	
		'click #showMoreMessages':'showMessageInbox',
		 'pagebeforeshow #articleDiv' : 'preloadAlfresco',
        'pageshow #articleDiv' : 'showAlfresco',
	},
	/**
	 * Name    : showMessageInbox
	 * Purpose : Method to showMessageInbox from Home shortcut
	 * Params  : --
	 * Return  : --
	 **/
	showMessageInbox:function(){
		mHealth.util.logMessage('Inside showMessageInbox Method');
		$.mobile.changePage("../../messages/view/showmessage.html");
		mHealth.util.loadMessagesBar();
	},
	/**
	 * Name    : parseArticle
	 * Purpose : 
	 * Params  : --
	 * Return  : --
	 **/
	 parseArticle : function(event){
       var target = event.target || event.srcElement;      
        if (target.href){
            var targetValue = target.href;
            var articleId = targetValue.substring(3, targetValue.length);
            assetID = articleId;
            // Overlay display
            event.preventDefault(); 
            $.mobile.changePage('../../messages/view/articlecontainer.html');   
                                                        
            // Browser display 
            //var hwUrl = "openurl://external?url=http://secure.uat.alerehealth.com:13085/api/health-articles/hwMCnt?id=healthwise://"+assetID;                                                           
            //alert("hwUrl: "+ hwUrl);
            //window.open(hwUrl, '_blank');      
        } else {
            mHealth.util.customAlert("No url found to navigate", '');	
            // HMM CHECK YOUR ID ON WHICH YOU ARE TRIGGERING THE EVENT
        }   
        
    },
    /**
	 * Name    : showAlfresco
	 * Purpose : Method to showAlfresco 
	 * Params  : --
	 * Return  : --
	 **/
       showAlfresco:function(){
    	
    	 $('#alfrescoDIV').css({'height':'auto !important'});
		if(isIOS) {
			$('#iframePage').css({
			'padding-right':'0px !important', 'margin-right':'0px !important'
		});
		}
    },
    
     /**
	 * Name    : preloadAlfresco
	 * Purpose : Method to preloads the contents into an IFRAME which is defined in alfrescocontainer.html 
	 * Params  : --
	 * Return  : --
	 **/
	 //This function preloads the contents into an IFRAME which is defined in alfrescocontainer.html
    //
    preloadAlfresco : function(){
                                                                                                                      
                                                           
        //alert("in preloadAlfresco ");
        
        // hardcoded host works
        //$('#iframePage').html('<iframe width="100%" height="100%" src="http://secure.uat.alerehealth.com:13085/api/health-articles/hwMCnt?id=healthwise://'+assetID+'" ></iframe>');
                               

       var srcUrl = "" + mHealth.env.healthwise_url + assetID;
          //alert(srcUrl);                                                 
        $('#iframePage').html('<iframe width="100%" height="100%" src="' + srcUrl +'" ></iframe>');
        //$('#iframePage').html('<iframe width="100%" height="100%" src="http://localhost:8090/Test/Testing.html"></iframe>');                                                    
        $('#iframePage').trigger('create');
       // $('#alfrescoDIV').css({'height':'auto !important'});
                                                           
                                                           
                                                           
    },
	/**
	 * Name    : showTabbar
	 * Purpose : Method to showTabbar
	 * Params  : --
	 * Return  : --
	 **/
	showTabbar : function() {
		if(isIOS){
			mHealth.util.unloadChart();
			mHealth.util.showTabBar();
		}else if(isAndroid){
			Android.logMessage('inside showTabbar messagecontroller');
			Android.showTab();
		}
	},
	
	/**
	 * Name    : hideTab
	 * Purpose : Method to hide the tab bar when video is shown.
	 * Params  : --
	 * Return  : --
	 **/
	hideTab:function(){
		if(isAndroid){
			Android.logMessage('inside hide tab');
			mHealth.util.hideTabBar();
		}
	},
	
	/**
	 * Name    : showTab
	 * Purpose : Method to show tab bar when video is not shown.
	 * Params  : --
	 * Return  : --
	 **/
	showTab:function(){
		if(isAndroid){
			Android.logMessage('inside the show tab');
			mHealth.util.showTabBar();
		}
	},
	
	/**
	 * Name    : showVideo
	 * Purpose : Method to set the id for video and navigate to video page
	 * Params  : --
	 * Return  : --
	 **/
	showVideo : function(event) {
		mHealth.util.logMessage('Video processing Method is been called');
		var target = event.target || event.srcElement
		if(target.href) {
			var targetValue = target.href;
			var videoId = targetValue.substring(3, targetValue.length);
			mHealth.videoLinkId = videoId;
			$.mobile.changePage('../../messages/view/messagesvideo.html');
			event.preventDefault();
		} else {
			mHealth.util.customAlert(mHealth.Messages.noUrlVideo, '');
		}

	},
	/**
	 * Name    : updateMessage
	 * Purpose : Method to update the message as read
	 * Params  : --
	 * Return  : --
	 **/
	updateMessage : function(messageId,updateType) {	
		mHealth.util.logMessage('Inside updateMessage Method');
		messageIdVal = messageId;
		var url = mHealth.env.messagedetails_url + messageId;
		var body = '{}';
		updateTypeValue = updateType;
		if(updateType =="read"){			
			body = '{}';
		} else if(updateType =="archive"){
			body = mHealth.recommendation.MessageArchiveMapper();
		}
		this.service.putRequest(url, body, this.updateMessageSucess);		
		if(updateTypeValue =="archive"){	
			mHealth.util.logMessage('updateTypeValue is Archive');		
			mHealth.MessageControllerObject.loadMessageTabBar();
			var messageObject = mHealth.models.MessageModel.findByAttribute('messageID', messageIdVal);			
			mHealth.models.MessageModel.destroy(messageObject.id);			
		} else {
			mHealth.models.MessageModel.select(function(msgObj) {
			if(msgObj.messageID == messageIdVal) {
				msgObj.isRead = "true";
			}
			});
		}			
	}, 
	/**
	 * Name    : updateMessageSucess
	 * Purpose : Method on success of update message service
	 * Params  : --
	 * Return  : --
	 **/
	updateMessageSucess : function(output) {		
		//TODO : Move logic here
	},
	/**
	 * Name    : loadMessageTabBar
	 * Purpose : Method to load message tabbar
	 * Params  : 
	 * Return  : --
	 **/
	loadMessageTabBar : function() {
		mHealth.util.logMessage('Service call to load message headers');		
		var url = mHealth.env.messageheaders_url ;
		this.proxy(this.service.getResponse(url, mHealth.MessageControllerObject.loadMessageHeaders,'',false));
		$.mobile.changePage("../../messages/view/showmessage.html");		
	},
	/**
	 * Name    : messageSuccess
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	messageSuccess : function(output) {
		mHealth.util.logMessage('Inside messageSuccess method');	
		var response = output.responseText;
		mHealth.MessageControllerObject.loadMessageHeaders(output);		
		$.mobile.changePage("../../home/view/home.html");
	},
	/**
	 * Name    : loadMessageHeaders
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageHeaders : function(output) {
		mHealth.util.logMessage('Inside loadMessageHeaders method');
		mHealth.util.hideMask();
		mHealth.models.MessageModel.destroyAll();
        var response = JSON.parse(output.responseText);
        var messageCount = response[0].totalMessageCount;
        if(messageCount > 0)
        {
            var messages = JSON.stringify(response[0].Message);
            var sortedData = mHealth.MessageControllerObject.getSortData(JSON.parse(messages));
            mHealth.models.MessageModel.customFromJSON(sortedData);			
        }

	},
	/**
	 * Name    : hightLightMessagetab
	 * Purpose : Method to highlight messages tab
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageBar : function() {		
			mHealth.util.logMessage('Inside loadMessageBar method');	
		if(messageTypeValue == "archive") {			
			$.mobile.changePage("../../messages/view/showarchive.html");
		} else {
			$.mobile.changePage("../../messages/view/showmessage.html");
		}
		mHealth.util.loadMessagesBar();
	},
	/**
	 * Name    : showHome
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	showHome : function() {
		mHealth.util.logMessage('Inside showHome method');
		$.mobile.changePage("../../home/view/home.html");
		if(isIOS){
			mHealth.util.loadHomeBar();
		}	
	},
	/**
	 * Name    : messageServiceFailure
	 * Purpose : Method on failure of message header service
	 * Params  : output
	 * Return  : --
	 **/
	messageServiceFailure : function() {
		mHealth.util.logMessage('Inside messageServiceFailure method');
		$.mobile.changePage("../../home/view/home.html");
		mHealth.util.hideMask();
	},
	/**
	 * Name    : showMessages
	 * Purpose : Load the message from the Model and Show the Result in the Message Center of the Home Tab
	 * Params  : --
	 * Return  : --
	 **/
	showMessages : function() {
		mHealth.util.logMessage('Inside showMessages method');
		if(isIOS){
			mHealth.util.unloadChart();
			mHealth.util.showTabBar();
		} else if(isAndroid){
			Android.showTab();
		}
		this.proxy(this.service.getResponse(mHealth.env.messageheaders_url, mHealth.MessageControllerObject.loadMessageHeaders));
		var len = mHealth.models.MessageModel.count();
		var messages_val = mHealth.models.MessageModel.all();
		if(len > 0) {
			$('#messages_div').html(_.template($('#messageList').html(), {
				messages_val : messages_val
			}));
			$('#messages_div').trigger('create');
		} else {
			var message = mHealth.Messages.noMessage;
			$('#messages_div').text(message);
		}
		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}
		$('#home').css({
				'height' : 'auto'
			});
	},
	/**
	 * Name    : loadMessage
	 * Purpose : Calls webservice to get message details page
	 * Params  : --
	 * Return  : --
	 **/
	loadMessage : function(event) {
			mHealth.util.showMask();
			var eventTarget = event.target;
			var messageID = $(eventTarget).parents().children('input[type="hidden"]').val();
			mHealth.util.messageID = messageID;
			var URL = mHealth.env.messagedetails_url + messageID;
			mHealth.util.loadMessagesBar();
			this.proxy(this.service.getResponse(URL, mHealth.MessageControllerObject.displayMessage, mHealth.MessageControllerObject.loadMessageTab1, true));
			//Updating the service after the Message is been dispalyed
			mHealth.util.logMessage('Inside loadMessage method- Service call to load a particular message');
			this.updateMessage(messageID,"read");		
	},
	/**
	 * Name    : displayMessage
	 * Purpose : Loads message details in to model
	 * Params  : --
	 * Return  : --
	 **/
	displayMessage : function(output) {
		mHealth.util.logMessage('Inside displayMessage method');
		messageTypeValue = $('select#msgHeader option:selected').val();
		mHealth.models.MessageQuestionModel.destroyAll();
		mHealth.models.QuestionGroupModel.destroyAll();
		mHealth.models.QuestionnaireModel.destroyAll();
		mHealth.models.MessageDetailsModel.destroyAll();
		mHealth.models.MessageSectionModel.destroyAll();
		mHealth.models.UserFeedbackModel.destroyAll();
		var response = output.responseText;
		//alert(response);
		var calendarSection = [];
		var calendarDesc = "";
		summarySection = "";
		var feedBackData = JSON.parse(response);
		mHealth.util.userResponseLength='';
		mHealth.util.isSubmitted=false;
		if(feedBackData[0].userFeedback){
		var userResponseLength=feedBackData[0].userFeedback.response.length;
		mHealth.util.userResponseLength=userResponseLength;
		var userResponse=feedBackData[0].userFeedback.response;	
		if(userResponseLength >0 && userResponseLength <21){
			mHealth.util.isSubmitted=true;
			userResponse= userResponse.splice(0,1);
			mHealth.models.UserFeedbackModel.customFromJSON(userResponse);
		}	
		if(userResponseLength>=21){
			mHealth.util.isSubmitted=true;
			userResponse= userResponse.splice(0,21);
			mHealth.models.UserFeedbackModel.customFromJSON(userResponse);
		}
		}
		var messageResponse = JSON.stringify(response);
		var messagesData = JSON.parse(messageResponse);
		mHealth.models.MessageDetailsModel.customFromJSON(messagesData);	
		var msgDetails = mHealth.models.MessageDetailsModel.first();
		msgFolderId = msgDetails.msgFolderID ;		
		mHealth.models.MessageDetailsModel.each(function(message) {
			if(message.cachedPersonalizedMessage) {
				if(message.cachedPersonalizedMessage.messageContent && message.cachedPersonalizedMessage.messageContent.sections && message.cachedPersonalizedMessage.messageContent.sections.section) {
					var sectionData = message.cachedPersonalizedMessage.messageContent.sections.section;
					var sectionResponse = JSON.stringify(sectionData);
					var sectionsData = JSON.parse(sectionResponse);
					mHealth.models.MessageSectionModel.customFromJSON(sectionsData);
					var sectionLength = sectionData.length;
					if(message.cachedPersonalizedMessage.messageContent.summary) {
						summarySection = message.cachedPersonalizedMessage.messageContent.summary;
					}
					if(sectionData.length != 0) {
						sectionData.map(function(sections) {
							if(sections) {
								calendarSection = [];
								if(sections.suggestedCalendarEvent) {
									if(sections.suggestedCalendarEvent.desc != "") {
										calendarSection.push(sections.suggestedCalendarEvent);
									}
								}
								if(sections.questionnaire) {
									var questionnaireData = sections.questionnaire;
									if(questionnaireData) {
										mHealth.models.QuestionnaireModel.customFromJSON(questionnaireData);
										mHealth.models.QuestionnaireModel.each(function(questionnaire) {
											if(questionnaire.qGroups) {
												if(questionnaire.qGroups.qGroup) {
													var groupQuestion = questionnaire.qGroups.qGroup;
													mHealth.models.QuestionGroupModel.customFromJSON(groupQuestion);
													mHealth.models.QuestionGroupModel.each(function(questionnaires) {
														if(questionnaires.questions) {
															if(questionnaires.questions.question) {
																var questions = questionnaires.questions.question;
																mHealth.models.MessageQuestionModel.customFromJSON(questions);
															}
														}
													});
												}
											}
										});
									}
								}
							}

						});
					}
					var calendarData = '';
					if(calendarSection) {

						calendarData = "true";
					}
					mHealth.util.hideMask();
					var messagesDetail = mHealth.models.MessageDetailsModel.first();
					mHealth.util.messageID = messagesDetail.messageID;
					mHealth.util.calendarSection = calendarData;		
					if(summarySection) {
						$.mobile.changePage("../../messages/view/showsummary.html");
					} else {
						$.mobile.changePage("../../messages/view/displayMessage.html");
					}			
					
				}
			} else {
				$.mobile.changePage("../../messages/view/showmessage.html");
				mHealth.util.loadMessagesBar();
				mHealth.util.hideMask();
			}
		});
		
		



			
	},
	/**
	 *Name   : showSummary
	 *Purpose: Method to show summary
	 *Params : --
	 *Return : --
	 **/
	showSummary : function() {
		$('#message_summary').append(summarySection);
	},
	/**
	 *Name   : submitAssessment
	 *Purpose: Method to submit mini assessment
	 *Params : --
	 *Return : --
	 **/
	submitAssessment : function() {	
		mHealth.util.logMessage('Inside submitAssessment method');	
		var mutliPartForm = $('#mutliPart').val();
		if(this.validateAssessment()) {
			$.mobile.loadingMessage = mHealth.Messages.loadingSubmitMessage;
			mHealth.util.showMask();
			var oForm = document.forms["messageform"];
			var answers = oForm.elements["form[answers]"];
			var questions = oForm.elements["form[questions]"];
			var requestData = {
				"saveUserFeedbackRequest" : {
					"transactionID" : '',
					"userFeedback" : {
						"messageID" : '',
						"questionResponses" : {
							"simpleQuestionResponse" : [],
							"multiPartQuestionResponse" : {
								"questionID" : "",
								"responseParts" : {
									"responsePart" : []
								}
							}
						}
					}
				}
			};
			requestData.saveUserFeedbackRequest.userFeedback['messageID'] = mHealth.util.messageID;
			requestData.saveUserFeedbackRequest['transactionID'] = new Date().getTime();
			var questionResponse = new Array();
			var length = mHealth.util.singleQuestionCount;
			for( i = 1; i <= length; i++) {
				var questionId;
				if(document.getElementById('answerId[' + i + ']')) {
					var answerId = document.getElementById('answerId[' + i + ']').value;
				}
				var setAnswerId = answerId.replace(/\{|\}/gi, '');
				if(document.getElementById('question[' + i + ']')) {
					questionId = document.getElementById('question[' + i + ']').value;
				}
				var simpleQuestionResponse = {};
				var questionResponseMap = {};
				simpleQuestionResponse["answer"] = setAnswerId;
				simpleQuestionResponse["questionID"] = questionId;
				questionResponse.push(simpleQuestionResponse);
				requestData.saveUserFeedbackRequest.userFeedback.questionResponses.simpleQuestionResponse.push(simpleQuestionResponse);
			}
			
			if(mutliPartForm == "true") {
				var multiResponse = this.formMultiRequestBody(requestData);
				requestData.saveUserFeedbackRequest.userFeedback.questionResponses.multiPartQuestionResponse = multiResponse;
			}
			var requestJSON = JSON.stringify(requestData);
			// mHealth.util.customAlert(mHealth.Messages.feedback,function(){
			this.service.postRequest(mHealth.env.messagefeedback_url, requestJSON, this.postMessageSuccess, this.postMessageFailure, false);

			// });
			

		}
	},
	/**
	 *Name   : postMessageSuccess
	 *Purpose: Method on success of post feedback
	 *Params : --
	 *Return : --
	 **/
	postMessageSuccess : function(output) {
		mHealth.util.logMessage('Inside postMessageSuccess method');	
		mHealth.util.hideMask();
		$.mobile.loadingMessage = mHealth.Messages.loadingMessage;
		$.mobile.changePage("../../home/view/home.html");
		mHealth.util.loadHomeBar();
	},
	/**
	 *Name   : postMessageFailure
	 *Purpose: Method on failure of post feedback
	 *Params : --
	 *Return : --
	 **/
	postMessageFailure : function() {
		mHealth.util.logMessage('Inside postMessageFailure method');	
		mHealth.util.hideMask();
		$.mobile.loadingMessage = mHealth.Messages.loadingMessage;
		$.mobile.changePage("../../home/view/home.html");
		mHealth.util.loadHomeBar();	
	},
	
	/**
	 *Name   : validateAssessment
	 *Purpose: Method to validate submit response
	 *Params : --
	 *Return : --
	 **/
	displayAlert : function(message) {
		mHealth.util.logMessage('Inside displayAlert method');	
		mHealth.util.customAlert(message, '');
		return true;

	},
		
	/**
	 *Name   : validateAssessment
	 *Purpose: Method to validate submit response
	 *Params : --
	 *Return : --
	 **/
	validateAssessment : function() {
		mHealth.util.logMessage('Inside validateAssessment method');	
		if(this.validateParticipantAnswer() && this.validateEmpoweredHTWT() && this.validateEmpoweredA1cDia()) {
			return true;
		} else {
			return false;
		}
	},
	/**
	 *Name   : formMultiRequestBody
	 *Purpose: Method to form request body for multi response
	 *Params : --
	 *Return : --
	 **/
	formMultiRequestBody : function(reqData) {
		mHealth.util.logMessage('Inside formMultiRequestBody method');	
		var requestData = {};
		var mutliPartResponse = new Array();
		requestData["questionID"] = $('#groupHtWtId').val();
		var questionMultiResponseMap = [];
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.HTWTDT';
		var htDate = this.getDateFormat('answerDateId');
		multiQuestionResponse["value"] = htDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.HT';
		var totalInches = '' + (Number($('#answerHtFtId').val()) * 12 + Number($('#answerHtInId').val()) );
		multiQuestionResponse["value"] = totalInches;
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.WT';
		multiQuestionResponse["value"] = $('#answerIdWtId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		requestData["responsePart"] = questionMultiResponseMap;
		mutliPartResponse.push(requestData);
		requestData = {};
		questionMultiResponseMap = [];
		multiQuestionResponse = {};
		requestData["questionID"] = $('#groupA1cId').val();
		multiQuestionResponse["name"] = 'PT.HD.TESTS.A1C.TAKEN';
		multiQuestionResponse["value"] = $('#answerA1cId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.A1C.DATE';
		var a1cDate = mHealth.util.getDateFormatOnly('answerA1cDateId');
		multiQuestionResponse["value"] = a1cDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.A1C.VALUE';
		multiQuestionResponse["value"] = $('#answerTxtA1cId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		requestData["responsePart"] = questionMultiResponseMap;
		mutliPartResponse.push(requestData);
		requestData = {};
		questionMultiResponseMap = [];
		multiQuestionResponse = {};
		requestData["questionID"] = $('#groupChoId').val();
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.TAKEN';
		multiQuestionResponse["value"] = $('#answerChoId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.DATE';
		var choDate = mHealth.util.getDateFormatOnly('answerChoDateId');
		multiQuestionResponse["value"] = choDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.LDL';
		multiQuestionResponse["value"] = $('#answerTxtLDLId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.HDL';
		multiQuestionResponse["value"] = $('#answerTxtHDLId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.TRIG';
		multiQuestionResponse["value"] = $('#answerTxtTriId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.TOTAL';
		multiQuestionResponse["value"] = $('#answerTxtTotalId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		requestData["responsePart"] = questionMultiResponseMap;
		mutliPartResponse.push(requestData);
		requestData = {};
		questionMultiResponseMap = [];
		multiQuestionResponse = {};
		requestData["questionID"] = $('#groupDiaId').val();
		multiQuestionResponse["name"] = 'PT.HD.TESTS.DIALATED.TAKEN';
		if(mHealth.util.answerDiaId==undefined)
		{
			mHealth.util.answerDiaId='NoTest';
		}
		multiQuestionResponse["value"] = mHealth.util.answerDiaId;
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.DIALATED.DATE';
		var diaDate = mHealth.util.getDateFormatOnly('answerDiaDateId');
		multiQuestionResponse["value"] = diaDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.FOOT.TAKEN';
		if(mHealth.util.answerDiaFootId==undefined)
		{
			mHealth.util.answerDiaFootId='NoTest';
		}
		multiQuestionResponse["value"] = mHealth.util.answerDiaFootId;
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.FOOT.DATE';
		var footDate =  mHealth.util.getDateFormatOnly('answerFootDateId');
		multiQuestionResponse["value"] = footDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.MICROALBUMIN.TAKEN';
		if(mHealth.util.answerMicroId==undefined)
		{
			mHealth.util.answerMicroId='NoTest';
		}
		multiQuestionResponse["value"] = mHealth.util.answerMicroId;
		questionMultiResponseMap.push(multiQuestionResponse);
		multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.MICROALBUMIN.DATE';
		var microDate =  mHealth.util.getDateFormatOnly('answerMicroDateId');
		multiQuestionResponse["value"] = microDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		requestData["responsePart"] = questionMultiResponseMap;
		mutliPartResponse.push(requestData);
		return mutliPartResponse
	},
	/**
	 *Name: getMeasurementDate
	 *Purpose: formats the measurement date to be passed as a parameter for health data object
	 *Params: Date field id
	 *Returns: returns formatted date object
	 **/
	getDateFormat : function(dateValue) {
		mHealth.util.logMessage('Inside getDateFormat method');	
		var dateSelected = $('#' + dateValue + '').val();
		if(dateSelected != "") {
			var dateFormat = mHealth.util.getDateFormat(dateSelected);
			return dateFormat;
		}
		return '';
	},
	/**
	 *Name   : validateParticipantAnswer
	 *Purpose: Method to validate Participant Answer
	 *Params : Number of question
	 *Return : --
	 **/
	validateParticipantAnswer : function() {
		mHealth.util.logMessage('Inside validateParticipantAnswer method');	
		var question1, question2, question3;
		if(document.getElementById("answerId[1]")) {
			question1 = document.getElementById("answerId[1]").value;
		}
		if(document.getElementById("answerId[2]")) {
			question2 = document.getElementById("answerId[2]").value;
		}
		if(document.getElementById("answerId[3]")) {
			question3 = document.getElementById("answerId[3]").value;
		}
		if(question1 == "default" && question2 == "default" && question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidAssessment, '');
			return false;
		}
		if(question1 == "default") {
            if(mHealth.util.messageTypeID==3){
				mHealth.util.customAlert(mHealth.Validation.invalidFirstQuesAssessment, '');
            }                
            else{
				mHealth.util.customAlert(mHealth.Validation.invalidQuesAssessment, '');
            }
            //document.getElementById("answerId[1]").focus();
            return false;
		}
		if(question2 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidSecondQuesAssessment, '');
            //document.getElementById("answerId[2]").focus();
			return false;
		}
		if(question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidThirdQuesAssessment, '');
            //document.getElementById("answerId[3]").focus();
			return false;
		}
		return true;
	},
	/**
	 * Name    : loadMessageTab1
	 * Purpose : To deal webservice failure scenario
	 * Params  : --
	 * Return  : --
	 **/
	loadMessageTab1 : function() {
		mHealth.util.logMessage('Inside loadMessageTab1 method');	
		mHealth.util.hideMask();
		$.mobile.changePage("../../messages/view/showmessage.html");
		mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');
		mHealth.util.loadMessagesBar();
	},
	/**
	 * Name    : renderMessage
	 * Purpose : Method to render data on html page
	 * Params  : --
	 * Return  : --
	 **/
	renderMessage : function() {
			mHealth.util.logMessage('Inside renderMessage method');	
		var len = mHealth.models.MessageQuestionModel.count();		
		if(len >= 0) {
			var messageType = 1;
			var title = "";
			mHealth.models.MessageDetailsModel.each(function(message) {
				messageType = message.msgTypeID;
				mHealth.util.messageTypeID=messageType;
				title = message.title;
			});
			var displayViewMessages = "";
			var calendarResponse = "";
			var messageIDVal = "";
			var messageData = mHealth.util.messageID;
			var calendarData = mHealth.util.calendarSection;
			if (calendarData == "true") {
			mHealth.models.MessageDetailsModel.each(function(message) {
			if(message.cachedPersonalizedMessage) {
				if(message.cachedPersonalizedMessage.messageContent && message.cachedPersonalizedMessage.messageContent.sections && message.cachedPersonalizedMessage.messageContent.sections.section) {
					var sectionData = message.cachedPersonalizedMessage.messageContent.sections.section;
					var sectionResponse = JSON.stringify(sectionData);
					var sectionsData = JSON.parse(sectionResponse);
					var sectionLength = sectionData.length;

					if(sectionData.length != 0) {
						sectionData.map(function(sections) {
							if(sections) {
								calendarSection = [];
								if(sections.suggestedCalendarEvent) {
									if(sections.suggestedCalendarEvent.desc != "") {
										calendarSection.push(sections.suggestedCalendarEvent);
									}
								}
							}
						});
					}
				}
			}
		});
		}
		//calendarData = calendarSection[0].desc;
		calendarData = JSON.stringify(calendarSection);; 
			//alert('calendarSection == ' +  calendarData);
			
			//calendarData=$.base64Decode(calendarData);
			if(calendarData && calendarData != undefined && calendarData != "undefined") {
				calendarResponse = JSON.parse(calendarData);
			}
			switch(messageType) {
				case "3":
					displayViewMessages = mHealth.assessment.generate_assesment("", calendarResponse);
					break;
				case "2":
					displayViewMessages = mHealth.assessment.generate_messageDetailsHtml("", calendarResponse);
					break;
				default:
					displayViewMessages = mHealth.assessment.generate_messageDetailsHtml("", calendarResponse);
					break;
			}
			//displayViewMessages = displayViewMessages.replace('\'', '&quot;');
			$('#messagedetails').append(displayViewMessages);
			if(messageIDVal) {
				messageIDVal = JSON.parse(messageData);
			}
			if(messageIDVal) {
				$('#messageID_data').html(_.template($('#msgDetails').html(), {
					messageID : messageIDVal
				}));
				$('#messageID_data').trigger('create');
			}//TODO : Commentting the following as length comes a undefined
			//if(calendarResponse != null && calendarResponse.length > 0 && calendarResponse[0] != null) {
			if(calendarResponse) {
				$('#show_calendar').html(_.template($('#calendarList').html(), {
					calendarResponse : calendarResponse
				}));
				$('#show_calendar').trigger('create');
			}
			// $('.mobiscroll').scroller({
				// preset : 'datetime',
				// seconds : true,
				// timeFormat : 'hh:ii A',
				// theme : 'ios',
				// beforeShow : function(input, inst) {
					// if (isIOS) {
					// $('#detailMessage').css('-webkit-backface-visibility','visible');
					// }
					// mHealth.util.hideTabBar();
// 
				// },
				// onClose : function(valueText, inst) {
					// if (isIOS) {
					// $('#detailMessage').css('-webkit-backface-visibility','hidden');
					// }
					// mHealth.util.showTabBar();
				// }
			// });
			submitFlow = "true";
			isSubmitted = mHealth.util.isSubmitted;
			if(len == 0) {
				submitFlow = "false";
				isSubmitted ="true";
			}
			if(mHealth.util.messageTypeValue==undefined){
			mHealth.util.messageTypeValue='messages'	
			}
			$('#showmessagecontent').html(_.template($('#showmessagetemplate').html(), {
				loginWorkflow : submitFlow,
				msgFolderId : msgFolderId,
				isSubmitted :isSubmitted,
				messageType :mHealth.util.messageTypeValue
			}));
			$('#showmessagecontent').trigger('create');
			$('#showmessagecontent1').html(_.template($('#showmessagetemplate1').html(), {
				loginWorkflow : submitFlow,
				msgFolderId : msgFolderId,
				isSubmitted :isSubmitted,
				messageType :mHealth.util.messageTypeValue
			}));
			$('#showmessagecontent1').trigger('create');
		} else {
			var message = mHealth.Messages.noMessage;
			$('#messagedetails').text(message);
			$('#showmessagecontent').html(_.template($('#showmessagetemplate').html(), {
				loginWorkflow : "false",
				msgFolderId : msgFolderId,
				isSubmitted :isSubmitted,
				messageType :mHealth.util.messageTypeValue
			}));
			$('#showmessagecontent').trigger('create');
			$('#showmessagecontent1').html(_.template($('#showmessagetemplate1').html(), {
				loginWorkflow : "false",
				msgFolderId : msgFolderId,
				isSubmitted :isSubmitted,
				messageType :mHealth.util.messageTypeValue
			}));
			$('#showmessagecontent1').trigger('create');
		}
		$('#messagedetails').trigger('create');
		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}
	},
	/**
	 * Name    : setHeight
	 * Purpose : Method to set height units
	 * Params  : --
	 * Returns : --
	 **/
	setHeight : function(height_unit, index) {
		mHealth.util.logMessage('Inside setHeight method');	
		var heightResponse = new Array();
		var heightIncr = 1;
		var heightUS = 36;
		var heightMetric = heightUS * 2.54;
		for( i = 0; i < 61; i++) {
			var feet = parseInt(heightUS / 12);
			var inch = heightUS % 12;
			var options = {};
			if(height_unit == mHealth.Messages.ftInch) {
				options["value"] = feet + " ft. " + inch + " in.";
				options["units"] = heightUS;
			} else {
				heightMetric = heightUS * 2.54;
				options["value"] = Math.round(heightMetric) + " cm";
				options["units"] = heightUS;
			}
			heightUS += heightIncr;
			heightResponse.push(options);
		}
		return heightResponse;
	},
	/**
	 * Name    : processHeightData
	 * Purpose : Method to process height units
	 * Params  : --
	 * Returns : --
	 **/
	processHeightData : function() {
		mHealth.util.logMessage('Inside processHeightData method');	
		var index = "30";
		if(mHealth.util.selUnits == undefined || mHealth.util.selUnits == mHealth.Messages.ftInch) {
			return this.setHeight(mHealth.Messages.ftInch, index);
		}
	},
	/**
	 * Name    : getMessages
	 * Purpose : Load the message from the Model and Show the Result in the  Message Tab
	 * Params  : --
	 * Return  : --
	 **/
	getMessages : function() {
		mHealth.util.logMessage('Inside getMessages method');	
		var len = mHealth.models.MessageModel.count();
		var messages_val = mHealth.models.MessageModel.all();				
		if(len < 0) {
			messages_val = mHealth.Messages.noMessage;
		}
		$('#message').html(_.template($('#messageList1').html(), {
			messages_val : messages_val
		}));
		$('#showMessage').trigger('create');
	},
	/**
	 * Name    : loadMessageTab
	 * Purpose : Highlight the Message when we redirect the shorcut from the Home to message TAB.
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageTab : function() {
		mHealth.util.logMessage('Inside loadMessageTab method');	
		$.mobile.changePage("../../messages/view/showmessage.html");
		mHealth.util.loadMessagesBar();
	},
	/**
	 *Name: getSortData
	 *Purpose: sorts the messages based on sent date.
	 *Params: messages to be sorted is passed as param
	 *Returns: returns the sorted messages
	 **/
	getSortData : function(msgData) {
		mHealth.util.logMessage('Inside getSortData method');	
		var keys = [];
		var sortedData = [];
		for(var i in msgData) {
			keys[i] = [];
			keys[i][0] = msgData[i]["sentDate"];
			keys[i][1] = i;
		}
		keys.sort();
		keys.reverse();
		for(var i in keys) {
			sortedData.push(msgData[keys[i][1]]);
		}
		return sortedData;
	},
	/**
	 *Name: changeFields
	 *Purpose: Method to hide/shoe of empowered fields
	 *Params: --
	 *Returns: --
	 **/
	changeFields : function(event) {
		mHealth.util.logMessage('Inside changeFields method');	
		var selectId = event.target.id
		if(selectId == 'answerA1cId') {
			var optvalue = $('select#answerA1cId option:selected').val();
			if(optvalue == mHealth.AssesmentEntry.dropdownOption1Value || optvalue == 'default') {
				$('#answerA1cDateId').hide();
				$('#answerTxtA1cId').hide();
				$('#answerA1cDateId').val("");
				$('#answerTxtA1cId').val("");
			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption3Value) {
				$('#answerA1cDateId').show();
				$('#answerTxtA1cId').show();

			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption2Value) {
				$('#answerA1cDateId').show();
				$('#answerTxtA1cId').hide();
				$('#answerTxtA1cId').val("");
			}
		} else if(selectId == 'answerChoId') {
			var optvalue = $('select#answerChoId option:selected').val();
			if(optvalue == mHealth.AssesmentEntry.dropdownOption1Value || optvalue == 'default') {
				$('#answerChoDateId').hide();
				$('#answerTxtLDLId').hide();
				$('#answerTxtHDLId').hide();
				$('#answerTxtTriId').hide();
				$('#answerTxtTotalId').hide();
				$('#answerTxtLDLId').val("");
				$('#answerTxtHDLId').val("");
				$('#answerTxtTriId').val("");
				$('#answerTxtTotalId').val("");
				$('#answerChoDateId').val("");
			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption2Value) {
				$('#answerChoDateId').show();
				$('#answerTxtLDLId').hide();
				$('#answerTxtHDLId').hide();
				$('#answerTxtTriId').hide();
				$('#answerTxtTotalId').hide();
				$('#answerTxtLDLId').val("");
				$('#answerTxtHDLId').val("");
				$('#answerTxtTriId').val("");
				$('#answerTxtTotalId').val("");
			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption3Value) {
				$('#answerTxtLDLId').show();
				$('#answerTxtHDLId').show();
				$('#answerTxtTriId').show();
				$('#answerTxtTotalId').show();
				$('#answerChoDateId').show();
			}
		} else if(selectId == 'answerDiaId') {
            var optvalue = $("#answerDiaId").is(":checked");
            if(optvalue == false) {
				$('#answerDiaDateId').hide();
                $('#answerDiaDateId').val(null);
				mHealth.util.answerDiaId='NoTest';
                                                             
			} else if(optvalue == true) {
				$('#answerDiaDateId').show();
				mHealth.util.answerDiaId='TestedHaveDate'
			}
		} else if(selectId == 'answerDiaFootId') {
			var optvalue =$("#answerDiaFootId").is(":checked");
            if(optvalue == false) {
				$('#answerFootDateId').hide();
                $('#answerFootDateId').val(null);
				mHealth.util.answerDiaFootId='NoTest';
			} else if(optvalue == true) {
				$('#answerFootDateId').show();
				mHealth.util.answerDiaFootId='TestedHaveDate';
			}
		} else if(selectId == 'answerMicroId') {
			var optvalue = $("#answerMicroId").is(":checked");
            if(optvalue == false) {
				$('#answerMicroDateId').hide();
                $('#answerMicroDateId').val(null);
				mHealth.util.answerMicroId='NoTest';
			} else if(optvalue == true) {
				$('#answerMicroDateId').show();
				mHealth.util.answerMicroId='TestedHaveDate';
			}
		}
		$('#detailMessage').css({
			'height' :'auto'
		});
		$('#detailMessage').trigger('create');
	},
	/**
	 *Name : showCalendarPage
	 *Purpose : Show clendar page
	 *Params: --
	 *Returns: --
	 **/
	showCalendarPage : function(event) {
		mHealth.util.logMessage('Inside showCalendarPage method');	
		var eventTarget = event.target;
		var calendarName = $(eventTarget).parents().parents().children('input[type="hidden"]').val();
		if(isIOS){
			$.mobile.changePage("../../messages/view/messagecalendar.html", {
				data : {
					calendarName : calendarName
				}
			});
		} else if(isAndroid) {
			mHealth.util.nativeCalendar(calendarName);
		}
		mHealth.util.loadMessagesBar();
	},
	/**
	 *Name : showCalendar
	 *Purpose : Show clendar page
	 *Params: --
	 *Returns: --
	 **/
	showCalendar : function() {
		mHealth.util.logMessage('Inside showCalendar method');	
		var activePage = $('div[id = "messageCalendarPage"]').attr('data-url');
		var calendarDesc = mHealth.util.getParameterByName('calendarName', activePage);
		$("#reminderName").val(calendarDesc);
		mHealth.util.showCalendar();
	},
	/**
	 * Name    : saveCalendar
	 * Purpose : Method to save the controller
	 * Params  : --
	 * Return  : --
	 **/
	saveCalendar : function(event) {
		mHealth.util.logMessage('Inside saveCalendar method');	
		var title, startDate, endDate;
		title = $('#reminderName').val();
		startDate = $('#startDate').val();
		endDate = $('#endDate').val();
		if(title == "" || startDate == "" || endDate == "") {
			mHealth.util.customAlert(mHealth.Validation.emptyValidation, function() {
				event.preventDefault();
			});
		} else {
			if(startDate > endDate) {
				mHealth.util.customAlert(mHealth.Validation.invalidDate, function() {
					event.preventDefault();
				});
			} else {
				mHealth.util.callCalendar(title, startDate, endDate);
				$.mobile.changePage("../../messages/view/showmessage.html");
				mHealth.util.loadMessagesBar();
			}
		}
	},
	/**
	 * Name    : saveCalendar
	 * Purpose : Method to save the controller
	 * Params  : --
	 * Return  : --
	 **/
	cancelCalendar : function() {
		mHealth.util.logMessage('Inside cancelCalendar method');	
		mHealth.util.showMask();
		var messagesDetail = mHealth.models.MessageDetailsModel.first();
		var messageID = messagesDetail.messageID;
		var URL = mHealth.env.messagedetails_url + messageID;
		this.proxy(this.service.getResponse(URL, mHealth.MessageControllerObject.displayMessage, mHealth.MessageControllerObject.loadMessageTab1, true));
		mHealth.util.loadMessagesBar();
	},
	/**
	 * Name    : validateEmpoweredHTWT
	 * Purpose : Method to validate height empowered fields
	 * Params  : --
	 * Return  : --
	 **/
//                        invalidHtWt  : "Please enter your Height and Weight.",
//                        selectDateforHtWt : "Please select Height and Weight date.",
//                        selectHtFt : "Please enter your Height in Ft.",
//                        selectHtIn : "Please enter your Height in inches.",
//                        selectWt   : "Please enter your Weight.",
    
	validateEmpoweredHTWT : function() {
		mHealth.util.logMessage('Inside validateEmpoweredHTWT method');	
		if($('#answerDateId').val() == "" && $('#answerHtFtId').val() == "" && $('#answerHtInId').val() == "" && $('#answerIdWtId').val() == "")
        {
            mHealth.util.customAlert(mHealth.Messages.selectDateforHtWt,function(){$('#answerDateId').focus();});
            setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
            setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
            setTimeout("$('input').blur()", 1);
            setTimeout("$('select').blur()", 1);
            return false;
        }
        else if($('#answerHtFtId').val() == "" && $('#answerHtInId').val() == "" && $('#answerIdWtId').val() == "" )
        {
            mHealth.util.customAlert(mHealth.Messages.invalidHtWt,function(){$('#answerHtFtId').focus();});
            setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
            setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
            setTimeout("$('input').blur()", 1);
            setTimeout("$('select').blur()", 1);
            
            return false;
        }
        else if($('#answerHtFtId').val() == "" && $('#answerHtInId').val() == "" )
        {
        mHealth.util.customAlert(mHealth.Messages.selectHt,function(){$('#answerHtFtId').focus();});
	        setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
	        setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
	        setTimeout("$('input').blur()", 1);
	        setTimeout("$('select').blur()", 1);
        return false;
        }
                                
        else if($('#answerHtFtId').val() == "")
        {
            mHealth.util.customAlert(mHealth.Messages.selectHtFt,function(){$('#answerHtFtId').focus();});
            setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
            setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
            setTimeout("$('input').blur()", 1);
            setTimeout("$('select').blur()", 1);
            return false;
        }
        else if($('#answerHtInId').val() == "")
        {
            mHealth.util.customAlert(mHealth.Messages.selectHtIn,function(){$('#answerHtInId').focus();});
            setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
            setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
            setTimeout("$('input').blur()", 1);
            setTimeout("$('select').blur()", 1);
            return false;
        }
        else if($('#answerIdWtId').val() == "")
        {
            mHealth.util.customAlert(mHealth.Messages.selectWt,function(){$('#answerIdWtId').focus();});
            setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
            setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
            setTimeout("$('input').blur()", 1);
            setTimeout("$('select').blur()", 1);
            return false;
        }
        else if($('#answerDateId').val() == "")
        {
            //mHealth.util.customAlert(mHealth.Messages.selectDateforHtWt, '');
            mHealth.util.customAlert(mHealth.Messages.selectDateforHtWt,function(){$('#answerDateId').focus();});
            setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
            setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
            setTimeout("$('input').blur()", 1);
            setTimeout("$('select').blur()", 1);
            return false;
        }
        else {
			return true;
		}
	},
	/**
	 * Name    : validateEmpoweredDia
	 * Purpose : Method to validate Diabetes empowered fields
	 * Params  : --
	 * Return  : --
	 **/
    //  selectA1C  : "Have you had A1c test?.",
    //  selectA1Cdate  : "Please select A1c test date.",
    //  selectCholesterol : "Have you had Cholesterol test?.",
    //  selectCholesteroldate : "Please select Cholesterol test date.",                                                         

	validateEmpoweredA1cDia : function() {
		mHealth.util.logMessage('Inside validateEmpoweredA1cDia method');	
        if($('#answerA1cId').val() == "default"){
            //mHealth.util.customAlert(mHealth.Messages.selectA1C, '');
            mHealth.util.customAlert(mHealth.Messages.selectA1C,function(){$('#answerA1cId').focus();});
            setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
            setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
            setTimeout("$('input').blur()", 1);
            setTimeout("$('select').blur()", 1);
            return false;
		}
                     
        if($('#answerA1cId').val() == mHealth.AssesmentEntry.dropdownOption2Value) {
			if($('#answerA1cDateId').val() == "") {
				mHealth.util.customAlert(mHealth.Messages.selectA1Cdate,function(){$('#answerA1cDateId').focus();});
                setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
                setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
                setTimeout("$('input').blur()", 1);
                setTimeout("$('select').blur()", 1);
                return false;
			}
		} 
        if($('#answerA1cId').val() == mHealth.AssesmentEntry.dropdownOption3Value) { 
			if($('#answerA1cDateId').val() == "" && $('#answerTxtA1cId').val() == "") {
				mHealth.util.customAlert(mHealth.Messages.selectA1CdateValue,function(){$('#answerA1cDateId').focus();});
                setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
                setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
                setTimeout("$('input').blur()", 1);
                setTimeout("$('select').blur()", 1);
                return false;
            }
            else if ($('#answerA1cDateId').val() == "")
            {
                mHealth.util.customAlert(mHealth.Messages.selectA1Cdate,function(){$('#answerA1cDateId').focus();});
                setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
                setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
                setTimeout("$('input').blur()", 1);
                setTimeout("$('select').blur()", 1);
                return false;                                          
            }
            else if ($('#answerTxtA1cId').val() == "")
            {
                mHealth.util.customAlert(mHealth.Messages.selectA1CValue,function(){$('#answerTxtA1cId').focus();});
                setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
                setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
                setTimeout("$('input').blur()", 1);
                setTimeout("$('select').blur()", 1);
                return false;                                          
            }
		}
		
        if($('#answerChoId').val() == "default") {
	         mHealth.util.customAlert(mHealth.Messages.selectCholesterol,function(){$('#answerChoId').focus();});
	         setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
	         setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
	         setTimeout("$('input').blur()", 1);
	         setTimeout("$('select').blur()", 1);
	         return false;
        }

        if($('#answerChoId').val() == mHealth.AssesmentEntry.dropdownOption2Value) {
			if($('#answerChoDateId').val() == "") {
				mHealth.util.customAlert(mHealth.Messages.selectCholesteroldate,function(){$('#answerChoDateId').focus();});
                setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
                setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
                setTimeout("$('input').blur()", 1);
                setTimeout("$('select').blur()", 1);
                                       
				return false;
			}
		} 
        if($('#answerChoId').val() == mHealth.AssesmentEntry.dropdownOption3Value) {
         if($('#answerChoDateId').val() == "" && ($('#answerTxtLDLId').val() == "") && ($('#answerTxtHDLId').val() == "" ) && ($('#answerTxtTriId').val() == "") && ($('#answerTxtTotalId').val() == "")) {
	         mHealth.util.customAlert(mHealth.Messages.selectCholesteroldateValue,function(){$('#answerA1cDateId').focus();});
	         setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
	         setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
	         setTimeout("$('input').blur()", 1);
	         setTimeout("$('select').blur()", 1);
	         return false;
         }
         else if($('#answerChoDateId').val() == "") {
             mHealth.util.customAlert(mHealth.Messages.selectCholesteroldate,function(){$('#answerChoDateId').focus();});
             setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
             setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
             setTimeout("$('input').blur()", 1);
             setTimeout("$('select').blur()", 1);
             return false;
        }                                                             
        if( ($('#answerTxtLDLId').val() == "") && ($('#answerTxtHDLId').val() == "" ) && ($('#answerTxtTriId').val() == "") && ($('#answerTxtTotalId').val() == "")) { 
            mHealth.util.customAlert(mHealth.Messages.selectCholesterolValue,function(){$('#answerTxtLDLId').focus();});
            setTimeout("$('#submitButton').removeClass('ui-btn-active')", 100);
            setTimeout("$('#submitButton1').removeClass('ui-btn-active')", 100);
            setTimeout("$('input').blur()", 1);
            setTimeout("$('select').blur()", 1);
			return false;
		}
		}
    
        if(mHealth.util.answerDiaId  == mHealth.AssesmentEntry.dropdownOption4Value) {
			if($('#answerDiaDateId').val() == "") {
				mHealth.util.customAlert(mHealth.Messages.retinalDate, '');
                $('#answerDiaDateId').focus();
				return false;
			}
		}
        if(mHealth.util.answerDiaFootId  == mHealth.AssesmentEntry.dropdownOption4Value) {
			if($('#answerFootDateId').val() == "") {
				mHealth.util.customAlert(mHealth.Messages.footDate, '');
                $('#answerFootDateId').focus();
				return false;
			}
		}
        if(mHealth.util.answerMicroId  == mHealth.AssesmentEntry.dropdownOption4Value) {
			if($('#answerMicroDateId').val() == "") {
				mHealth.util.customAlert(mHealth.Messages.microAlbuminDate, '');
                $('#answerMicroDateId').focus();
				return false;
			}
		}
		return true;
	},
	/**
	 * Name    : archiveMessage
	 * Purpose : Method to archieve message
	 * Params  : --
	 * Return  : --
	 **/
	archiveMessage : function (){	
		mHealth.util.logMessage('Inside archiveMessage method');	
		mHealth.util.customPrompt(mHealth.Messages.archiveConfirm, function() {
		}, function() {
		var messageId = mHealth.util.messageID;	
		mHealth.MessageControllerObject.updateMessage(messageId,'archive');	
			});		
	},
	/**
	 * Name    : changeMsgList
	 * Purpose : Method to display list of message / archive based on the user selected value.
	 * Params  : --
	 * Return  : --
	 **/
	changeMsgList : function(){
		mHealth.util.logMessage('Inside changeMsgList method');	
		messageTypeValue = $('select#msgHeader option:selected').val();		
		mHealth.util.messageTypeValue=messageTypeValue;		
		if(messageTypeValue == "messages"){									
			this.loadMessageTabBar();	
			messagearchive = "messages";
		} else if (messageTypeValue == "archive"){
			this.getArchiveMessage();
			messagearchive = "archive";
		}
	},
	
	/**
	 * Name    : getArchiveMessage
	 * Purpose : Method to display list of archive messages
	 * Params  : --
	 * Return  : --
	 **/
	getArchiveMessage : function(){ 
		mHealth.util.logMessage('Inside getArchiveMessage method');	
		mHealth.util.showMask();
		var url = mHealth.env.messageheaders_url+"?folder=4";
		this.service.getResponse(url, this.loadArchiveMessage, this.loadArchiveMessageFailure);
	},
	/**
	 * Name    : loadArchiveMessage
	 * Purpose : Method on success of archive messages
	 * Params  : --
	 * Return  : --
	 **/
	loadArchiveMessage : function(output){
		mHealth.util.logMessage('Inside loadArchiveMessage method');	
        var response = JSON.parse(output.responseText);
        var archiveMessageCount = response[0].totalMessageCount;
        if(archiveMessageCount > 0)
        {
            mHealth.MessageControllerObject.loadArchives(output);
        }
        $.mobile.changePage("../../messages/view/showarchive.html");
       mHealth.util.loadMessagesBar();
       mHealth.util.hideMask();
	},
	/**
	 * Name    : loadArchives
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	loadArchives : function(output) {
		mHealth.util.logMessage('Inside loadArchives method');	
		var response = output.responseText;	
    	mHealth.models.ArchiveModel.destroyAll();
		if(response != null && response.length > 0) {
			var bundleMessage = JSON.parse(response);
			var messages = JSON.stringify(bundleMessage[0].Message);
			var sortedData = mHealth.MessageControllerObject.getSortData(JSON.parse(messages));
			mHealth.models.ArchiveModel.customFromJSON(sortedData);
		}		
    },
	/**
	 * Name    : loadArchiveMessageFailure
	 * Purpose : Method on failure of archive messages
	 * Params  : --
	 * Return  : --
	 **/
	loadArchiveMessageFailure : function(){
		mHealth.util.logMessage('Inside loadArchiveMessageFailure method');	
		//TODO : To handle failure
		mHealth.util.hideMask();
		$.mobile.changePage("../../messages/view/showmessage.html");
		mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');
		$("select#msgHeader option[value='messages']").attr("selected","selected");
        $('select#msgHeader').selectmenu('refresh', true);
		mHealth.util.loadMessagesBar();
	},
	/**
	 * Name    : getArchives
	 * Purpose : Load the archive message from the Model and Show the Result in the  Message Tab
	 * Params  : --
	 * Return  : --
	 **/
	getArchives : function() {
		mHealth.util.logMessage('Inside getArchives method');	
		var len = mHealth.models.ArchiveModel.count();
		var archive_val = mHealth.models.ArchiveModel.all();		
		if(len < 0) {
			archive_val = mHealth.Messages.noMessage;
		}
		$('#archive').html(_.template($('#archiveList').html(), {
			archive_val : archive_val
		}));
		$('#showArchive').trigger('create');
	},
	/**
	 * Name    : populateAnswer
	 * Purpose : populate the fields with answer
	 * Params  : --
	 * Return  : --
	 **/
	populateAnswer:function(){
		mHealth.util.logMessage('Inside populateAnswer method');	
		var getAnswers=[],getQuesSubID=[];
		mHealth.util.getSingleAnswer = mHealth.models.UserFeedbackModel.findByAttribute('questionID', '10001');
	if(mHealth.util.getSingleAnswer==null){
		mHealth.util.getSingleAnswer = mHealth.models.UserFeedbackModel.findByAttribute('questionID', '10002');
	}
			var getHeightWeight = mHealth.models.UserFeedbackModel.findAllByAttribute('questionID', '8004');
			getHeightWeight.map(function(val,key){
				htWtVal = val.answer;
				if (htWtVal != "" && val.questionSubID == "PT.HD.HTWTDT") {
					utcSec = Date.UTC(htWtVal.substr(0,4),htWtVal.substr(4,2)-1,htWtVal.substr(6,2),htWtVal.substr(9,2),htWtVal.substr(11,2));
	        		htWtVal = new Date(utcSec).format(mHealth.pegadateformat);

				}
				getAnswers.push(htWtVal);
				getQuesSubID.push(val.questionSubID);
			});
			var getA1c = mHealth.models.UserFeedbackModel.findAllByAttribute('questionID', '8009');
			var a1cFlag=false;
			getA1c.map(function(val,key){			
				if(val.questionSubID=='PT.HD.TESTS.A1C.TAKEN')
				{
					mHealth.util.getA1cAnswer=val.answer;
					a1cFlag=true;
				}
				getAnswers.push(val.answer); 	
				getQuesSubID.push(val.questionSubID);	
				});
			var getCholesterol = mHealth.models.UserFeedbackModel.findAllByAttribute('questionID', '8015');
			var cholFlag=false;
			getCholesterol.map(function(val,key){
				if(val.questionSubID=='PT.HD.TESTS.CHOL.TAKEN')
				{
					mHealth.util.getCholAnswer=val.answer;
					cholFlag=true;
				}
				getAnswers.push(val.answer);
				getQuesSubID.push(val.questionSubID);	
			});
			var getLabTest = mHealth.models.UserFeedbackModel.findAllByAttribute('questionID', '8016');
			getLabTest.map(function(val,key){
				getAnswers.push(val.answer);
				getQuesSubID.push(val.questionSubID);	
			});
			mHealth.util.getFirstAnswer=mHealth.models.UserFeedbackModel.findByAttribute('questionID', '8001');		
			mHealth.util.getSecondAnswer=mHealth.models.UserFeedbackModel.findByAttribute('questionID', '8002');
			mHealth.util.getThirdAnswer=mHealth.models.UserFeedbackModel.findByAttribute('questionID', '8003');
			$.each($('input,select', '#detailMessage'), function(k) {
				
			if($(this).attr('type') == 'text') {
				for(var i=0;i<getQuesSubID.length;i++){
				if($(this).attr('name')==getQuesSubID[i]){
					if(getAnswers[i]!=undefined){
					getAnswers[i]=mHealth.util.parseDateString(getAnswers[i]);
					}
				$(this).val(getAnswers[i]);
				$(this).textinput('disable');
				break;
				}
				}
			}
			else if($(this).attr('type') == 'number') {
				for(var i=0;i<getQuesSubID.length;i++){
					if($(this).attr('name')==getQuesSubID[i]){
						$(this).val(getAnswers[i]);
						$(this).textinput('disable');
					}
					if(getQuesSubID[i]=='PT.HD.HT'){
						var feet=getAnswers[i]/12;
						feet=mHealth.util.truncate(feet);
						var inches=getAnswers[i]%12;
						if($(this).attr('name')=='PT.HD.HT.FT'){
							$(this).val(feet);
							$(this).textinput('disable');
						}
						if($(this).attr('name')=='PT.HD.HT.IN'){
							$(this).val(inches);
							$(this).textinput('disable');
						}
						
					}
				}	
				}
			else if($(this).attr('type') == 'checkbox'){
				for(var i=0;i<getQuesSubID.length;i++){
				if($(this).attr('name')==getQuesSubID[i]){
					if(getAnswers[i]=='TestedHaveDate'){
						$(this).attr("checked",true).checkboxradio("refresh");
						var getID=$(this).attr('id');
						mHealth.MessageControllerObject.updateCheckBox(getID);
					}
				}
				}
			}
		});
	},
	/**
	 * Name    : updateCheckBox
	 * Purpose : when checkbox 
	 * Params  : --
	 * Return  : --
	 **/
	updateCheckBox:function(id,value){
		mHealth.util.logMessage('Inside updateCheckBox method');	
		if(id == 'answerDiaId') {
				$('#answerDiaDateId').show();	}
		 else if(id == 'answerDiaFootId') {
				$('#answerFootDateId').show();
		} else if(id == 'answerMicroId') {
				$('#answerMicroDateId').show();
			}
		else if(id == 'answerA1cId') {
			if(value == mHealth.AssesmentEntry.dropdownOption1Value || value == 'default') {
				$('#answerA1cDateId').hide();
				$('#answerTxtA1cId').hide();

			} else if(value == mHealth.AssesmentEntry.dropdownOption3Value) {
				$('#answerA1cDateId').show();
				$('#answerTxtA1cId').show();

			} else if(value == mHealth.AssesmentEntry.dropdownOption2Value) {
				$('#answerA1cDateId').show();
				$('#answerTxtA1cId').hide();
			}
		}
		else if(id == 'answerChoId') {
			if(value == mHealth.AssesmentEntry.dropdownOption1Value || value == 'default') {
				$('#answerChoDateId').hide();
				$('#answerTxtLDLId').hide();
				$('#answerTxtHDLId').hide();
				$('#answerTxtTriId').hide();
				$('#answerTxtTotalId').hide();

			} else if(value == mHealth.AssesmentEntry.dropdownOption2Value) {
				$('#answerChoDateId').show();
				$('#answerTxtLDLId').hide();
				$('#answerTxtHDLId').hide();
				$('#answerTxtTriId').hide();
				$('#answerTxtTotalId').hide();

			} else if(value == mHealth.AssesmentEntry.dropdownOption3Value) {
				$('#answerTxtLDLId').show();
				$('#answerTxtHDLId').show();
				$('#answerTxtTriId').show();
				$('#answerTxtTotalId').show();
				$('#answerChoDateId').show();
			}
		} 
		$('#detailMessage').css({
					'height' : 'auto'
				});
	},
	/**
	 * Name    : processMessage
	 * Purpose : Process the user response from the model and disable the fields
	 * Params  : --
	 * Return  : --
	 **/
	processMessage:function(){
		mHealth.util.logMessage('Inside processMessage method');	
	if(mHealth.util.userResponseLength!=''){
		if(document.getElementById("answerId[1]")) {
			if(mHealth.util.messageTypeID == 3) {
				this.populateAnswer();
				var firstAns = '{' + mHealth.util.getFirstAnswer.answer + '}';
				var secondAns = '{' + mHealth.util.getSecondAnswer.answer + '}';
				var thirdAns = '{' + mHealth.util.getThirdAnswer.answer + '}';
				$.each($('select', '#detailMessage'), function(k) {
					$(this).find("option[value='" + firstAns + "']").attr('selected', 'selected');
					$(this).find("option[value='" + secondAns + "']").attr('selected', 'selected');
					$(this).find("option[value='" + thirdAns + "']").attr('selected', 'selected');
					if($(this).attr('name') == 'answerA1cId') {
						$(this).find("option[value='" + mHealth.util.getA1cAnswer + "']").attr('selected', 'selected');
						mHealth.MessageControllerObject.updateCheckBox($(this).attr('name'), mHealth.util.getA1cAnswer);
					}
					if($(this).attr('name') == 'answerChoId') {
						$(this).find("option[value='" + mHealth.util.getCholAnswer + "']").attr('selected', 'selected');
						mHealth.MessageControllerObject.updateCheckBox($(this).attr('name'), mHealth.util.getCholAnswer);
					}
				});
				$('select').selectmenu('disable').selectmenu('refresh');
				$("input[type='checkbox']").checkboxradio('disable');
			}
			else{
				this.populateAnswer();
				var eyeAns = '{' + mHealth.util.getSingleAnswer.answer + '}';
				$.each($('select', '#detailMessage'), function(k) {
					$(this).find("option[value='" + eyeAns + "']").attr('selected', 'selected');
				});
				$('select').selectmenu('disable').selectmenu('refresh');
				}
		}
	}
	 }
});
