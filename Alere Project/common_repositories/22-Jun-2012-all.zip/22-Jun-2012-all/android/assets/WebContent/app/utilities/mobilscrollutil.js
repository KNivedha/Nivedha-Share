mHealth.mobiscrollutil = {

	mobiScollDateTime : function(id) {
		$(id).scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'datetime',
			seconds : true,
			timeFormat : 'hh:ii:ss A',
			theme : 'ios',
			beforeShow : function(input, inst) {
				mHealth.util.hideTabBar();
			},
			onClose : function(valueText, inst) {
				mHealth.util.showTabBar();
			}
		});

	}
}