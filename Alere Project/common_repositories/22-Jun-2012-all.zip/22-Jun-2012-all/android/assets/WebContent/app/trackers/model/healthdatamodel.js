mHealth.models.HealthDataModel=Spine.Model.sub();
mHealth.models.HealthDataModel.configure("HealthDataModel","healthDataId","participantId","memberEligId","groupId","healthDataType","measurementDate","collectedDate","insertDate","value","unit","source","appSource","comments","longitude","latitude","valueBMI");

