package com.alere.mya;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;

import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabWidget;

import com.alere.util.MyaUtil;
import com.alere.util.SessionTimer;

/**
 * Activity that is Web Container for locally loaded resources.
 * 
 * @author efiller
 * 
 */

public class WebContainerActivity extends TabActivity implements
TabHost.TabContentFactory, TabHost.OnTabChangeListener {

	private static MyaUtil util = MyaUtil.getInstance();
	private final NetworkStateReceiver networkStateReceiver = new NetworkStateReceiver();
	public static WebView webview;
	private TabHost tabHost;
	private TabWidget tabwidget = null;
	private LinearLayout tabLayout;
	private SessionTimer sessionTimer;
	private Timer timer;
	ImageView imageView;
	private boolean startSessionTracking = false, isTabFocus, onGraph;
	private static final String TAG = "WebContainerActivity";

	private final Map<String, Integer> appConfigurations = new HashMap<String, Integer>();

	private boolean onLogin;


	public void addTab(List<String> tabs) {
		tabLayout.setVisibility(ViewGroup.VISIBLE);

		if (tabHost == null) {
			tabHost = getTabHost();
			tabwidget = getTabWidget();
			Resources res = getResources();
			int count = 0;
			for (String string : tabs) {
				appConfigurations.put(string, count);
				int resourceId = res.getIdentifier("n_" + string.toLowerCase(),
						"drawable", this.getPackageName());
				Log.d("Tab Name", string + "1");
				count++;
				tabHost.addTab(tabHost.newTabSpec(string)
						.setIndicator(string, res.getDrawable(resourceId))
						.setContent(this));

			}
			Log.d("Map Response is ", appConfigurations.toString());

		}
		startSessionTracking = true;
		this.enableSessonTimer();
		tabHost.setCurrentTab(0);
		tabHost.setOnTabChangedListener(this);

	}

	private void cancelSessionTimer() {
		Log.d("Timer Resetted", "Timer Resetted");
		timer.cancel();
	}

	@Override
	public View createTabContent(String tag) {
		setTabJavascriptPage(tag);
		return webview;
	}

	public void enableSessonTimer() {
		this.cancelSessionTimer();
		timer = new Timer();
		sessionTimer = new SessionTimer();
		timer.schedule(sessionTimer, 900000, 900000);
	}

	@Override
	public void finish() {
		this.unregisterReceiver(networkStateReceiver);
		super.finish();
	}

	public void getCurrentConditionOrientation() {
		if (getWindowManager().getDefaultDisplay().getRotation() == 0) {
			webview.loadUrl("javascript:currentOrientation('portrait')");
		} else {
			webview.loadUrl("javascript:currentOrientation('landscape')");
		}
	}

	public void getCurrentOrientation() {
		onGraph = true;
		if (getWindowManager().getDefaultDisplay().getRotation() == 0) {
			webview.loadUrl("javascript:currentOrientationGraph('portrait')");
		} else {
			webview.loadUrl("javascript:currentOrientationGraph('landscape')");
		}

	}

	public void getDeviceConfiguration() throws NameNotFoundException {
		Log.d("getDeviceConfiguration Activity:", ">>>deviceFeatures");
		String TAG = this.getString(R.string.TAG);
		Log.d(TAG, ">>>deviceFeatures");

		String deviceName = android.os.Build.DEVICE;
		String brand = android.os.Build.BRAND;
		String hardware = android.os.Build.HARDWARE;
		String id = android.os.Build.ID;
		String manufacturer = android.os.Build.MANUFACTURER;
		String model = android.os.Build.MODEL;
		String product = android.os.Build.PRODUCT;
		// String type = android.os.Build.TYPE;
		String user = android.os.Build.USER;
		// int SDK_INT = android.os.Build.VERSION.SDK_INT;
		String platform = System.getProperty("os.name");
		String devicetoken = this.getSharedPreferences(
				NotificationRegister.KEY, Context.MODE_PRIVATE).getString(
						NotificationRegister.REGISTRATION_KEY, "NONE");
		String deviceId = Secure.getString(this.getContentResolver(),
				Secure.ANDROID_ID);

		Log.d(TAG, "deviceName1" + deviceName);
		Log.d(TAG, " brand" + brand);
		Log.d(TAG, "hardware" + hardware);
		Log.d(TAG, "id" + id);
		Log.d(TAG, "manufacturer" + manufacturer);
		Log.d(TAG, "model" + model);
		Log.d(TAG, "product" + product);
		Log.d(TAG, "user" + user);
		Log.d(TAG, "platform" + platform);
		Log.d(TAG, "devicetoken = " + devicetoken);
		Log.d(TAG, "deviceId = " + deviceId);

		String osVersion, osID, deviceMake, deviceModel;
		osVersion = Build.VERSION.SDK;
		Log.d(TAG, "XXX osVersion" + osVersion);
		String appVersion = util.getAppVersion();

		osID = "2";  // defined in the Apollo db to mean "Android"

		deviceMake = manufacturer;
		deviceModel = model;
		// getDeviceInfo is defined in nativebridge following is the method
		// signature
		webview.loadUrl("javascript:getDeviceInfo('" + osID + "', '"
				+ osVersion + "','" + deviceMake + "','" + deviceModel + "', '"
				+ deviceId + "', '" + devicetoken + "', '" + deviceName
				+ "', '" + appVersion + "')");
	}

	public void hideImage()
	{
		ImageView   id=(ImageView) this.findViewById(R.id.imageView1);
		id.setVisibility(View.INVISIBLE);
		webview.setVisibility(View.VISIBLE);
	}

	public void highlightedTabBar(String tabName) {

		int index = appConfigurations.get(tabName);
		isTabFocus = false;
		tabHost.setOnTabChangedListener(null);
		tabHost.setCurrentTab(index);
		tabHost.getTabWidget().focusCurrentTab(index);

	}

	public boolean isOnLogin() {
		return onLogin;
	}

	public void onConfigurationChanged(Configuration newConfig) {

		imageView=(ImageView) findViewById(R.id.imageView1);
		// Checks the orientation of the screen
		if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
			imageView.setImageDrawable(this.getResources().getDrawable(R.drawable.default_landscape));
			Log.d("on Landscape Orientation", webview.toString());
			webview.loadUrl("javascript:currentOrientation('landscape')");

		} else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
			Log.d("on Portrait Orientation", webview.toString());
			imageView.setImageDrawable(this.getResources().getDrawable(R.drawable.m_logo));
			webview.loadUrl("javascript:currentOrientation('portrait')");
		}
		if (onGraph) {
			getCurrentOrientation();

		}

		super.onConfigurationChanged(newConfig);
	}

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {

		boolean isNotification = this.getIntent().hasExtra("payload");
		if(!isNotification){
			super.onCreate(savedInstanceState);
			Log.d(TAG, "Get home activity");
			setContentView(R.layout.main_layout);
			imageView=(ImageView) findViewById(R.id.imageView1);
			if (getWindowManager().getDefaultDisplay().getRotation() == 0) {
				imageView.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.m_logo));
			} else {
				imageView.setBackgroundDrawable(this.getResources().getDrawable(R.drawable.default_landscape));
			}
			tabLayout = (LinearLayout) findViewById(R.id.popupTabs);
			webview = util.setWebviewConfiguration(this);
			webview.setVisibility(View.INVISIBLE);
			util.registerReceiver(this, networkStateReceiver);
			util.loadWebPageURL(webview);
			sessionTimer = new SessionTimer();
			timer = new Timer();
		}

	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK && webview.isEnabled()
				&& !this.onLogin) {

			webview.loadUrl("javascript:handleDeviceBack()");
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_BACK && this.onLogin) {
			moveTaskToBack(true);
		}
		if (keyCode == KeyEvent.KEYCODE_HOME) {
			webview.loadUrl("javascript:handleDeviceHome()");
			return true;
		}
		return false;
	}

	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub


		boolean isNotification = intent.hasExtra("payload");
		if (isNotification) {
			if (startSessionTracking != false) {
				highlightedTabBar("Messages");
			} else {
				util.loadWebPageURL(webview);
			}
			super.onNewIntent(intent);
		}

	}

	@Override
	public void onTabChanged(String tabId) {
		// TODO Auto-generated method stub
		Log.d("tag Name", tabId + "");
		setTabJavascriptPage(tabId);
	}

	@Override
	public void onUserInteraction() {
		// TODO Auto-generated method stub

		if (startSessionTracking != false) {
			tabHost.setOnTabChangedListener(this);
			this.enableSessonTimer();
		}
		super.onUserInteraction();

	}

	public void removeTab() {
		Log.d("removeTab ",  "removeTab called: - "+onGraph);
		tabLayout.setVisibility(ViewGroup.GONE);
	}

	public void setOnLogin(boolean onLogin) {
		if (onLogin) {
			this.cancelSessionTimer();

		}
		startSessionTracking=!onLogin;
		this.onLogin = onLogin;
	}

	private void setTabJavascriptPage(String tabs) {

		if (tabs.equalsIgnoreCase("Home")) {
			webview.loadUrl("javascript:loadHome()");
		} else if (tabs.equalsIgnoreCase("Settings")) {
			webview.loadUrl("javascript:loadSettings()");
		} else if (tabs.equalsIgnoreCase("Messages") & isTabFocus != true) {
			webview.loadUrl("javascript:loadMessages()");
		} else if (tabs.equals("Trackers") & isTabFocus != true) {
			webview.loadUrl("javascript:loadTrackers()");
		} else if (tabs.equals("Challenges") & isTabFocus != true) {
			this.toggleMasking(false);
			webview.loadUrl("javascript:loadActivities()");
		}
		isTabFocus = false;
	}

	public void showTab() {
		Log.d("showTab ",  "showTab called: - "+onGraph);

		tabLayout.setVisibility(ViewGroup.VISIBLE);
	}

	public void toggleMasking(boolean flag) {
		if (tabHost != null) {
			tabwidget.setEnabled(flag);
			tabHost.setEnabled(flag);
		}

		webview.setEnabled(flag);
		isTabFocus = false;
	}

	public void unLoadChart() {
		onGraph = false;
	}

}