/**
 * 
 */
package com.alere.mya;

import java.util.Date;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.util.Log;

import com.alere.mya.R;
import com.alere.util.MyaUtil;

/**
 * @author rajasekharm
 *
 */
public class NotificationRegister extends BroadcastReceiver {

	static String KEY = "c2dmPref";
	static String REGISTRATION_KEY = "deviceToken";
	
	private static final String TAG = "NotificationReceiver";
	
	
	/* (non-Javadoc)
	 * @see android.content.BroadcastReceiver#onReceive(android.content.Context, android.content.Intent)
	 */
	@Override
	public void onReceive(Context context, Intent intent) {
		
		
	    Log.d(TAG, "MyC2dmReceiver " + intent.getAction());
		if (intent.getAction().equals("com.google.android.c2dm.intent.REGISTRATION")) {
			
	        handleRegistration(context, intent); 
	    } else if (intent.getAction().equals("com.google.android.c2dm.intent.RECEIVE")) {
			handleMessage(context, intent);
	    }
	}
	
	private void handleRegistration(Context context, Intent intent) {
		Log.d("Inside the handleRegisration","Inside the handleRegisration");
	    String registration = intent.getStringExtra("registration_id");
	    if (intent.getStringExtra("error") != null) {
		    String error = intent.getStringExtra("error");
		    Log.e(TAG, "registration failed with error " + error);
		    
	    } else if (intent.getStringExtra("unregistered") != null) {
	    	Log.d(TAG, "unregistered");

	    } else if (registration != null) {
	    	
	    	Log.d(TAG, registration);
	    	Editor editor =   context.getSharedPreferences(KEY, Context.MODE_PRIVATE).edit();
            editor.putString(REGISTRATION_KEY, registration);
            
            
    		editor.commit();
	    }
	    
	    Log.d(TAG, "Device token = " + context.getSharedPreferences(KEY, Context.MODE_PRIVATE).getString(REGISTRATION_KEY, "NONE"));
	    
	}  

	private void createNotification(Context context, String payload) {
		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
		Notification notification = new Notification(R.drawable.ic_launcher,payload, System.currentTimeMillis());
		// Hide the notification after its selected
		notification.flags |= Notification.FLAG_AUTO_CANCEL;

		Intent intent = new Intent(context, WebContainerActivity.class);
		intent.putExtra("payload", payload);
		PendingIntent pendingIntent = PendingIntent.getActivity(context, 0,	intent, PendingIntent.FLAG_UPDATE_CURRENT);
		notification.setLatestEventInfo(context, context.getString(R.string.app_name), payload, pendingIntent);
		notificationManager.notify(0, notification);
	}

	private void handleMessage(Context context, Intent intent) {
		
		Log.d(TAG, "Received message on " + new Date());
		final String payload = intent.getStringExtra("payload");
		createNotification(context, payload);
		Log.d(TAG, "MESSAGE FROM SERVER = " + payload);
	}

}
