/**
 * 
 */
package com.alere.webcontainer;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import com.alere.mya.WebContainerActivity;

/**
 * Java Script hook into webview. Most of the methods are commented out because
 * unused. logMessage is the most used function.
 * 
 * @author efiller
 * 
 */
public class AlereJSHook {

	private WebContainerActivity activity;

	private static String TAG = "WebContainerActivity";

	/**
	 * 
	 */
	public AlereJSHook() {
		super();
	}

	/**
	 * @param activity
	 */
	public AlereJSHook(WebContainerActivity activity) {
		this.activity = activity;
	}

	public void logMessage(String message) {

		Log.i(TAG, message);
	}

	public void showTab() {

		this.activity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				activity.unLoadChart();
				activity.showTab();
			}
		});

	}

	public void getConOrientation() {
		this.activity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				activity.getCurrentConditionOrientation();

			}
		});
	}

	public void highlightHome() {

		this.activity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				activity.highlightedTabBar("Home");

			}
		});

	}

	public void finishActivity() {

		this.activity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				activity.moveTaskToBack(true);

			}
		});

	}

	public void openHref(String loadurls) {

		Log.d("openHref", loadurls);
		Intent i = new Intent(Intent.ACTION_VIEW);
		i.setData(Uri.parse(loadurls));
		activity.startActivity(i);

	}

	public void pageHistory() {
		this.activity.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				WebContainerActivity.webview.goBack();

			}
		});

	}

	public void logValues(String message) {
		Log.d("Message from Webview", message);
	}

	public void onReady()
	{
		this.activity.runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				activity.hideImage();
			}
		});
		
	}
	/*
	 * public void pickTime() { activity.showDialog(0);
	 * 
	 * } public void pickDate() { activity.showDialog(1); } public String
	 * getDate() { StringBuilder buffer = new StringBuilder();
	 * buffer.append((activity.getmMonth() + 1)) // Month is zero based
	 * .append("/") .append(activity.getmDay()) .append("/")
	 * .append(activity.getmYear()); return buffer.toString(); } public String
	 * getTime() {
	 * 
	 * Date time = new Date(activity.getmYear(), activity.getmMonth(),
	 * activity.getmDay(), activity.getmHour(), activity.getmMinute() );
	 * 
	 * return timeFormat.format(time); } public void
	 * setDateDialogCallback(String dateDialogCallback) {
	 * activity.addDateDialogCallback(dateDialogCallback); }
	 * 
	 * 
	 * public void setTimeDialogCallback(String timeDialogCallback) {
	 * activity.addTimeDialogCallback(timeDialogCallback); }
	 */

}
