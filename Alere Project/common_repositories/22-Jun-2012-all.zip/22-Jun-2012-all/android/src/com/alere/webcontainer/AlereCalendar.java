package com.alere.webcontainer;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;

public class AlereCalendar {
	private static Context _context;

	public static Context getContext() {
		return _context;
	}

	public static void setContext(Context context) {
		_context = context;
	}

	public static void readCalendar(Context context) {
		ContentValues event1 = new ContentValues();

		String startDate = "2012-05-01 12:20:26 PM";
		String endDate = "2012-05-02 12:20:30 PM";
		// Calendar in which you want to add Evnet
		event1.put("calendar_id", 2);
		// Title of the Event
		event1.put("title", "Birthday");
		// Description of the Event
		event1.put("description", "Birthday Party");
		// Venue of the Event
		event1.put("eventLocation", "Delhi");
		// Start Date of the Event
		// event1.put("dtstart", convertDateStringtoLong(startDate));
		event1.put("dtstart", startDate);
		// End Date of the Event
		event1.put("dtend", endDate);
		// Event is all day
		event1.put("allDay", 1);
		// Set alarm on this Event
		event1.put("hasAlarm", 1);
		
		Uri eventsUri1 = Uri.parse("content://com.android.calendar/events");
		// Uri eventsUri = Uri.parse("content://calendar/events");
		// Uri url = getContentResolver().insert(eventsUri, event);
		// event is added
		context.getContentResolver().insert(eventsUri1, event1);

	}

//	public static void insertCalendar() {
//
//		Calendar cal = Calendar.getInstance();
//		Intent intent = new Intent(Intent.ACTION_EDIT);
//		intent.setType("vnd.android.cursor.item/event");
//		intent.putExtra("beginTime", cal.getTimeInMillis());
//		intent.putExtra("allDay", true);
//		intent.putExtra("rrule", "FREQ=YEARLY");
//		intent.putExtra("endTime", cal.getTimeInMillis() + 60 * 60 * 1000);
//		intent.putExtra("title", "A Test Event from android app");
//		
//		WebContainerActivity. ).startActivity(intent);
//
//	}

	class MyCalendar {
		public String name;
		public String id;

		public MyCalendar(String _name, String _id) {
			name = _name;
			id = _id;
		}

		@Override
		public String toString() {
			return name;
		}
	}

}
