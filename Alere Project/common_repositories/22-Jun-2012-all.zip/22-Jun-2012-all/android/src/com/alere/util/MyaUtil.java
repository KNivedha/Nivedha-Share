package com.alere.util;

import java.net.URLDecoder;

import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.util.Log;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import com.alere.mya.NetworkStateReceiver;
import com.alere.mya.WebContainerActivity;
import com.alere.mya.R;
import com.alere.webcontainer.AlereJSHook;
import com.alere.webcontainer.AssetWebViewClient;

public class MyaUtil {

	private static MyaUtil myaUtil = null;

	private Context context;

	public static MyaUtil getInstance() {
		if (myaUtil == null) {
			myaUtil = new MyaUtil();

		}
		return myaUtil;
	}

	public void loadWebPageURL(WebView webview) {
		SharedPreferences sharedPreferences = context.getSharedPreferences(
				context.getString(R.string.PREFS_NAME), 0);
		boolean accepted = sharedPreferences.getBoolean(
				context.getString(R.string.SHAREDTAG), false);
		if (accepted != true) {
			webview.loadUrl(context.getString(R.string.termsofUseURL));
		} else {
			webview.loadUrl(context.getString(R.string.LoginURL));
		}
	}

	public void showAlertMessage(String message) {
		AlertDialog alertDialog = new AlertDialog.Builder(context).create();
		alertDialog.setTitle("Information");
		alertDialog.setMessage(message);
		alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				// here you can add functions
			}
		});
		alertDialog.setIcon(R.drawable.ic_launcher);
		alertDialog.show();
	}

	public Context getContext() {
		return context;
	}

	public void setContext(Context context) {
		this.context = context;
	}

	public void registerReceiver(Context context,NetworkStateReceiver networkStateReceiver) {
		
		this.context = context;
		// Push Notification Registeration

		Intent registrationIntent = new Intent("com.google.android.c2dm.intent.REGISTER");

		registrationIntent.putExtra("app",	PendingIntent.getBroadcast(context, 0, new Intent(), 0));

		registrationIntent.putExtra("sender", "alere.mya@gmail.com"); // password
																		// is
																		// MyaHealth22
		context.startService(registrationIntent);
		
		// network State Receiver registration
		IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
		
		context.registerReceiver(networkStateReceiver, filter);
	}

	public WebView setWebviewConfiguration(WebContainerActivity activity) {
		WebView webview = (WebView) activity.findViewById(R.id.myWebView);

		webview.addJavascriptInterface(new AlereJSHook(
				(WebContainerActivity) activity), "Android");

		WebSettings settings = webview.getSettings();
		// Settings
		settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
		settings.setAppCacheEnabled(false);
		settings.setJavaScriptEnabled(true);
		settings.setPluginsEnabled(true);
		settings.setDatabaseEnabled(true);
		settings.setDomStorageEnabled(true);
		// settings.setUseWideViewPort(true);
		settings.setLoadsImagesAutomatically(true);

		webview.setHorizontalScrollBarEnabled(false);
		webview.setVerticalScrollBarEnabled(false);
		webview.setWebViewClient(new AssetWebViewClient(activity));

		webview.setWebChromeClient(new WebChromeClient() {

			@Override
			public boolean onJsAlert(WebView view, String url, String message,
					JsResult result) {
				// Required functionality here
				return super.onJsAlert(view, url, message, result);
			}
		});
		return webview;

	}

	public void onAccept() {
		SharedPreferences settings = context.getSharedPreferences(
				context.getString(R.string.PREFS_NAME), 0);
		SharedPreferences.Editor editor = settings.edit();
		editor.putBoolean("accepted", true);
		// Commit the edits!
		editor.commit();
	}

	public void invokeCalendar(String url) throws Exception {
		String TAG = context.getString(R.string.TAG);
		Log.i(TAG, "IN insertAppointment " + url);
		String title = url.substring(17, url.length());
		Intent l_intent = new Intent(Intent.ACTION_EDIT);
		l_intent.setType("vnd.android.cursor.item/event");
		// l_intent.putExtra("calendar_id", m_selectedCalendarId); //this
		// doesn't work
		l_intent.putExtra("title", URLDecoder.decode(title, "UTF-8"));
		l_intent.putExtra("description", URLDecoder.decode(title, "UTF-8"));
		l_intent.putExtra("eventLocation", "");
		l_intent.putExtra("beginTime", System.currentTimeMillis());
		l_intent.putExtra("endTime", System.currentTimeMillis() + 1800 * 1000);
		l_intent.putExtra("allDay", 0);
		// status: 0~ tentative; 1~ confirmed; 2~ canceled
		l_intent.putExtra("eventStatus", 1);
		// 0~ default; 1~ confidential; 2~ private; 3~ public
		l_intent.putExtra("visibility", 0);
		// 0~ opaque, no timing conflict is allowed; 1~ transparency, allow
		// overlap of scheduling
		l_intent.putExtra("transparency", 0);
		// 0~ false; 1~ true
		l_intent.putExtra("hasAlarm", 1);
		try {
			context.startActivity(l_intent);
		} catch (Exception e) {
			Toast.makeText(context, "Sorry, no compatible calendar is found!",
					Toast.LENGTH_LONG).show();
		}
	}

	public String getAppVersion() throws NameNotFoundException {
		String versionName = context.getPackageManager().getPackageInfo(
				context.getPackageName(), 0).versionName;
		Log.d("APP VERSION", versionName);
		return versionName;
	}

}
