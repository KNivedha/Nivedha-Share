/**
 * 
 */
package com.alere.webcontainer;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.MailTo;
import android.net.Uri;
import android.net.http.SslError;
import android.util.Log;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.alere.mya.WebContainerActivity;
import com.alere.util.MyaUtil;

/**
 * WebViewClient for load resources from the asset directory
 * 
 * @author EFiller
 * 
 */
public class AssetWebViewClient extends WebViewClient {
	
	 
	private static String TAG = AssetWebViewClient.class.getName();

	private WebContainerActivity _activity;
	
	private MyaUtil util=MyaUtil.getInstance(); 
	

	// list of URLs patterns to override
	private static String[] overrideLinks = { "tabbar:", "gyro:", "plist:",
			"forceQuit:", "forcequit:", "email", "abt:" };

	/**
	 * constructor that gets pointer to web container activity.
	 * 
	 * @param activity
	 */
	public AssetWebViewClient(WebContainerActivity activity) {
		_activity = activity;

	}
	

	/**
	 * Override special URLs that javascript code passes to webview. If URL
	 * should be overwritten call the activity to perform action and return true
	 * to tell web view that URL has been processed.
	 * 
	 * @param the
	 *            Web View that is trying to load the url
	 * @param the
	 *            resource to load.
	 * @return true if the resource was loaded here
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * android.webkit.WebViewClient#shouldOverrideUrlLoading(android.webkit.
	 * WebView, java.lang.String)
	 */
	public boolean shouldOverrideUrlLoading(WebView view, String url) {
		boolean shouldOverride = false;

		
		Log.i(TAG, "url:" + url + " is overridden.");
		for (String link : overrideLinks) {
			if (url.startsWith("tabbar://login")) {
				shouldOverride = true;
				
				_activity.setOnLogin(false);

				List<String> configurableTab = new ArrayList<String>();

				StringTokenizer stringTokenizer = new StringTokenizer(url, "?");

				stringTokenizer.nextToken();
				String tabs = stringTokenizer.nextToken();

				StringTokenizer stringTokenizer2 = new StringTokenizer(tabs,	"&");
				while (stringTokenizer2.hasMoreTokens()) {
					StringTokenizer finalTokenizer = new StringTokenizer(stringTokenizer2.nextToken(), "=");
					finalTokenizer.nextToken();
					configurableTab.add(finalTokenizer.nextToken());
				}

				Log.d("The List Value is ", configurableTab.toString());
				_activity.addTab(configurableTab);
				break;
			} else if (url.startsWith("forcequit")) {
				Log.d("forcequit", "forcequit");
				shouldOverride = true;
				util.onAccept();
				break;

			} 
			
			else if (url.startsWith("tabbar://logout")) {
				shouldOverride = true;
				_activity.setOnLogin(true);
				Log.d("Inside the Logout", "Inside the logout");
				_activity.removeTab();
				break;
			} else if (url.startsWith("tabbar://hideTabBar?")) {
				_activity.enableSessonTimer();
				shouldOverride = true;
				Log.d("Inside the hideTabBar", "Inside the hideTabBar");
				_activity.removeTab();
				break;
			} else if (url.startsWith("tabbar://showTabBar")) {
				shouldOverride = true;
				Log.d("Inside the showTabBar", "Inside the showTabBar");
				_activity.showTab();
				break;
			} else if (url.startsWith("tabbar://addMask")) {
				shouldOverride = true;
			
				Log.d("Inside the add mask", "Inside the add mask");
				_activity.toggleMasking(false);
				
//				InputMethodManager imm = (InputMethodManager) _activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
//			    imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
				break;
			} else if (url.startsWith("tabbar://removeMask")) {
				shouldOverride = true;
				Log.d("Inside the remove mask", "Inside the remove mask");
				_activity.toggleMasking(true);
				break;
			} else if (url.startsWith("tabbar://Trackers")) {
				shouldOverride = true;
				_activity.highlightedTabBar("Trackers");
				break;
			} else if (url.startsWith("tabbar://Challenges")) {
				shouldOverride = true;
				_activity.highlightedTabBar("Challenges");
				break;
			} else if (url.startsWith("tabbar://Messages")) {
				shouldOverride = true;
				_activity.toggleMasking(true);
				_activity.highlightedTabBar("Messages");
				break;

			} else if (url.startsWith("tabbar://loadHome")) {
				Log.d("Inside the loadhome", "Inside the loadhome");
				shouldOverride = true;
				_activity.highlightedTabBar("Home");
				break;

			} else if (url.startsWith("abt://getdevicefeatures")) {
				Log.d("Inside getdeviceFeatures", "Inside getdeviceFeatures");
				shouldOverride = true;
				try {
					_activity.getDeviceConfiguration();
				} catch (NameNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			} else if (url.startsWith("gyro://loadChart")) {
				shouldOverride = true;
				Log.d("Inside the hideTabBar", "Inside the hideTabBar");
				_activity.removeTab();
				_activity.getCurrentOrientation();
				break;
			} else if (url.startsWith("gyro://getCurrentConditionOrientation")) {
				shouldOverride = true;
				Log.d("Inside the getCurrentConditionOrientation", "Inside the getCurrentConditionOrientation");
				_activity.getCurrentConditionOrientation();
				break;
			}else if (url.startsWith("gyro://unLoadChart")) {
				shouldOverride = true;
				Log.d("Inside the showTabBar", "Inside the showTabBar");
				_activity.showTab();
				_activity.unLoadChart();
				break;
			} else if (url.startsWith("tel://")) {
				shouldOverride = true;
				Log.i(TAG, "url:" + url + " is overridden.");
				performDial(url);
				break;
			} else if (url.startsWith("email://")) {
				shouldOverride = true;
				Log.i(TAG, "url:" + url + " is overridden.");
				sendEmail(url);
				break;
			} else if (url.startsWith("cal://")) {//
				shouldOverride = true;
				Log.i(TAG, "url:" + url + " is overridden.");
					try {
						util.invokeCalendar(url);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				break;
			}
			// OVERRIDE BY DEFAULT
			else if (url.startsWith(link)) {
				shouldOverride = true;
				Log.i(TAG, "url:" + url + " is overridden.");
				break;
			}
			
		}
		return shouldOverride;
	}




	

	/**
	 * When webview sends URL that starts with tel: Create Call intent and pass
	 * phone number in the form tel:999-999-9999
	 * 
	 * @param url
	 *            phone number preceded by tel:
	 */
	private void performDial(String url) {
		Log.i(TAG, "IN performDial Phone Number is:" + url);
		try {
			Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse(url));
			_activity.startActivity(intent);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * When webview sends URL that starts with email:
	 * email://sendEmail?mailto=feedback
	 * 
	 * @myahealth.com&cc=&subject=Mya%20Login%20Feedback
	 * 
	 * @param url
	 * 
	 */
	private void sendEmail(String url) {
		Log.i(TAG, "IN SEND EMAIL:" + url);
		// email://sendEmail?mailto:feedback@myahealth.com&subject=Mya%20Login%20Feedback
		url = url.substring(18, url.length()); // 18 is the length of//
												// email://sendEmail?
		Log.i(TAG, "IAFTER :" + url);
		try {
			Log.i(TAG, "Encoded URL " + url);
			MailTo mt = MailTo.parse(url);
			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("text/plain");
			intent.putExtra(Intent.EXTRA_EMAIL, new String[] { mt.getTo() });
			intent.putExtra(Intent.EXTRA_SUBJECT, mt.getSubject());
			if (mt.getCc() != null) {
				Log.i(TAG, "CC IS NOT NULL :" + mt.getCc());
				intent.putExtra(Intent.EXTRA_CC, new String[] { mt.getCc() });
			}
			intent.putExtra(Intent.EXTRA_TEXT, mt.getBody());
			_activity.startActivity(intent);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * android.webkit.WebViewClient#onReceivedSslError(android.webkit.WebView,
	 * android.webkit.SslErrorHandler, android.net.http.SslError)
	 */
	public void onReceivedSslError(WebView view, SslErrorHandler handler,	SslError error) {
		Log.d(TAG, "SSL Error Certificate " + error.getPrimaryError() + "   "	+ error.getCertificate());
		handler.proceed();
	}

}
