package com.alere.util;

import android.content.Context;

public class TabBarUtil {
	
	private static TabBarUtil tabBarUtil=null;
	
	private Context context;

	public Context getContext() {
		return context;
	}

	public void setContext(Context context) {
		this.context = context;
	}

	private TabBarUtil() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static TabBarUtil getInstance()
	{
		if(tabBarUtil==null)
		{
			tabBarUtil= new TabBarUtil();
		}
		return tabBarUtil;
	}
	

	
	
	
	

}
