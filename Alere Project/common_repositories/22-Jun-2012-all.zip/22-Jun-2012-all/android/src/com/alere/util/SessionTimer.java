package com.alere.util;

import java.util.TimerTask;

import com.alere.mya.WebContainerActivity;

import android.util.Log;

public class SessionTimer extends TimerTask {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		WebContainerActivity.webview.loadUrl("javascript:sessionExpired()");
		Log.d("The result after 1 min","The result After 1 min");
		this.cancel();
		
	}

	

}
