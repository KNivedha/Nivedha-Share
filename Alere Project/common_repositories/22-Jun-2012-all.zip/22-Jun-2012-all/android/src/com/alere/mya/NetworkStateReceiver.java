package com.alere.mya;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;

public class NetworkStateReceiver extends BroadcastReceiver {
	

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		
		System.out.println(intent.hasExtra(ConnectivityManager.EXTRA_NO_CONNECTIVITY));
		boolean noConnectivity = intent.getBooleanExtra(
				ConnectivityManager.EXTRA_NO_CONNECTIVITY, false);
//		WebContainerActivity activity = (WebContainerActivity) context;
		if (noConnectivity) {
			WebContainerActivity.webview.loadUrl("javascript:networkStatus('false')");
		}

	}

}
