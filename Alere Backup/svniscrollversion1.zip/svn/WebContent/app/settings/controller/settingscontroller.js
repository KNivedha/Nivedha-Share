mHealth.controllers.SettingsController=Spine.Controller.sub({
                        el:'body',
                        elements:
                        {

                        },
                        service : mHealth.util.RemoteServiceProxy.getInstance(),
                        events :
                        {
                                'click #logout_id' : 'doLogout'
                        },
                        
                        //*********************Method to logout********************
                        doLogout : function()
                        {   
                           if (confirm("Are you sure you want to logout?")) {  
//                                mHealth.models.AnswerModel.destroyAll();
//                                mHealth.models.ParticipantAnswerModel.destroyAll();
                                mHealth.models.ConditionModel.destroyAll();
                                mHealth.models.MedicationModel.destroyAll();
                                mHealth.models.ParticipantModel.destroyAll();
//                                mHealth.models.SpaceModel.destroyAll();
//                                mHealth.models.ViewModel.destroyAll();
//                                mHealth.models.ZoneModel.destroyAll();
                                mHealth.models.HealthDataModel.destroyAll();
                                $.mobile.changePage("../../rootView/view/login.html");
                            } 
                        },
                                                            
                                                            
                askUserYesOrNo : function() {
                    var myDialog = $('<div class="mydialog"><p>Yes or No</p><input type="button" id="yes" value="Yes"/><input type="button" id="no" value="No"/></div>');
                    $("#yes").click(this.handleYes);
                    $("#no").click(this.handleNo);
                    myDialog.modal(); 
                },
                
                handleYes  : function() {
                //handle yes...
                },
                
                handleNo : function() {
                //handle no...
                }

});