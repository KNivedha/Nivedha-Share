mHealth.models.ZoneModel = Spine.Model.sub();
mHealth.models.ZoneModel.configure('ZoneModel','participantId','parentSpaceName','parentZoneName','moduleId','rank',
		'title','bodyCopy','zoneStyle','zoneName','recentlySynced','disp','col',
                    'isInset'):   

