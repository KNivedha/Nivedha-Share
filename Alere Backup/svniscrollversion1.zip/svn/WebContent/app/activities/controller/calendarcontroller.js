mHealth.controllers.CalendarController=Spine.Controller.sub({
el:'body',
 events :
{
'click #calendar_save'    : 'getCalendarData',
},
                                             init:function(){},
                                             
getCalendarData:function(){
//alert('hi');
                                             var title=$('#eventName').val();
                                              var sDate=$('#startDate').val();
                                              var eDate=$('#endDate').val();
                                             location.href = "cal://?eventname=setEvent&eventTitle="+title+"&startDate="+sDate+"&endDate="+eDate;

                                             }
});