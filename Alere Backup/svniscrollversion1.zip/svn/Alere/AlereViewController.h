//
//  AlereViewController.h
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlereViewController : UIViewController <UIWebViewDelegate>
{
    IBOutlet UIWebView* webView;
    NSMutableData* responseData;
    NSString* token;
    NSString* eventname;
}
//-(void) getToken:(NSMutableArray*)headerKey;
//-(void) getHealthData:(NSMutableArray*)urlString;
-(void)setCalendarEvent:(NSMutableArray*)params;
-(void)callNumber:(NSMutableArray*)number;
@end
