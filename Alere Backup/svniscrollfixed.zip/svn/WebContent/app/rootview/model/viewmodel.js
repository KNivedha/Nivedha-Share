mHealth.models.ViewModel = Spine.Model.sub();
mHealth.models.ViewModel.configure("ViewModel",'participantId','parentSpaceName','parentZoneName','moduleId','activityId',
		'lastName','dateOfBirth','gender','height','emailAddress','firstName','createTimestamp',
		'status','allowLearnMore','allowSave','allowRemove','promptStatusText','title','bodyCopy','tellMeMore','dontShowAgain',
   'credit','creditLabel', 'targetLabel', 'target',   'community', 'maxCredits', 'earnedCredits',  'earnedIncentives',
                    'rank','name','completeDate','beginDate','endDate','viewTag','viewCategory','viewTemplate',
                    'allowEvent','viewStyle','activityName','image','imageUrl','recentlySynced','style'      );


