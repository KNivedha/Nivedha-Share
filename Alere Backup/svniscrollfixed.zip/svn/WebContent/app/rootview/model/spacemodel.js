mHealth.models.SpaceModel =  Spine.Model.sub();
mHealth.models.SpaceModel.configure('SpaceModel','participantId',
		'appStyle','appName','spaceName','isCleanForSession','recentlySynced',
                     'title','theme','localThemePath');



