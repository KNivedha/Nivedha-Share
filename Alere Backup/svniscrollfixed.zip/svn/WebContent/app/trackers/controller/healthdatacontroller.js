

mHealth.controllers.HealthDataController=Spine.Controller.sub({
    healthdatatracker:'',                                                         
	el:'body',
    service : mHealth.util.RemoteServiceProxy.getInstance(),
	events :
	{
    'click #viewJournal' : 'getJournalData',
    'pagebeforeshow #journal_page' :'showJournal',
    'click #viewGraph'      :  'getGraphData',  
	'pagebeforeshow #show_tracker_view'	: 'renderShowTrackerView',
	'pagebeforeshow #show_tracker_track'	: 'renderShowTrackerTrack',
	'click #track_save'	: 'saveTrackData',
    'click .tracker':'setTrackerType'
	},
                             
    //Method to set Tracker Type
  	setTrackerType:function(e){
  		this.healthdatatracker=$(e.target).parents(".tracker").attr('name');
  	},
     
    //Method for calling HealthData Service                                                          
	getJournalData:function(){
    var journalServiceUrl;
    var header;
    header=ALSECTOKEN;
    this.service.getResponse(mHealth.uat.healthdata_url, header);
    this.processJournalData(response);                                       
    },
    
    //Method for calling HealthData Service for plotting graph
    getGraphData:function(){
    var journalServiceUrl;
    var header;
    header=ALSECTOKEN;
    this.service.getResponse(mHealth.uat.healthdata_url, header);
    this.processGraphData(response);  
    },
    
    //Method for rendering the Show tracker View content and header
    renderShowTrackerView:function(){
    trackerType={"name":this.healthdatatracker};
    $('#trackviewcontent').html(_.template($('#trackerviewtemplate').html(),{trackerType : trackerType}));
    $('#headercontent').html(_.template($('#headertemplate').html(),{trackerType : trackerType}));
    $('#trackview_list').listview();
    $('#show_tracker_view').page('destroy').page();	
    },
    
    //Method for rendering the Show tracker track content
    renderShowTrackerTrack:function(){
    trackerType={"name":this.healthdatatracker};
    $('#showtrackertrackcontent').html(_.template($('#showtrackertracktemplate').html(),{trackerType : trackerType}));
    $('input').textinput();
    $('textarea').textinput();
    },
    
    //Method to save the tracker new entry
    saveTrackData:function(){
    	if(validForm){
            var dateselected= $('#selectDate').val();
            var dateobject=new Date(dateselected.substr(0,4),(dateselected.substr(5,2)-1),dateselected.substr(8,2));
            var MeasurementDate=dateobject.format('yyyymmdd"T"HHMMss".000 GMT"');
            var CollectedDate=(new Date()).format('yyyymmdd"T"HHMMss".000 GMT"');
            var jsondata1=[{"collectedDate":CollectedDate,"latitude":"","comments":$('#comments').val(),"measurementDate":MeasurementDate,"appSource":"1","value":"","longitude":"","groupId":"","source":"1"}];
            var jsondata2=[{"collectedDate":CollectedDate,"latitude":"","comments":$('#comments').val(),"measurementDate":MeasurementDate,"appSource":"1","value":"","longitude":"","groupId":"","source":"1"}];
            var tracker_url;
            if(this.trhealthdatatrackeracker=="Weight and BMI")
            {
            	jsondata1[0].value=$('#value_Weight').val();
                jsondata2[0].value=$('#value_Bmi').val();
	            tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/Weight";
	            this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
	            alert(response);
	            tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/BMI";
	            this.service.postRequest(tracker_url,JSON.stringify(jsondata2));
	            alert(response);
            }
            else if(this.healthdatatracker=="A1C")
            {
            	jsondata1[0].value=$('#value_A1C').val();
                tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/A1C";
	            this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
	            alert(response);
            }
            else if(this.healthdatatracker=="Blood Glucose")
            {
                jsondata1[0].value=$('#value_Glucose').val();
                tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/Bloodglucose";
	            this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
	            alert(response);                                    
            }
            else if(this.healthdatatracker=="Blood Pressure")                                 
            {
                jsondata1[0].value=$('#value_Sys').val();
            	jsondata2[0].value=$('#value_Dia').val();
                tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/BPS";
	            this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
	            alert(response);
	            tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/BPD";
	            this.service.postRequest(tracker_url,JSON.stringify(jsondata2));
	            alert(response);
            }
            else if(this.healthdatatracker=="Cholesterol")
            {
              	jsondata1[0].value=$('#value_LDL').val();
		      	jsondata2[0].value=$('#value_HDL').val();
                var jsondata3=[{"collectedDate":CollectedDate,"latitude":"","comments":$('#comments').val(),"measurementDate":MeasurementDate,"appSource":"1","value":$('#value_Tri').val(),"longitude":"","groupId":"","source":"1"}];
	           	var jsondata4=[{"collectedDate":CollectedDate,"latitude":"","comments":$('#comments').val(),"measurementDate":MeasurementDate,"appSource":"1","value":$('#value_Cholesterol').val(),"longitude":"","groupId":"","source":"1"}];
	          	tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/LDL";
	            this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
                alert(response);
                tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/HDL";
                this.service.postRequest(tracker_url,JSON.stringify(jsondata2));
                alert(response);
                tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/Triglycerides";
                this.service.postRequest(tracker_url,JSON.stringify(jsondata3));
                alert(response);
                tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/Cholesterol";
                this.service.postRequest(tracker_url,JSON.stringify(jsondata4));
                alert(response);
         	 }
      	 }//else
                                              // $.mobile.changePage("../View/journal.html");
   },
                                                   
	init : function(){},
    
                                                             // To render the journal data
    showJournal:function(){
                                                             
    weightData = mHealth.models.HealthDataModel.all();                          
                                                   
    $('#test').html(_.template($('#healthDataList').html(),{weightData : weightData}));
    $('#weight_list').listview();
    
                                                             //using iscroll for scrolling the page
    var myScroll;
    myScroll = new iScroll('journalView', {
     snap:true   
    });
   },
       // Processing the response from server and binding it with model
                
    processJournalData:function(responseText){
    var weightData;
    var responseData;
    responseData = JSON.parse(responseText);
    for(i=0;i<responseData.length;i++){
                                                  
    //Binding the HealthDataValues for Weight and BMI in HealthData Model
     if((responseData[i].healthDataType=='Weight')||(responseData[i].healthDataType=='BMI')){
       mHealth.models.HealthDataModel.create({
                                                                                  healthDataId: responseData[i].healthDataId,
                                                                                  participantId:responseData[i].participantId,
                                                                                  memberEligId :responseData[i].memberEligId,
                                                                                  groupId :responseData[i].groupId,
                                                                                  healthDataType: responseData[i].healthDataType,
                                                                                  measurementDate :responseData[i].measurementDate,
                                                                                  collectedDate :responseData[i].collectedDate,
                                                                                  value :responseData[i].value,
                                                                                  unit:responseData[i].unit,
                                                                                  source :responseData[i].source,
                                                                                  appSource :responseData[i].appSource,
                                                                                  comments :responseData[i].comments,
                                                                                  longitude :responseData[i].longitude,
                                                                                  latitude:responseData[i].latitude,
                                                                                  valueBMI:''
                                                                                  });
                                                   }
                                                   }
                                                   
                                                    mHealth.models.HealthDataModel.select(function(record) {
                                                                                  if(record.healthDataType == 'Weight')
                                                                                  { 
                                                                                  
                                                                                   mHealth.models.HealthDataModel.select(function(recordb){
                                                             if(recordb.healthDataType=='BMI'){
                                                                                             
                                                                 if(record.measurementDate==recordb.measurementDate){
                                                                                                 
                                                                                       var val = recordb.value;
                                                                     record.updateAttributes({valueBMI:val});
                                                                             }
                                                                             
                                                                             }
                                                                             
                                                                             });
                                              }
                                                                                  });
                                                   
                                                   
                                                   
                                                    mHealth.models.HealthDataModel.select(function(recordc){
                                                                                  if(recordc.valueBMI==''){
                                                                                  
                                                                                  recordc.destroy();
                                                                                  
                                                                                  }
                                                                                  
                                                                                  });
                                                   
                                                   },
                                                   processGraphData:function(responseText){
                                                   
                                                   
                                                   var responseData;
                                                   responseData = JSON.parse(responseText);
                                                   
                                                   
                                                   for(i=0;i<responseData.length;i++){
                                                   //Binding the HealthDataValues for Weight and BMI in HealthData Model
                                                   if((responseData[i].healthDataType=='Bloodglucose')){
                                                   
                                                   
                                                    mHealth.models.HealthDataModel.create({
                                                                                  healthDataId: responseData[i].healthDataId,
                                                                                  participantId:responseData[i].participantId,
                                                                                  memberEligId :responseData[i].memberEligId,
                                                                                  groupId :responseData[i].groupId,
                                                                                  healthDataType: responseData[i].healthDataType,
                                                                                  measurementDate :responseData[i].measurementDate,
                                                                                  collectedDate :responseData[i].collectedDate,
                                                                                  value :responseData[i].value,
                                                                                  unit:responseData[i].unit,
                                                                                  source :responseData[i].source,
                                                                                  appSource :responseData[i].appSource,
                                                                                  comments :responseData[i].comments,
                                                                                  longitude :responseData[i].longitude,
                                                                                  latitude:responseData[i].latitude,
                                                                                  valueBMI:''
                                                                                  });
                                                   }
                                                   }
                                                   glucoseData = 
                                                    mHealth.models.HealthDataModel.select(function(record) {
                                                                                  if(record.healthDataType == "Bloodglucose")
                                                                                  {            
                                                                                  return record;
                                                                                  }
                                                                                  
                                                                                  });
                                                   
                                                   
                                                   
                                                
                                                   
                                                   }
});


                            
