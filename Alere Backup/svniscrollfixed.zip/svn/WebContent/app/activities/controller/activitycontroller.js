mHealth.controllers.ActivityController=Spine.Controller.sub({
el:'body',
																																																												service : mHealth.util.RemoteServiceProxy.getInstance(),
 events :
{

                                                            'click #activity' : 'getActivity'                                                          
},
                                                            getActivity : function()
                                                            {
                                                            var body=JSON.stringify([{"ActivityCount":"","AppName":"Mobile Main","RelatedActivityCount":"","Mode":"","ActivityID":"","StatusID":"","SessionID":"1326387223","ResponseType":"1003","EffectiveDate":""}]);
                                                            
                                                            this.service.postRequest(mHealth.uat.recommendation_json_url,body,this.recommendationSuccess,this.recommendationFailure);
                                                            },
																																													init:function(){},
                                                            recommendationSuccess: function(output){
                                                            var	response = output.responseText;
//                                                            alert(response);
//                                                            alert(responseData.Space);
                                                            
                                                            for(var i=0; i<responseData.Space.length;i++)
                                                            {
                                                            // alert(responseData.Space[i].participantId);
                                                            }
                                                            
                                                            
                                                            
//                                                            alert("count " +mHealth.models.SpaceModel.count());
//                                                            
//                                                            alert('Space' + space);
//                                                           
                                                            
                                                            $.mobile.changePage('../../activities/view/showactivity.html');
                                                            },
                                                            recommendationFailure: function(jqXHR, textStatus, errorThrown){
                                                              
                                                            }
                                                            
                                             

});