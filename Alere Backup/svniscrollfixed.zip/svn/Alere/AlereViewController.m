//
//  AlereViewController.m
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "AlereViewController.h"
#import <EventKit/EventKit.h>
@implementation AlereViewController

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle


 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad
 {
      NSLog(@"view did load");
     webView.delegate=self;
     
     //****************************Native calander**************
//    NSURL *url=[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"Calendar" ofType:@"html" inDirectory:@"Calendar"]];
     
     //****************************mHelath**************
     NSURL *url=[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"termsandconditions" ofType:@"html" inDirectory:@"WebContent/app/rootview/view"]];
     
     //***************************hitting service*****************
     
     //NSURL *url=[NSURL URLWithString:@"http://203.62.174.97/Cache/app/RootView/View/login.html"];
     
   NSURLRequest* request=[NSURLRequest requestWithURL:url ];
     [webView loadRequest:request];
     [super viewDidLoad];
 }


#pragma mark - webview delegate methods

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSLog(@"webView : delegate method");
    NSString* urlString=[[request URL] absoluteString]; 
    NSLog(@"url from webView is %@",urlString);
    BOOL returnType;
    @try 
    {
        NSArray* urlArray=[urlString componentsSeparatedByString:@"?"];
        if([urlArray count]>1)
        {
            NSArray* paramArray=[[urlArray objectAtIndex:1]componentsSeparatedByString:@"&"];
            NSLog(@" %@",paramArray);
            int paramcount=[paramArray count];
            eventname=[[NSString alloc]initWithString:[[[paramArray objectAtIndex:0] componentsSeparatedByString:@"="]objectAtIndex:1]];
            if (paramcount==1){
                returnType=NO;
            }  
            else if(paramcount>1)
            {
                NSLog(@"more than one parameter");
                int index=0;
                NSMutableArray* paramData=[[NSMutableArray alloc]initWithCapacity:4];
                for(int i = 1; i < paramcount; i++)
                {
                    NSString *aParam = [[[paramArray objectAtIndex:i] componentsSeparatedByString:@"="] objectAtIndex:1];
                    NSString *message = [aParam stringByReplacingPercentEscapesUsingEncoding:NSStringEncodingConversionAllowLossy];
                   
                    [paramData insertObject:message atIndex:index];
                    index++;
                }	
                NSLog(@"Received Request eventname: %@ with message %@\n",eventname,paramData);
                if ([eventname isEqualToString:@"saveCalendarEvent"]) 
                {
                    [self setCalendarEvent:paramData];
                }
                else if ([eventname isEqualToString:@"callNumber"]) 
                {
                    [self setCalendarEvent:paramData];
                }
            }
            returnType=NO;
        }
        else
        {
            NSLog(@"open url");
            returnType=YES;
        }
    }
    @catch (NSException *exception) 
    {
        returnType=NO;
        NSLog(@"thrown execption %@",exception);
    }
    return returnType;
}


- (void)webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"webview : started");
}
- (void)webViewDidFinishLoad:(UIWebView *)webView1
{
    NSLog(@"webview : finished");
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"webview : loading error %@",error);
}


-(void)setCalendarEvent:(NSMutableArray*)params
{
    NSDate *startdate ;
    NSDate *enddate ;
    
    //***********setting date format*********
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"yyyy-MM-dd"];
    
    //*********** setting event store*********

    EKEventStore *eventStore = [[EKEventStore alloc] init];
    
    //************adding events****************
    EKEvent *event  = [EKEvent eventWithEventStore:eventStore];
    
    event.title =[params objectAtIndex:0] ;
    startdate =[dateFormatter dateFromString:[params objectAtIndex:1]];
	enddate = [dateFormatter dateFromString:[params objectAtIndex:2]];
    NSLog(@"storing in calander %@ sring : %@",enddate,startdate);
    event.startDate =  startdate;
    event.endDate   = enddate;
    
    [event setCalendar:[eventStore defaultCalendarForNewEvents]];
    
    NSError *err;
    [eventStore saveEvent:event span:EKSpanThisEvent error:&err];  
}

-(void)callNumber:(NSMutableArray*)number
{
    //*****************for openinig native phone app*********
    NSString* urlString=[NSString stringWithFormat:@"tel:%@",[number objectAtIndex:0]];
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlString]];

}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    //return (interfaceOrientation == UIInterfaceOrientationPortrait);
    return YES;
}

@end
