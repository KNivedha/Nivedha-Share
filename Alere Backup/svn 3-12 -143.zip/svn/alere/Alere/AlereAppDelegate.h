//
//  AlereAppDelegate.h
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AlereViewController;
@class TabBarController;

@interface AlereAppDelegate : NSObject <UIApplicationDelegate,UITabBarControllerDelegate > {
    

  
 IBOutlet TabBarController* tabBarController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet AlereViewController *viewController;
@property (nonatomic, retain) IBOutlet TabBarController* tabBarController;
@end
