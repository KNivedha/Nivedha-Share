//
//  TabBar.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TabBar.h"
#import "AlereAppDelegate.h"
#import "TabBarController.h"

@implementation TabBar
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
     AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    if ([action isEqualToString:@"login"] )  
    {

         UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
    
        if (interfaceOrientation==UIDeviceOrientationLandscapeRight||interfaceOrientation==UIDeviceOrientationLandscapeLeft )
        {
           app.tabBarController.tabBar.view.frame=CGRectMake(0, -20, 480, 320);
        }
        else
        {
           app.tabBarController.tabBar.view.frame=CGRectMake(0, 0, 320, 460);
            
        }
         app.tabBarController.tabBar.tabBar.hidden=NO;
         [app.tabBarController.tabBar setSelectedIndex:0];
         [app.tabBarController.tabBar setSelectedViewController:app.viewController];  
    }

   else if ([action isEqualToString:@"logout"] )
    {
        NSLog(@"logout in viewcontroler");
        AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
       
        UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];

        if (interfaceOrientation==UIDeviceOrientationLandscapeRight||interfaceOrientation==UIDeviceOrientationLandscapeLeft )
        {
           app.tabBarController.tabBar.view.frame=CGRectMake(0, 0, 480, 370);
        }
        else
        {
            app.tabBarController.tabBar.view.frame=CGRectMake(0, 0, 320, 510);
            
        }
        app.tabBarController.tabBar.tabBar.hidden=YES;  
    }
   else if ([action isEqualToString:@"loadAcivity"] )
   {
       
   }
} 
//UIDevice* myDevice=[UIDevice currentDevice];
//w[myDevice beginGeneratingDeviceOrientationNotifications];
@end
