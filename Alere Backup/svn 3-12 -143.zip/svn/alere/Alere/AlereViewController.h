//
//  AlereViewController.h
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Calendar.h"
#import "EMail.h"
#import "Devices.h"
#import "TabBar.h"
#import "Orientation.h"
#import "TabBarController.h"

@protocol DeviceDelegate; 

@interface AlereViewController : UIViewController <UIWebViewDelegate>
{
    
    TabBarController *tabBarControllerObj;
    IBOutlet UIWebView* webView;
    NSMutableData* responseData;
    NSString* token;
    NSString* eventname;
    BOOL landscp;
    BOOL returnType;
    BOOL rotated;
    Calendar* calObj;
    EMail* emailObj;
    Devices* deviceObj;
    Orientation* orientationObj;
    TabBar* tabBarObj;
    NSMutableDictionary* pluginObjects;
    BOOL cameBack;
    BOOL enteredGraph;
    BOOL resized;
    
}
@property(nonatomic,retain)IBOutlet UIWebView* webView;
@property(nonatomic)BOOL rotated;
@property(nonatomic)BOOL landscp;
@property(nonatomic)BOOL insideTabBar;
@property(nonatomic)BOOL enteredGraph;
@property(nonatomic)BOOL resized;
@property(nonatomic,retain) TabBarController *tabBarControllerObj;

@end

