/**
 * Controller : MedicalHistoryController
 * Controller to do the  logic of conditions
 **/

mHealth.controllers.MedicalHistoryController = Spine.Controller.sub({
	el : 'body',

	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		'click #condition_history' : 'getCondition',
		'click #index_prev' : 'setPrev',
		'click #con_save' : 'saveCondition',
		'click #con_update' : 'updateCondition',
		'pagebeforeshow #condition_index' : 'showCondition',
		'pagebeforeshow #add_condition' : 'addCondition',
		'pagebeforeshow #editCondition' : 'editCondition',
		'click .search_name' : 'addConditionDetails',
		'click #condition' : 'getSubCondition',
		'pagebeforeshow #condition_search' : 'showSubCondition',
		'click .edit' : 'editConditionDetails',
		'keyup #con' : 'searchCondition'
	},
	/**
	 * Name    : searchCondition
	 * Purpose : Method to Search conditions
	 * Params  : --
	 * Return  : --
	 **/
	searchCondition : function(event) {
		var keyCode = event.which;
		if(keyCode == 13) {
			event.preventDefault();
			mHealth.models.SearchConditionModel.destroyAll();
			var filterValue = "";
			filterValue = $('#con').val();
			this.service.getResponse(mHealth.dev.searchindexcondition_url + filterValue, this.proxy(this.subConditionSuccess), this.proxy(this.conditionError),true);
		}

	},
	/**
	 * Name    : updateCondition
	 * Purpose : Method to update conditions
	 * Params  : --
	 * Return  : --
	 **/
	updateCondition : function() {
		var recordupdt, editConditionValue, dateObject, body;
		editConditionValue = $('#conditionName').val();
		mHealth.models.ConditionModel.each(function(record) {
			if(record.conditionName === editConditionValue) {
				recordupdt = record;

			}
		});
		recordupdt.fromForm('#confirm_condition').save();
		dateObject = new Date(recordupdt.diagnosisDate.substr(6, 4), recordupdt.diagnosisDate.substr(0, 2) - 1, recordupdt.diagnosisDate.substr(3, 2));
		recordupdt.updateAttributes({
			diagnosisDate : dateObject.format("yyyy-mm-dd")
		});
		body = JSON.stringify([recordupdt]);
		this.service.postRequest(mHealth.env.condition_url, body, this.proxy(this.postSuccess), this.proxy(this.postError) ,true);
	},
	/**
	 * Name    : postSuccess
	 * Purpose : Success callback for updating/saving conditions to the server
	 * Params  : output - response from the server
	 * Return  : --
	 **/
	postSuccess : function(output) {
		$.mobile.changePage('conditionindex.html');
	},
	/**
	 * Name    :
	 * Purpose : Failure callback for updating/saving conditions to the server
	 * Params  : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server
	 * Return  : Alerts 'Information not available'
	 **/
	postError : function(jqXHR, textStatus, errorThrown) {
		alert("Information not available");
	},
	/**
	 * Name    :
	 * Purpose : Method to set the values of the fields in confirmCondition.html
	 * Params  : --
	 * Return  : --
	 **/
	editCondition : function() {
		var currentPageURL, renderConditionName, renderDate;
		currentPageURL = $('div[id = "editCondition"]').attr('data-url');
		renderConditionName = mHealth.util.getParameterByName('renderConditionName', currentPageURL);
		renderDate = mHealth.util.getParameterByName('renderDate', currentPageURL);
		$('#diagnosisDate').scroller({preset:'date',theme:'ios'});
		$('#conditionName').val(renderConditionName);
		$('#diagnosisDate').val(renderDate);
	},
	/**
	 * Name    :
	 * Purpose : Method to get the rendered value of condition name and diagnosis date from conditionindex.html
	 * Params  : e - event object
	 * Return  : --
	 **/
	editConditionDetails : function(e) {
		var item, trimRenderConditionName, trimRenderDate, renderConditionName, renderDate;
		item = e.target;
		renderConditionName = $(item).parents().children('div[id="conditionname"]').text();
		trimRenderConditionName = renderConditionName.trim();
        renderDate = $(item).parents().children('div[id="diagnosisdate"]').text();
		trimRenderDate = renderDate.trim();
		$.mobile.changePage('confirmcondition.html', {data:{renderConditionName:trimRenderConditionName, renderDate:trimRenderDate}});
	},
	/**
	 * Name    :
	 * Purpose : Method to save a new condition in the server
	 * Params  : --
	 * Return  : --
	 **/
	saveCondition : function() {
		var recordIcd9Id, recordSubConditionName, subConditionSelected, subConditions, i, dateObject, dateValue, conditionRecord, msg, keys, body;
		recordIcd9Id = '';
		recordSubConditionName = '';
		if(mHealth.controllers.MedicalHistoryController.prev !== 'condition_index') {
			if(mHealth.controllers.MedicalHistoryController.flagShow === true) {
				subConditionSelected = $('select#subcondition option:selected').val();
				subConditions = renderRecord.SubCondition
				for( i = 0; i < subConditions.length; i++) {
					if(subConditions[i].subConditionName === subConditionSelected) {
						recordIcd9Id = subConditions[i].icd9Id;
						recordSubConditionName = subConditions[i].subConditionName;
					}
				}
			} else {
				recordIcd9Id = renderRecord.icd9Id;
				recordSubConditionName = '';
			}
		} else {
			recordIcd9Id = '';
			recordSubConditionName = '';
		}
		dateObject = new Date($('#dt').val().substr(6, 4), $('#dt').val().substr(0, 2) - 1, $('#dt').val().substr(3, 2));
		dateValue = dateObject.format("yyyy-mm-dd");
		conditionRecord = new mHealth.models.ConditionModel({
			participantId : '',
			memberEligId : '',
			participantConditionId : '',
			icd9Id : recordIcd9Id,
			conditionName : renderRecord.conditionName,
			subConditionName : recordSubConditionName,
			diagnosisDate : dateValue,
			conditionComment : '',
			statusId : '',
			sourceId : '',
			applicationId : ''
		});
		conditionRecord.save();
		if(!conditionRecord.save()) {
			msg = conditionRecord.validate();
			alert(msg);
		} else {
			keys = ['participantId', 'memberEligId', 'participantConditionId', 'icd9Id', 'conditionName', 'subConditionName', 'diagnosisDate', 'conditionComment', 'statusId', 'sourceId', 'applicationId'];
			body = JSON.stringify([conditionRecord], keys);
			this.service.postRequest(mHealth.env.condition_url, body, this.proxy(this.postSuccess), this.proxy(this.postError),true);
		}
	},
	/**
	 * Name    :
	 * Purpose : Method tho set the previous page of addcondition.html
	 * Params  : --
	 * Return  : --
	 **/
	setPrev : function() {
		mHealth.controllers.MedicalHistoryController.flagShow = false;
		mHealth.controllers.MedicalHistoryController.prev = "condition_index";
	},
	/**
	 * Name    :
	 * Purpose : Method to get the associated record with the search condition clicked
	 * Params  : e - event object
	 * Return  : Condition model record associated with the fields
	 **/
	addConditionDetails : function(e) {
		var item, itemHtml;

		mHealth.controllers.MedicalHistoryController.prev = "condition_search"
		item = $(e.target);
		itemHtml = item.html();
		mHealth.models.SearchConditionModel.each(function(record) {
			if(record.conditionName === itemHtml) {
				if(_.isEmpty(record.SubCondition)) {
					mHealth.controllers.MedicalHistoryController.flagShow = false;
				} else {
					mHealth.controllers.MedicalHistoryController.flagShow = true;
				}
				renderRecord = record;
				// TODO : renderRecord should not be a global variable.
			}
		});
	},
	/**
	 * Name    :
	 * Purpose : Method to make service call for fetching list of conditions from the server
	 * Params  : --
	 * Return  : --
	 **/
	getCondition : function() {
		var modelCount;
		modelCount = mHealth.models.ConditionModel.count();
		if(modelCount === 0) {
			this.service.getResponse(mHealth.env.condition_url, this.proxy(this.conditionSuccess), this.proxy(this.conditionError),true);
		} else {
			$.mobile.changePage("../view/conditionindex.html");
		}
	},
	/**
	 * Name    :
	 * Purpose : Success callback for fetching search conditions from the server
	 * Params  : output - XMLHttpRequest object to get the response from the server
	 * Return  : --
	 **/
	subConditionSuccess : function(output) {
	
		var response;
		var searchConditionData;
		response = output.responseText;
		this.proxy(this.saveSubCondition(response));
		searchConditionData = mHealth.models.SearchConditionModel.all();
	
		$('#search_div').html(_.template($('#search_script').html(), {
			searchConditionData : searchConditionData
		}));
		$('#search_div').trigger('create');
		//$.mobile.changePage("../view/conditionsearch.html");
	},
	/**
	 * Name    :
	 * Purpose : Success callback for fetching conditions from the server
	 * Params  : output - XMLHttpRequest object to get the response from the server
	 * Return  : --
	 **/
	conditionSuccess : function(output) {
		var response;
		response = output.responseText;
		this.proxy(this.processConditionData(response));
		$.mobile.changePage("../view/conditionindex.html");
	},
	/**
	 * Name    :
	 * Purpose : Failure callback for fetching conditions from the server
	 * Params  : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server
	 * Return  : Alerts 'Information not available'
	 **/
	conditionError : function(jqXHR, textStatus, errorThrown) {
		alert("Information not available");
	},
	/**
	 * Name    :
	 * Purpose : Render conditions in conditionindex.html
	 * Params  : --
	 * Return  : conditionData - list of conditions to be rendered
	 **/
	showCondition : function() {
		var conditionData;
		mHealth.models.ConditionModel.each(function(record) {
			if(record.statusId == '2') {
				mHealth.models.ConditionModel.destroy(record.id);
			}
		});
		conditionData = mHealth.models.ConditionModel.all();
		$('#condition_div').html(_.template($('#conditionDataList').html(), {
			conditionData : conditionData
		}));
		$('#condition_index').trigger('create');

	},
	/**
	 Purpose: Method to set the field values in addcondition.html
	 Params : --
	 Return : --
	 */
	addCondition : function() {
		var subCondition;
		$('#dt').val(mHealth.util.getCurrentDate());
		if(mHealth.controllers.MedicalHistoryController.flagShow === true) {
			$('#subconditiondiv').show();
			$('#con_div').html(_.template($('#con_script').html(), {
				renderRecord : renderRecord
			}));
			subCondition = renderRecord.SubCondition;
			$('#subconditiondiv').html(_.template($('#subcon_script').html(), {
				subCondition : subCondition
			}));

		}
		if(mHealth.controllers.MedicalHistoryController.flagShow === false) {
			if(mHealth.controllers.MedicalHistoryController.prev === 'condition_index') {
				renderRecord = '';
				renderRecord.conditionName = '';
			}
			$('#subconditiondiv').hide();
			$('#con_div').html(_.template($('#con_script').html(), {
				renderRecord : renderRecord
			}));

		}
		$('#dt').scroller({preset:'date',theme:'ios'});
		$('#add_condition').trigger('create');
	},
	/**
	 * Name    : getSubCondition
	 * Purpose : Service call to fetch search conditions from the server
	 * Params  : --
	 * Return  : --
	 **/
	getSubCondition : function() {
		// var modelCount;
		// modelCount = mHealth.models.SearchConditionModel.count();
		// if(modelCount === 0) {
		//
		// this.service.getResponse(mHealth.dev.searchcondition_url, this.proxy(this.subConditionSuccess), this.proxy(this.conditionError));
		// } else {
		$.mobile.changePage("../view/conditionsearch.html");
		// }
	},
	/**
	 * Name    : showSubCondition
	 * Purpose : Method to render the list of search conditions in conditionsearch.html
	 * Params  : --
	 * Return  : searchConditionData - Search condition data to be rendered
	 **/
	showSubCondition : function() {
		var searchConditionData;
		searchConditionData = mHealth.models.SearchConditionModel.all();
		$('#search_div').html(_.template($('#search_script').html(), {
			searchConditionData : searchConditionData
		}));
		$('#condition_search').trigger('create');
	},
	/**
	 * Name    : processConditionData
	 * Purpose : Method to set the condition data to condition model
	 * Params  : responseText - Response from the server
	 * Return  : --
	 **/
	processConditionData : function(responseText) {
		mHealth.models.ConditionModel.customFromJSON(responseText);
	},
	/**
	 * Name    : saveSubCondition
	 * Purpose : Method to set the search condition data to search condition model
	 * Params  : response - Response from the server
	 * Return  : --
	 **/
	saveSubCondition : function(response) {
		mHealth.models.SearchConditionModel.customFromJSON(response);
	},
	/**
	 * Name    : init
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	init : function() {
	}
});

mHealth.controllers.MedicalHistoryController.extend({

	flagShow : false, // Property that decides whether to hide or show the sub condition field in addcondition.html.

	prev : ''         // Property that contains the previous page of addcondition.html

});
