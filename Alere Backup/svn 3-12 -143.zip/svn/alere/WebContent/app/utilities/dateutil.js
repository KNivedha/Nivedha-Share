/**
  * Date functions
  **/

/**
  * Name    : parseUTC 
  * Purpose : Method to convert date from UTC format to mm/dd/yyyy hrs:min format 
  * Params  : utcDate - UTC date string
  * Returns : dateString
  **/
mHealth.util.parseUTC = function(utcDate){
    var year, mon, day, hr, min, sec, date, dateString;
year = utcDate.substring(0,4);
mon = utcDate.substring(4,6);
day = utcDate.substring(6,8);
hr = utcDate.substring(9,11);
min = utcDate.substring(11,13);
sec = utcDate.substring(13,15);

date = new Date(year, mon, day, hr, min, sec);
dateString = date.getMonth()+'/'+date.getDate()+'/'+date.getFullYear()+' '+date.toLocaleTimeString();
return dateString;
};

/**
 * Name    : getCurrentDate 
 * Purpose : Method to get the current date in mm/dd/yyyy format 
 * Params  : --
 * Returns : today
 **/
mHealth.util.getCurrentDate = function()
{
    var today, today, mm, yyyy;
today = new Date();
dd = today.getDate();
mm = today.getMonth()+1; 

yyyy = today.getFullYear();
if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm}  today = mm+'/'+dd+'/'+yyyy;
return today;
};
