/**  
  * Assessment UI generator
  **/
mHealth.assessment = {

/**
  * Name    : createRecommendationRequestJSON
  * Purpose : Method to create request body for recommendation Service.
  * Params  : responseType -  recommendation type
  * Returns : bodyContent
  **/
	get_dropdown_html : function(question) {			
			disabled = false;
			id = "";
			question.answers.each(function(answer) {
				if(ParticipantAnswer.exists(answer)) {
					disabled = true;
					id = answer.answerId;
				}
			});
			instance_outputHTML = "";
			instance_outputHTML += "<div data-role='fieldcontain'>";
	
			if(!disabled) {
				instance_outputHTML += "<label for='#{question.questionId}' class='select'>#{question.theQuestion}</label>";
				instance_outputHTML += "<select onChange='changeValue(this)' id='#{question.questionId}' name='form[dropdown]'>";
				instance_outputHTML += "<option id=\"Default\" name =\"form[dropdown]\" value=\"default\">Please Select One</option>";
	
				question.answers.each(function(answer) {
					instance_outputHTML += "<option id=\"#{answer.object}\" name =\"form[dropdown]\" value=\"#{answer.theAnswer}\">";
					instance_outputHTML += answer.theAnswer.to_s;
					instance_outputHTML += "</option>";
	
				});
				instance_outputHTML += "</select>";
	
			} else if(disabled) {
				instance_outputHTML += "<label for='#{question.questionId}' class='select'>#{question.theQuestion}</label>";
				instance_outputHTML += "<select onChange=\"changeValue(this)\" id='#{question.questionId}' name='form[nil]' disabled>";
	
				question.answers.each(function(answer) {
	
					if(answer.answerId == id) {
						instance_outputHTML += "<option selected='yes' ";
	
					} else if(answer.answerId != id) {
						instance_outputHTML += "<option ";
	
					}
					instance_outputHTML += "id='#{answer.answerId}' value='#{answer.theAnswer}'>";
					instance_outputHTML += answer.theAnswer.to_s;
					instance_outputHTML += "</option>";
	
				});
				instance_outputHTML += "</select>";
	
			}
			instance_outputHTML += "</div>";
	
			return instance_outputHTML;
	}
};