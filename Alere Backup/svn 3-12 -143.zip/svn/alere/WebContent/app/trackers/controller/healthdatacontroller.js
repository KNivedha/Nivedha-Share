mHealth.controllers.HealthDataController = Spine.Controller.sub({
	healthDataTracker : 'Blood Glucose',
	trackerData : '',
	
	currentView : "Month",
	
	currentTime : new Date(),
	cyear : new Date().getFullYear(),
	cmonth : new Date().getMonth() + 1,
	
	lastDateM : new Date(this.cyear, this.cmonth, 0),
	gTitleM : '',
	xMaxDate : '',
	xMinDate : '',

	currentTimeM : this.currentTime,
	cyearM : this.cyear,
	cmonthM : this.cmonth,

	maxWeekDate : '',
	maxDateW : '',
	minWeekDate : '',
	minDateW : '',
	gTitleW : '',
	gTitleWmax : '',
	gTitleWmin : '',

	maxDayDate : '',
	maxDateD : '',
	minDayDate : '',
	minDateD : '',
	gTitleD : '',
	
	xMaxDateMonth: '',
	xMaxDateWeek: '',
	xMaxDateDay: '',
	
	dataPoints: '',
	getPlotOptions: '',
	
	seriesDataSet1: '',
	seriesDataSet2: '',
	
	glucosePlotOptions: '',
	avgCords: '',
	plotCords: '',
	thresholdMinGlucose: '',
	thresholdMaxGlucose: '',
	maxHealthDataValue: 0,
	
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #viewJournal' : 'getJournalData',
		'click #viewGraph' : 'getGraphData',
		'pagebeforeshow #show_tracker_view' : 'showTracker',
		'pagebeforeshow #show_tracker_track' : 'newEntryTracker',
		'click #track_save' : 'newEntrySave',
		'click .tracker' : 'setTrackerType',
		'pagebeforeshow #show_journal' : 'showJournal',
		'pagebeforeshow #graphpage' : 'showGraphHeader',
		'click .chotype' : 'setChoType',
		'click #graphBack' : 'setBackPage',
		'click #trackClick' : 'setBackPage',
        'click #glucoseBackButton' : 'setStopRotation',
        'click "#leftbutton' : 'leftButtonClick',
		'click #rightbutton' : 'rightButtonClick',
		'click #monthbutton' : 'monthButtonClick',
		'click #weekbutton' : 'weekButtonClick',
		'click #daybutton' : 'dayButtonClick',
		'pageshow #graphpage' : 'drawGraph',
		'pageshow #glucosegraphpage' : 'drawGlucoseGraph',
		'click #showTrackerPage':'setGlucoseTracker'
		                                                                
	},

	/**
	 *Name: setTrackerType
	 *Purpose: Sets Tracker type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setTrackerType : function(e) {
		this.healthDataTracker = $(e.target).parents(".tracker").attr('name');
		if(this.healthDataTracker!='Exams')
		$.mobile.changePage('detailtracker.html');
		else
		$.mobile.changePage('examslist.html');
	},
	
	/**
	 *Name: setChoType
	 *Purpose: Sets Cholesterol type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setChoType : function(e) {
		this.healthDataTracker = $(e.target).parents(".chotype").attr('name');
		this.getGraphData();
	},
	
	/**
	 *Name: showGraphHeader
	 *Purpose: Sets Back button action depending on the tracker type
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	showGraphHeader : function(){
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#graphHeader').html(_.template($('#graphtemplate').html(), {
			trackerType : trackerType
		}));
		$('#graphHeader').trigger('create');
	},
	
	/**
	 *Name: setBackType
	 *Purpose: Sets Back Page from Cholesterol graph
	 *Params: no params
	 *Returns: doesn't return
	 **/
	setBackPage : function(e) {
		this.healthDataTracker =  "Cholesterol";
	},
                                                                
    /**
     *Name: setStopRotation
     *Purpose: changes the orientation to default
     *Params: no params
     *Returns: doesn't return
     **/
    setStopRotation : function(e) {
    location.href="gyro://stopRotation?";
    },
    
   /**
	 *Name: showGraph
	 *Purpose: Shows graph page
	 *Params: no params
	 *Returns: doesn't return
	 **/
	showGraph : function() {
		//alert($("#trackergraphs").html());
		if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure"){
				this.currentView = "Week";
				var wday = this.currentTime.getDay();
				this.minWeekDate = new Date(this.currentTime.getTime() - (wday * 24 * 60 * 60 * 1000));
				this.minDateW = this.calculateDate(this.minWeekDate,1);
				this.gTitleWmin = this.setTitle(this.minWeekDate,this.currentView);
				this.maxWeekDate = new Date(this.currentTime.getTime() + ((6 - wday + 1) * 24 * 60 * 60 * 1000));
				this.maxDateW = this.calculateDate(this.maxWeekDate,1);
				this.gTitleWmax = this.setTitle(this.maxWeekDate,this.currentView);
				this.gTitleW = this.gTitleWmin + "-" + this.gTitleWmax;
				//$("#spantitle span").text(this.gTitleW);
				
				this.xMaxDateWeek=this.maxDateW;
				this.setGraph(this.currentView,this.minDateW, this.maxDateW,this.gTitleW);
		}
		else {		
				this.currentView = "Month";
				this.lastDateM = new Date(this.cyear, this.cmonth, 0);
				this.gTitleM = this.setTitle(this.lastDateM,this.currentView);
				this.xMaxDate = this.calculateDate(this.lastDateM,2);
				if(this.cmonth<=9)
				this.cmonth="0"+this.cmonth;
				this.xMinDate = this.cyear + "-" + this.cmonth + "-" + "01" + " " + "00" + ":" + "00";
				//$("#spantitle span").text(this.gTitleM);
				//$("#rightbutton").css("display", "none");
				this.cyearM = this.cyear;
				this.cmonthM = parseInt(this.cmonth,10);
				this.xMaxDateMonth=this.xMaxDate;
				this.setGraph(this.currentView,this.xMinDate,this.xMaxDate,this.gTitleM);
		}	
	},
		
		/**
	 *Name: setTitle 
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	setTitle : function(lastDateM,currentView) {
		var months = new Array(12);
			months[0] = "January";
			months[1] = "February";
			months[2] = "March";
			months[3] = "April";
			months[4] = "May";
			months[5] = "June";
			months[6] = "July";
			months[7] = "August";
			months[8] = "September";
			months[9] = "October";
			months[10] = "November";
			months[11] = "December";
			
			if(currentView=="Month")
           	return months[lastDateM.getMonth()] + "-" + lastDateM.getFullYear();
            else if(currentView=="Week")
			return months[lastDateM.getMonth()].substr(0, 3) + " " + lastDateM.getDate();
            else
            return months[lastDateM.getMonth()].substr(0, 3) + lastDateM.getDate() + "," + lastDateM.getFullYear();
	},

	
	
	/**
	 *Name: calculateDate
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	calculateDate: function(currentTime,minmax)  {
		var month = currentTime.getMonth() + 1;
			var day = currentTime.getDate();
			var year = currentTime.getFullYear();
			var hours = currentTime.getHours();
			var minutes = currentTime.getMinutes();
			var seconds = currentTime.getSeconds();
			if(month<=9)
			 month="0"+month;
			 if(day<=9)
			 day="0"+day;
			
			if(minmax==1)
			return year + "-" + month + "-" + day + " " + "00" + ":" + "00";
			else
			return year + "-" + month + "-" + day + " " + "23" + ":" + "59";
	},
	
		/**
	 *Name: setGraph
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	setGraph: function(currentView,xMinDate,xMaxDate,gTitleM)  {
		
			   if(this.healthDataTracker == "Weight & BMI") {
			   	//alert("inside setGraph WBMIs");
			   		if(currentView == "Month"){
			   			//alert("Month view"+xMinDate);
			   			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 400,0,0, '1 week', 50, '%b %d', '%.0f', gTitleM, '', 'Weight', 'BMI', "trackergraphs","Weight & BMI");	
					}else if(currentView == "Week"){
						this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 400,0,0, '1 day', 50, '%a', '%.0f', gTitleM, '', 'Weight', 'BMI', "trackergraphs","Weight & BMI");
					}else{
						this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 400,0,0, '4 hour', 50, '%I %p', '%.0f', gTitleM, '', 'Weight', 'BMI', "trackergraphs","Weight & BMI");
					}
					this.dataPoints=this.calculateDataPoints(this.seriesDataSet1, this.seriesDataSet2,xMinDate,xMaxDate);
					
				} 
				else if(this.healthDataTracker == "Blood Pressure") {
					if(currentView == "Month"){
			   			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 200,80,40, '1 week', 40, '%b %d', '%.0f', gTitleM, '',  'Diastolic','Systolic', "trackergraphs","Blood Pressure");	
					}else if(currentView == "Week"){
						this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 200,80,40, '1 day',40, '%a', '%.0f', gTitleM, '',  'Diastolic','Systolic',  "trackergraphs","Blood Pressure");
					}else{
						this.getPlotOptions= this.setPlotOptions(xMinDate, xMaxDate, 0, 200,80,40, '4 hour', 40, '%I %p', '%.0f', gTitleM, '',  'Diastolic','Systolic',  "trackergraphs","Blood Pressure");
					}
					this.dataPoints=this.calculateDataPoints(this.seriesDataSet1, this.seriesDataSet2,xMinDate,xMaxDate);
					
				}
				else if(this.healthDataTracker == "A1c") {
					if(this.currentView == "Month"){
			   			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 3, 10,6,1, '1 week', 1, '%b %d', '%.0f', gTitleM, '', 'A1c', null, "trackergraphs","A1c");	
					}else if(this.currentView == "Week"){
						this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate,  3, 10,6,1, '1 day', 1, '%a', '%.0f', gTitleM, '',  'A1c', null,  "trackergraphs","A1c");
					}else{
						this.getPlotOptions= this.setPlotOptions(xMinDate, xMaxDate,  3, 10,6,1, '4 hour', 1, '%I %p', '%.0f', gTitleM, '',  'A1c', null, "trackergraphs","A1c");
					}
					this.dataPoints=this.calculateDataPoints(this.seriesDataSet1,null,xMinDate,xMaxDate);
					
				}
				else if(this.healthDataTracker == "LDL & HDL") {
                   if(this.currentView == "Month"){
			   			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate,0, 200,0,0, '1 week', 40, '%b %d', '%.0f', gTitleM, '', 'LDL', 'HDL', "trackergraphs","LDL & HDL");	
					}else if(this.currentView == "Week"){
						this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate,0, 200,0,0, '1 day',40, '%a', '%.0f', gTitleM, '',  'LDL', 'HDL',  "trackergraphs","LDL & HDL");
					}else{
						this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate,0, 200,0,0, '4 hour', 40, '%I %p', '%.0f', gTitleM, '', 'LDL', 'HDL', "trackergraphs","LDL & HDL");
					}
					this.dataPoints=this.calculateDataPoints(this.seriesDataSet1, this.seriesDataSet2,xMinDate,xMaxDate);
					
				}
				else if(this.healthDataTracker == "Total Cholesterol") {
                   if(this.currentView == "Month"){
			   			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 400,0,200, '1 week', 40, '%b %d', '%.0f', gTitleM, '', 'Cholesterol',null, "trackergraphs","Total Cholesterol");	
					}else if(this.currentView == "Week"){
						this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 400,0,200, '1 day', 40, '%a', '%.0f', gTitleM, '',  'Cholesterol', null,  "trackergraphs","Total Cholesterol");
					}else{
						this.getPlotOptions= this.setPlotOptions(xMinDate, xMaxDate, 0, 400,0,200, '4 hour', 40, '%I %p', '%.0f', gTitleM, '', 'Cholesterol', null, "trackergraphs","Total Cholesterol");
					}
					this.dataPoints=this.calculateDataPoints(this.seriesDataSet1,null,xMinDate,xMaxDate);
					
				}
				else if(this.healthDataTracker == "Triglycerides") {
                   if(this.currentView == "Month"){
			   			this.getPlotOptions= this.setPlotOptions(xMinDate, xMaxDate,  0, 160,0,150, '1 week', 50, '%b %d', '%.0f', gTitleM, '', 'Triglycerides',null, "trackergraphs","Triglycerides");	
					}else if(this.currentView == "Week"){
						this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate,  0, 160,0,150, '1 day', 50, '%a', '%.0f', gTitleM, '',  'Triglycerides', null,  "trackergraphs","Triglycerides");
					}else{
						this.getPlotOptions= this.setPlotOptions(xMinDate, xMaxDate,  0, 160,0,150, '4 hour',50, '%I %p', '%.0f', gTitleM, '', 'Triglycerides', null, "trackergraphs","Triglycerides");
					}
					this.dataPoints=this.calculateDataPoints(this.seriesDataSet1,null,xMinDate,xMaxDate);
					
				}
	},
	
		/**
	 *Name: setPlotOptions 
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	setPlotOptions : function(xMin, xMax, yMin, yMax,threshMin,threshMax, xTickInterval, yTickInterval, xstringFormat, ystringFormat, xLabel, yLabel, series1Label, series2Label, divname,graph_title){
		var viewOptions = new Object();

			viewOptions['xMin'] = xMin;
			viewOptions['xMax'] = xMax;
			viewOptions['yMin'] = yMin;
			viewOptions['yMax'] = yMax;
			viewOptions['threshMin'] = threshMin;
			viewOptions['threshMax'] = threshMax;
			viewOptions['xTickInterval'] = xTickInterval;
			viewOptions['yTickInterval'] = yTickInterval;
			viewOptions['xstringFormat'] = xstringFormat;
			viewOptions['ystringFormat'] = ystringFormat;
			viewOptions['xLabel'] = xLabel;
			viewOptions['yLabel'] = yLabel;
			viewOptions['series1Label'] = series1Label;
			viewOptions['series2Label'] = series2Label;
			viewOptions['divname'] = divname;
			viewOptions['graph_title'] = graph_title;
			
			return viewOptions;
	},
	
	/**
	 *Name: calculateDataPoints 
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	 calculateDataPoints : function(trackerIDW, trackerIDBMI,xMinDate,xMaxDate){
		var storeCordsWeight = new Array();
			var storeCordsBMI = new Array();
			var counterTrackerIDW=0;
			var counterTrackerIDBMI=0;
			if(trackerIDW) {
				plotdata = trackerIDW;
				for(var counter = 0; counter < plotdata.length; counter++) {
					var usrtmeYear = parseInt((plotdata[counter].measurementDate).substr(0, 4),10);
					var usrtmeMonth = parseInt((plotdata[counter].measurementDate).substr(4, 2),10);
					var usrtmeDay = parseInt((plotdata[counter].measurementDate).substr(6, 2),10);
					var usrtmeHours = parseInt((plotdata[counter].measurementDate).substr(9, 2),10);
					var usrtmeMinutes = parseInt((plotdata[counter].measurementDate).substr(11, 2),10);
					var usrtmeSeconds = parseInt((plotdata[counter].measurementDate).substr(13, 2),10);

					var hlthdataWeight = parseInt(plotdata[counter].value);
					if(usrtmeMonth<=9)
					usrtmeMonth="0"+usrtmeMonth;
					if(usrtmeDay<=9)
					usrtmeDay="0"+usrtmeDay;
					
					usrtmeDay = usrtmeYear + '-' + usrtmeMonth + '-' + usrtmeDay + ' ' + usrtmeHours + ':' + usrtmeMinutes;
					
					if(usrtmeDay>=xMinDate && usrtmeDay<=xMaxDate)
					{
						
					storeCordsWeight[counterTrackerIDW] = new Array(2);
					
					storeCordsWeight[counterTrackerIDW][0] = usrtmeDay;
					storeCordsWeight[counterTrackerIDW][1] = hlthdataWeight;
					counterTrackerIDW=counterTrackerIDW+1;
					if(this.maxHealthDataValue<hlthdataWeight)
						this.maxHealthDataValue=hlthdataWeight;
					 }
				}
			}
			if(trackerIDBMI) {
				plotdata = trackerIDBMI;
				for(var counter = 0; counter < plotdata.length; counter++) {
					var usrtmeYear = parseInt((plotdata[counter].measurementDate).substr(0, 4),10);
					var usrtmeMonth = parseInt((plotdata[counter].measurementDate).substr(4, 2),10);
					var usrtmeDay = parseInt((plotdata[counter].measurementDate).substr(6, 2),10);
					var usrtmeHours = parseInt((plotdata[counter].measurementDate).substr(9, 2),10);
					var usrtmeMinutes = parseInt((plotdata[counter].measurementDate).substr(11, 2),10);
					var usrtmeSeconds = parseInt((plotdata[counter].measurementDate).substr(13, 2),10);

					var hlthdataBMI = parseInt(plotdata[counter].value);
									
					if(usrtmeMonth<=9)
					usrtmeMonth="0"+usrtmeMonth;
					if(usrtmeDay<=9)
					usrtmeDay="0"+usrtmeDay;
					
					usrtmeDay = usrtmeYear + '-' + usrtmeMonth + '-' + usrtmeDay + ' ' + usrtmeHours + ':' + usrtmeMinutes;
					
					
					if(usrtmeDay>=xMinDate && usrtmeDay<=xMaxDate)
					{
					storeCordsBMI[counterTrackerIDBMI] = new Array(2);
					storeCordsBMI[counterTrackerIDBMI][0] = usrtmeDay;
					storeCordsBMI[counterTrackerIDBMI][1] = hlthdataBMI;
					counterTrackerIDBMI=counterTrackerIDBMI+1;
					if(this.maxHealthDataValue<hlthdataBMI)
						this.maxHealthDataValue=hlthdataBMI;
					}

				}
			}
			var storeCords=[storeCordsWeight,storeCordsBMI];
			return storeCords;
	},

	/**
	 *Name: drawGraph
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	drawGraph: function(){
		$("#rightbutton").css("display", "none");
		if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure"){
			$("#spantitle span").text(this.gTitleW);
			$("#week").addClass("ui-btn-active");
		}
		else{
			$("#spantitle span").text(this.gTitleM);
			$("#month").addClass("ui-btn-active");
		}
		//alert("before calling");
		this.plotGraph(this.getPlotOptions,this.dataPoints);
	},
	
	/**
	 *Name: getGender
	 *Purpose: get gender for geting HDL min max value for graph
	 *Params: 
	 *Returns: returns gender
	 **/
	getGender: function() {
		var gend =(mHealth.models.ParticipantModel.first()).gender;
		return gend;

	},
	
		/**
	 *Name:plotGraph
	 *Purpose: 
	 *Params: 
	 *Returns:
	 **/
	plotGraph : function(getPlotOptions,dataPoints){
		//alert(this.maxHealthDataValue);
		var intervalCount=0;
			while(this.maxHealthDataValue>=intervalCount)
				{
					intervalCount=intervalCount+40;
				}
				this.maxHealthDataValue=0;
		if(this.healthDataTracker == "LDL & HDL" ){
			var genericSeries=[
					{
					color: '#9E0516', //red
					showLabel:false,
					showMarker:false,
					lineWidth:.9,
					fill:false
					},
					{
					color: '#9E0516', //red
					showLabel:false,
					showMarker:false,
					lineWidth:2,
					fill:true,
					fillAlpha:0.25
					},					
					{
					color: '#CFC4AE', //green
					showLabel:false,
					showMarker:false,
					lineWidth:.9,
					fill:false
					},
					{
					color: '#71BF44', //green
					showLabel:false,
					showMarker:false,
					lineWidth:2,
					fill:true,
					fillAlpha:0.25
					},					
					{
						disableStack:true,
						color: '#faa01b',   // red						
						// showMarker:% if @graph['count'] > 1 %>false % else %>trues% end %>, // original%>
						label:'HDL',
						showMarker:true,
						lineWidth:3
						},
						{
						disableStack:true,
						color: '#92c83e', //green	
						label:'LDL',					
						showMarker:true,
						lineWidth:2
						}
		
					];
			var thresholdMinLDL=[[getPlotOptions['xMin'],0], [getPlotOptions['xMax'], 0]];
			var thresholdMaxLDL=[[getPlotOptions['xMin'],100], [getPlotOptions['xMax'], 100]];
			var gend=this.getGender();
			
				//alert(intervalCount);
			if(gend!=null)
			{
				if(gend == "M"){
					var threshMinHDL=-60;
					var threshMaxHDL=intervalCount-60;
				}
				else{
					var threshMinHDL=-50;
					var threshMaxHDL=intervalCount-50;
				}
				var thresholdMin = [[getPlotOptions['xMin'],threshMinHDL], [getPlotOptions['xMax'], threshMinHDL]];
				var thresholdMax = [[getPlotOptions['xMin'], threshMaxHDL], [getPlotOptions['xMax'],threshMaxHDL]];
			}
			else{
				var thresholdMin = [[getPlotOptions['xMin'],getPlotOptions['threshMin']], [getPlotOptions['xMax'], getPlotOptions['threshMin']]];
				var thresholdMax = [[getPlotOptions['xMin'], getPlotOptions['threshMax']], [getPlotOptions['xMax'],getPlotOptions['threshMax']]];
			}
		}
		else{
			var genericSeries=[{
					color : '#92c83e', //green
					showLabel : false,
					showMarker : false,
					lineWidth : .1,
					fill : false
				}, {
					color : '#333333', //dark gray
					showLabel : false,
					showMarker : false,
					lineWidth : 2,
					fill : true,
					fillAlpha : 0.25
				}, {
					disableStack : true,
					color : '#92c83e', //green
					label : getPlotOptions['series1Label'],
					showMarker : true,
					lineWidth : 3
				}, {
					disableStack : true,
					color : '#faa01b', // orange
					label : getPlotOptions['series2Label'],
					showMarker : true,
					lineWidth : 2
				}];
				
			var thresholdMin = [[getPlotOptions['xMin'],getPlotOptions['threshMin']], [getPlotOptions['xMax'], getPlotOptions['threshMin']]];
			var thresholdMax = [[getPlotOptions['xMin'], getPlotOptions['threshMax']], [getPlotOptions['xMax'],getPlotOptions['threshMax']]];
		}
		var plotOptions = {
				title:getPlotOptions['graph_title'],
				legend : {
					show : true,
					placement: "outsideGrid",
				    location: 'nw'
				},

				axes : {
					xaxis : {
						min : getPlotOptions['xMin'],
						max : getPlotOptions['xMax'],
						renderer : $.jqplot.DateAxisRenderer,
						tickInterval : getPlotOptions['xTickInterval'],
						tickOptions : {
							formatString : getPlotOptions['xstringFormat']
						},
						showTickMarks : false
						// label : getPlotOptions['xLabel'],
						// showLabel : true
					},
					yaxis : {
						min : getPlotOptions['yMin'],
						//max : intervalCount,
						tickInterval : getPlotOptions['yTickInterval'],
						tickOptions : {
							formatString : getPlotOptions['ystringFormat']
						},
						showTickMarks : false
					}
				},
				grid : {
					drawGridLines : true,
					gridLineColor : '#cccccc',
					background : '#666666',
					borderWidth : 0
				},
				stackSeries : true,
				series : genericSeries
			};
			
		
			if(this.healthDataTracker == "A1c" || this.healthDataTracker == "Total Cholesterol" || this.healthDataTracker == "Triglycerides")
			plot1 = $.jqplot(getPlotOptions['divname'], [thresholdMin, thresholdMax, dataPoints[0]], plotOptions).replot();
			else if(this.healthDataTracker == "Blood Pressure" )
			plot1 = $.jqplot(getPlotOptions['divname'], [thresholdMin, thresholdMax, dataPoints[1],dataPoints[0]], plotOptions).replot();
			else if(this.healthDataTracker == "LDL & HDL" )
			plot1 = $.jqplot(getPlotOptions['divname'], [thresholdMinLDL, thresholdMaxLDL,thresholdMin, thresholdMax, dataPoints[0], dataPoints[1]], plotOptions).replot();
			else
			plot1 = $.jqplot(getPlotOptions['divname'], [thresholdMin, thresholdMax, dataPoints[0], dataPoints[1]], plotOptions).replot();


	},
		/**
	 *Name: leftButtonClick
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	leftButtonClick : function() {
		$("#rightbutton").css("display", "block");
		if(this.currentView == "Month") {
			
					this.currentTimeM = new Date(this.cyearM, parseInt(this.cmonthM,10) - 1, 0);
					this.cyearM = this.currentTimeM.getFullYear();
					this.cmonthM = this.currentTimeM.getMonth() + 1;
					this.lastDateM = new Date(this.cyearM, this.cmonthM, 0);
					this.gTitleM = this.setTitle(this.lastDateM,this.currentView);
					this.xMaxDate = this.calculateDate(this.lastDateM,2);
					if(this.cmonthM<=9)
					this.cmonthM="0"+this.cmonthM;
					this.xMinDate = this.cyearM + "-" + this.cmonthM + "-" + "01" + " " + "00" + ":" + "00";
					$("#spantitle span").text(this.gTitleM);

					this.setGraph(this.currentView,this.xMinDate,this.xMaxDate,this.gTitleM);
					

				} else if(this.currentView == "Week") {
					this.maxWeekDate = this.minWeekDate;
					this.maxDateW = this.calculateDate(this.maxWeekDate,1);
					this.gTitleWmax = this.setTitle(this.maxWeekDate,this.currentView);
					this.minWeekDate = new Date(this.maxWeekDate.getTime() - (7 * 24 * 60 * 60 * 1000));
					this.minDateW = this.calculateDate(this.minWeekDate,1);
					this.gTitleWmin = this.setTitle(this.minWeekDate,this.currentView);
					this.gTitleW = this.gTitleWmin + "-" + this.gTitleWmax;
					$("#spantitle span").text(this.gTitleW);
					this.setGraph(this.currentView,this.minDateW, this.maxDateW,this.gTitleW);

				} else {
					this.maxDayDate = this.minDayDate;
					this.maxDateD = this.calculateDate(this.maxDayDate,1);
					this.minDayDate = new Date(this.maxDayDate.getTime() - (24 * 60 * 60 * 1000));
					this.minDateD = this.calculateDate(this.minDayDate,1);
					this.gTitleD = this.setTitle(this.minDayDate,this.currentView);
					$("#spantitle span").text(this.gTitleD);
					
					this.setGraph(this.currentView,this.minDateD, this.maxDateD,this.gTitleD);

				}
				this.plotGraph(this.getPlotOptions,this.dataPoints);
	},
	
	/**
	 *Name: rightButtonClick
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	rightButtonClick : function(e) {
		if(this.currentView == "Month") {
			//alert("inside right button month");
					this.currentTimeM = new Date(this.cyearM, parseInt(this.cmonthM,10) + 1, 0);
					this.cyearM = this.currentTimeM.getFullYear();
					this.cmonthM = this.currentTimeM.getMonth() + 1;
					this.lastDateM = new Date(this.cyearM, this.cmonthM, 0);
					this.gTitleM = this.setTitle(this.lastDateM,this.currentView);
					$("#spantitle span").text(this.gTitleM);
					this.xMaxDate = this.calculateDate(this.lastDateM,2);
					if(this.cmonthM<=9)
					this.cmonthM="0"+this.cmonthM;
					this.xMinDate = this.cyearM + "-" + this.cmonthM + "-" + "01" + " " + "00" + ":" + "00";
					if(this.xMaxDate==this.xMaxDateMonth)
					$("#rightbutton").css("display", "none");
					else
					$("#rightbutton").css("display", "block");
					this.setGraph(this.currentView,this.xMinDate,this.xMaxDate,this.gTitleM);

				} else if(this.currentView == "Week") {
					this.minWeekDate = this.maxWeekDate;
					this.minDateW = this.calculateDate(this.minWeekDate,1);
					this.gTitleWmin = this.setTitle(this.minWeekDate,this.currentView);
					this.maxWeekDate = new Date(this.minWeekDate.getTime() + (7 * 24 * 60 * 60 * 1000));
					this.maxDateW = this.calculateDate(this.maxWeekDate,1);
					this.gTitleWmax = this.setTitle(this.maxWeekDate,this.currentView);
					this.gTitleW = this.gTitleWmin + "-" + this.gTitleWmax;
					$("#spantitle span").text(this.gTitleW);
					if(this.maxDateW==this.xMaxDateWeek)
					$("#rightbutton").css("display", "none");
					else
					$("#rightbutton").css("display", "block");
					this.setGraph(this.currentView,this.minDateW, this.maxDateW,this.gTitleW);


				} else {
					this.minDayDate = this.maxDayDate;
					this.minDateD = this.calculateDate(this.minDayDate,1);
					this.gTitleD = this.setTitle(this.minDayDate,this.currentView);
					$("#spantitle span").text(this.gTitleD);
					this.maxDayDate = new Date(this.minDayDate.getTime() + (24 * 60 * 60 * 1000));
					this.maxDateD = this.calculateDate(this.maxDayDate,1);
					if(this.maxDateD==this.xMaxDateDay)
					$("#rightbutton").css("display", "none");
					else
					$("#rightbutton").css("display", "block");
					this.setGraph(this.currentView,this.minDateD, this.maxDateD,this.gTitleD);

				}
				this.plotGraph(this.getPlotOptions,this.dataPoints);
	},
	
	/**
	 *Name: monthButtonClick
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	monthButtonClick : function(e) {
		this.currentView = "Month";
				this.lastDateM = new Date(this.cyear, this.cmonth, 0);
				this.gTitleM = this.setTitle(this.lastDateM,this.currentView);
				this.xMaxDate = this.calculateDate(this.lastDateM,2);
				if(this.cmonth<=9)
				this.cmonth="0"+this.cmonth;
				this.xMinDate = this.cyear + "-" + this.cmonth + "-" + "01" + " " + "00" + ":" + "00";
				$("#spantitle span").text(this.gTitleM);
				$("#rightbutton").css("display", "none");
				this.cyearM = this.cyear;
				this.cmonthM = parseInt(this.cmonth,10);
				this.xMaxDateMonth=this.xMaxDate;
				this.setGraph(this.currentView,this.xMinDate,this.xMaxDate,this.gTitleM);
				this.plotGraph(this.getPlotOptions,this.dataPoints);
				
	},
	
	/**
	 *Name: weekButtonClick
	 *Purpose: 
	 *Params:
	 *Returns:
	 **/
	weekButtonClick : function(e) {
		this.currentView = "Week";
				var wday = this.currentTime.getDay();
				this.minWeekDate = new Date(this.currentTime.getTime() - (wday * 24 * 60 * 60 * 1000));
				this.minDateW = this.calculateDate(this.minWeekDate,1);
				this.gTitleWmin = this.setTitle(this.minWeekDate,this.currentView);
				this.maxWeekDate = new Date(this.currentTime.getTime() + ((6 - wday + 1) * 24 * 60 * 60 * 1000));
				this.maxDateW = this.calculateDate(this.maxWeekDate,1);
				this.gTitleWmax = this.setTitle(this.maxWeekDate,this.currentView);
				this.gTitleW = this.gTitleWmin + "-" + this.gTitleWmax;
				$("#spantitle span").text(this.gTitleW);
				$("#rightbutton").css("display", "none");
				this.setGraph(this.currentView,this.minDateW, this.maxDateW,this.gTitleW);
				this.plotGraph(this.getPlotOptions,this.dataPoints);
	},
	
	/**
	 *Name: dayButtonClick
	 *Purpose: 
	 *Params:
	 *Returns:
	 **/
	dayButtonClick : function(e) {
		this.currentView = "Day";
				this.minDayDate = new Date(this.currentTime.getTime());
				this.minDateD = this.calculateDate(this.minDayDate,1);
				this.gTitleD = this.setTitle(this.minDayDate,this.currentView);
				$("#spantitle span").text(this.gTitleD);
				$("#rightbutton").css("display", "none");
				this.maxDayDate = new Date(this.currentTime.getTime() + (24 * 60 * 60 * 1000));
				this.maxDateD = this.calculateDate(this.maxDayDate,1);
				this.xMaxDateDay=this.maxDateD;
				this.setGraph(this.currentView,this.minDateD, this.maxDateD,this.gTitleD);
				this.plotGraph(this.getPlotOptions,this.dataPoints);
	},

	
	/**
	 *Name: plotGlucoseCords
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	plotGlucoseCords: function(glucosedata){
           	                          var storeCords=new Array();
                                      var plotData=glucosedata;
                                      for(var counter=0;counter<plotData.length;counter++)
                                      {
                                      var userTime=parseInt((plotData[counter].measurementDate).substr(9,2),10);
                                      var healthData=parseInt(plotData[counter].value);
                                      storeCords[counter]=new Array(2)
                                      if(userTime>=6 && userTime<9)
                                         storeCords[counter][0]=2;
                                      else if(userTime>=9 && userTime<11)
                                         storeCords[counter][0]=6;
                                      else if(userTime>=11 && userTime<14)
                                      	storeCords[counter][0]=10;
                                      else if(userTime>=14 && userTime<17)
                                      	storeCords[counter][0]=14;
                                      else if(userTime>=17 && userTime<20)
                                      	storeCords[counter][0]=18;
                                      else if(userTime>=20 && userTime<23)
                                      	storeCords[counter][0]=22;
                                      else if(userTime>=23 || userTime<6)
                                      	storeCords[counter][0]=26;
                                      	
                                      storeCords[counter][1]=healthData;
                                      }
                                     
                                    var groupSixAm=0,groupNineAm=0,groupElevenAm=0,groupTwoPm=0,groupSixPm=0,groupEightPm=0,groupElevenPm=0;
                                    var countGroupSixAm=0,countGroupNineAm=0,countGroupElevenAm=0,countGroupTwoPm=0,countGroupSixPm=0,countGroupEightPm=0,countGroupElevenPm=0;
                                    this.plotCords=storeCords;
                                    var plotCords_length=this.plotCords.length;
                                    for(var i=0;i<plotCords_length;i++)  {
                                    if(this.plotCords[i][0]==2){
                                    groupSixAm=groupSixAm+this.plotCords[i][1];
                                    countGroupSixAm=countGroupSixAm+1;
                                    }
                                    else if(this.plotCords[i][0]==6){
                                    groupNineAm=groupNineAm+this.plotCords[i][1];
                                    countGroupNineAm=countGroupNineAm+1;
                                    }
                                    else if(this.plotCords[i][0]==10){
                                    groupElevenAm=groupElevenAm+this.plotCords[i][1];
                                    countGroupElevenAm=countGroupElevenAm+1;
                                    }else if(this.plotCords[i][0]==14){
                                    groupTwoPm=groupTwoPm+this.plotCords[i][1];
                                    countGroupTwoPm=countGroupTwoPm+1;
                                    }else if(this.plotCords[i][0]==18){
                                    groupSixPm=groupSixPm+this.plotCords[i][1];
                                    countGroupSixPm=countGroupSixPm+1;
                                    }else if(this.plotCords[i][0]==22){
                                    groupEightPm=groupEightPm+this.plotCords[i][1];
                                    countGroupEightPm=countGroupEightPm+1;
                                    }else {
                                    groupElevenPm=groupElevenPm+this.plotCords[i][1];
                                    countGroupElevenPm=countGroupElevenPm+1;
                                    }
                                    }
                                    this.avgCords=[[2,groupSixAm/countGroupSixAm],[6,groupNineAm/countGroupNineAm],[10,groupElevenAm/countGroupElevenAm],[14,groupTwoPm/countGroupTwoPm],[18,groupSixPm/countGroupSixPm],[22,groupEightPm/countGroupEightPm],[26,groupElevenPm/countGroupElevenPm]];
                                    this.thresholdMinGlucose=[[0,80],[28,80]];
                                    this.thresholdMaxGlucose=[[0,40],[28,40]];

                                    this.glucosePlotOptions={
                                    	title: "Blood Glucose",
                                        axes:{
                                            xaxis:{
                                                min: 0,
                                                max: 28,
                                                //ticks: [[0, "6am-9am"], [4, "9am-11am"], [8, "11am-2pm"], [12,"2pm-5pm"],[16,"5pm-8pm"],[20,"8pm-11pm"],[24,"11pm-6am"],[28," "]],
                                                ticks: [[0, "6am"], [4, "9am"], [8, "11am"], [12,"2pm"],[16,"5pm"],[20,"8pm"],[24,"11pm"],[28,"6am"]],
                                                tickInterval: 4,
                                                showTickMarks: false
                                            },
                                            yaxis:{
                                                min:0,
                                                max: 350,
                                                tickInterval: 50,
                                                tickOptions:{ 
                                                   formatString: '%.0f'
                                                },
                                                showTickMarks: false,
                                                label: 'mg/dL'
                                            }
                                        },
                                        grid:{
                                            drawGridLines: true,         
                                            gridLineColor: '#FFFFFF',     
                                            background: '#463E41',
                                            borderWidth: 0           
                                        },
                                        stackSeries: true,
                                        series:[
                                                {
                                                color: '#92c83e', //green
                                                showLabel:false,
                                                showMarker:false,
                                                lineWidth:.1,
                                                fill:false
                                                },
                                                {
                                                color: '#C38EC7', //violet
                                                showLabel:false,
                                                showMarker:false,
                                                lineWidth:2,
                                                fill:true,
                                                fillAlpha:0.25
                                                },
                                                {
                                                disableStack:true,
                                                color: 'cyan',  
                                                label:'Data',
                                                showLine:false, 
                                                markerOptions: { size: 7, style:"x" }
                                                },
                                                {
                                                disableStack:true,
                                                color: 'white', 
                                                label:'Average',
                                                showLine:false,
                                                markerOptions: { style:"filledSquare", size:10 }
                                                }
                                                ]
                                         };
                                    
                                   // plot1 = $.jqplot ("monthgraph", [thresholdMin,thresholdMax,plotCords,avgCords],plotOptions).replot();
        
        },
        
        /**
	 *Name: drawGlucoseGraph
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
        drawGlucoseGraph: function() {
        	//alert("inside drawGlucoseGraph"+this.thresholdMinGlucose+this.thresholdMaxGlucose+this.plotCords+this.avgCords+this.glucosePlotOptions);
        	$("#graphtitle span").text(this.healthDataTracker);
        	plot1 = $.jqplot ("glucosegraph", [this.thresholdMinGlucose,this.thresholdMaxGlucose,this.plotCords,this.avgCords],this.glucosePlotOptions).replot();
        },

	/**
	 *Name: showJournal
	 *Purpose: Renders the showjournal.html page content
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	showJournal : function() {
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#journal_content').html(_.template($('#journal_list').html(), {
			trackerData : this.trackerData,
			trackerType : trackerType
		}));
		
		$('#show_journal').trigger('create');
	},
	
	/**
	 *Name: showTracker
	 *Purpose: renders the showtracker.html page
	 *Params: No params required
	 *Returns: Doesn't return
	 **/
	showTracker : function() {
		// healthDataTracker has to change to class level.
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#trackviewcontent').html(_.template($('#trackerviewtemplate').html(), {
			trackerType : trackerType
		}));
		$('#headercontent').html(_.template($('#headertemplate').html(), {
			trackerType : trackerType
		}));
		//Usong the page id and trigger .create should populate the value
		//$('#show_tracker_view').page('destroy').page();
		$('#headercontent').trigger('create');
		$('#trackviewcontent').trigger('create');
	},
	
	/**
	 *Name: newEntryTracker
	 *Purpose: renders the showtrackertrack.html page
	 *Params: None
	 *Returns:Doesn't return
	 **/
	newEntryTracker : function() {
		// healthDataTracker has to change to class level.
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#showtrackertrackcontent').html(_.template($('#showtrackertracktemplate').html(), {
			trackerType : trackerType
		}));
		
		$('#show_tracker_track').trigger('create');
	},
	
	/**
	 *Name: newHDataObject
	 *Purpose: Creates new health data object to be saved
	 *Params: measurement date, collected date and value. These are set in json object that is created.
	 *Returns: returns a formatted object to be passed as a param in the postRequest service call
	 **/
	newHDataObject : function(measurementDate, collectedDate, value) {
		var hDataObject = [{
			"collectedDate" : collectedDate,
			"latitude" : "",
			"comments" : $('#comments').val(),
			"measurementDate" : measurementDate,
			"appSource" : "1",
			"value" : value,
			"longitude" : "",
			"groupId" : "",
			"source" : "1"
		}];
		return (JSON.stringify(hDataObject));
	},
	
	/**
	 *Name: newEntrySave
	 *Purpose: Saves new tracker entry
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	newEntrySave : function() {
		if(validForm) {//validForm is a global varaible set to true if the submitted form is valid. It should be eliminated.
			var dateSelected = $('#selectDate').val();
			var dateObject;
			if(this.healthDataTracker=='Blood Pressure' || this.healthDataTracker=='Blood Glucose' || this.healthDataTracker=='Weight & BMI')
			{
				var hour = dateSelected.substr(11, 2);
				hour = parseInt(hour, 10);
				if(dateSelected.substr(17, 2) == "PM") {
					if(hour != 12)
						hour = hour + 12;
				} else {
					if(hour == 12)
						hour = 0;
				}
				dateObject = new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2), hour, dateSelected.substr(14, 2));
			}
			else
				dateObject=new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2));
			var measurementDate = dateObject.format('yyyymmdd"T"HHMMss".000 GMT"');
			var collectedDate = (new Date()).format('yyyymmdd"T"HHMMss".000 GMT"');
			if(this.healthDataTracker == "Weight & BMI") {
				var weightModifier=1;
				if(mHealth.util.selWeightUnits=='Kg')
					weightModifier=2.205;
				else
					weightModifier=1;
				var value = String(Math.round(parseInt($('#value_Weight').val())*weightModifier));
				var weightHDataObject = this.newHDataObject(measurementDate, collectedDate, value);
				var bmiHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Bmi').val());
				this.service.postRequest((mHealth.env.healthdata_url + "Weight"), weightHDataObject, "", this.proxy(this.trackerSaveFailure),false);
				this.service.postRequest((mHealth.env.healthdata_url + "BMI"), bmiHDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure),true);
			} else if(this.healthDataTracker == "A1c") {
				var hDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_A1C').val());
				this.service.postRequest((mHealth.env.healthdata_url + "A1C"), hDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure),true);
			} else if(this.healthDataTracker == "Blood Glucose") {
				var hDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Glucose').val());
				this.service.postRequest((mHealth.env.healthdata_url + "Bloodglucose"), hDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure),true);
			} else if(this.healthDataTracker == "Blood Pressure") {
				var sysHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Sys').val());
				var diaHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Dia').val());
				this.service.postRequest((mHealth.env.healthdata_url + "BPS"), sysHDataObject, "", this.proxy(this.trackerSaveFailure),false);
				this.service.postRequest((mHealth.env.healthdata_url + "BPD"), diaHDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure),true);
			} else if(this.healthDataTracker == "Cholesterol") {
				var ldlHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_LDL').val());
				var hdlHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_HDL').val());
				var triHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Tri').val());
				var choHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Cholesterol').val());
				this.service.postRequest((mHealth.env.healthdata_url + "LDL"), ldlHDataObject, "", this.proxy(this.trackerSaveFailure),false);
				this.service.postRequest((mHealth.env.healthdata_url + "HDL"), hdlHDataObject, "", this.proxy(this.trackerSaveFailure),false);
				this.service.postRequest((mHealth.env.healthdata_url + "Triglycerides"), triHDataObject, "", this.proxy(this.trackerSaveFailure),false);
				this.service.postRequest((mHealth.env.healthdata_url + "Cholesterol"), choHDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure),true);
			} else if(this.healthDataTracker == "Microalbumin") {
				var hDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Microalbumin').val());
				this.service.postRequest((mHealth.env.healthdata_url + "MAU"), hDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure),true);
			} else if(this.healthDataTracker=='Foot Exam - Provider' || this.healthDataTracker=='Dilated Retinal Exam' || this.healthDataTracker=='Foot Exam - Self') {
				var hDataObject = this.newHDataObject(measurementDate, collectedDate, '');
				var trackerId;
				if(this.healthDataTracker=='Foot Exam - Provider')
					trackerId='FootExam';
				else if(this.healthDataTracker=='Dilated Retinal Exam')
					trackerId='RetinalExam';
				else
				 	trackerId='FootSelfExam';
				alert(mHealth.env.healthdata_url + trackerId);
				this.service.postRequest((mHealth.env.healthdata_url + trackerId), hDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure),true);
			}
		}
	},
	
	/**
	 *Name: trackerFinalSaveSuccess
	 *Purpose: success callback function for new entry tracker save
	 *Params: output from postRequest as implicit param
	 *Returns: Doesn't return
	 **/
	trackerFinalSaveSuccess : function(output) {
		this.proxy(this.getJournalData());
		//mHealth.controllers.HealthDataController.getJournalData(mHealth.controllers.HealthDataController.healthDataTracker);
	},
	
	/**
	 *Name: trackerSaveFailure
	 *Purpose: Failure callback function for new entry tracker save. This is used in case of cholesterol, weight & bmi and blood pressure where all the postRequest service calls except last call uses this failure callback function.
	 *Params: Implicit callback function params
	 *Returns: Doesn't return
	 **/
	trackerSaveFailure : function(jqXHR, textStatus, errorThrown) {

	},
	
	/**
	 *Name: trackerFinalSaveFailure
	 *Purpose: Failure callback function for new entry tracker save. Used by all trackers, this is failure callback function of last service call.
	 *Params: Implicit callback function params
	 *Returns: Doesn't return
	 **/
	trackerFinalSaveFailure : function(jqXHR, textStatus, errorThrown) {
		
	},
	
	 /**
	 *Name: getJournalData
	 *Purpose:  gets the Journal Data using getResponse service call. Called on view my journal click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getJournalData : function() {
		this.service.getResponse(mHealth.env.healthdata_url, this.proxy(this.getJournalSuccess), this.proxy(this.getJournalFailure),true);
		//mHealth.controllers.HealthDataController.getJournalData(mHealth.controllers.HealthDataController.healthDataTracker)
	},
	
	 /**
	 *Name: getGraphData
	 *Purpose:  gets the Graph Data using getResponse service call. Called on view my graph click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getGraphData : function() {
		if(this.healthDataTracker == "Cholesterol") {
            $.mobile.changePage('detailscholesterol.html');                                 
		}
		else
		this.service.getResponse(mHealth.env.healthdata_url,  this.proxy(this.getGraphSuccess), this.proxy(this.getJournalFailure),true);
		//mHealth.controllers.HealthDataController.getGraphData(mHealth.controllers.HealthDataController.healthdatatracker)
	},
	
		 /**
	 *Name: getGraphSuccess
	 *Purpose: Success callback function for getting graph data.
	 *Params: Implicit callback function param
      *Returns: Doesn't return; passes healthdata value nad healthdata type as global to the html pages
	 **/
	getGraphSuccess : function(output) {
		var response = output.responseText;
		var responses = JSON.parse(response);
		console.log(responses);
		var len = responses.length;
		//health = this.healthDataTracker;
		if(this.healthDataTracker == "Blood Glucose") {
			var glucoseHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "Bloodglucose") {
				glucoseHealthData.push(responses[i]);
				}
			}
			this.seriesDataSet1 = glucoseHealthData;
			location.href="gyro://startRotation?";
			this.plotGlucoseCords(this.seriesDataSet1);
			//alert(this.healthDataTracker+"before changepage");
			$.mobile.changePage('glucosegraph.html');
		}
		if(this.healthDataTracker== "Weight & BMI") {
			//alert("inside graph Weight & BMI");
			var set1HealthData = [];
			var set2HealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "Weight") {
					set1HealthData.push(responses[i]);
				}
				if(responses[i].healthDataType == "BMI") {
					set2HealthData.push(responses[i]);
				}

			}
			this.seriesDataSet1 = set1HealthData;
			this.seriesDataSet2 = set2HealthData;
			this.showGraph();
			$.mobile.changePage('showgraph.html');
		}
		if(this.healthDataTracker == "Blood Pressure") {
			var set1HealthData = [];
			var set2HealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "BPS") {
					set1HealthData.push(responses[i]);
				}
				if(responses[i].healthDataType == "BPD") {
					set2HealthData.push(responses[i]);
				}

			}
			this.seriesDataSet1 = set1HealthData;
			this.seriesDataSet2 = set2HealthData;
			this.showGraph();
			$.mobile.changePage('showgraph.html');
		}
		if(this.healthDataTracker == "A1c") {
			var a1cHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "A1C") {
				a1cHealthData.push(responses[i]);
				}
			}
			this.seriesDataSet1 = a1cHealthData;
			this.showGraph();
			$.mobile.changePage('showgraph.html');
                                               
		}
	
		if(this.healthDataTracker == "LDL & HDL") {
			var ldlHealthData = [];
			var hdlHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "LDL") {
					ldlHealthData.push(responses[i]);
				}
				if(responses[i].healthDataType == "HDL") {
					hdlHealthData.push(responses[i]);
				}

			}
			this.seriesDataSet1 = ldlHealthData;
			this.seriesDataSet2 = hdlHealthData;
			this.showGraph();
			$.mobile.changePage('showgraph.html');
                                               
		}
		if(this.healthDataTracker == "Total Cholesterol") {
			var cholesterolHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "Cholesterol") {
					cholesterolHealthData.push(responses[i]);
				}
			}
			this.seriesDataSet1 = cholesterolHealthData;
			this.showGraph();
			$.mobile.changePage('showgraph.html');
                                               
		}
		if(this.healthDataTracker == "Triglycerides") {
			var triglyceridesHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "Triglycerides") {
					triglyceridesHealthData.push(responses[i]);
				}
			}
			this.seriesDataSet1 = triglyceridesHealthData;
			this.showGraph();
			$.mobile.changePage('showgraph.html');
                                               
		}
	},
	
	 /**
	 *Name: getJournalSuccess
	 *Purpose: Success callback function for get journal data. output Response is formatted to key value pairs and shows showjournal.html
	 *Params: Implicit callback function param
	 *Returns: Doesn't return
	 **/
	getJournalSuccess : function(output) {
		var response = output.responseText;
		var responses = JSON.parse(response);
		var len = responses.length;
		var healthData = [];
		var sortedData=[];
		if(this.healthDataTracker=='Blood Glucose')
			healthData=this.getHealthData(responses,'Bloodglucose');
		else if(this.healthDataTracker=='Dilated Retinal Exam')
			healthData=this.getHealthData(responses,'RetinalExam');	
		else if(this.healthDataTracker=='Foot Exam - Self')
			healthData=this.getHealthData(responses,'FootSelfExam');	
		else if(this.healthDataTracker=='Foot Exam - Provider')
			healthData=this.getHealthData(responses,'FootExam');	
		else if(this.healthDataTracker=='Microalbumin')
			healthData=this.getHealthData(responses,'MAU');
		else if(this.healthDataTracker=='A1c')
			healthData=this.getHealthData(responses,'A1C');	
		else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure" || this.healthDataTracker == "Cholesterol") 
		{
			var subHealthDataTypes = [];
			if(this.healthDataTracker == "Weight & BMI") {
				subHealthDataTypes = ['Weight', 'BMI', '', ''];
			} else if(this.healthDataTracker == "Blood Pressure") {
				subHealthDataTypes = ['BPS', 'BPD', '', ''];
			} else if(this.healthDataTracker == "Cholesterol") {
				subHealthDataTypes = ['LDL', 'HDL', 'Cholesterol', 'Triglycerides'];
			}
			
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == subHealthDataTypes[0] || responses[i].healthDataType == subHealthDataTypes[1] || responses[i].healthDataType == subHealthDataTypes[2] || responses[i].healthDataType == subHealthDataTypes[3]) {
					healthData.push(responses[i]);
				}
			}
		}
		sortedData=this.getSortedData(healthData);
		this.trackerData = this.getFormattedData(sortedData);
		$.mobile.changePage('showjournal.html');
	},
	
	
	/**
	 *Name: getHealthData
	 *Purpose: filter the health data responses based on tracker id.  
	 *Params: health data responses and tracker id are passed as params
	 *Returns: returns the health data corresponding to the tracker id.
	 **/
	getHealthData:function(responses,trackerId){
		var len = responses.length;
		var healthData = [];
		for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == trackerId) {
					healthData.push(responses[i]);
				}
		}
		return healthData;	
	},
	
	
	/**
	 *Name: getSortedData
	 *Purpose: sorts the health data based on measurement date.  
	 *Params: health data to be sorted is passed as param
	 *Returns: returns the sorted health data
	 **/
	getSortedData : function(healthData){
		var keys = [];
		var sortedData = [];
			for(var i in healthData) {
				keys[i] = [];
				keys[i][0] = healthData[i]["measurementDate"];
				keys[i][1] = i;

			}
			keys.sort();
			keys.reverse();
			
			for(var i in keys) {
				sortedData.push(healthData[keys[i][1]]);
			}
			return sortedData;
	},
	
	/**
	 *Name: getFormattedData
	 *Purpose:  formats the sorted health data to key value pairs based on measurement date. 
	 *Params: takes sorted health data as parameter
	 *Returns: returns the formatted hash object
	 **/
	getFormattedData: function(sortedData){
		var healthDataObjects=new Object();
		var len = sortedData.length;
		var child = new Object();
		if(this.healthDataTracker=='A1c' || this.healthDataTracker=='Blood Glucose'  || this.healthDataTracker=='Microalbumin' || this.healthDataTracker=='Foot Exam - Provider' || this.healthDataTracker=='Dilated Retinal Exam' || this.healthDataTracker=='Foot Exam - Self')
		{
			for(var i = 0; i < len; i++) {
				child = new Object();
				child['measurementDate'] = sortedData[i]['measurementDate'];
				child['value'] = sortedData[i]['value'];
				child['comments'] = sortedData[i]['comments'];
				healthDataObjects[sortedData[i].measurementDate] = child;
			}
		}
		else
		{
			var key;
			for(var i = 0; i < len; i++) {
				key = sortedData[i].measurementDate;
				if(healthDataObjects.hasOwnProperty(key)) {
					if(child['measurementDate'] == key)
						child[sortedData[i].healthDataType] = sortedData[i].value;
				} else {
					child = new Object();
					child['comments'] = sortedData[i].comments;
					child['measurementDate'] = sortedData[i].measurementDate;
					child[sortedData[i].healthDataType] = sortedData[i].value;
				}
				healthDataObjects[key] = child;
			}
		}
		return healthDataObjects;
	},
	
	/**
	 *Name: getJournalFailure
	 *Purpose: Failure callback function for get journal data. 
	 *Params: Implicit callback function params
	 *Returns:: Doesn't return
	 **/
	getJournalFailure : function(jqXHR, textStatus, errorThrown) {
		//alert('trackerGetFailure');
	},
	
	/**
	 *Name: setGlucoseTracker
	 *Purpose: Opens detailtracker.html when blood glucose icon is clicked on home page. sets the healthDataTracker to Blood Glucose.
	 *Params: No params
	 *Returns:: 
	 **/
	setGlucoseTracker : function(){
	//	location.href="tabbar://setSelectedTab?tabSelected=trackers";
		this.healthDataTracker='Blood Glucose';
		$.mobile.changePage('../../trackers/view/detailtracker.html');
	},
	
	/**
	 *Name: init
	 *Purpose: 
	 *Params: 
	 *Returns:: Doesn't return
	 **/
	init : function() {
	},
});