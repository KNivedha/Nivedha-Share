mHealth.models.ChallengeResponseModel=Spine.Model.sub();
mHealth.models.ChallengeResponseModel.configure('ChallengeResponseModel','MeasurementDate','QuestionResponse');

mHealth.models.QuestionResponsesModel=Spine.Model.sub();
mHealth.models.QuestionResponsesModel.configure('QuestionResponsesModel','QuestionID','Answer','Comments');