//
//  TabBar.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TabBar.h"
#import "AlereAppDelegate.h"
#import "TabBarController.h"
#import "AlereViewController.h"

@implementation TabBar
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
     AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    if ([action isEqualToString:@"login"] )  
    {
		  if ( !app.viewController.login)
			{
        UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];
        if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
            app.viewController.webView.frame=CGRectMake(0,0,320,414);
        }
        if (interfaceOrientation==UIInterfaceOrientationLandscapeRight||interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
            app.viewController.webView.frame=CGRectMake(0,0,480,260);
        }
        
        app.viewController.baseTabBar.hidden=NO;
        UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:0];
        app.viewController.baseTabBar.selectedItem=homeTab;
        app.viewController.login=YES;

     }
    }
   else if ([action isEqualToString:@"logout"] )
    {
		  app.viewController.baseTabBar.userInteractionEnabled=YES;

        UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];

        if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
            app.viewController.webView.frame=CGRectMake(0,0,320,460);
        }
        if (interfaceOrientation==UIInterfaceOrientationLandscapeRight||interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
            app.viewController.webView.frame=CGRectMake(0,0,480,300);
        }        app.viewController.baseTabBar.hidden=YES;  
        app.viewController.login=NO;
    }
		else if ([action isEqualToString:@"loadHome"] )
   {
	  app.viewController.baseTabBar.userInteractionEnabled=YES;
					 	 app.viewController.webView.userInteractionEnabled=YES;
       UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:0];
       app.viewController.baseTabBar.selectedItem=homeTab;
   }
   else if ([action isEqualToString:@"loadTrackers"] )
   {
	  app.viewController.baseTabBar.userInteractionEnabled=YES;
      app.viewController.webView.userInteractionEnabled=YES;
       UITabBarItem *trackersTab=[[app.viewController.baseTabBar items]objectAtIndex:3];
       app.viewController.baseTabBar.selectedItem=trackersTab;
   }
	 else if ([action isEqualToString:@"loadActivities"] )
   {
	  app.viewController.baseTabBar.userInteractionEnabled=YES;
					 	 app.viewController.webView.userInteractionEnabled=YES;
       UITabBarItem *activitiesTab=[[app.viewController.baseTabBar items]objectAtIndex:2];
       app.viewController.baseTabBar.selectedItem=activitiesTab;
   }
	  else if ([action isEqualToString:@"loadMessages"] )
   {
	  app.viewController.baseTabBar.userInteractionEnabled=YES;
					 	 app.viewController.webView.userInteractionEnabled=YES;
       UITabBarItem *messagesTab=[[app.viewController.baseTabBar items]objectAtIndex:1];
       app.viewController.baseTabBar.selectedItem=messagesTab;
   }
	 
	 else if ([action isEqualToString:@"addMask"] )
   {
	         app.viewController.baseTabBar.userInteractionEnabled=YES;
		  
	     app.viewController.baseTabBar.userInteractionEnabled=NO;
		
			 //flag="true";
   }
	 else if ([action isEqualToString:@"removeMask"] )
   {
	 //if flag="true";
           app.viewController.baseTabBar.userInteractionEnabled=YES;
		
						 //flag="false";
   }
    if([action isEqualToString:@"Accepted"]) 
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains
        (NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        
        //make a file name to write the data to using the documents directory:
        NSString *fileName = [NSString stringWithFormat:@"%@/textfile.txt", 
                              documentsDirectory];
        
        BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:fileName];
        if (!fileExists) {
            NSString *content = @"Yes";
            //save content to the documents directory
            [content writeToFile:fileName 
                      atomically:NO 
                        encoding:NSStringEncodingConversionAllowLossy 
                           error:nil];
            
        }
        
        
    }


} 
//UIDevice* myDevice=[UIDevice currentDevice];
//w[myDevice beginGeneratingDeviceOrientationNotifications];
@end
