mHealth.controllers.GraphController = Spine.Controller.sub({
	healthDataTracker : '',
	showLabel : false,
	currentView : "Month",
	currentTime : new Date(),
	cyear : new Date().getFullYear(),
	cmonth : new Date().getMonth() + 1,

	seriesDataSet1 : '',
	seriesDataSet2 : '',
	plotData: '',
	plotOptions: '',
	graphPlot: '',
	dataSeries1: '',
	dataSeries2: '',
	plotxMin: '',
	plotxMax: '',
	xTickInterval: '',
	xTimeformat: '',
	yTickInterval: '',
	threshMin: '',
	threshMax: '',
	pointShow: '',
	healthDataCount: '',

	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click .tracker' : 'setTrackerType',
		'click #showTrackerPage' : 'setGlucoseTracker',
		'click #viewGraph' : 'getGraphData',
		'pageshow #singlehealthdatapage' : 'drawSingleHealthDataGraph',
		'pageshow #multiplehealthdatapage' : 'drawMultipleHealthDataGraph',
		'click #daybutton' : 'dayButtonClick',
		'click #weekbutton' : 'weekButtonClick',
		'click #monthbutton' : 'monthButtonClick',
		'click #showLabel' : 'showLabels',
		'click #back' : 'unloadChart',
		'click #previousbutton' : 'previousButton',
		'click #nextbutton' : 'nextButton',
		'click .chotype' : 'setChoType'
		

	},
	
	
		/**
	 *Name: unloadChart
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	unloadChart : function(e) {
		location.href = "gyro://unLoadChart?";
	},
	
		/**
	 *Name: setTrackerType
	 *Purpose: Sets Tracker type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setTrackerType : function(e) {
		this.healthDataTracker = $(e.target).parents(".tracker").attr('name');
	},
	
	/**
	 *Name: setChoType
	 *Purpose: Sets Cholesterol type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setChoType : function(e) {
		this.healthDataTracker = $(e.target).parents(".chotype").attr('name');
		this.getGraphData();
	},
	
	/**
	 *Name: setHealthData
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setHealthData : function(output) {
		var response = JSON.parse(output.responseText);
		var modelData = JSON.stringify(response);
		mHealth.models.HealthDataModel.customFromJSON(modelData);
	},
	
	/**
	 *Name: setGlucoseTracker
	 *Purpose: Opens detailtracker.html when blood glucose icon is clicked on home page. sets the healthDataTracker to Blood Glucose.
	 *Params: No params
	 *Returns::
	 **/
	setGlucoseTracker : function() {
		this.healthDataTracker = 'Blood Glucose';
		location.href = "tabbar://loadTrackers?";
		$.mobile.changePage('../../trackers/view/detailtracker.html');
	},
	
	/**
	 *Name: setTrackerId
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	setTrackerId : function() {
		var trackerId = '';
		if(this.healthDataTracker == 'Blood Glucose') {
			trackerId = 'Bloodglucose';
		} else if(this.healthDataTracker == 'Dilated Retinal Exam') {
			trackerId = 'RetinalExam';
		} else if(this.healthDataTracker == 'Foot Exam - Self') {
			trackerId = 'FootSelfExam';
		} else if(this.healthDataTracker == 'Foot Exam - Provider') {
			trackerId = 'FootExam';
		} else if(this.healthDataTracker == 'Microalbumin') {
			trackerId = 'MAU';
		} else if(this.healthDataTracker == 'A1c') {
			trackerId = 'A1C';
		} else if(this.healthDataTracker == 'Weight & BMI') {
			trackerId = 'Weight';
		} else if(this.healthDataTracker == 'Blood Pressure') {
			trackerId = 'BPS';
		} else if(this.healthDataTracker == 'Cholesterol') {
			trackerId = 'Cholesterol';
		}
		return trackerId;
	},
	
	/**
	 *Name: getHealthTrackerData
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/	
		getHealthTrackerData : function(healthDataType) {
		var healthDataResponse = [];
		var modelResponse = mHealth.models.HealthDataModel.findAllByAttribute("healthDataType", healthDataType);
		modelResponse.map(function(response) {
			healthDataResponse.push(response);
		});
		return healthDataResponse;
	},
	
	/**
	 *Name: plotMultipleLineGraph
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/	
	plotMultipleLineGraph : function(healthDataValue1, healthDataValue2) {
		this.seriesDataSet1 = healthDataValue1;
		this.seriesDataSet2 = healthDataValue2;
		location.href = "gyro://loadChart?";
		this.monthView();
		$.mobile.changePage('multiplehealthdata.html');
	},
	
	/**
	 *Name: plotSingleLineGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	plotSingleLineGraph : function(healthDataValue) {
		this.seriesDataSet1 = healthDataValue;
		location.href = "gyro://loadChart?";
		this.monthView();
		$.mobile.changePage('singlehealthdata.html');
	},
	
	/**
	 *Name: getGraphData
	 *Purpose:  gets the Graph Data using getResponse service call. Called on view my graph click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getGraphData : function() {
		this.cmonth=new Date().getMonth()+1;
		this.cyear=new Date().getFullYear();
		this.currentTime=new Date();
		var healthDataResponse = [];
		var healthDataResponseDouble = [];
		var trackerId = this.setTrackerId();
		if(this.healthDataTracker == "Cholesterol") {
			$.mobile.changePage('detailscholesterol.html');
		} else {
			if(trackerId == 'Bloodglucose') {
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotSingleLineGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'Weight & BMI') {
				trackerId1 = "Weight";
				trackerId2 = "BMI";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotMultipleLineGraph(healthDataResponse, healthDataResponseDouble);
			} else if(this.healthDataTracker == 'Blood Pressure') {
				trackerId1 = "BPS";
				trackerId2 = "BPD";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotMultipleLineGraph(healthDataResponse, healthDataResponseDouble);
			} else if(this.healthDataTracker == 'LDL') {
				trackerId1 = "LDL";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				this.plotSingleLineGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'HDL') {
				trackerId1 = "HDL";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				this.plotSingleLineGraph(healthDataResponse);
			}else if(this.healthDataTracker == 'Triglycerides') {
				healthDataResponse = this.getHealthTrackerData(this.healthDataTracker);
				this.plotSingleLineGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'Total Cholesterol') {
				trackerId = 'Cholesterol';
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotSingleLineGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'A1c') {
				trackerId = 'A1C';
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotSingleLineGraph(healthDataResponse);
			}
			return;
		}

	},
	
	
	/**
	 *Name: monthView
	 *Purpose:sets the month view for the graph when landing on the graph for the first time, and when clicked on the month button
	 *Params:
	 *Returns:
	 **/
	monthView : function() {
		if(parseInt(this.cmonth,10)==(new Date().getMonth()+1) && this.cyear==new Date().getFullYear())
			$("#nextbutton").css("display", "none");
		//alert("monthView");
		this.currentView = "Month";
		var lastDateM = new Date(this.cyear, this.cmonth, 0);
		var xMaxDate = this.calculateDate(lastDateM, 2);
		if(this.cmonth <= 9)
			this.cmonth = "0" + parseInt(this.cmonth, 10);
		var xMinDate = this.cyear + "-" + this.cmonth + "-" + "01" + " " + "00" + ":" + "00";
		
		this.dataSeries1=this.calculateSingleLineDataPoints (this.seriesDataSet1,xMinDate, xMaxDate);
		this.plotxMax=new Date(lastDateM.getFullYear(),lastDateM.getMonth(),lastDateM.getDate()).getTime()-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
		this.plotxMin=new Date(lastDateM.getFullYear(),lastDateM.getMonth(),1).getTime()-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);

		if(this.healthDataTracker == "Blood Glucose"){
		this.threshMin=80;
		this.threshMax=120;
		this.glucoseGraph(this.dataSeries1);
		}
		else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure"){
			this.dataSeries2=this.calculateSingleLineDataPoints (this.seriesDataSet2, xMinDate, xMaxDate);
			this.getOptions([1,"day"],"%d",null,null,null);
			if(this.healthDataTracker == "Blood Pressure"){
				this.setBPGraph();
			}
			else{
				this.multipleLineGraph();
			}
		}
		else{ 
			if(this.healthDataTracker == "A1c")
				this.getOptions([1,"day"],"%d",1,6,7);
			else if(this.healthDataTracker == "LDL")
				this.getOptions([1,"day"],"%d",40,0,100);
			else if(this.healthDataTracker == "HDL"){
				this.getOptions([1,"day"],"%d",40,0,50);
			}
			else if(this.healthDataTracker == "Total Cholesterol")
				this.getOptions([1,"day"],"%d",40,0,200);
			else if(this.healthDataTracker == "Triglycerides")
				this.getOptions([1,"day"],"%d",40,0,150);
				
			this.singleLineGraph();
		}
	},

		
	/**
	 *Name: weekView
	 *Purpose:sets the week view for the graph
	 *Params:
	 *Returns:
	 **/
	weekView : function() {
		this.currentView = "Week";
		if((this.currentTime.getFullYear())==(new Date().getFullYear()) &&  (this.currentTime.getMonth())==(new Date().getMonth()) && (this.currentTime.getDate())==(new Date().getDate()))
			$("#nextbutton").css("display", "none");
		var wday = this.currentTime.getDay();
		var minWeekDate = new Date(this.currentTime.getTime() - (wday * 24 * 60 * 60 * 1000));
		var minDateW = this.calculateDate(minWeekDate, 1);
		var maxWeekDate = new Date(this.currentTime.getTime() + ((6 - wday + 1) * 24 * 60 * 60 * 1000));
		var maxDateW = this.calculateDate(maxWeekDate, 1);
		
		this.dataSeries1=this.calculateSingleLineDataPoints (this.seriesDataSet1,minDateW,maxDateW);
		this.plotxMin=new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()).getTime() - (wday * 24 * 60 * 60 * 1000)-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
		this.plotxMax=new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()).getTime()+ ((6 - wday + 1) * 24 * 60 * 60 * 1000)-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);

		
		if(this.healthDataTracker == "Blood Glucose"){
			this.threshMin=80;
			this.threshMax=120;
			this.glucoseGraph(this.dataSeries1);
		}
		else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure"){
			this.dataSeries2=this.calculateSingleLineDataPoints (this.seriesDataSet2,minDateW,maxDateW);
			this.getOptions([1,"day"],"%d",null,null,null);
			if(this.healthDataTracker == "Blood Pressure"){
				this.setBPGraph();
			}
			else{
				this.multipleLineGraph();
			}
		}
		else{ 
			if(this.healthDataTracker == "A1c")
				this.getOptions([1,"day"],"%d",1,6,7);
			else if(this.healthDataTracker == "LDL")
				this.getOptions([1,"day"],"%d",40,0,100);
			else if(this.healthDataTracker == "HDL"){
				this.getOptions([1,"day"],"%d",40,0,50);
			}
			else if(this.healthDataTracker == "Total Cholesterol")
				this.getOptions([1,"day"],"%d",40,0,200);
			else if(this.healthDataTracker == "Triglycerides")
				this.getOptions([1,"day"],"%d",40,0,150);
				
			this.singleLineGraph();
		}
	},
		
	/**
	 *Name: dayView
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	dayView : function(e) {
		this.currentView = "Day";
		if((this.currentTime.getFullYear())==(new Date().getFullYear()) &&  (this.currentTime.getMonth())==(new Date().getMonth()) && (this.currentTime.getDate())==(new Date().getDate()))
			$("#nextbutton").css("display", "none");
		var minDayDate = new Date(this.currentTime.getTime());
		var minDateD = this.calculateDate(minDayDate, 1);
		var maxDayDate = new Date(this.currentTime.getTime() + (24 * 60 * 60 * 1000));
		var maxDateD = this.calculateDate(maxDayDate, 1);
		
		this.dataSeries1=this.calculateSingleLineDataPoints (this.seriesDataSet1, minDateD, maxDateD);
		this.plotxMin=new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate(),00,00).getTime()-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
		this.plotxMax=new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate(),00,00).getTime()+ (24 * 60 * 60 * 1000)-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);

		if(this.healthDataTracker == "Blood Glucose"){
			this.threshMin=80;
			this.threshMax=120;
			this.glucoseGraph(this.dataSeries1);
		}
		else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure"){
			this.dataSeries2=this.calculateSingleLineDataPoints (this.seriesDataSet2, minDateD, maxDateD);
			this.getOptions([4,"hour"],"%H:%M",null,null,null);
			if(this.healthDataTracker == "Blood Pressure"){
				this.setBPGraph();
			}
			else{
				this.multipleLineGraph();
			}
		}
		else{ 
			if(this.healthDataTracker == "A1c")
				this.getOptions([4,"hour"],"%H:%M",1,6,7);
			else if(this.healthDataTracker == "LDL")
				this.getOptions([4,"hour"],"%H:%M",40,0,100);
			else if(this.healthDataTracker == "HDL"){
				this.getOptions([4,"hour"],"%H:%M",40,0,50);
			}
			else if(this.healthDataTracker == "Total Cholesterol")
				this.getOptions([4,"hour"],"%H:%M",40,0,200);
			else if(this.healthDataTracker == "Triglycerides")
				this.getOptions([4,"hour"],"%H:%M",40,0,150);
				
			this.singleLineGraph();
		}
	},
	
	/**
	 *Name: getOptions
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	getOptions : function(xTickInterval,xTimeformat,yTickInterval,threshMin,threshMax){
		this.xTickInterval=xTickInterval;
		this.xTimeformat=xTimeformat;
		this.yTickInterval=yTickInterval;
		this.threshMin=threshMin;
		this.threshMax=threshMax;
		if(this.healthDataCount==1)
		this.pointShow=true;
		else
		this.pointShow=false;
	},
	/**
	 *Name: setBPGraph
	 *Purpose:sets the datapoints and graph options for blood pressure graph
	 *Params:--
	 *Returns:--
	 **/
	setBPGraph : function(){
		var markings = [
    				{ color: '#ff8c00',
    				 lineWidth: 1, 
    				 xaxis: { 
    				 	from: new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate()).getTime()-((new Date()).getTimezoneOffset()*60*1000)+1000000, 
    				 	to: new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate()).getTime()-((new Date()).getTimezoneOffset()*60*1000)+1000000
    				 	} 
    				 }
	 			   ];
	 	if(this.currentView == "Day")
	 		markings=null;
	 	this.plotData=[{     //$('#DIV NAME'), data
			data: this.dataSeries1,
			points:{
        		show: this.pointShow,
        		lineWidth: 2
        	},
			//points: {show: true},
			label : 'Systolic',
			color : '#BB6AAB'
			},
			{     //$('#DIV NAME'), data
			data: this.dataSeries2,
			points:{
        		show: this.pointShow,
        		lineWidth: 2
        	},
			label : 'Diastolic',
			color : '#FFA01B',
		}];
		this.plotOptions={
			xaxis : {
				mode: "time",
				tickSize: this.xTickInterval,
				min: this.plotxMin,
                max: this.plotxMax,
                timeformat: this.xTimeformat,
				tickColor : '#574F52',
				color : '#574F52'
				},
			yaxis : {
				min : 0,
				tickSize : 40,
				decimal : 0,
				tickColor : '#574F52',
				color : '#574F52'
				},
			series : {
				grow:{
					active: true,
		            valueIndex: 1,
		           // stepDelay: 20,
		            steps:5,
		            stepMode: "maximum",
		            stepDirection: "up"
            	}
			},
			grid : {
				hoverable : false,
				backgroundColor : '#463E41',
				markings: markings
			},
			legend : {
				show: true,
				position: "se",
				margin: 2,
				backgroundOpacity: 0
			}
		};  
	},	
	/**
	 *Name: multipleLineGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	multipleLineGraph : function(){
		var bmiDataLow=[];
		var bmiDataAvg =[];
		var bmiDataHigh =[];
		for(var i=0;i<this.dataSeries2.length;i++)
		{	
			if(this.dataSeries2[i][1]<=25){
				bmiDataLow.push(this.dataSeries2[i]);
			}else if(this.dataSeries2[i][1]>25 && this.dataSeries2[i][1]<=30){
				bmiDataAvg.push(this.dataSeries2[i]);
			}else{
				bmiDataHigh.push(this.dataSeries2[i]);
			}
				
		}
    	var markings = [
    				{ color: '#ff8c00',
    				 lineWidth: 1, 
    				 xaxis: { 
    				 	from: new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate()).getTime()-((new Date()).getTimezoneOffset()*60*1000)+1000000, 
    				 	to: new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate()).getTime()-((new Date()).getTimezoneOffset()*60*1000)+1000000
    				 	} 
    				 }
	 			   ];
	 	if(this.currentView == "Day")
	 		markings=null;
    	this.plotData=[{     //$('#DIV NAME'), data
			data: this.dataSeries1,
			points:{
        		show: this.pointShow,
        		lineWidth: 2
        	},
        	lines: {
						show: true,
                        lineWidth: 2, // in pixels
                        fill: false,
                        fillColor: null,
                        steps: false
                  },
			label : 'Weight',
			color : '#BB6AAB'
		},{     //$('#DIV NAME'), data
			data: bmiDataLow,
			label : 'BMI-Low',
			points: {show: true,
				fillColor:'#7C92CA',
				fill : true,
				radius: 3},
			color : '#7C92CA',
		},{     //$('#DIV NAME'), data
			data: bmiDataAvg,
			label : 'BMI-Average',
			points: {show: true,
				fillColor:'#92C83E',
				fill : true,
				radius: 3},
			color : '#92C83E',
		},{     //$('#DIV NAME'), data
			data: bmiDataHigh,
			label : 'BMI-High',
			points: {show: true,
				fillColor:'#FFA01B',
				fill : true,
				radius: 3},
			color : '#FFA01B',
		}];
		this.plotOptions={
			xaxis : {
				mode: "time",
				tickSize: this.xTickInterval,
				min: this.plotxMin,
                max: this.plotxMax,
                timeformat: this.xTimeformat,
				tickColor : '#574F52',
				color : '#574F52'
				},
			yaxis : {
				min : 0,
				tickSize : 40,
				decimal : 0,
				tickColor : '#574F52',
				color : '#574F52'
				},
			series : {
				grow:{
					active:true,
		            valueIndex: 1,
		           // stepDelay: 20,
		            steps:5,
		            stepMode: "maximum",
		            stepDirection: "up"
            	}
            	
			},
			grid : {
				hoverable : false,
				backgroundColor : '#463E41',
				markings: markings
			},
			legend : {
				show: false,
				position: "se",
				margin: 2
			}
		};   
	},
	
		/**
	 *Name: glucoseGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	glucoseGraph : function(glucosedata) {
		var storeCords = new Array();
		for(var counter = 0; counter < glucosedata.length; counter++) {
			var userTime = parseInt((glucosedata[counter].measurementDate).substr(9, 2), 10);
			var healthData = parseInt(glucosedata[counter].value);
			storeCords[counter] = new Array(2)
			if(userTime >= 6 && userTime < 9)
				storeCords[counter][0] = 2;
			else if(userTime >= 9 && userTime < 11)
				storeCords[counter][0] = 6;
			else if(userTime >= 11 && userTime < 14)
				storeCords[counter][0] = 10;
			else if(userTime >= 14 && userTime < 17)
				storeCords[counter][0] = 14;
			else if(userTime >= 17 && userTime < 20)
				storeCords[counter][0] = 18;
			else if(userTime >= 20 && userTime < 23)
				storeCords[counter][0] = 22;
			else if(userTime >= 23 || userTime < 6)
				storeCords[counter][0] = 26;

			storeCords[counter][1] = healthData;
		}
		var groupSixAm = 0, groupNineAm = 0, groupElevenAm = 0, groupTwoPm = 0, groupSixPm = 0, groupEightPm = 0, groupElevenPm = 0;
		var countGroupSixAm = 0, countGroupNineAm = 0, countGroupElevenAm = 0, countGroupTwoPm = 0, countGroupSixPm = 0, countGroupEightPm = 0, countGroupElevenPm = 0;
		var plotCords_length = storeCords.length;
		for(var i = 0; i < plotCords_length; i++) {
			if(!isNaN(storeCords[i][1])){
			if(storeCords[i][0] == 2) {
				groupSixAm = groupSixAm + storeCords[i][1];
				countGroupSixAm = countGroupSixAm + 1;
			} else if(storeCords[i][0] == 6) {
				groupNineAm = groupNineAm + storeCords[i][1];
				countGroupNineAm = countGroupNineAm + 1;
			} else if(storeCords[i][0] == 10) {
				groupElevenAm = groupElevenAm + storeCords[i][1];
				countGroupElevenAm = countGroupElevenAm + 1;
			} else if(storeCords[i][0] == 14) {
				groupTwoPm = groupTwoPm + storeCords[i][1];
				countGroupTwoPm = countGroupTwoPm + 1;
			} else if(storeCords[i][0] == 18) {
				groupSixPm = groupSixPm + storeCords[i][1];
				countGroupSixPm = countGroupSixPm + 1;
			} else if(storeCords[i][0] == 22) {
				groupEightPm = groupEightPm + storeCords[i][1];
				countGroupEightPm = countGroupEightPm + 1;
			} else {
				groupElevenPm = groupElevenPm + storeCords[i][1];
				countGroupElevenPm = countGroupElevenPm + 1;
			}
			}
		}
		var avgCords = [[2, groupSixAm / countGroupSixAm], [6, groupNineAm / countGroupNineAm], [10, groupElevenAm / countGroupElevenAm], [14, groupTwoPm / countGroupTwoPm], [18, groupSixPm / countGroupSixPm], [22, groupEightPm / countGroupEightPm], [26, groupElevenPm / countGroupElevenPm]];

    this.plotData = [
		{ 
			data: avgCords, 
			//label: 'Average',
			color: 'orange',
			points: { 
				symbol: "square",
				fill : true,
				fillColor : 'orange',
				show: true,
        		radius: 5
				} 
		},
        { 	
        	data: storeCords,
        	//label: 'Data',
        	color: 'white', 
        	points: { 
        		symbol: "cross",
        		show: true,
        		radius: 3
        		}
		}
		
    ];
	this.plotOptions={
        xaxis: {
        	min: 0, 
            max: 28,
            tickSize: 4,
            labelWidth: -25, 
            ticks: [[0, "6am-9am"], [4, "9am-11am"], [8, "11am-2pm"], [12,"2pm-5pm"],[16,"5pm-8pm"],[20,"8pm-11pm"],[24,"11pm-6am"],[28,""]]
        },
        yaxis: {
        	min: 0, 
            //max: 350,
            tickSize: 50
        },
        legend : {
				show : false,
				//container : '#legendcontainer',
				backgroundOpacity : 0
			},
		series : {
			grow:{
				active: true,
	            valueIndex: 1,
	           // stepDelay: 20,
	            steps:30,
	            stepMode: "maximum",
	            stepDirection: "up"
	    	}
		},
        grid: { 
        	//hoverable: true 
        	color: '#FFFFFF',
        	backgroundColor: '#463E41',
        	borderColor: '#463E41'
        	//tickColor: '#FFFFFF'
        },
        selection: {
        	mode: "y",
        	color: '#C38EC7'
        }
        };
	},
	
	/**
	 *Name: singleLineGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	singleLineGraph : function(){
		 this.plotData = [

        { 	
        	data: this.dataSeries1,
        	label : 'High',
			color : '#FAA016',
			constraints : [{
				threshold : this.threshMax,
				color : '#92C83E',
				label : 'Average',
				evaluate : function(y, threshold) {
					return y < threshold;
				}
			}, {
				threshold : this.threshMin,
				color : '#7C92CA',
				label : 'Low',
				evaluate : function(y, threshold) {
					return y < threshold;
				}
			}
			]
		}
    ];
	this.plotOptions={
        xaxis : {
				mode: "time",
				tickSize: this.xTickInterval,
				min: this.plotxMin,
                max: this.plotxMax,
                timeformat: this.xTimeformat,
				tickColor : '#574F52',
				color : '#574F52'
				},
			yaxis : {
				min : 0,
				tickSize : this.yTickInterval,
				//decimal : 0,
				tickDecimals: 0,
				tickColor : '#574F52',
				color : '#574F52'
				},
			series : {
				grow:{
					active: false
            },
            points:{
        		show: this.pointShow,
        		lineWidth: 2
        	},
        	lines: {
						show: true,
                        lineWidth: 2, // in pixels
                        fill: false,
                        fillColor: null,
                        steps: false
                    }
			},
			grid : {
				hoverable : false,
				backgroundColor : '#463E41'
				//markings: markings
			},
			legend : {
				show: true,
				position: "se",
				margin: 2,
				backgroundOpacity: 0
			},
			selection: {
        	mode: "y",
        	color: '#C38EC7'
        }
		};   
	},
	
	/**
	 *Name: drawMultipleHealthDataGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	drawMultipleHealthDataGraph : function(){
			if(this.showLabel == false){
			$('#trackerbuttons').css('visibility','hidden');
			$('#viewbuttons').css('visibility','hidden');
			}
			this.graphPlot = $.plot($("#graphdiv"), this.plotData,this.plotOptions);
			this.showDate(); 
			this.plotOptions.series.grow=true;
			if(this.showLabel==false){
			setTimeout("$('#trackerbuttons').css('visibility','visible');",800);
			setTimeout("$('#viewbuttons').css('visibility','visible');",800);
			}
		},
	
	/**
	 *Name: drawSingleHealthDataGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	drawSingleHealthDataGraph : function() {
		//alert(this.threshMin+" : "+this.threshMax);
		   	$('#trackerbuttons1').css('visibility','hidden');
			$('#viewbuttons').css('visibility','hidden');
			this.graphPlot=$.plot($("#graphdiv"), this.plotData, this.plotOptions);
	    	if(this.healthDataTracker == "HDL"){
	    		var gend = (mHealth.models.ParticipantModel.first()).gender;
	    		if(gend == "M") {
						this.threshMin = 0;
						this.threshMax = 60;
					} else {
						this.threshMin = 0;
						this.threshMax = 50;
					}
	    	}
	    	this.graphPlot.setSelection({yaxis: {from: this.threshMin, to: this.threshMax}});
	    	if(this.healthDataTracker != "Blood Glucose")
	    		this.showDate();
	    		
	    	setTimeout("$('#trackerbuttons1').css('visibility','visible');",800);
			setTimeout("$('#viewbuttons').css('visibility','visible');",800);
	},
	
	/**
	 *Name: previousButton
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	previousButton : function(){
		this.showLabel=false;
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ViewReading.png");
		$("#nextbutton").css("display", "block");
               if(this.cmonth=="1"||this.cmonth=='01'){
                       this.cmonth='12';
                       this.cyear=String(parseInt(this.cyear,10)-1);        
               }
               else
                       this.cmonth=String(parseInt(this.cmonth,10)-1);
               if(this.currentView == "Week")
               {
                       //alert(this.currentTime);
                       this.currentTime=new Date(this.currentTime.getTime() - (7 * 24 * 60 * 60 * 1000));
                      // alert(this.currentTime);
                       this.weekView();
               }else if(this.currentView == "Day"){
                       this.currentTime=new Date(this.currentTime.getTime() - (1 * 24 * 60 * 60 * 1000));
                      // alert(this.currentTime);
                       this.dayView();
               }else{
                       this.monthView();
               }
               if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure")
					this.drawMultipleHealthDataGraph();
				else
					this.drawSingleHealthDataGraph();
       },
	
	/**
	 *Name: nextButton
	 *Purpose:
	 *Params:
	 *Returns:
	 **/	
	 nextButton : function(){
	 	this.showLabel=false;
	 	$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ViewReading.png");
               if(this.cmonth=="12"){
                       this.cmonth='1';
                       this.cyear=String(parseInt(this.cyear,10)+1);        
               }else
                       this.cmonth=String(parseInt(this.cmonth,10)+1);
               if(this.currentView == "Week")
               {
                       this.currentTime=new Date(this.currentTime.getTime()+(7 * 24 * 60 * 60 * 1000));
                       this.weekView();
               }else if(this.currentView == "Day"){
                       this.currentTime=new Date(this.currentTime.getTime() + (1 * 24 * 60 * 60 * 1000));
                       this.dayView();
               }else{
                       this.monthView();
               }
               if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure")
					this.drawMultipleHealthDataGraph();
				else
					this.drawSingleHealthDataGraph();
       },	
	/**
	 *Name: showDate
	 *Purpose: displays date on top of graph depending on the view ie., Month, Week or Daily 
	 *Params: --
	 *Returns: --
	 **/
	showDate : function() {
		var placeholder=$('#graphdiv');
		var xOffset=(new Date(this.cyear,parseInt(this.cmonth,10)-1,12)).getTime()+12*60*60*1000;;
		var month=parseInt(this.cmonth,10);
		if(month == 1 || month == 3 || month == 5 ||month == 7 || month == 12 || month == 8 || month == 10)
			xOffset=xOffset+17*60*60*1000;
		else if(month == 11 || month == 8 || month == 6 || month == 4)
			xOffset=xOffset+11*60*60*1000;
		var datestring=mHealth.util.getYearWithMonth(new Date(this.cyear,parseInt(this.cmonth,10)-1,1));
		if(this.currentView=="Month"){
            if(parseInt(this.cmonth,10)==(new Date().getMonth() + 1) && parseInt(this.cyear,10)==(new Date().getFullYear())){
                datestring=mHealth.util.getDateWithMonth(new Date());
            }
        }
        else if(this.currentView=='Week'){
        	var wday = this.currentTime.getDay();
			xOffset=(new Date(new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()).getTime() - ((wday-3.0399) * 24 * 60 * 60 * 1000))).getTime();
            datestring=mHealth.util.getDateWithWeek(this.currentTime);
        }
        else {
			xOffset=((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTime()+(15.15)*60*60*1000);
            datestring=mHealth.util.getDateWithMonth(new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()));
        }
        var yOffset=this.graphPlot.getAxes().yaxis.max;
        var o = this.graphPlot.pointOffset({ x: xOffset, y: yOffset});
        placeholder.append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + o.top + 'px;color:#CCCCCC;font-size:bigger">'+datestring+'</div>');
	},
	/**
	 *Name: showLabels
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	showLabels : function() {
		if(!this.showLabel){
			$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Orange_ViewReading.png");
			var o = this.graphPlot.pointOffset({ x: new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate()).getTime()-((new Date()).getTimezoneOffset()*60*1000)+1000000, y:0});
		    var ctx = this.graphPlot.getCanvas().getContext("2d");
		     ctx.fillStyle = "#FFA01B";
		    ctx.strokeStyle = "#FFA01B";
		    if(this.currentView != "Day")
		    {
	    	ctx.beginPath();
		    o.left -= 7;
		    ctx.moveTo(o.left, o.top);
		    ctx.lineTo(o.left+7, o.top - 5);
		    ctx.lineTo(o.left+14 , o.top);
		    ctx.lineTo(o.left, o.top);
		    ctx.fillStyle = "#FFA01B";
		    ctx.strokeStyle = "#FFA01B";
		    ctx.fill();
		    }
	 		this.drawLabel();
	 		this.showLabel=true;
  		}
 		else{
 			this.plotOptions.series.grow=false;
 			$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ViewReading.png");
 			if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure")
				this.drawMultipleHealthDataGraph();
			else
				this.drawSingleHealthDataGraph();
			this.showLabel=false;
 		}
	},
		
	/**
	 *Name: drawLabel
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
drawLabel: function() {
		var placeholder=$('#graphdiv');
		var ctx = this.graphPlot.getCanvas().getContext("2d");
		ctx.globalAlpha = 1;
		if(this.healthDataTracker=="Weight & BMI"){ 
			for(var i=0;i<this.dataSeries1.length;i++){
				var o=this.graphPlot.pointOffset({x:this.dataSeries1[i][0],y:this.dataSeries1[i][1]});
			    placeholder.append('<div style=opacity:'+(1)+';filter:alpha(opacity=60);background-color:#333333;position:absolute;z-index:1000;left:' + (o.left - 15) + 'px;top:' + (o.top-23) + 'px;color:#cccccc;font-size:smaller">&nbsp;&nbsp;'+this.dataSeries1[i][1]+'&nbsp;&nbsp;</div>');
				 ctx.moveTo(o.left,o.top);
				 ctx.lineTo(o.left-7,o.top-7);
		 		 ctx.lineTo(o.left+7,o.top-7);
				 ctx.lineTo(o.left,o.top);
				 ctx.fillStyle="#ff8c00";
				 ctx.fill();
			}
		}else {
			var moonPoints=[];
			var sunPoints=[];
			var moonCounter=0;
			var sunCounter=0;
			for(var i=0;i<this.dataSeries1.length;i++){
		var o=this.graphPlot.pointOffset({x:this.dataSeries1[i][0],y:this.dataSeries1[i][1]});
		var o1=this.graphPlot.pointOffset({x:this.dataSeries2[i][0],y:this.dataSeries2[i][1]});
		ctx.beginPath();	
		ctx.moveTo(o.left,o.top);
		ctx.lineTo(o1.left,o1.top);
		ctx.stroke();
		var y=(o.top+o1.top)/2;
		var x=o.left;
		if(new Date(this.dataSeries1[i][0]).getHours() > 6 && new Date(this.dataSeries1[i][0]).getHours() < 18)
		{
			sunPoints[sunCounter]=new Array(2);
			sunPoints[sunCounter][0]=o.left -5;
			if(y-15 < o.top)
				sunPoints[sunCounter][1]=y-25;
			else
				sunPoints[sunCounter][1]=o.top -10;
			sunCounter++;
		}
		else
		{
			moonPoints[moonCounter]=new Array(2);
			moonPoints[moonCounter][0]=o.left -5;
			if(y-15 < o.top)
				moonPoints[moonCounter][1]=y-25;
			else
				moonPoints[moonCounter][1]=o.top -10;
			moonCounter++;
		}
	    placeholder.append('<div style=opacity:'+(1)+';filter:alpha(opacity=60);background-color:#333333;position:absolute;z-index:1000;left:' + (x - 20) + 'px;top:' + (y-5) + 'px;color:#cccccc;font-size:smaller">'+this.dataSeries1[i][1]+'/'+this.dataSeries2[i][1]+ '</div>');
		ctx.moveTo(x,y-15);
		ctx.lineTo(x-10,y-5);
		ctx.lineTo(x+10,y-5);
		ctx.lineTo(x,y-15);
		ctx.fillStyle="#ff8c00";
		ctx.fill();
		
		y=y+5;
		ctx.moveTo(x,y+15);
		ctx.lineTo(x-10,y+5);
		ctx.lineTo(x+10,y+5);
		ctx.lineTo(x,y+15);
		ctx.fillStyle="#ff8c00";
		ctx.fill();
		
	 }
	 var moonObj = new Image();
	 var sunObj = new Image();
	    moonObj.onload = function(){
	        for(var j=0;j<moonCounter;j++)
	        ctx.drawImage(moonObj, moonPoints[j][0], moonPoints[j][1]);
	    };
	    sunObj.onload = function(){
	        for(var j=0;j<sunCounter;j++)
	        ctx.drawImage(sunObj, sunPoints[j][0], sunPoints[j][1]);
	    };
	    moonObj.src = "../../../assets/images/trackerimages_new/MOON.png";
	    sunObj.src = "../../../assets/images/trackerimages_new/SUN.png";
		}
 	},



	/**
	 *Name: monthButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	monthButtonClick : function() {
		this.showLabel=false;
		this.cmonth=new Date().getMonth()+1;
		this.cyear=new Date().getFullYear();
		//alert("monthButtonClick");
		$("#monthbutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Month.png");
		$("#weekbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Week.png");
		$("#daybutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Day.png");
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ViewReading.png");
		this.monthView();
		if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure")
			this.drawMultipleHealthDataGraph();
		else
			this.drawSingleHealthDataGraph();
	},
	
	/**
	 *Name: weekButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	weekButtonClick : function() {
		this.showLabel=false;
		this.currentTime=new Date();
		//alert("weekButtonClick");
		$("#monthbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Month.png");
		$("#weekbutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Week.png");
		$("#daybutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Day.png");
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ViewReading.png");
		this.weekView();
		if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure")
			this.drawMultipleHealthDataGraph();
		else
			this.drawSingleHealthDataGraph();
	},
	
		/**
	 *Name: dayButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	dayButtonClick : function() {
		this.showLabel=false;
		this.currentTime=new Date();		//alert("dayButtonClick");
		$("#monthbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Month.png");
		$("#weekbutton").attr("src", "../../../assets/images/trackerimages_new/Gray_Week.png");
		$("#daybutton").attr("src", "../../../assets/images/trackerimages_new/Orange_Day.png");
		$("#showLabel").attr("src", "../../../assets/images/trackerimages_new/Gray_ViewReading.png");
		this.dayView();
		if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure")
			this.drawMultipleHealthDataGraph();
		else
			this.drawSingleHealthDataGraph();
	},
	
	

	/**
	 *Name: calculateDate
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	calculateDate : function(currentTime, minmax) {
		var month = currentTime.getMonth() + 1;
		var day = currentTime.getDate();
		var year = currentTime.getFullYear();
		var hours = currentTime.getHours();
		var minutes = currentTime.getMinutes();
		var seconds = currentTime.getSeconds();
		if(month <= 9)
			month = "0" + month;
		if(day <= 9)
			day = "0" + day;

		if(minmax == 1)
			return year + "-" + month + "-" + day + " " + "00" + ":" + "00";
		else
			return year + "-" + month + "-" + day + " " + "23" + ":" + "59";
	},
	
	/**
	 *Name: calculateSingleLineDataPoints
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	calculateSingleLineDataPoints : function(trackerData, xMinDate, xMaxDate) {
		//alert("xmindate: "+xMinDate+"xmaxdate: "+xMaxDate);
		//alert("inside calculateSingleLineDataPoints");
		this.healthDataCount=0;
		var dataGlucose=new Array();
		var counterTrackerData = 0;
		var  dataSeries1=[];
		if(trackerData) {
		
			for(var counter = 0; counter < trackerData.length; counter++) {
				var usrtmeYear = parseInt((trackerData[counter].measurementDate).substr(0, 4), 10);
				var usrtmeMonth = parseInt((trackerData[counter].measurementDate).substr(4, 2), 10);
				var usrtmeDay1 = parseInt((trackerData[counter].measurementDate).substr(6, 2), 10);
				var usrtmeHours = parseInt((trackerData[counter].measurementDate).substr(9, 2), 10);
				var usrtmeMinutes = parseInt((trackerData[counter].measurementDate).substr(11, 2), 10);
				var usrtmeSeconds = parseInt((trackerData[counter].measurementDate).substr(13, 2), 10);

				var hlthData = parseInt(trackerData[counter].value);
				if(usrtmeMonth <= 9)
					usrtmeMonth = "0" + usrtmeMonth;
				if(usrtmeDay1 <= 9)
					usrtmeDay1 = "0" + usrtmeDay1;
				usrtmeDay = usrtmeYear + '-' + usrtmeMonth + '-' + usrtmeDay1 + ' ' + usrtmeHours + ':' + usrtmeMinutes;

				if(usrtmeDay >= xMinDate && usrtmeDay <= xMaxDate) {
					this.healthDataCount=this.healthDataCount+1;
					if(this.healthDataTracker == "Blood Glucose"){
						dataGlucose[counterTrackerData]=new Array();
					dataGlucose[counterTrackerData]=trackerData[counter];
					}
					else if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure"){
						if(hlthData<1000)
						{dataSeries1[counterTrackerData]=new Array(2);
						dataSeries1[counterTrackerData][0]=(new Date(usrtmeYear,parseInt(usrtmeMonth,10)-1,parseInt(usrtmeDay1,10),usrtmeHours,usrtmeMinutes).getTime())-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
						dataSeries1[counterTrackerData][1]=hlthData;}
						else
							counterTrackerData--;
					}
						else if(this.healthDataTracker == "A1c"){
						if(hlthData<31)
						{dataSeries1[counterTrackerData]=new Array(2);
						dataSeries1[counterTrackerData][0]=(new Date(usrtmeYear,parseInt(usrtmeMonth,10)-1,parseInt(usrtmeDay1,10),usrtmeHours,usrtmeMinutes).getTime())-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
						dataSeries1[counterTrackerData][1]=hlthData;}
						else
							counterTrackerData--;
					}
					else {
						{dataSeries1[counterTrackerData]=new Array(2);
						dataSeries1[counterTrackerData][0]=(new Date(usrtmeYear,parseInt(usrtmeMonth,10)-1,parseInt(usrtmeDay1,10),usrtmeHours,usrtmeMinutes).getTime())-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
						dataSeries1[counterTrackerData][1]=hlthData;}
					}
					counterTrackerData = counterTrackerData + 1;
				}
			}
		}
		if(this.healthDataTracker == "Blood Glucose"){
			return dataGlucose;
		}
		else
			return dataSeries1;
	}

});
