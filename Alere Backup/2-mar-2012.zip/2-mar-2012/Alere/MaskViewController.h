//
//  MaskViewController.h
//  TreatmentCostCalculator
//
//  Created by virtusa virtusa on 2/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MaskViewController : UIViewController {

}


+ (id)sharedMaskController;
@end
