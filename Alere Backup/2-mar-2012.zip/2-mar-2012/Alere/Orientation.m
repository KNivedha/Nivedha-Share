//
//  Orientation.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Orientation.h"
#import "AlereAppDelegate.h"
#import "TabBarController.h"
#import "OrientationConstants.h"
#import "AlereViewController.h"
@implementation Orientation
#define DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) / 180.0 * M_PI)
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    
    AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
		UIApplication *application= [UIApplication sharedApplication] ;
    if( [action isEqualToString:@"loadChart"])       
    {
        NSLog(@"start rotated method");
        app.viewController.enteredGraph=YES;
        app.viewController.baseTabBar.hidden=YES;
		UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
        if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown )
        {
            [app.viewController.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(-90));
            app.viewController.view.transform = cgCTM;
            app.viewController.view.frame = CGRectMake(0, 0, 320, 480);
            app.viewController.webView.frame=CGRectMake(0, 0, 480, 320);
            rotated=YES;
           
             [[UIApplication sharedApplication]setStatusBarHidden:YES];
        }
        else  if (interfaceOrientation==UIInterfaceOrientationLandscapeRight||interfaceOrientation==UIInterfaceOrientationLandscapeLeft )
        {
              [[UIApplication sharedApplication]setStatusBarHidden:YES];
              app.viewController.view.frame = CGRectMake(0, 0,320,  480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);

        }
    }
    else if( [action isEqualToString:@"unLoadChart"])       
    {
         app.viewController.enteredGraph=NO;
		 app.viewController.baseTabBar.hidden=NO;
		 application.statusBarHidden=NO;
        
        [[UIApplication sharedApplication]setStatusBarHidden:NO];
        if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationLandscapeLeft)
        {
            app.viewController.view.frame=CGRectMake(20, 0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,272);
        }
        if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationLandscapeRight)
        {
            app.viewController.view.frame=CGRectMake(0, 0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,272);
        }
        if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationPortrait)
        {
            [app.viewController.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(0));
            app.viewController.view.transform = cgCTM;
            app.viewController.view.frame = CGRectMake(0, 20, 320, 460);
            app.viewController.webView.frame=CGRectMake(0, 0, 320, 416);
            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortrait animated:YES];
        }
        else if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationPortraitUpsideDown)
        {
            //if ( app.viewController.enteredGraph)
            {
                [app.viewController.view setCenter:CGPointMake(160, 240)];
                CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(-180));
                app.viewController.view.transform = cgCTM;
                app.viewController.view.frame = CGRectMake(0, 0, 320, 460);
                app.viewController.webView.frame=CGRectMake(0, 0, 320, 416);
                [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortraitUpsideDown animated:YES];
            }
            
        }

    }
		else if( [action isEqualToString:@"loadGlucose"])       
    {
         app.viewController.enteredGlucose=YES;
        
        UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
        if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown )
        {
           [app.viewController.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(-90));
            app.viewController.view.transform = cgCTM;
            app.viewController.view.bounds = CGRectMake(0, 00, 480, 300);
            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationLandscapeLeft];
            rotated=YES;
        }
     }
		else if( [action isEqualToString:@"unLoadGlucose"])       
    {
         app.viewController.enteredGlucose=NO;
         app.viewController.baseTabBar.hidden=NO;
    }


}
@end
