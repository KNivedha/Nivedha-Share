//
//  AlereViewController.h
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlereViewController : UIViewController <UIWebViewDelegate>
{
    IBOutlet UIWebView* webView;
    NSMutableData* responseData;
    NSString* token;
    NSString* eventname;
    BOOL landscp;
    BOOL returnType;
    BOOL rotated;
   // UIInterfaceOrientation orientation;
    BOOL cameBack;
}
@property(nonatomic,retain) IBOutlet UIWebView* webView;
@property(nonatomic)BOOL rotated;
@property(nonatomic)BOOL landscp;

//-(void) getToken:(NSMutableArray*)headerKey;
//-(void) getHealthData:(NSMutableArray*)urlString;
-(void)setCalendarEvent:(NSMutableArray*)params;
-(void)callNumber:(NSMutableArray*)number;
-(void)startRotation;
-(void)stopRotation;
-(void)loadTabBar;
-(void)logOut;
-(void)getDeviceFeatures;
-(void)sendMail:(NSMutableArray*)params;
@end
