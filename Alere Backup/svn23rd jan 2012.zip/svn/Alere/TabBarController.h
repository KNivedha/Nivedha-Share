//
//  TabBarController.h
//  Alere
//
//  Created by virtusa5 on 18/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AlereViewController.h"
@interface TabBarController : UIViewController <UITabBarControllerDelegate>
{
    IBOutlet  AlereViewController* alereViewController;
    IBOutlet UITabBarController* tabBar ;
}
@property(nonatomic,retain) IBOutlet UITabBarController* tabBar ;
@end
