/*
 Controller : Settings Controller
 This is the controller to do the  logic of settings 
 */

mHealth.controllers.SettingsController=Spine.Controller.sub({
        el:'body',
        service : mHealth.util.RemoteServiceProxy.getInstance(),
        events :
        {
                'click #logout_id' : 'doLogout',
                'click #showabout' :'getFeatures',
                'click #sendfb' : 'callEmail',
                'pagebeforeshow #aboutsDetail' :'renderDetail',
                'change #HeightUnit' :'heightUnits',
                'pagebeforeshow #settingspage' :'showsettings'
        },
/**
 Method to call logout method
 Removing models data
**/ 
        doLogout : function()
        {   
           if (confirm("Are you sure you want to logout?")) {  
                mHealth.models.ConditionModel.destroyAll();
                mHealth.models.MedicationModel.destroyAll();
                mHealth.models.ParticipantModel.destroyAll();
//              mHealth.models.SpaceModel.destroyAll();
//              mHealth.models.ViewModel.destroyAll();
//              mHealth.models.ZoneModel.destroyAll();
                mHealth.models.HealthDataModel.destroyAll();
                $.mobile.changePage("../../rootView/view/login.html");
                location.href="mHealth?eventname=logOut";
            } 
        },
/**
 Method to get the selected value of height units field 
 on change of the select menu
**/
        heightUnits:function(){
        mHealth.util.selUnits=$('select#HeightUnit option:selected').val();
        },
/**
 Method to get the selected value of height units field
 on load of the page
 **/                                                           
        showsettings:function(){
        mHealth.util.selUnits=$('select#HeightUnit option:selected').val();
        },  
/**
 Method to bind the values of devices details using underscore
 **/
        renderDetail:function()
        {
                                                   
        $('#aboutDevices').html(_.template($('#deviceDetails').html(),{deviceinfo:deviceinfo}));
        $('#aboutsDetail').trigger('create'); 

        },
/**
 Method to call the webview to get Device Features
 **/                                                    
        getFeatures:function()
        {
        location.href="mHealth?eventName=getDeviceFeatures";
        },
/**
 Method to call the webview to call native email
 **/ 
        callEmail :function()
        {
        location.href="mHealth?eventName=sendMail&mailto=corpfeedback@alere.com&subject=Alere+mHealth"
        }
        });

        mHealth.controllers.SettingsController.extend({
/**
 call back function from webview to get device features
 **/                                                  
        getDevicesFeature : function(device,osversion){
        mHealth.util.osversion=osversion;
        mHealth.util.device=device;
        deviceinfo=[{'reguser':mHealth.util.participantemail,
        'version':mHealth.util.version,
        'platform':'APPLE',
        'devname':mHealth.util.device,
        'devmodel':mHealth.util.osversion}];

        }
        });
