/**

 * Controller :Participant controller
 * Logic for profile is added here

 **/

mHealth.controllers.ParticipantController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		'click #show_profile' : 'getProfileData',
		'click #saveProfile' : 'saveProfileData',
		'pagebeforeshow #profile_page' : 'renderProfiledata'
	},

	/**
	 Method to call participant service
	 Calling processProfiledata with returned response
	 **/
	getProfileData : function() {
		modelCount = mHealth.models.ParticipantModel.count();
		header = ALSECTOKEN;
		if(modelCount === 0) {
			this.service.getResponse(mHealth.uat.message_get_url, header, this.participantSuccess, this.participantFailure);
			participantdata = mHealth.models.ParticipantModel.first();
		} else {
			$.mobile.changePage("../../home/view/profile.html");
		}
	},
	/**
	 Success method of Service call
	 **/
	participantSuccess : function(output) {
		var response = output.responseText;
		var participant = new mHealth.controllers.ParticipantController
		participant.processProfileData(response);
		$.mobile.changePage("../../home/view/profile.html");
	},
	/**
	 Error method of Service call
	 **/
	participantFailure : function(jqXHR, textStatus, errorThrown) {
		alert("Information not available");
	},
	/**
	 Method to show the profile data
	 Rendering the data with the help of underscore
	 **/
	renderProfiledata : function() {
		participantdata = mHealth.models.ParticipantModel.all();
		$('#profiles').html(_.template($('#ParticipantList').html(), {
			participantdata : participantdata
		}));
		$('#profile_page').trigger('create');

	},
	/**
	 Method to save profile data
	 Updating the participant model with preferred name and height attributes
	 **/
	saveProfileData : function() {
		participantdata = mHealth.models.ParticipantModel.first();
		participantdata.updateAttributes({
			preferredName : $("#preferredName").val(),
			height : $('select#height option:selected').val()
		});
		mHealth.index = $('select#height option:selected').val();
		$.mobile.changePage("home.html");
	},
                                                                 
     	/**
	 Method for process response from service
	 Binding the response from the service to participant model
	 **/
     processProfileData : function(response) {
     if(response !== '') {
     data = JSON.parse(response);
     
     /**
      Binding the data to participant model
      **/
     var participant = JSON.stringify(data); 
     mHealth.models.ParticipantModel.customFromJSON(participant);
     
     }
     }
   });
