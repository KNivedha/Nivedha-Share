//
//  ForceQuit.h
//  Alere
//
//  Created by Nivedha Kaliaperumal on 2/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ForceQuit : NSObject

@end
