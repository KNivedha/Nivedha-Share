//
//  Orientation.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Orientation.h"
#import "AlereAppDelegate.h"
#import "TabBarController.h"
#import "OrientationConstants.h"
#import "AlereViewController.h"
@implementation Orientation
#define DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) / 180.0 * M_PI)
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    
    AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    if( [action isEqualToString:@"startRotation"])       
    {
        NSLog(@"start rotated method");
        UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
        app.viewController.enteredGraph=YES;
        if (interfaceOrientation==UIDeviceOrientationPortrait||interfaceOrientation==UIDeviceOrientationPortraitUpsideDown) 
        {
           
           
            NSLog(@"rotating to landscape");
//             app.tabBarController.rotated=YES;
//            [ app.tabBarController.view setCenter:CGPointMake(160, 240)];
//            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(-90));
//            app.tabBarController.view.transform = cgCTM;
//            app.tabBarController.view.bounds = CGRectMake(0, 00, 480, 300);
//            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationLandscapeLeft];
            
            
              app.tabBarController.alereViewController.enteredGraph=YES;
        }
        else
        {
            //app.tabBarController.landscp=YES;
            app.tabBarController.alereViewController.enteredGraph=YES;
        }
    }
    else if( [action isEqualToString:@"stopRotation"])       
    {
         app.viewController.enteredGraph=NO;
        if(app.tabBarController.rotated==YES)        
        {
              NSLog(@"rotating to portrait");
//            [ app.tabBarController.view setCenter:CGPointMake(160, 240)];
//            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(0));
//            app.tabBarController.view.transform = cgCTM;
//            app.tabBarController.view.bounds = CGRectMake(0, 00, 320, 460);
//            app.tabBarController.rotated=NO;
//            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortrait];
              app.tabBarController.alereViewController.enteredGraph=NO;   
        }
        else
        {
             app.tabBarController.alereViewController.enteredGraph=NO;
             //app.tabBarController.landscp=NO;
        }
        UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
        if (interfaceOrientation==UIDeviceOrientationLandscapeRight||interfaceOrientation==UIDeviceOrientationLandscapeLeft )
        {
             app.tabBarController.tabBar.view.frame=CGRectMake(0, -20, 480, 320);
        }
        else
        {
             app.tabBarController.tabBar.view.frame=CGRectMake(0, 0, 320, 460);
            
        }
        app.viewController.resized=NO;
        app.tabBarController.tabBar.tabBar.hidden=NO;
    }

}
@end
