//
//  Orientation.h
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DeviceDelegate.h"
@interface Orientation : NSObject<DeviceDelegate>

@end
