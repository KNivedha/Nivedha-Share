//
//  Orientation.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Orientation.h"
#import "AlereAppDelegate.h"


#import "AlereViewController.h"
@implementation Orientation
#define DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) / 180.0 * M_PI)
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    
    AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    UIApplication *application= [UIApplication sharedApplication] ;
  
    if( [action isEqualToString:@"loadChart"])       
    {
        NSLog(@"start rotated method");
        app.viewController.enteredGraph=YES;
        app.viewController.baseTabBar.hidden=YES;
		UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
        [[UIApplication sharedApplication]setStatusBarHidden:YES];
        orginPoint= app.viewController.view.frame.origin;
        sizePoint=app.viewController.view.frame.size;
        if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown )
        {
            portraitOrientation=   app.viewController.view.frame;
            app.viewController.view.frame = CGRectMake(0, 0, 320, 480);
            app.viewController.webView.frame=CGRectMake(0, 0,320, 480 );
            rotated=YES;
        }
        else  if (interfaceOrientation==UIInterfaceOrientationLandscapeRight||interfaceOrientation==UIInterfaceOrientationLandscapeLeft )
        {    
            landscapeOrientation=   app.viewController.view.frame;

            app.viewController.view.frame = CGRectMake(0, 0, 320 ,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);
        }
    }
    else if( [action isEqualToString:@"unLoadChart"])       
    {
         app.viewController.enteredGraph=NO;
		 app.viewController.baseTabBar.hidden=NO;
		 application.statusBarHidden=NO;
        [[UIApplication sharedApplication]setStatusBarHidden:NO];
         UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
        if (interfaceOrientation==UIInterfaceOrientationLandscapeLeft)
        {
          
            app.viewController.view.frame=CGRectMake(20, 0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,272);
        }
       else if (interfaceOrientation==UIInterfaceOrientationLandscapeRight)
        {
            
            app.viewController.view.frame=CGRectMake(0, 0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,272);
        }
       else  if (interfaceOrientation==UIInterfaceOrientationPortrait)
        {
            CGRect statusBarHeight=application.statusBarFrame;
            app.viewController.view.frame = CGRectMake(0, statusBarHeight.size.height, 320, statusBarHeight.size.height>20?440:460);
            app.viewController.webView.frame=CGRectMake(0, 0, 320, 416);
         
        }
        else if (interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown)
        {
            CGRect statusBarHeight=application.statusBarFrame;
            app.viewController.view.frame = CGRectMake(0, 0, 320,  statusBarHeight.size.height>20?440:460);
            app.viewController.webView.frame=CGRectMake(0, 0, 320, 416);
        }

    }
      else if( [action isEqualToString:@"getCurrentOrientation"])    
      {
          UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
          if ((interfaceOrientation==UIInterfaceOrientationPortrait)||(interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown)) 
          {
              
              NSString* callBackFunction=@"currentOrientationGraph([\"portrait\"])";
              [ app.viewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
          }
          else  if ((interfaceOrientation==UIInterfaceOrientationLandscapeLeft)||(interfaceOrientation==UIInterfaceOrientationLandscapeRight)) 
          {
              NSString* callBackFunction=@"currentOrientationGraph([\"landscape\"])";
              [ app.viewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
          }

      }
}
@end
