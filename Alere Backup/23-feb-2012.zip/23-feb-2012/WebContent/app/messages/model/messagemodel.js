mHealth.models.MessageModel = Spine.Model.sub();
// mHealth.models.MessageModel.configure('MessageModel','messageID',
// 'msgTypeID','title','sentDate','msgFolderID','healthTopicID',
// 'isRead','isReplied','isUrgent');

mHealth.models.MessageModel.configure("MessageModel", "sections", "messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "sentDate", "deliveredDate", "expiredDate", "sections");

mHealth.models.MessageDetailsModel = Spine.Model.sub();
mHealth.models.MessageDetailsModel.configure("MessageDetailsModel", "sections", "messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "sentDate", "deliveredDate", "expiredDate", "sections");


mHealth.models.SectionModel = Spine.Model.sub();
mHealth.models.SectionModel.configure("SectionModel","videos","summary","questionnaire");

mHealth.models.QuestionnaireModel = Spine.Model.sub();
mHealth.models.QuestionnaireModel.configure("QuestionnaireModel", "learnMore","introCopy","qSections");

mHealth.models.QuestionSectionModel = Spine.Model.sub();
mHealth.models.QuestionSectionModel.configure('QuestionSectionModel', 'questions', 'id', 'seq', 'title', 'learnMore', 'ImageURL');

mHealth.models.MessageQuestionModel = Spine.Model.sub();
mHealth.models.MessageQuestionModel.configure('MessageQuestionModel', 'id', 'seq', 'questionText', 'answerType', 'ImageURL', 'answerOptions', 'learnMore');

// mHealth.models.AnswerModel = Spine.Model.sub();
// mHealth.models.AnswerModel.configure('AnswerModel', 'id', 'seq', 'Label', 'ImageURL');

messageData = [{
	"messageID" : "999",
	"msgTypeID" : "1",
	"senderID" : "Virtual Coach",
	"senderTypeID" : "2",
	"recipientID" : "27458",
	"recipientTypeID" : "1",
	"concernedPartyID" : "1",
	"concernedPartyTypeID" : "1",
	"title" : "Diabetes MiniAssessment",
	"conversationID" : "",
	"msgFolderID" : "1",
	"healthTopicID" : "",
	"msgTemplateID" : "",
	"targetPresentationLayerID" : "",
	"isRead" : "false",
	"isReplied" : "false",
	"isUrgent" : "false",
	"sentDate" : "2012-02-17 00:00:00",
	"deliveredDate" : "2012-02-17 00:00:00",
	"expiredDate" : "",
	"sections" : {
		"section" : [{
			"videos" : ""
		}, {
			"summary" : ""
		}, {
			"questionnaire" : {
				"learnMore" : "text",
				"introCopy" : "Diabetes Mini Assessment",
				"qSections" : {
					"qSection" : [{
						"id" : 1001,
						"seq" : 1,
						"title" : "text",
						"learnMore" : "text",
						"ImageURL" : "text",
						"questions" : {
							"question" : [{
								"id" : 8001,
								"seq" : 1,
								"questionText" : "Are you currently affected by diabetes? If so, which type?",
								"answerType" : "FixedListSingleSelect",
								"ImageURL" : "text",
								"answerOptions" : {
									"answerOption" : [{
										"id" : 99001,
										"seq" : 1,
										"Label" : "Type I",
										"ImageURL" : "text"
									}, {
										"id" : 99002,
										"seq" : 2,
										"Label" : "Type II"
									}, {
										"id" : 99003,
										"seq" : 3,
										"Label" : "Unknown"
									}, {
										"id" : 99004,
										"seq" : 4,
										"Label" : "I don't have diabetes"
									}]
								},
								"learnMore" : "text"
							}, {
								"id" : 8002,
								"seq" : 2,
								"questionText" : "How do you manage your diabetes?",
								"answerType" : "FixedListSingleSelect",
								"answerOptions" : {
									"answerOption" : [{
										"id" : 99005,
										"seq" : 1,
										"Label" : "Diet and exercise"
									}, {
										"id" : 99006,
										"seq" : 2,
										"Label" : "Oral medication"
									}, {
										"id" : 99007,
										"seq" : 3,
										"Label" : "Insulin or insulin pump"
									}]
								}
							}, {
								"id" : 8003,
								"seq" : 3,
								"questionText" : "What glucometer do you predominantly use?",
								"answerType" : "FixedListSingleSelect",
								"answerOptions" : {
									"answerOption" : [{
										"id" : 99008,
										"seq" : 1,
										"Label" : "None"
									}, {
										"id" : 99009,
										"seq" : 2,
										"Label" : "glucometer ABC"
									}, {
										"id" : 99010,
										"seq" : 3,
										"Label" : "glucometer XYZ"
									}]
								}
							}]
						}
					}, {
						"id" : 1002,
						"seq" : 2,
						"title" : "Please enter your Height and Weight",
						"questions" : {
							"question" : [{
								"id" : 8004,
								"seq" : 1,
								"questionText" : "select Date",
								"answerType" : "Date"
							}, {
								"id" : 8005,
								"seq" : 2,
								"questionText" : "select Height",
								"answerType" : "FixedListSingleSelect",
								"answerOptions" : {
									"answerOption" : [{
										"id" : 99011,
										"seq" : 1,
										"Label" : "3 ft. 0 in."
									}, {
										"id" : 99012,
										"seq" : 2,
										"Label" : "3 ft. 1 in."
									}, {
										"id" : 99071,
										"seq" : 99,
										"Label" : "8 ft. 0 in."
									}]
								}
							}, {
								"id" : 8006,
								"seq" : 3,
								"questionText" : "Enter Weight",
								"answerType" : "Float"
							}]
						}
					}, {
						"id" : 1003,
						"seq" : 3,
						"questions" : {
							"question" : [{
								"id" : 8007,
								"seq" : 1,
								"questionText" : "Please enter your latest Hemoglobin A1c test result",
								"answerType" : "FixedListSingleSelect",
								"answerOptions" : {
									"answerOption" : [{
										"id" : 99011,
										"seq" : 1,
										"Label" : "I have never had the test completed"
									}, {
										"id" : 99012,
										"seq" : 2,
										"Label" : "I have had the test but don't remember the values"
									}, {
										"id" : 99071,
										"seq" : 3,
										"Label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
									}]
								}
							}, {
								"id" : 8008,
								"seq" : 2,
								"questionText" : "select Date",
								"answerType" : "Date"
							}, {
								"id" : 8009,
								"seq" : 3,
								"questionText" : "Enter A1c",
								"answerType" : "Float"
							}]
						}
					}, {
						"id" : 1004,
						"seq" : 4,
						"title" : "Please enter your latest Cholesterol or Lipid Panel test results",
						"questions" : {
							"question" : [{
								"id" : 8010,
								"seq" : 1,
								"questionText" : "Please Select One",
								"answerType" : "FixedListSingleSelect",
								"answerOptions" : {
									"answerOption" : [{
										"id" : 100001,
										"seq" : 1,
										"Label" : "I have never had the test completed"
									}, {
										"id" : 100002,
										"seq" : 2,
										"Label" : "I have had the test but don't remember the values"
									}, {
										"id" : 100003,
										"seq" : 3,
										"Label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
									}]
								}
							}, {
								"id" : 8011,
								"seq" : 2,
								"questionText" : "Enter LDL",
								"answerType" : "Float"
							}, {
								"id" : 8012,
								"seq" : 3,
								"questionText" : "Enter HDL",
								"answerType" : "Float"
							}, {
								"id" : 8013,
								"seq" : 4,
								"questionText" : "Enter Triglycerides",
								"answerType" : "Float"
							}, {
								"id" : 8014,
								"seq" : 5,
								"questionText" : "Enter Cholesterol",
								"answerType" : "Float"
							}]
						}
					}, {
						"id" : 1005,
						"seq" : 5,
						"title" : "Please tell us about your recent lab tests for Diabetes",
						"questions" : {
							"question" : [{
								"id" : 8015,
								"seq" : 1,
								"questionText" : "Dilated Retinal Exam",
								"answerType" : "FixedListSingleSelect",
								"answerOptions" : {
									"answerOption" : [{
										"id" : 100001,
										"seq" : 1,
										"Label" : "I have never had the test completed"
									}, {
										"id" : 100003,
										"seq" : 2,
										"Label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
									}]
								}
							}, {
								"id" : 8016,
								"seq" : 2,
								"questionText" : "Enter Date",
								"answerType" : "Date"
							}, {
								"id" : 8017,
								"seq" : 3,
								"questionText" : "Foot Exam - Provider",
								"answerType" : "FixedListSingleSelect",
								"answerOptions" : {
									"answerOption" : [{
										"id" : 100001,
										"seq" : 1,
										"Label" : "I have never had the test completed"
									}, {
										"id" : 100003,
										"seq" : 2,
										"Label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
									}]
								}
							}, {
								"id" : 8018,
								"seq" : 4,
								"questionText" : "Enter Date",
								"answerType" : "Date"
							}, {
								"id" : 8019,
								"seq" : 5,
								"questionText" : "Microalbumin",
								"answerType" : "FixedListSingleSelect",
								"answerOptions" : {
									"answerOption" : [{
										"id" : 100001,
										"seq" : 1,
										"Label" : "I have never had the test completed"
									}, {
										"id" : 100003,
										"seq" : 2,
										"Label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
									}]
								}
							}, {
								"id" : 8020,
								"seq" : 6,
								"questionText" : "Enter Date",
								"answerType" : "Date"
							}]
						}
					}]
				}
			}
		}]
	}
}];
