/**
 * Controller : MessageController
 * This is the controller to do the  logic of message
 **/
mHealth.controllers.MessageController = Spine.Controller.sub({
	el : 'body',
	elements : {},

	tabbarloaded : false,

	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		'pagebeforeshow #home' : 'showMessages',
		'click #messageCenter' : 'loadMessageTab',
		'click #displayMessage' : 'loadMessage',
		'pagebeforeshow #renderMessage' : 'renderMessage',
		'pagebeforeshow #showMessage' : 'getMessages'
	},
	/**
	 * Name    : messageSuccess
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	messageSuccess : function(output) {
		
		alert('messagesuccess');

		// var response = output.responseText;
		// alert('message response '+response);
		// var bundleMessage = JSON.parse(response);
// 
		// var messages = JSON.stringify(bundleMessage[0].Message);
		// mHealth.models.MessageModel.customFromJSON(messages);
		$.mobile.changePage("../../home/view/home.html");
		mHealth.HealthDataControllerObject.loadTrackerData();
		
	
	},
	/**
	 * Name    : showHome
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	showHome : function() {
		alert('showhome');
		$.mobile.changePage("../../home/view/home.html");
		mHealth.HealthDataControllerObject.loadTrackerData();

	},
	
	messageServiceFailure : function() {
		mHealth.util.hideMask();
	},
	
	/**
	 * Name    : showMessages
	 * Purpose : Load the message from the Model and Show the Result in the Message Center of the Home Tab
	 * Params  : --
	 * Return  : --
	 **/
	showMessages : function() {
		alert('showmessages');

		var len = mHealth.models.MessageModel.count();

		var messages_val = mHealth.models.MessageModel.all();

		if(len > 0) {

			$('#messages_div').html(_.template($('#messageList').html(), {
				messages_val : messages_val
			}));
			$('#home').trigger('create');
		} else {
			var message = "There are no messages for you to view at this time.";
			$('#messages_div').text(message);
		}

		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}

	},

	/**
	 * Name    : loadMessage
	 * Purpose : Calls webservice to get message details page
	 * Params  : --
	 * Return  : --
	 **/	
	loadMessage : function() {
		var URL ='http://localhost/WebContent/';
        this.proxy(this.service.getResponse(URL, mHealth.MessageControllerObject.displayMessage, mHealth.MessageControllerObject.loadMessageTab1, true));
		
	},

	/**
	 * Name    : displayMessage
	 * Purpose : Loads message details in to model
	 * Params  : --
	 * Return  : --
	 **/		
	displayMessage : function(output) {
		var response = messageData; //output.responseText;

		var messageResponse = JSON.stringify(response);	
		var messagesData = JSON.parse(messageResponse)				
		var messages = JSON.stringify(messagesData);	

		mHealth.models.MessageDetailsModel.customFromJSON(messages);			
		mHealth.models.MessageDetailsModel.each(function(message) {
			var sectionData = message.sections.section;										
			var questionnaireData = sectionData[2].questionnaire;								
			mHealth.models.QuestionnaireModel.customFromJSON(questionnaireData);	
		
			mHealth.models.QuestionnaireModel.each(function(questionnaire) {				
				var questionSectionData = questionnaire.qSections;
				var questionSecData = questionSectionData.qSection;					
				mHealth.models.QuestionSectionModel.customFromJSON(questionSecData);
				mHealth.models.QuestionSectionModel.each(function(questionSection) {					
					var questionsData = questionSection.questions;					
					var questionData = questionsData.question;										
					questionData.map(function(question) {						
						mHealth.models.MessageQuestionModel.customFromJSON(question);							
					});				
				});
			});		
        }); 

		$.mobile.changePage("../../messages/view/displayMessage.html");

	},
	
	/**
	 * Name    : loadMessageTab1
	 * Purpose : To deal webservice failure scenario
	 * Params  : --
	 * Return  : --
	 **/
	loadMessageTab1 : function() {
		$.mobile.changePage("../../messages/view/showmessage.html");
		location.href = "tabbar://loadMessages?";
	},

	/**
	 * Name    : renderMessage
	 * Purpose : Method to render data on html page
	 * Params  : --
	 * Return  : --
	 **/	
	renderMessage : function() {
		var len = mHealth.models.MessageDetailsModel.count();
		var messages_val = mHealth.models.MessageDetailsModel.all();


		$('#messages-details_div').html(_.template($('#messageList').html(), {
			messages_val : messages_val
		}));
		$('#messages-details').trigger('create');

		$.mobile.changePage("../../messages/view/displayMessage.html");
	},
	
	/**
	 * Name    : getMessages
	 * Purpose : Load the message from the Model and Show the Result in the  Message Tab
	 * Params  : --
	 * Return  : --
	 **/
	getMessages : function() {
		var len = mHealth.models.MessageModel.count();

		var messages_val = mHealth.models.MessageModel.all();

		if(len < 0) {
			messages_val = "There are no messages for you to view at this time.";
		}

		$('#message').html(_.template($('#messageList1').html(), {
			messages_val : messages_val
		}));
		$('#showMessage').trigger('create');

	},
	/**
	 * Name    : loadMessageTab
	 * Purpose : Highlight the Message when we redirect the shorcut from the Home to message TAB.
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageTab : function() {

		$.mobile.changePage("../../messages/view/showmessage.html");
		location.href = "tabbar://loadMessages?";
	}
});
