/**
 * Controller : SettingsController
 * Controller to do logic of settings
 **/
mHealth.controllers.SettingsController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #logoutId' : 'doLogout',
		'click #showAbout' : 'getFeatures',
		'click #sendFeedBack' : 'sendMail',
		'pagebeforeshow #aboutsDetail' : 'showDetail',
		'change #HeightUnit' : 'getHeightUnits',
		'change #WeightUnit' : 'getWeightUnits',
		'pagebeforeshow #settingsPage' : 'showSettings',
		'click #debugId' : 'debug',
        'click #dummyalfresco' : 'getAlfresco',
        'click #healthwise' : 'getHealthwise',
        'click #hw_samepage' : 'getHealthwisePage',
        'click #directArticle' : 'getdirectArticle'
	},
    
    /**
	 * Name    : getHealthwisePage
	 * Purpose : Method to do get Healthwise Contents.
	 * Params  : --
	 * Return  : --
	 **/
	getdirectArticle : function() {
        $.mobile.changePage('../../settings/view/aa20968.html');
	},
    
	/**
	 * Name    : getHealthwisePage
	 * Purpose : Method to do get Healthwise Contents.
	 * Params  : --
	 * Return  : --
	 **/
	getHealthwisePage : function() {
        $.mobile.changePage('../../settings/view/healthwise.html');
	},

	/**
	 * Name    : getHealthwise Content
	 * Purpose : Method to do get Healthwise Contents.
	 * Params  : --
	 * Return  : --
	 **/
	getHealthwise : function() {
        //healthwise_url: "http://secure.uat.alerehealth.com:13085/api/health-articles/aa20968"
        //var article_id = "aa20968";
		//var URL = mHealth.env.healthwise_url+article_id;
        //this.service.getResponse("http://secure.uat.alerehealth.com:13085/api/health-articles/aa20968",
        this.service.getResponse("http://10.75.205.206/~ameyathakur/aa20968.html",
        this.proxy(this.healthwiseSuccess),
        this.proxy(this.healthwiseError), true);
        //$.mobile.changePage('../../settings/view/aa20968.html');
	},
    /**
	 * Name    : healthwiseSuccess
	 * Purpose : Method to do get Alfreco Contents.
	 * Params  : --
	 * Return  : --
	 **/
	healthwiseSuccess : function(output) {
        var healthwiseContent;
        healthwiseContent = output.responseText;
        alert("HEALTH WISE CONTENT IS "+healthwiseContent);
        
        
       
        //$.mobile.changePage('../../settings/view/dummyarticle.html');
	}, 
    /**
     * Name    : healthwiseError
     * Purpose : Method to do get Alfreco Contents.
     * Params  : --
     * Return  : --
    **/
	healthwiseError : function(errorMessage) {
        alert("Failure"+errorMessage);
        //$.mobile.changePage('../../settings/view/aa20968.html');
	}, 
    /**
	 * Name    : getAlfreco
	 * Purpose : Method to do get Alfreco Contents.
	 * Params  : --
	 * Return  : --
	 **/
	getAlfresco : function() {
        $.mobile.changePage('../../settings/view/healthwise1.html');
	},
    /**
	 * Name    : debug
	 * Purpose : Method to do Debug.
	 * Params  : --
	 * Return  : --
	 **/
	debug : function() {
		//mHealth.util.customAlert("Under Construction", mHealth.GuiHelper.alerttitle);
        $.mobile.changePage('../../settings/view/debugindex.html');
	},
	/**
	 * Name    : doLogout
	 * Purpose : Method to do required actions while logout.
	 * Params  : --
	 * Return  : --
	 **/
	doLogout : function() {
		mHealth.util.customPrompt(mHealth.SettingsController.logoutConfirm, mHealth.GuiHelper.alerttitle, function() {
			location.href = "tabbar://removeMask?";
		}, function() {
			
			var splashMessage = mHealth.SettingsLogin.logout;
			//mHealth.models.AnswerModel.destroyAll();
			//mHealth.models.ParticipantAnswerModel.destroyAll();
			mHealth.models.ConditionModel.destroyAll();
			mHealth.models.MessageModel.destroyAll();
			mHealth.models.MedicationModel.destroyAll();
			mHealth.models.ParticipantModel.destroyAll();
			//mHealth.models.SpaceModel.destroyAll();
			//mHealth.models.ViewModel.destroyAll();
			//mHealth.models.ZoneModel.destroyAll();
			mHealth.models.HealthDataModel.destroyAll();

			$.mobile.changePage("../../rootview/view/login.html", {
				data : {
					splashMessage : splashMessage
				}
			});

			mHealth.util.removeNativeBar();
			mHealth.MessageControllerObject.tabbarloaded= false;
		});
	},
	/**
	 * Name    : getHeightUnits
	 * Purpose : Method to get the selected value of height units field on change of the select menu
	 * Params  : --
	 * Return  : --
	 **/
	getHeightUnits : function() {
		mHealth.util.selUnits = $('select#HeightUnit option:selected').val();
	},
	/**
	 * Name:WeightUnits
	 *Purpose:Method to get the selected value of weight units field
	 on change of the select menu
	 **/

	getWeightUnits : function() {
		mHealth.util.selWeightUnits = $('select#WeightUnit option:selected').val();
	},
	/**
	 * Name    : showSettings
	 * Purpose : Method to render the selected value of height units field on load of the page
	 * Params  : --
	 * Return  : --
	 **/
	showSettings : function() {
		if(mHealth.util.selUnits == 'cm') {
			$("select#HeightUnit option[value='cm']").attr("selected", "selected");
			$('select').selectmenu('refresh');

		}

		if(mHealth.util.selWeightUnits == 'Kg') {
			$("select#WeightUnit option[value='Kg']").attr("selected", "selected");
			$('select').selectmenu('refresh');

		}
	},
	/**
	 * Name    : showDetail
	 * Purpose : Method to render the values of device details
	 * Params  : --
	 * Return  : settingsDetail, deviceInfo
	 **/
	showDetail : function() {
		var settingsDetail;
		settingsDetail = mHealth.SettingsAbout;
		$('#settingsHeader').html(_.template($('#headerScript').html(), {
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').html(_.template($('#deviceDetails').html(), {
			deviceInfo : deviceInfo,
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').trigger('create');
		$('#settingsHeader').trigger('create');

	},
	/**
	 * Name    : getFeatures
	 * Purpose : Method to call the webview to get Device Features
	 * Params  : --
	 * Return  : --
	 **/
	getFeatures : function() {
		mHealth.util.getDeviceFeatures();
		$.mobile.changePage("about.html");
	},
	/**
	 * Name    : sendMail
	 * Purpose : Method to call the webview to call native email
	 * Params  : --
	 * Return  : --
	 **/
	sendMail : function() {
        mHealth.util.sendEmail(mHealth.env.emailTo,mHealth.env.emailCC , mHealth.env.emailSubject);
	}
});

mHealth.controllers.SettingsController.extend({

	/**
	 * Name    : getDevicesFeature
	 * Purpose : Method to call from webview to get device features
	 * Params  : --
	 * Return  : --
	 **/
	getDevicesFeature : function(device, osversion) {
		mHealth.util.osversion = osversion;
		mHealth.util.device = device;
		deviceInfo = [{
			'regUser' : mHealth.util.participantEmail,
			'version' : mHealth.util.version,
			'platform' : 'APPLE',
			'deviceName' : mHealth.util.device,
			'deviceModel' : mHealth.util.osversion
		}];

	}
});
