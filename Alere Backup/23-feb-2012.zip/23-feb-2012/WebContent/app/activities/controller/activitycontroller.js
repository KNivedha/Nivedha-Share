/**
 *Controller : ActivityController
 *Controller to do Activity Tab functionality.
 **/

mHealth.controllers.ActivityController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	subActivityView : "",
	activity : null,
	activityDetailRecord : null,
	spaceviewzone : null,
	events : {

		'pagebeforeshow #showActivity' : 'showActivity',
		'click .detailActivity' : 'getSubActivity',
		'pagebeforeshow #detailActivity' : 'showDetailActivity',
		'pagebeforeshow #calendarPage' : 'showCalendar',
		'click #calendarSave' : 'getCalendarData',
		'click #challengesShortCut' : 'getActivity',
		'pagebeforeshow #displayQuestions' : 'showQuestions',
		'pageshow #displayQuestions' : 'processQuestions',
		'pagebeforeshow #assessNotFound' : 'showNotFoundPage',
		'click #leftArrow' : 'leftButton',
		'click #rightArrow' : 'rightButton',
		'click #infoButton' : 'showdetailactivity'

	},

	/**
	 *Name        : showDetailActivity
	 *Purpose
	 *Params
	 *Returns
	 **/
	showDetailActivity : function() {
		var currentDate = mHealth.util.getCurrentDay();
		if(mHealth.ActivityControllerObject.activityDetailRecord.status==0 && mHealth.ActivityControllerObject.activityDetailRecord.endDate < currentDate)
		{
			$('.showLabel').show();
			$('#buttonText .ui-btn-text').html(mHealth.ActivityControllerObject.activityDetailRecord.targetLabel);
			$('#buttonText').trigger('create');
		}
		//$('.showLabel').hide();
		$('#detailActivity_div').html(_.template($('#detailActivityDataList').html(), {
			activityDetailRecord : mHealth.ActivityControllerObject.activityDetailRecord
		}));
		$('#detailActivity').trigger('create');

	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showActivity : function() {

		$('#activityTitle').text(this.activity[0].space[0].title);

		if(this.activity[0].zone.length > 1) {

			$('#activity_zone').show();
			var activityZone = this.activity[0].zone[0].isInset;

			$('#activity_zone').html(_.template($('#navDataList').html(), activityZone));
		}

		var activityView = this.activity[0].view;

		$('#activity_div').html(_.template($('#activityDataList').html(), {
			activityView : activityView
		}));
		$('#showActivity').trigger('create');
		//this.getActivity();
	},
	/**
	 *Name: getSubActivity
	 *Purpose: On click the View of the Activity, the Function will be
	 *Params
	 *Returns
	 **/
	getSubActivity : function(event) {
		alert('getSubActivity');
		var view = event.target;
		selectedViewName = $(view).parents('li').children('div').children('div').children('a').children('h3').text();
		mHealth.models.SpaceViewZoneModel.each(function(record) {
			if(record.pageName === 'Activity') {
				for( i = 0; i < record.view.length; i++) {
					if(record.view[i].title.trim() === selectedViewName.trim()) {
						this.subActivityView = record.view[i];
						//alert(mHealth.ActivityControllerObject.activityDetailRecord);
						mHealth.ActivityControllerObject.activityDetailRecord = this.subActivityView;
						mHealth.ActivityControllerObject.assesssmentName = mHealth.ActivityControllerObject.activityDetailRecord.name;
						break;
					}
				}
			}
		});
		//this.getChallengeData(mHealth.ActivityControllerObject.assesssmentName);
		//$.mobile.changePage("detailactivity.html");
		var URL=mHealth.env.challenge_details_url +mHealth.ActivityControllerObject.assesssmentName+'/';
		alert('url '+URL);
		this.service.getResponse(URL,this.proxy(this.getChallengeDetailSuccess),this.proxy(this.getChallengeDetailFailure),false);

	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	getActivity : function() {
		alert('getactivity');
		
		if(this.spaceviewzone != null) {

			

										$.mobile.changePage("../../activities/view/showactivity.html");
				location.href = "tabbar://loadActivities?";

			
		} else {

			mHealth.util.showMask();
			var body = mHealth.recommendation.RecommendationMapper("", "", "1003");
			this.proxy(this.service.postRequest(mHealth.env.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.recommendationFailure), false));
			//this.proxy(this.service.getResponse(mHealth.env.challenge_details_url,this.proxy(this.getChallengeDetailSuccess),this.proxy(this.getChallengeDetailFailure),true));
			}


		
	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showCalendar : function() {
		$("#eventName").val(selectedViewName);
		$('#startDate').scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'datetime',
			seconds : true,
			timeFormat : 'hh:ii:ss A',
			theme : 'ios'
		});
		$('#endDate').scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'datetime',
			seconds : true,
			timeFormat : 'hh:ii:ss A',
			theme : 'ios'
		});
	},
	/**
	 * Name    : getCalendarData
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	getCalendarData : function() {
		var title, startDate, endDate;
		title = $('#eventName').val();
		startDate = $('#startDate').val();
		endDate = $('#endDate').val();
		if(startDate > endDate) {
			mHealth.util.customAlert(mHealth.Validation.invalidDate, "mHealth");
		} else {
			mHealth.util.callCalendar(title, startDate, endDate);
			$.mobile.changePage("../../activities/view/detailactivity.html");
		}

	},
	/**
	 * Name    : setActivityData
	 * Purpose : Method to set the value
	 * Params  : --
	 * Return  : --
	 **/
	setActivityData : function(output) {
		alert('setActivityData');

		var response, recommandationData, spaceData, zoneData, viewData;
		response = output.responseText;
		alert('setActivityData response '+response);
		recommandationData = JSON.parse(response);
		spaceData = JSON.stringify(recommandationData.Space);
		zoneData = JSON.stringify(recommandationData.Zone);
		viewData = JSON.stringify(recommandationData.View);
		this.spaceviewzone = new mHealth.models.SpaceViewZoneModel({

			pageName : 'Activity',
			space : mHealth.models.SpaceModel.fromJSON(spaceData),
			view : mHealth.models.ViewModel.fromJSON(viewData),
			zone : mHealth.models.ZoneModel.fromJSON(zoneData)

		});
		this.spaceviewzone.save();
		mHealth.ActivityControllerObject.activity = mHealth.models.SpaceViewZoneModel.select(function(record) {

			if(record.pageName === 'Activity') {

				return record;
			}
		});
	},
	/**
	 *Name: recommendationSuccess
	 *Purpose: After getting the response from the recommandation Service, the functon will parse the space, View and ZOne
	 Set the value in the respective model.
	 *Params: output
	 *Returns: null
	 **/
	recommendationSuccess : function(output) {
		alert('recommendationSuccess');

		this.proxy(this.setActivityData(output));

		$.mobile.changePage("../../activities/view/showactivity.html");
		mHealth.util.hideMask();
		location.href = "tabbar://loadActivities?";
	},
	/**
	 *Name : recommendationFailure
	 *Purpose: On the Failure of the recommandation service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {
		alert('recommendationFailure');
		mHealth.util.hideMask();

	},
	
	/**
	 *Name : getChallengeDetailSuccess
	 *Purpose: On the Failure of the recommandation service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	getChallengeDetailSuccess:function(output)
	{
		alert('getChallengeDetailSuccess');
		var challengeDetailData=output.responseText;
                                                              alert('challengeDetailData '+challengeDetailData);
                                                              var response = JSON.parse(challengeDetailData);	
		if (JSON.stringify(response[0].Challenge[0]) == null || JSON.stringify(response[0].Challenge[0]) == undefined) {
			$.mobile.changePage('../../activities/view/assessmentnotfound.html');
		}
		var assessData=response[0].Challenge[0];
		
		var question=response[0].Challenge[0].Question;
		mHealth.models.ChallengeModel.customFromJSON(response[0].Challenge[0]);
		for(var i=0;i<question.length;i++){
		if(question[i].EntryType=='1'){
				var entryType='Checkbox';
			}
			else if(question[i].EntryType=='2'){
				var entryType='NumberEdit';
			}
		}
		alert('entryType'+entryType);
		output_html=mHealth.assessment.generate_html(question,entryType);	
		var currentDate = mHealth.util.getCurrentDay();
		var earnedCredits = assessData.EarnedCredits;
		var nextTierPoints = assessData.NextTierPoints;
		if(mHealth.ActivityControllerObject.activityDetailRecord.status==0 && mHealth.ActivityControllerObject.activityDetailRecord.endDate < currentDate)
		{
			$.mobile.changePage("detailactivity.html");
		}
		else
		{
			//(assessData.earnedCredits + ' of ' + assessData.nextTierPoints)
			 // $.mobile.changePage('confirmcondition.html', {
                            // data : {
                            // renderConditionName : trimRenderConditionName,
                            // renderDate : trimRenderDate
                            // }
                            // });
        			
		$.mobile.changePage("displayassessment.html", {data : {credits:earnedCredits,points:nextTierPoints}});
		}
	},
	/**
	 *Name : getChallengeDetailFailure
	 *Purpose: On the Failure of the recommandation service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	getChallengeDetailFailure:function()
	{
		alert('getChallengeDetailFailure');
	},


	
	/**
	 *Name : challengeSuccess
	 *Purpose :After getting the response from the challenge Service, the functon will parse the activity,subactivity and subactivity response
	 Maps the activity to assessment & Section, subactivity to question and answer and stores in a JSON structure.
	 *Params : output from the service
	 *Returns
	 **/
	// challengeSuccess : function(output) {
		// var challengesData = output.responseText;
		// challengesData = JSON.parse(challengesData);
		// var participant = challengesData.Participant;
		// var activity = challengesData.Activity;
		// var subactivity = challengesData.SubActivity;
		// var subactivityresponse = challengesData.SubActivityResponse;
		// sectionData = [], questionData = [], answerData = [];
		// for(var i = 0; i < subactivity.length; i++) {
			// if(subactivity[i].inputType == '1') {
				// subactivity[i].entryType = 'Checkbox';
			// } else if(subactivity[i].inputType == '2') {
				// subactivity[i].entryType = 'NumberEdit';
			// }
			// questionData.push({
				// questionId : subactivity[i].subActivityId,
				// createTimestamp : subactivity[i].createTimestamp,
				// updateTimestamp : subactivity[i].updateTimestamp,
				// startDate : subactivity[i].beginDate,
				// endDate : subactivity[i].endDate,
				// learnMore : subactivity[i].description,
				// assessmentId : subactivity[i].activityId,
				// sectionId : subactivity[i].categoryId,
				// rank : subactivity[i].rank,
				// theQuestion : subactivity[i].title
			// });
			// answerData.push({
				// questionId : subactivity[i].subActivityId,
				// answerId : subactivity[i].subActivityId,
				// createTimestamp : subactivity[i].createTimestamp,
				// updateTimestamp : subactivity[i].updateTimestamp,
				// startDate : subactivity[i].beginDate,
				// endDate : subactivity[i].endDate,
				// learnMore : subactivity[i].description,
				// assessmentId : subactivity[i].activityId,
				// sectionId : subactivity[i].categoryId,
				// rank : subactivity[i].rank,
				// entryType : subactivity[i].entryType
			// });
		// }
// 
		// for(var i = 0; i < activity.length; i++) {
			// mHealth.models.AssessmentModel.customFromJSON({
				// assessmentId : activity[i].activityId,
				// title : activity[i].title,
				// recurringFlag : 'true',
				// rank : activity[i].rank,
				// dashboardModuleId : activity[i].moduleTypeId,
				// maxCredits : activity[i].maxCredits,
				// earnedCredits : activity[i].earnedCredits,
				// imageURL : activity[i].image,
				// createTimestamp : activity[i].createTimestamp,
				// updateTimestamp : activity[i].updateTimestamp,
				// startDate : activity[i].beginDate,
				// endDate : activity[i].endDate,
				// learnMore : activity[i].bodyCopy,
				// nextTierPoints : activity[i].nextTierPoints,
				// earnedPts : activity[i].earnedPts,
				// isEngaged : activity[i].isEngaged
			// });
			// sectionData.push({
				// assessmentId : activity[i].activityId,
				// sectionId : activity[i].categoryId,
				// title : activity[i].title,
				// recurringFlag : 'true',
				// rank : activity[i].rank,
				// dashboardModuleId : activity[i].moduleTypeId,
				// maxCredits : activity[i].maxCredits,
				// earnedCredits : activity[i].earnedCredits,
				// imageURL : activity[i].image,
				// createTimestamp : activity[i].createTimestamp,
				// updateTimestamp : activity[i].updateTimestamp,
				// startDate : activity[i].beginDate,
				// endDate : activity[i].endDate,
				// learnMore : activity[i].bodyCopy,
				// nextTierPoints : activity[i].nextTierPoints,
				// earnedPts : activity[i].earnedPts,
				// isEngaged : activity[i].isEngaged
			// });
		// }
	// },
	/**
	 *Name : challengeFailure
	 *Purpose: On the Failure of the recommandation service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	// challengeFailure : function(jqXHR, textStatus, errorThrown) {
		// mHealth.util.hideMask();
	// },
	/**
	 *Name : getChallengeData
	 *Purpose : to get the corresponding challenge data, when a user clicks on the activity.
	 *Params : the selected activity name
	 *Returns
	 **/
	// getChallengeData : function(activity) {
		// assessData = mHealth.models.AssessmentModel.findByAttribute('assessmentId', activity);
		// if(assessData == null) {
			// $.mobile.changePage('../../activities/view/assessmentnotfound.html');
		// }
		// assessData.section = [];
		// assessData.section.question = [];
		// assessData.section.question.answer = [];
		// sectionData.map(function(section) {
			// if(section.assessmentId == assessData.assessmentId) {
				// assessData.section.push(mHealth.models.SectionModel.fromJSON(section));
				// assessData.save();
			// }
		// });
		// assessData.section.map(function(sectionmodel) {
			// sectionmodel.question = [];
			// questionData.map(function(question) {
				// if(question.assessmentId === sectionmodel.assessmentId && question.sectionId === sectionmodel.sectionId) {
					// sectionmodel.question.push(mHealth.models.QuestionModel.fromJSON(question));
					// assessData.save();
				// }
			// });
		// });
		// assessData.section[0].question.map(function(question) {
			// question.answer = [];
			// answerData.map(function(answer) {
				// if(answer.assessmentId === question.assessmentId && answer.sectionId === question.sectionId && answer.questionId === question.questionId) {
					// question.answer.push(mHealth.models.AnswerModel.fromJSON(answer));
					// assessData.save();
				// }
			// });
		// });
		// var startDate = assessData.startDate;
		// var isEngaged = assessData.isEngaged;
		// var endDate = assessData.endDate;
		// var type = assessData.section[0].question[0].answer[0].entryType;
		// output_html = mHealth.assessment.generate_html(assessData, type);
		// $.mobile.changePage("displayassessment.html");
	// },
	/**
	 *Name : leftButton
	 *Purpose : to check the current day and to show the previous day on click of the left disclosure button
	 *Params
	 *Returns
	 **/
	leftButton : function() {
		var currentDate, previousDay, today;
		currentDate = $('#currentDate').text();
		today = mHealth.util.getCurrentDay();
		previousDay = mHealth.util.getPreviousDay(currentDate);
		$('#currentDate').text(previousDay);
		previousDay = mHealth.util.parseDate(previousDay);
		today = mHealth.util.parseDate(today);
		currentDate = mHealth.util.parseDate(currentDate);
		if(previousDay < today || currentDate >= previousDay) {
			$('.showNextDay').show();
		} else {
			$('.showNextDay').hide();
		}
	},
	/**
	 *Name : rightButton
	 *Purpose : to check the current day and to show the next day on click of the left disclosure button
	 *Params
	 *Returns
	 **/
	rightButton : function() {
		var currentDate, nextDay, today;
		currentDate = $('#currentDate').text();
		today = mHealth.util.getCurrentDay();
		nextDay = mHealth.util.getNextDay(currentDate);
		$('#currentDate').text(nextDay);
		nextDay = mHealth.util.parseDate(nextDay);
		today = mHealth.util.parseDate(today);
		currentDate = mHealth.util.parseDate(currentDate);
		if(nextDay >= today) {
			$('.showNextDay').hide();
		} else {
			$('.showNextDay').show();
		}
	},
	/**
	 *Name : showNotFoundPage
	 *Purpose : when the assessment is not found for the particular activity, this page should be displayed
	 *Params
	 *Returns
	 **/
	showNotFoundPage : function() {
		var assessment = mHealth.Assessment;
		$('#assessmentNotFound').html(_.template($('#assessmentScript').html(), {
			assessment : assessment
		}));
		$('#assessmentNotFound').trigger('create');
	},
	/**
	 *Name :showQuestions
	 *Purpose : to set the value of current date, points earned and info button text
	 *Params
	 *Returns
	 **/
	showQuestions : function() {
		alert('showquestions');
		var currentPageURL, earnedCredits, nextTierPoints;
		
		
		currentPageURL = $('div[id = "displayQuestions"]').attr('data-url');
		
		earnedCredits = mHealth.util.getParameterByName('credits', currentPageURL);
		nextTierPoints = mHealth.util.getParameterByName('points', currentPageURL);
		

		
		var currentDate = mHealth.util.getCurrentDay();
		var today = mHealth.util.getCurrentDay();
		
		if(currentDate <= today) {
			$('.showNextDay').hide();
		} else {
			$('.showNextDay').show();
		}
		$('#currentDate').val(currentDate);
				var close = false;
				today = new Date();
        var validDate = today;
        $('#currentDate').scroller({
					dateFormat:'DD, M dd, yyyy',
					dayNames:['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
					monthNames:['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
					monthNamesShort:['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
					
                                     preset : 'date',
                                     theme : 'ios',
                                     endYear : 2012,
                                     onCancel : function(valueText, inst) {
                                     close = true;
                                     
                                     },
                                     onClose : function(valueText, inst) {
                                     
                                     if(!close) {
                                     return false;
                                     } else {
                                     if(inst.getDate() > (new Date()))
                                     inst.setDate(validDate);
                                     
                                     return true;
                                     }
                                     },
                                     onSelect : function(valueText, inst) {
                                     if(inst.getDate() > (new Date())) {
                                     close = false;
                                     
                                     mHealth.util.customAlert(mHealth.Section.dateOutOfRange, 'mHealth');
                                     
                                     } else {
                                     validDate = inst.getDate();
                                     close = true;
                                     }
                                     
                                     }
                                     });

		$('#showPoints').html(earnedCredits + ' of ' + nextTierPoints);
		$('#displayQues').append(output_html);
		$('#infoButton .ui-btn-text').html(selectedViewName);
		// $('#dateHeader').scroller({
			// dateFormat:'yyyy-mm-dd',
			// preset : 'datetime',
			// seconds:true,
			// timeFormat:'hh:ii:ss A',
			// theme : 'ios'
		// });
		if(mHealth.ActivityControllerObject.activityDetailRecord.endDate > currentDate)
		{
			$('.showLabel').show();
		}
		else
		{
			$('.showLabel').hide();
		}

		$('#displayQuestions').trigger('create');
		$('#infoButton').trigger('create');
	},
	processQuestions:function()
			{
				if(mHealth.ActivityControllerObject.activityDetailRecord.endDate < currentDate)
				{
					$("input[type='checkbox']").checkboxradio('disable');
					$('.selector').textinput('disable');
				}
			}
});
