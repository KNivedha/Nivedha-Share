/**
 *Controller : LoginController
 *Controller to do login functionality.
 **/

mHealth.controllers.LoginController = Spine.Controller.sub({
	el : 'body',
	count : 0,	
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #loginbutton' : 'doLogin',
		'click #sendMail' : 'sendEmail',
        'pagebeforeshow #showassessment' : 'showMiniAssessment',
        'pagebeforeshow #home' : 'showHomePage',
        'pagebeforeshow #loginPage' : 'setPrevLogin',       
		'click #assessmentBtn' : 'submitAssessment',	
		'change .selectValue' : 'setProgressBar',
		'click #skipBtn' : 'showHomePage',
	},
	/**
	 *Name   : sendEmail
	 *Purpose: Method to send email.
	 *Params : --
	 *Return : --
	 **/
	setPrevLogin : function()
	{
		 var rememberMe= mHealth.models.RememberMeModel.first();
		
            
				if( rememberMe != undefined ){
				$('#username').val(rememberMe.username);
				}
	},

	/**
	 *Name   : sendEmail
	 *Purpose: Method to send email.
	 *Params : --
	 *Return : --
	 **/
	sendEmail : function() {
	
                                                           mHealth.util.customAlert('nivedha', 'Title');
	   mHealth.util.sendEmailEvent("service.desk@alere.com","Alere mHealth");
		
	},
	/**
	 *Name   : loginSuccess
	 *Purpose: Success callback to authenticate user.
	 *Params : output - response from the server
	 *Return : --
	 **/
	loginSuccess : function(output) {
		mHealth.models.RememberMeModel.destroyAll();
		var rememberMe = new mHealth.models.RememberMeModel({
			"username" : $('#username').val()});
			rememberMe.save();
		var body = mHealth.recommendation.createRecommendationRequestJSON("1020");
		this.proxy(this.service.getResponse(mHealth.env.message_get_url, this.proxy(this.participantSuccess), "", false));
		this.proxy(this.service.postRequest(mHealth.env.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.loginFailure), true));
	},
	
	
	/**
	 * Name    : participantSuccess
	 * Purpose : Success callback for getting participant data.
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	participantSuccess : function(output) {
		var response = output.responseText;
		mHealth.models.ParticipantModel.customFromJSON(response);
	},
	/**
	 *Name   : loginFailure
	 *Purpose: Failure callback to authenticate user.
	 *Params : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server.
	 *Return : Displays error message.
	 **/
	loginFailure : function(jqXHR, textStatus, errorThrown) {

		$('#splash_message').show();
		if(errorThrown == mHealth.SettingsController.timeOut) {
			$('#splash_message').html(mHealth.SettingsController.errTimeout);
		} else if(errorThrown == mHealth.SettingsController.unauthorized) {
			$('#splash_message').html(mHealth.SettingsController.msgBadLogin);
		} else {
			$('#splash_message').html(mHealth.SettingsController.msgErrorCommunication);

		}
		mHealth.util.hideMask();
	},
	/**
	 *Name   : doLogin
	 *Purpose: Method to encode user credential to base64 encoding.
	 *Params : --
	 *Return : --
	 **/
	doLogin : function() {

		var username, password, credentials;
		username = $('#username').val();
		password = $('#password').val();
		environment = $('select#server option:selected').val();
		switch(environment) {
			case "dev":
				mHealth.env = mHealth.dev
				break;
			case "uat":
				mHealth.env = mHealth.uat
				break;
			case "prod":
				mHealth.env = mHealth.prod
				break;
			case "qa":
				mHealth.env = mHealth.uat
				break;
			default:
				mHealth.env = mHealth.dev
				break;

		}
		mHealth.util.participantEmail = username;
		$('#splash_message').hide();
		if((username != '') && (password != '')) {
			mHealth.util.showMask();
			credentials = $.base64Encode(username + ":" + password);
			this.service.authenticateUser(mHealth.env.authtoken_get_url, credentials, this.proxy(this.loginSuccess), this.proxy(this.loginFailure));
		} else {
			$('#splash_message').show();
			$('#splash_message').html('Enter the Username and password');
		}
		
	},
	/**
	 *Name   : recommendationSuccess
	 *Purpose: Success callback for getting home recommendation type.
	 *Params : output - response from the server.
	 *Return : --
	 **/

	recommendationSuccess : function(output) {		
		var response = output.responseText;
		var recommandationData = JSON.parse(response);
		var viewData = JSON.stringify(recommandationData.View);
		mHealth.models.ViewModel.customFromJSON(viewData);
		var assessment = mHealth.recommendation.createAssessment("20120101T141339.000 GMT", "20120101T141339.000 GMT", "");
		this.proxy(this.service.postRequest(mHealth.env.assessment_json_url, assessment, this.proxy(this.assessmentSuccess), this.proxy(this.assessmentFailure), true));
		this.proxy(this.service.getResponse(mHealth.env.medicaldevices_url, this.proxy(this.medicalSuccess), "", false));
		
		
	},
	/**
	 *Name   : medicalSuccess
	 *Purpose: Method on success of medical devices
	 *Return : --
	 **/
	medicalSuccess : function(output){
		var response = output.responseText;		
		devices = response;			
		mHealth.models.MedicalDevicesModel.customFromJSON(response);		
	},
	/**
	 *Name   : recommendationFailure
	 *Purpose: Failure callback for getting home recommendation type.
	 *Params : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server.
	 *Return : Alerts 'The service is not available'.
	 **/
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.customAlert("The service is not available","");
		mHealth.util.hideMask();

	},
	/**
	 *Name : assessmentSuccess
	 *Purpose: After getting the response from the assessment Service, the functon will parse the participant,assessment,section,question,answer and participantanswer
	 Set the value in the respective model.
	 *Params: output
	 *Return: null
	 **/
  assessmentSuccess : function(output) {
		var response, sectionData, participantData, assessmentData, questionData, answerData, participantAnswerData;
		response = output.responseText;
		assessmentsData = JSON.parse(response);		
		assessmentData = JSON.stringify(assessmentsData.Assessment);
		participantData = JSON.stringify(assessmentsData.Participant);				
		sectionData = assessmentsData.Section;
		questionData = assessmentsData.Question;
		answerData = assessmentsData.Answer;		
		mHealth.models.AssessmentModel.customFromJSON(assessmentData);
		mHealth.models.ParticipantAnswerModel.customFromJSON(participantData);
		// var assessData = mHealth.models.AssessmentModel.first();
		// assessData.
		// mHealth.models.SectionModel.customFromJSON(sectionData);
		// mHealth.models.QuestionModel.customFromJSON(questionData);
		// mHealth.models.AnswerModel.customFromJSON(answerData);		
		// mHealth.models.ParticipantModel.customFromJSON(participantData);
		this.getMiniAssessmentData(assessmentsData);
		
	},
   /**
	 *Name   : getMiniAssessmentData
	 *Purpose: Method to fetch the questions & answers for mini assessment
	 *Params : --
	 *Return : mini assessment questions & answers
	 **/

	getMiniAssessmentData : function(assessmentsData) {
		assessData = mHealth.models.AssessmentModel.findByAttribute("assessmentId", "Diabetes Mini Assessment");

		assessData.section = [];
		assessData.section.question = [];
		assessData.section.question.answer = [];
		assessmentsData.Section.map(function(section) {
			if(section.assessmentId == assessData.assessmentId) {
				assessData.section.push(mHealth.models.SectionModel.fromJSON(section));
				assessData.save();
			}
		});
		assessData.section.map(function(sectionmodel) {
			sectionmodel.question = [];
			assessmentsData.Question.map(function(question) {
				if(question.assessmentId === sectionmodel.assessmentId && question.sectionId === sectionmodel.sectionId) {
					sectionmodel.question.push(mHealth.models.QuestionModel.fromJSON(question));
					assessData.save();
				}
			});
		});
		assessData.section[0].question.map(function(question) {
			question.answer = [];
			assessmentsData.Answer.map(function(answer) {
				if(answer.assessmentId === question.assessmentId && answer.sectionId === question.sectionId && answer.questionId === question.questionId) {
					question.answer.push(mHealth.models.AnswerModel.fromJSON(answer));
					assessData.save();
				}
			});
		});
		outputHTML = mHealth.assessment.get_dropdown_html(assessData);		
		$.mobile.changePage("../../rootview/view/showassessment.html",{
			data : {
				loginWorkflow : "true"}
			});
		
	},
	/**
	 *Name    : showMiniAssessment
	 *Purpose : Method to render Mini assessment screen
	 *Params  : --
	 *Return  : --
	 **/
	showMiniAssessment : function() {		
		var currentPageURL = $('div[id = "showassessment"]').attr('data-url');
		var loginWorkflow = mHealth.util.getParameterByName('loginWorkflow', currentPageURL);		
		$('#showassessmentcontent').html(_.template($('#showassessmenttemplate').html(), { loginWorkflow : loginWorkflow }));		
		$('#showassessmentcontent').trigger('create');
		$('#showassessmentcontent1').html(_.template($('#showassessmenttemplate1').html(), { loginWorkflow : loginWorkflow }));		
		$('#showassessmentcontent1').trigger('create');
		$('#output').append(outputHTML);		
		$('#output').trigger('create');
		mHealth.util.hideMask();
	},
	
	
    		

	
	/**
	 *Name   : showHomePage
	 *Purpose: Method to call native bar on login
	 *Params : --
	 *Return : --
	 **/
	showHomePage : function(){		
		mHealth.util.callNativeBarEvent();
		$.mobile.changePage("../../home/view/home.html");	
	},
	
	/**
	 *Name   : submitAssessment
	 *Purpose: Method to submit mini assessment
	 *Params : --
	 *Return : --
	 **/
	submitAssessment: function(){	
		if(this.validateParticipantAnswer()){					
			var oForm = document.forms["assessmentform"];
			var questions = oForm.elements["form[dropdown]"];	
			var participantdatas = [];	
			var medicalDevices = JSON.parse(devices);		
			for(i=0; i< questions.length; i++){
					var questionId = document.getElementById('questionId['+i+']').value;
					var setQuestionId = questionId.replace(/\{|\}/gi,'');						
			 		assessData.section[0].question[i].answer.map(function(answer) {	
						if(setQuestionId === answer.answerId  ){				 			
				 			mHealth.controllers.LoginController.setMiniAssessmentData(answer);	 
			 			}	else{
			 				medicalDevices.map(function(device){			 															
								if(setQuestionId === device.sku){					 				
						 			mHealth.controllers.LoginController.setMiniAssessmentData(answer);				 			
						 		}			
							});
			 			}																			
					});	 		
			} 
		}  
	},	
	
	
    
	/**
	 *Name   : setProgressBar
	 *Purpose: Method to call progress bar 
	 *Params : --
	 *Return : --
	 **/
    setProgressBar : function()	{    		
		if(this.count == 0){
			if(document.getElementById("questionId[0]").value != "default" && this.count <= 0){
				this.updateProgressBar(1);			
				this.count++;	
			}else if(document.getElementById("questionId[1]").value != "default" && this.count <= 0){
				this.updateProgressBar(1);			
				this.count++;
			}else if(document.getElementById("questionId[2]").value != "default" && this.count <= 0){
				this.updateProgressBar(1);
				this.count++;
			}else{
				this.updateProgressBar(0);	
				if(this.count != 0){					
					this.count--;
				}
			}	
		}else if(this.count == 1){
			if(document.getElementById("questionId[0]").value != "default" && this.count <= 1){
				this.updateProgressBar(2);			
				this.count++;	
			}else if(document.getElementById("questionId[1]").value != "default" && this.count <= 1){
				this.updateProgressBar(2);			
				this.count++;
			} else if(document.getElementById("questionId[2]").value != "default" && this.count <= 1){
				this.updateProgressBar(2);
				this.count++;
			}else{
				this.updateProgressBar(0);
				if(this.count != 0){
					this.count--;
				}	
			}
		}else if(this.count == 2){
			if(document.getElementById("questionId[0]").value != "default" && this.count <= 2){
				this.updateProgressBar(3);								
			}else if(document.getElementById("questionId[1]").value != "default" && this.count <= 2){				
				this.updateProgressBar(3);						
			}else if(document.getElementById("questionId[2]").value != "default" && this.count <= 2){
				this.updateProgressBar(3);
			}else{
				this.updateProgressBar(0);	
				if(this.count != 0){
					this.count--;
				}
			}
		}
	},
	
	/**
	 *Name   : updateProgressBar
	 *Purpose: Method to update progress bar 
	 *Params : Number of question
	 *Return : --
	 **/
	updateProgressBar : function(numOfQues){		
		var numberQuestions = parseInt(numOfQues,10);		
		var numberDirtyQuestions = 3;
		var percent =  ( numberQuestions / numberDirtyQuestions) * 100;
		$('div.progress-bar').css( 'width', percent+'%'  );
		$('div.progress-bar-text').text(percent.toFixed(0)+'%');
	},
	
	
	/**
	 *Name   : validateParticipantAnswer
	 *Purpose: Method to validate Participant Answer 
	 *Params : Number of question
	 *Return : --
	 **/
	validateParticipantAnswer : function(){		
		var question1 = document.getElementById("questionId[0]").value;
		var question2 = document.getElementById("questionId[1]").value;
		var question3 = document.getElementById("questionId[2]").value;
		if(question1 == "default"){
			mHealth.util.customAlert("Please select the first question","");
			return false;
		}
		if(question2 == "default"){
			mHealth.util.customAlert("Please select the second question","");
			return false;
		}
		if(question3 == "default"){
			mHealth.util.customAlert("Please select the third question","");
			return false;
		}
		return true;
	},
	/**
	 *Name : assessmentFailure
	 *Purpose: On the Failure of the assessment service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	assessmentFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.customAlert("The service is not available","");
		mHealth.util.hideMask();
	}

});

mHealth.controllers.LoginController.extend({
		
		
		/**
		 *Name   : setMiniAssessmentData
		 *Purpose: Method to set the partcipant model and save the data
		 *Params : Response
		 *Return : --
		 **/		
		setMiniAssessmentData : function(response){ 	
                        var  requestData = [{
                               "participantId":response.participantId,
                               "assessmentId":response.assessmentId,
                               "sectionId":response.sectionId,
                               "questionId":response.questionId,
                               "answerId":response.answerId,                               
                               "language":response.language,
                               "answerValue":response.theAnswer, 
                               "createTimestamp":response.createTimestamp,
                               "updateTimestamp":(new Date()).format('yyyymmdd"T"HHMMss".000 GMT"'),                              
                               "dirty":'true',
                               "entryType":response.entryType,
                               "indicatorValue":response.indicatorValue                                
                             }];                              
                             var body = JSON.stringify(requestData);
                             var data = JSON.parse(body);                                                        
                             var service = mHealth.util.RemoteServiceProxy.getInstance();
                             var reqData = mHealth.recommendation.createAssessment("20120101T141339.000 GMT", "20120101T141339.000 GMT", data);                           
                             service.postRequest(mHealth.env.assessment_json_url, reqData, mHealth.controllers.LoginController.participantAnswerSuccess, mHealth.controllers.LoginController.participantAnswerFailure, true);
                             // var assessment = mHealth.recommendation.createAssessment("20120101T141339.000 GMT", "20120101T141339.000 GMT", "");
							 // service.postRequest(mHealth.env.assessment_json_url, assessment, mHealth.controllers.LoginController.participantAnswerSuccess, mHealth.controllers.LoginController.participantAnswerFailure, true);
    		},
    /**
	 *Name   : participantAnswerSuccess
	 *Purpose: Method on success on Participant answer submit 
	 *Params : Response
	 *Return : --
	 **/		
    participantAnswerSuccess : function(output) {    	
    	// var updateData = (new Date()).format('yyyymmdd"T"HHMMss".000 GMT"');
    	// var service = mHealth.util.RemoteServiceProxy.getInstance();
    	// var  requestData = [{
                               // "participantId":response.participantId,
                               // "assessmentId":response.assessmentId,
                               // "sectionId":response.sectionId,
                               // "questionId":response.questionId,
                               // "answerId":response.answerId,                               
                               // "language":response.language,
                               // "answerValue":response.theAnswer, 
                               // "createTimestamp":response.createTimestamp,
                               // "updateTimestamp":(new Date()).format('yyyymmdd"T"HHMMss".000 GMT"'),                              
                               // "dirty":'true',
                               // "entryType":response.entryType,
                               // "indicatorValue":response.indicatorValue                                
                             // }]; 
        // var data = mHealth.recommendation.createAssessment("20120101T141339.000 GMT", updateData, body);
    	// service.postRequest(mHealth.env.assessment_json_url, data, mHealth.controllers.LoginController.participantAnswerSuccess, mHealth.controllers.LoginController.participantAnswerFailure, true);
    	$.mobile.changePage("../../home/view/home.html");		
	},
	/**
	 *Name   : participantAnswerFailure
	 *Purpose: Method on failure on Participant answer submit 
	 *Params : Response
	 *Return : --
	 **/	
	participantAnswerFailure : function(jqXHR, textStatus, errorThrown) {				
		 $.mobile.changePage("../../home/view/home.html");			 
	}
});
