/**
 * Class : RemoteServiceProxy
 * Utility class for making ajax calls to the server.
 **/
mHealth.util.RemoteServiceProxy = Spine.Class.sub({
	/**
	 * Name    : init
	 * Purpose : Initialize the oontroller.
	 * Params  : --
	 * Returns : --
	 **/
	init : function() {
	},
	/**
	 * Name    : authenticateUser
	 * Purpose : Method to make service call for user authentication.
	 * Params  : url - The service url to call,
	 credentials - base64 encoded username and password combination.
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	authenticateUser : function(url, credentials, successCallback, errorCallback) {
		// $.mobile.showPageLoadingMsg();
		// mHealth.util.showMask();
		$.ajax({
			url : url,
			async : true,
			type : 'GET',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				if(environment == "dev") {
					mHealth.util.RemoteServiceProxy.alSecToken = jqXHR.getResponseHeader('Pragma');
				} else {
					mHealth.util.RemoteServiceProxy.alSecToken = jqXHR.getResponseHeader('ALSECTOKEN');
				}

				// $.mobile.hidePageLoadingMsg();
				// mHealth.util.hideMask();
				successCallback();
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				// $.mobile.hidePageLoadingMsg();
				// mHealth.util.hideMask();
				errorCallback(jqXHR, textStatus, errorThrown);
			},
			beforeSend : function(xhr) {
				xhr.withCredentials = true;
				xhr.setRequestHeader('Authorization', 'Basic ' + credentials);
               mHealth.util.customAlert(credentials, 'credentials');
               alert('credentials'+credentials);

			}
		});
	},
	/**
	 * Name    : getResponse
	 * Purpose : Method for making the GET request service call.
	 * Params  : url - The service url to call,
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	getResponse : function(url, successCallback, errorCallback, indicatorFlag) {

		// if(indicatorFlag === true) {
			// $.mobile.showPageLoadingMsg();
			// mHealth.util.showMask();
			// location.href = "tabbar://addMask?";
		// }
		$.ajax({
			url : url,
			async : true,
			type : 'GET',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				// if(indicatorFlag === true) {
					// $.mobile.hidePageLoadingMsg();
					// mHealth.util.hideMask();
					// location.href = "tabbar://removeMask?";
					successCallback(jqXHR);
				// } else {
					// successCallback(jqXHR);
				// }
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				if(errorThrown == mHealth.SettingsController.timeOut) {
					// if(indicatorFlag === true) {
					// $.mobile.hidePageLoadingMsg();
					// mHealth.util.hideMask();
					// location.href = "tabbar://removeMask?";
					//
					// }
					mHealth.util.customAlert(mHealth.SettingsController.errTimeout, '');
				} else if(indicatorFlag === true) {
					errorCallback(jqXHR, textStatus, errorThrown);
				}
				// } else if(indicatorFlag === true) {
				// mHealth.util.hideMask();
				// $.mobile.hidePageLoadingMsg();
				// location.href = "tabbar://removeMask?";

			},
			beforeSend : function(xhr) {
				xhr.setRequestHeader('ALSECTOKEN', mHealth.util.RemoteServiceProxy.alSecToken);
			}
		});
	},
	/**
	 * Name    : authenticateUser
	 * Purpose : Method for making the POST request service call
	 * Params  : url - The service url to call,
	 body - Request body to be sent to the server
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	postRequest : function(url, body, postSuccessCallback, errorCallback, indicatorFlag) {

		// if(indicatorFlag === true) {
		// $.mobile.showPageLoadingMsg();
		// mHealth.util.showMask();
		// location.href = "tabbar://addMask?";
		// }s
		$.ajax({
			url : url,
			async : true,
			data : body,
			type : 'POST',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				//				if(indicatorFlag === true) {
				//					location.href = "tabbar://removeMask?";
				//					$.mobile.hidePageLoadingMsg();
				//					mHealth.util.hideMask();
				postSuccessCallback(jqXHR);
				//				} else {
				//					postSuccessCallback(jqXHR);
				//				}

			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				if(errorThrown === mHealth.SettingsController.timeOut) {
					// if(indicatorFlag === true) {
					// mHealth.util.hideMask();
					// $.mobile.hidePageLoadingMsg();
					// location.href = "tabbar://removeMask?";
					//
					// }
					mHealth.util.customAlert(mHealth.SettingsController.errTimeout, '');

				} else if(indicatorFlag === true) {
					// mHealth.util.hideMask();
					// $.mobile.hidePageLoadingMsg();
					// location.href = "tabbar://removeMask?";
					errorCallback(jqXHR, textStatus, errorThrown);
				}
				//errorCallback(jqXHR, textStatus, errorThrown);
			},
			beforeSend : function(xhr) {
				xhr.setRequestHeader('ALSECTOKEN', mHealth.util.RemoteServiceProxy.alSecToken);
			}
		});
	}
});

mHealth.util.RemoteServiceProxy.extend({

	alSecToken : null,

	/**
	 * Name    : getInstance
	 * Purpose : Method to create Singleton object for RemoteServiceProxy class
	 * Params  : --
	 * Returns : --
	 **/
	getInstance : function() {

		if(mHealth.util.RemoteServiceProxy.instance == null) {

			mHealth.util.RemoteServiceProxy.instance = new mHealth.util.RemoteServiceProxy();
		}
		return mHealth.util.RemoteServiceProxy.instance;
	}
});
