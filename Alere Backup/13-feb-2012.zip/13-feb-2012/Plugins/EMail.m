//
//  EMail.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "EMail.h"

@implementation EMail
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    NSArray* keys=[parameters allKeys];
    NSLog(@"keys : %@",keys);
    NSString* toAddress=[parameters objectForKey:@"mailto"];
    
    NSString* subject=[parameters objectForKey:@"subject"];
    NSString* urlString=[NSString stringWithFormat:@"mailto:?to=%@&subject=%@",toAddress,subject];
		urlString=[urlString stringByAddingPercentEscapesUsingEncoding:NSStringEncodingConversionAllowLossy];
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlString]];

}
//if(rotated==YES)        
//         {
//            NSLog(@"rotating to portrait");
//            [app.viewController.view setCenter:CGPointMake(160, 240)];
//            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(0));
//            app.viewController.view.transform = cgCTM;
//            app.viewController.view.bounds = CGRectMake(0, 00, 320, 460);
//            rotated=NO;
//            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortrait];
//         }

@end
