/**
 * Object : recommendation
 * Recommendation default settings
 **/
mHealth.recommendation = {};

/**
 * Name    : RecommendationMapper
 * Purpose : Method to create request body for recommendation Service.
 * Params  : responseType -  recommendation type
 * Returns : bodyContent
 **/
mHealth.recommendation.RecommendationMapper = function(activityID, statusID, responseType) {

	var bodyContent = JSON.stringify([{
		"ActivityCount" : "",
		"AppName" : "Mobile Main",
		"RelatedActivityCount" : "",
		"Mode" : "",
		"ActivityID" : "",
		"StatusID" : "",
		"SessionID" : "1326387223",
		"ResponseType" : responseType,
		"EffectiveDate" : ""
	}]);

	return bodyContent;
};
/**
 * Name    : AssessmentMapper
 * Purpose : Method to create request body for Assessment Service.
 * Params  : starttoken, endToken, participantAnswer
 * Returns : bodyContent
 **/
mHealth.recommendation.AssessmentMapper = function(startToken, endToken, participantAnswer) {

	var bodyContent = JSON.stringify([{
		"StartToken" : startToken,
		"EndToken" : endToken,
		"ParticipantAnswerClientUpdates" : participantAnswer
	}]);
	return bodyContent;
};
/**
 * Name    : ChallengeMapper
 * Purpose : Method to create request body for Challenge Service.
 * Params  : starttoken, endToken, participantAnswer
 * Returns : bodyContent
 **/
mHealth.recommendation.ChallengeMapper = function(startToken, endToken, participantAnswer) {
	var bodyContent = JSON.stringify([{
		"StartToken" : startToken,
		"EndToken" : endToken,
		"SubActivityResponseClientUpdates" : participantAnswer
	}]);
	return bodyContent;
};
/**
 * Name    : EventMapper
 * Purpose : Method to create request body for Event Service.
 * Params  : activityId, statusId, responseType -  recommendation type
 * Returns : bodyContent
 **/
mHealth.recommendation.EventMapper = function(activityId, statusId, updateTime) {

	var bodyContent = JSON.stringify([{
		"activityId" : activityId,
		"status" : statusId,
		"date" : updateTime
	}]);
	return bodyContent;
};

/**
 * Name    : ParticipantMapper
 * Purpose : Method to create request body for Participant Service.
 * Params  : participantID, value
 * Returns : hDataObject
 **/
mHealth.recommendation.ParticipantMapper = function(participantID, value) {
	var measurementDate = (new Date()).format(mHealth.pegadateformat);
	var collectedDate = (new Date()).format(mHealth.pegadateformat);
	var hDataObject = [{
		"collectedDate" : collectedDate,
		"latitude" : "",
		"memberEligId" : participantID,
		"comments" : "",
		"measurementDate" : measurementDate,
		"appSource" : mHealth.appsource,
		"value" : value,
		"longitude" : "",
		"groupId" : "",
		"source" : "1"
	}];
	return JSON.stringify(hDataObject);
};

/**
 * Name    : ParticipantPostMapper
 * Purpose : Method to create request body for Participant Post Service.
 * Params  : preferredName, eMail
 * Returns : bodyContent
 **/
mHealth.recommendation.ParticipantPostMapper=function(preferredName,eMail){
	var bodyContent = JSON.stringify([{
			"preferredName" : preferredName,
			"emailAddress" : eMail
	}]);	
	return bodyContent;
};

mHealth.recommendation.HealthDataMapper = function(measurementDate, comments, value) {
	var collectedDate = (new Date()).format(mHealth.pegadateformat);
	var hDataObject = [{
		"collectedDate" : collectedDate,
		"latitude" : "",
		"comments" : comments,
		"measurementDate" : measurementDate,
		"appSource" : mHealth.appsource,
		"value" : value,
		"longitude" : "",
		"groupId" : "",
		"source" : "1"
	}];
	return JSON.stringify(hDataObject);
};
mHealth.recommendation.HealthDataTypeMapper = function(measurementDate, comments, value,healthDataType) {
	var hDataObject = [{
		"collectedDate" : measurementDate,
		"healthDataType": healthDataType,
		"latitude" : "",
		"comments" : comments,
		"measurementDate" : measurementDate,
		"appSource" : mHealth.appsource,
		"value" : value,
		"longitude" : "",
		"groupId" : "",
		"source" : "1"
	}];
	return JSON.stringify(hDataObject);
};
mHealth.recommendation.ConditionMapper = function(diagnosisDate, icd9Id) {
	
	var conditionObject = [{
		"diagnosisDate": diagnosisDate,
		"icd9Id" : icd9Id,
		"sourceId" : "1",
		"statusId" : "1",
	}];
	return JSON.stringify(conditionObject);
};
/**
 * Name    : ChallengePostMapper
 * Purpose : Method to create request body for Challenge Post Service.
 * Params  : assessmentName, measurementDate,questionResponse
 * Returns : requestData
 **/
mHealth.recommendation.ChallengePostMapper =function(assessmentName,measurementDate,questionResponse){
	var requestData = [{
		"ChallengeResponse" : {
			"ChallengeID" : assessmentName,
			"MemberEligId" : '',
			"MeasurementDate" : measurementDate,
			"Origin" : "Mobile",
			"QuestionResponse" : questionResponse
		}
	}];
	return JSON.stringify(requestData);
};
mHealth.recommendation.MessageArchiveMapper =function(){
	var requestData = { "updateType" :  "Archive"};
	return JSON.stringify(requestData);
};