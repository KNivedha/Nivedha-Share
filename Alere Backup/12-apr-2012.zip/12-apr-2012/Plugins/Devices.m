//
//  Devices.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Devices.h"
#import "AlereAppDelegate.h"
#import "AlereViewController.h"
@implementation Devices
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{ AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    UIDevice *myDevice=[UIDevice currentDevice];
    NSString* osversion=[myDevice systemVersion];
    NSString* deviceName=[myDevice name];
    NSString* udid=[myDevice uniqueIdentifier];
    NSString* osName=[myDevice systemName];
    NSString* devMake=@"Apple";
    NSString* devModel=[myDevice model];
    NSString* devCustomId= [NSString  stringWithFormat:@"%@%@", deviceName,osName];
    
    NSLog(@"********** osversion: %@ ,deviceName: %@ , udid: %@ ,osName: %@, devMake: %@, devModel: %@, devCustomId: %@", osversion, deviceName, udid, osName, devMake, devModel, devCustomId);
    
    [ app.viewController.webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"mHealth.controllers.SettingsController.getDevicesFeature([\"%@\"],[\"%@\"],[\"%@\"],[\"%@\"],[\"%@\"],[\"%@\"],[\"%@\"])",osversion, deviceName, udid, osName, devMake, devModel, devCustomId]];
}
@end
