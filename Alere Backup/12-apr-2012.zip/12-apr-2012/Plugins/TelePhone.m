//
//  TelePhone.m
//  Alere
//
//  Created by virtusa on 04/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TelePhone.h"

@implementation TelePhone
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    NSString* phoneUrl=@"tel://";
    phoneUrl=[NSString stringWithFormat:@"%@%@",phoneUrl,[parameters objectForKey:@"number"]];NSLog(@"%@",phoneUrl);
     [[UIApplication sharedApplication]openURL:[NSURL URLWithString:phoneUrl]];
}
@end
