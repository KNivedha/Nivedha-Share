

mHealth.controllers.HealthDataController=Spine.Controller.sub({
    healthdatatracker:'',
    trackerdata:'',                                                         
	el:'body',
    service : mHealth.util.RemoteServiceProxy.getInstance(),
	events :
	{
    'click #viewJournal' : 'getJournalData',
    //'pagebeforeshow #journal_page' :'showJournal',
    'click #viewGraph'      :  'getGraphData',  
	'pagebeforeshow #show_tracker_view'	: 'renderShowTrackerView',
	'pagebeforeshow #show_tracker_track'	: 'renderShowTrackerTrack',
	'click #track_save'	: 'saveTrackData',
    'click .tracker':'setTrackerType',
    'pagebeforeshow #show_journal' : 'renderJournalContenet'
	},
	
                             
    //Method to set Tracker Type
  	setTrackerType:function(e){
  		mHealth.controllers.HealthDataController.healthdatatracker=$(e.target).parents(".tracker").attr('name');
  	},
     
    //Method for calling HealthData Service                                                          
	//getJournalData:function(){
    //var journalServiceUrl;
    // var header;
    // header=ALSECTOKEN;
    //this.service.getResponse(mHealth.uat.healthdata_url, header);
    //this.processJournalData(response);                                       
    //},
    
    //Method for calling HealthData Service for plotting graph
    getGraphData:function(){
    var journalServiceUrl;
    var header;
    header=ALSECTOKEN;
    this.service.getResponse(mHealth.uat.healthdata_url, header);
    this.processGraphData(response);  
    },
    
    //Method to render the health data tracker Journal content
    renderJournalContent:function(){
    	var trackerType={"name":mHealth.controllers.HealthDataController.healthdatatracker};
    	$('#test1').html(_.template($('#healthDataList1').html(),{trackerdata : trackerdata,trackerType:trackerType}));
    	$('#weight_list1').listview();
    },
    
    //Method to rendering Show tracker page View content and header
    renderShowTrackerView:function(){
    var trackerType={"name":mHealth.controllers.HealthDataController.healthdatatracker};
    $('#trackviewcontent').html(_.template($('#trackerviewtemplate').html(),{trackerType : trackerType}));
    $('#headercontent').html(_.template($('#headertemplate').html(),{trackerType : trackerType}));
    $('#trackview_list').listview();
    $('#show_tracker_view').page('destroy').page();	
    },
    
    //Method for rendering the Show tracker track content
    renderShowTrackerTrack:function(){
    var trackerType={"name":mHealth.controllers.HealthDataController.healthdatatracker};
    $('#showtrackertrackcontent').html(_.template($('#showtrackertracktemplate').html(),{trackerType : trackerType}));
    $('input').textinput();
    $('textarea').textinput();
    },
    
    //Method to save the tracker new entry
    saveTrackData:function(){
    	if(validForm){
            var dateselected= $('#selectDate').val();
            var dateobject=new Date(dateselected.substr(0,4),(dateselected.substr(5,2)-1),dateselected.substr(8,2));
            var MeasurementDate=dateobject.format('yyyymmdd"T"HHMMss".000 GMT"');
            var CollectedDate=(new Date()).format('yyyymmdd"T"HHMMss".000 GMT"');
            var jsondata1=[{"collectedDate":CollectedDate,"latitude":"","comments":$('#comments').val(),"measurementDate":MeasurementDate,"appSource":"1","value":"","longitude":"","groupId":"","source":"1"}];
            var jsondata2=[{"collectedDate":CollectedDate,"latitude":"","comments":$('#comments').val(),"measurementDate":MeasurementDate,"appSource":"1","value":"","longitude":"","groupId":"","source":"1"}];
            //var tracker_url;
            if(mHealth.controllers.HealthDataController.healthdatatracker=="Weight and BMI")
            {
            	jsondata1[0].value=$('#value_Weight').val();
                jsondata2[0].value=$('#value_Bmi').val();
                this.service.postRequest((mHealth.uat.healthdata_url+"Weight"), JSON.stringify(jsondata1),this.trackerSaveSuccess, this.trackerSaveFailure);
	            //tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/Weight";
	            //this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
	           // alert(response);
	            //tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/BMI";
	            //this.service.postRequest(tracker_url,JSON.stringify(jsondata2));
	            this.service.postRequest((mHealth.uat.healthdata_url+"BMI"), JSON.stringify(jsondata2),this.trackerFinalSaveSuccess, this.trackerFinalSaveFailure);
	           // alert(response);
	          // this.getJournalData();
            }
            else if(mHealth.controllers.HealthDataController.healthdatatracker=="A1C")
            {
            	jsondata1[0].value=$('#value_A1C').val();
                //tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/A1C";
	            //this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
	            this.service.postRequest((mHealth.uat.healthdata_url+"A1C"), JSON.stringify(jsondata1),this.trackerFinalSaveSuccess, this.trackerFinalSaveFailure);
	          //  alert(response);
	          //  this.getJournalData();
            }
            else if(mHealth.controllers.HealthDataController.healthdatatracker=="Blood Glucose")
            {
                jsondata1[0].value=$('#value_Glucose').val();
                //tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/Bloodglucose";
	            //this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
	            this.service.postRequest((mHealth.uat.healthdata_url+"Bloodglucose"), JSON.stringify(jsondata1),this.trackerFinalSaveSuccess, this.trackerFinalSaveFailure);
	           // alert(response); 
	           // this.getJournalData();                                   
            }
            else if(mHealth.controllers.HealthDataController.healthdatatracker=="Blood Pressure")                                 
            {
                jsondata1[0].value=$('#value_Sys').val();
            	jsondata2[0].value=$('#value_Dia').val();
                //tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/BPS";
	            //this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
	            this.service.postRequest((mHealth.uat.healthdata_url+"BPS"), JSON.stringify(jsondata1),this.trackerSaveSuccess, this.trackerSaveFailure);
	           // alert(response);
	            //tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/BPD";
	            //this.service.postRequest(tracker_url,JSON.stringify(jsondata2));
	            this.service.postRequest((mHealth.uat.healthdata_url+"BPD"), JSON.stringify(jsondata2),this.trackerFinalSaveSuccess, this.trackerFinalSaveFailure);
	           // alert(response);
	           // this.getJournalData();
            }
            else if(mHealth.controllers.HealthDataController.healthdatatracker=="Cholesterol")
            {
              	jsondata1[0].value=$('#value_LDL').val();
		      	jsondata2[0].value=$('#value_HDL').val();
                var jsondata3=[{"collectedDate":CollectedDate,"latitude":"","comments":$('#comments').val(),"measurementDate":MeasurementDate,"appSource":"1","value":$('#value_Tri').val(),"longitude":"","groupId":"","source":"1"}];
	           	var jsondata4=[{"collectedDate":CollectedDate,"latitude":"","comments":$('#comments').val(),"measurementDate":MeasurementDate,"appSource":"1","value":$('#value_Cholesterol').val(),"longitude":"","groupId":"","source":"1"}];
	          	//tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/LDL";
	            //this.service.postRequest(tracker_url,JSON.stringify(jsondata1));
	            this.service.postRequest((mHealth.uat.healthdata_url+"LDL"), JSON.stringify(jsondata1),this.trackerSaveSuccess, this.trackerSaveFailure);
               // alert(response);
                //tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/HDL";
                //this.service.postRequest(tracker_url,JSON.stringify(jsondata2));
                this.service.postRequest((mHealth.uat.healthdata_url+"HDL"), JSON.stringify(jsondata2),this.trackerSaveSuccess, this.trackerSaveFailure);
               // alert(response);
                //tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/Triglycerides";
                //this.service.postRequest(tracker_url,JSON.stringify(jsondata3));
                this.service.postRequest((mHealth.uat.healthdata_url+"Triglycerides"), JSON.stringify(jsondata3),this.trackerSaveSuccess, this.trackerSaveFailure);
               // alert(response);
                //tracker_url="https://secure.uat.alerehealth.com:13086/api/healthdata/Cholesterol";
                //this.service.postRequest(tracker_url,JSON.stringify(jsondata4));
                this.service.postRequest((mHealth.uat.healthdata_url+"Cholesterol"), JSON.stringify(jsondata4),this.trackerFinalSaveSuccess, this.trackerFinalSaveFailure);
               // alert(response);
                //this.getJournalData();
         	 }
      	 }//else
                                              // $.mobile.changePage("../View/journal.html");
   },
   trackerSaveSuccess:function(){
   	//alert('save success');
   	
   },
   trackerFinalSaveSuccess:function(output){
   	var	response = output.responseText;
   	//alert('final success');
   	
   	mHealth.controllers.HealthDataController.getJournalData(mHealth.controllers.HealthDataController.healthdatatracker);
   	//this.proxy(this.getJournalData());
   },
   trackerSaveFailure:function(){
   	
   },
   trackerFinalSaveFailure:function(){
   //	alert('Data Not Available');
   },
   getJournalData:function(){
   	//alert('inside getJournalData 1111');
   	mHealth.controllers.HealthDataController.getJournalData(mHealth.controllers.HealthDataController.healthdatatracker)
   		
   		// this.service.getResponse(mHealth.uat.healthdata_url, ALSECTOKEN);
    			// //console.log(response);
    			// //responses = JSON.parse(response);
    			// //console.log(responses);
    			// var healthdataObjects=new Object();
    			// var temp;
    			// var trackertype;
    			// if(this.healthdatatracker=="BloodGlucose")
    				// trackertype="Bloodglucose";
    			// else
    				// trackertype="A1C";
    			// var responses=JSON.parse(response);
    			// var len=responses.length;
    			// alert(len);
    			// if(this.healthdatatracker=="A1C" || this.healthdatatracker=="Blood Glucose")
    			// {
	    			// var healthdata=[];
	    			// for(var i=0;i<len;i++){
	    				// if(responses[i].healthDataType==trackertype)
	    				// {
	    					// healthdata.push(responses[i]);
						// }
	    			// }
					// var keysarray=[];
					// for(var i in healthdata)
					// {
						// keysarray[i]=[];
						// keysarray[i][0]=healthdata[i]["measurementDate"];
						// keysarray[i][1]=i;
					// }
					// keysarray.sort();
// 					
					// var sorteddata=[];
					// for(var i in keysarray){
						// sorteddata.push(healthdata[keysarray[i][1]]);
					// }	    			
// 	    			
	    			// len=sorteddata.length;
	    			// for(var i=0;i<len;i++){
	    				// temp=new Object();
						// temp['measurementDate']=sorteddata[i]['measurementDate'];
						// temp['value']=sorteddata[i]['value'];
						// temp['comments']=sorteddata[i]['comments'];
						// //console.log(temp);
						// healthdataObjects[sorteddata[i].measurementDate]=temp;
	    			// }
// 	    			
// 	    			
// 	    			
	    			// //for(var i=0;i<len;i++){
	    			// //	if(responses[i].healthDataType==trackertype)
	    			// //	{
	    			// //		temp=new Object();
					// //		temp['measurementDate']=responses[i]['measurementDate'];
					// //		temp['value']=responses[i]['value'];
					// //		temp['comments']=responses[i]['comments'];
					// //		//console.log(temp);
					// //		healthdataObjects[responses[i].measurementDate]=temp;
					// //	}
	    			// //};
	    			// console.log(healthdataObjects);
	    			// this.trackerdata=healthdataObjects;
	    			// $.mobile.changePage('showjournal.html');
	   			// }
   				// else if(this.healthdatatracker=="Weight and BMI" || this.healthdatatracker=="Blood Pressure" || this.healthdatatracker=="Cholesterol"){
   					// var healthdata=[];
   					// var subhealthdatatypes=[];
   					// if(this.healthdatatracker=="Weight and BMI"){
   						// subhealthdatatypes=['Weight','BMI','',''];
   					// }
   					// else if(this.healthdatatracker=="Blood Pressure"){
   						// subhealthdatatypes=['BPS','BPD','',''];
   					// }
   					// else if(this.healthdatatracker=="Cholesterol"){
   						// subhealthdatatypes=['LDL','HDL','Cholesterol','Triglycerides'];
   					// }
// 
   					// var keydate;
   					// var child=new Object();
   					// var group=new Object();
   					// for(var i=0;i<len;i++){
						// if(responses[i].healthDataType==subhealthdatatypes[0] || responses[i].healthDataType==subhealthdatatypes[1] || responses[i].healthDataType==subhealthdatatypes[2] || responses[i].healthDataType==subhealthdatatypes[3]){
							// healthdata.push(responses[i]);
						// }
					// }
// 					
					// var keysarray=[];
					// for(var i in healthdata)
					// {
						// keysarray[i]=[];
						// keysarray[i][0]=healthdata[i]["measurementDate"];
						// keysarray[i][1]=i;
					// }
					// keysarray.sort();
// 					
					// var sorteddata=[];
					// for(var i in keysarray){
						// sorteddata.push(healthdata[keysarray[i][1]]);
					// }
					// console.log(sorteddata);
					// //alert(arr.length);
					// len=sorteddata.length;
					// for(var i=0;i<len;i++){
						// keydate=sorteddata[i].measurementDate;
						// //alert(keydate);
						// if(group.hasOwnProperty(keydate))
						// {
							// if(child['measurementDate']==keydate)
								// child[sorteddata[i].healthDataType]=sorteddata[i].value;
							// else
								// console('problem');
						// }
						// else
						// {	
							// child=new Object();
							// child['comments']=sorteddata[i].comments;
							// child['measurementDate']=sorteddata[i].measurementDate;
							// child[sorteddata[i].healthDataType]=sorteddata[i].value;	
						// }
						// group[keydate]=child;
					// }
					// console.log(group);
					// this.trackerdata=group;
					// $.mobile.changePage('showjournal.html');
   				// }
   },
                                                   
	init : function(){},
    
                                                             // To render the journal data
    //showJournal:function(){
                                                             
    //weightData = mHealth.models.HealthDataModel.all();                          
                                                   
    //$('#test').html(_.template($('#healthDataList').html(),{weightData : weightData}));
    //$('#weight_list').listview();
    
                                                             //using iscroll for scrolling the page
    //var myScroll;
    //myScroll = new iScroll('journalView', {
    // snap:true   
    //});
   //},
       // Processing the response from server and binding it with model
                
//    processJournalData:function(responseText){
//    var weightData;
//    var responseData;
//    responseData = JSON.parse(responseText);
//    for(i=0;i<responseData.length;i++){
//                                                  
//    //Binding the HealthDataValues for Weight and BMI in HealthData Model
//     if((responseData[i].healthDataType=='Weight')||(responseData[i].healthDataType=='BMI')){
//       mHealth.models.HealthDataModel.create({
//                                                                                  healthDataId: responseData[i].healthDataId,
//                                                                                  participantId:responseData[i].participantId,
//                                                                                  memberEligId :responseData[i].memberEligId,
//                                                                                  groupId :responseData[i].groupId,
//                                                                                  healthDataType: responseData[i].healthDataType,
//                                                                                  measurementDate :responseData[i].measurementDate,
//                                                                                  collectedDate :responseData[i].collectedDate,
//                                                                                  value :responseData[i].value,
//                                                                                  unit:responseData[i].unit,
//                                                                                  source :responseData[i].source,
//                                                                                  appSource :responseData[i].appSource,
//                                                                                  comments :responseData[i].comments,
//                                                                                  longitude :responseData[i].longitude,
//                                                                                  latitude:responseData[i].latitude,
//                                                                                  valueBMI:''
//                                                                                  });
//                                                   }
//                                                   }
//                                                   
//                                                    mHealth.models.HealthDataModel.select(function(record) {
//                                                                                  if(record.healthDataType == 'Weight')
//                                                                                  { 
//                                                                                  
//                                                                                   mHealth.models.HealthDataModel.select(function(recordb){
//                                                             if(recordb.healthDataType=='BMI'){
//                                                                                             
//                                                                 if(record.measurementDate==recordb.measurementDate){
//                                                                                                 
//                                                                                       var val = recordb.value;
//                                                                     record.updateAttributes({valueBMI:val});
//                                                                             }
//                                                                             
//                                                                             }
//                                                                             
//                                                                             });
//                                              }
//                                                                                  });
//                                                   
//                                                   
//                                                   
//                                                    mHealth.models.HealthDataModel.select(function(recordc){
//                                                                                  if(recordc.valueBMI==''){
//                                                                                  
//                                                                                  recordc.destroy();
//                                                                                  
//                                                                                  }
//                                                                                  
//                                                                                  });
//                                                   
//                                                   },
                                                   processGraphData:function(responseText){
                                                   
                                                   
                                                   var responseData;
                                                   responseData = JSON.parse(responseText);
                                                   
                                                   
                                                   for(i=0;i<responseData.length;i++){
                                                   //Binding the HealthDataValues for Weight and BMI in HealthData Model
                                                   if((responseData[i].healthDataType=='Bloodglucose')){
                                                   
                                                   
                                                    mHealth.models.HealthDataModel.create({
                                                                                  healthDataId: responseData[i].healthDataId,
                                                                                  participantId:responseData[i].participantId,
                                                                                  memberEligId :responseData[i].memberEligId,
                                                                                  groupId :responseData[i].groupId,
                                                                                  healthDataType: responseData[i].healthDataType,
                                                                                  measurementDate :responseData[i].measurementDate,
                                                                                  collectedDate :responseData[i].collectedDate,
                                                                                  value :responseData[i].value,
                                                                                  unit:responseData[i].unit,
                                                                                  source :responseData[i].source,
                                                                                  appSource :responseData[i].appSource,
                                                                                  comments :responseData[i].comments,
                                                                                  longitude :responseData[i].longitude,
                                                                                  latitude:responseData[i].latitude,
                                                                                  valueBMI:''
                                                                                  });
                                                   }
                                                   }
                                                   glucoseData = 
                                                    mHealth.models.HealthDataModel.select(function(record) {
                                                                                  if(record.healthDataType == "Bloodglucose")
                                                                                  {            
                                                                                  return record;
                                                                                  }
                                                                                  
                                                                                  });
                                                   
                                                   
                                                   
                                                
                                                   
                                                   }
});

mHealth.controllers.HealthDataController.extend({
	
	healthdatatracker : '',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	trackerdata:'', 
	
	getJournalData:function(healthdatatrackerName){
   	//alert('inside getJournalData 1234');
   	healthdatatracker = healthdatatrackerName;
   	//alert(healthdatatracker);
   	
   		this.service.getResponse(mHealth.uat.healthdata_url, ALSECTOKEN,this.trackerGetSuccess, this.trackerGetFailure);
    			//console.log(response);
    			//responses = JSON.parse(response);
    			//console.log(responses);
    			
   }
   ,
   
   trackerGetFailure:function(){
   	//alert('trackerGetFailure');
   },
   
   trackerGetSuccess:function(output){
			   //	alert('trackerGetSuccess');
			   	var	response = output.responseText;
			   	responses = JSON.parse(response);
			    console.log(responses);
		
   				var healthdataObjects=new Object();
    			var temp;
    			var trackertype;
    			if(healthdatatracker=="BloodGlucose")
    				trackertype="Bloodglucose";
    			else
    				trackertype="A1C";
    			var responses=JSON.parse(response);
    			var len=responses.length;
    			//alert(len);
    			if(healthdatatracker=="A1C" || healthdatatracker=="Blood Glucose")
    			{
	    			var healthdata=[];
	    			for(var i=0;i<len;i++){
	    				if(responses[i].healthDataType==trackertype)
	    				{
	    					healthdata.push(responses[i]);
						}
	    			}
					var keysarray=[];
					for(var i in healthdata)
					{
						keysarray[i]=[];
						keysarray[i][0]=healthdata[i]["measurementDate"];
						keysarray[i][1]=i;
					}
					keysarray.sort();
					
					var sorteddata=[];
					for(var i in keysarray){
						sorteddata.push(healthdata[keysarray[i][1]]);
					}	    			
	    			
	    			len=sorteddata.length;
	    			for(var i=0;i<len;i++){
	    				temp=new Object();
						temp['measurementDate']=sorteddata[i]['measurementDate'];
						temp['value']=sorteddata[i]['value'];
						temp['comments']=sorteddata[i]['comments'];
						//console.log(temp);
						healthdataObjects[sorteddata[i].measurementDate]=temp;
	    			}
	    			
	    			
	    			
	    			//for(var i=0;i<len;i++){
	    			//	if(responses[i].healthDataType==trackertype)
	    			//	{
	    			//		temp=new Object();
					//		temp['measurementDate']=responses[i]['measurementDate'];
					//		temp['value']=responses[i]['value'];
					//		temp['comments']=responses[i]['comments'];
					//		//console.log(temp);
					//		healthdataObjects[responses[i].measurementDate]=temp;
					//	}
	    			//};
	    			console.log(healthdataObjects);
	    			trackerdata=healthdataObjects;
	    			$.mobile.changePage('showjournal.html');
	   			}
   				else if(healthdatatracker=="Weight and BMI" || healthdatatracker=="Blood Pressure" || healthdatatracker=="Cholesterol"){
   					var healthdata=[];
   					var subhealthdatatypes=[];
   					if(healthdatatracker=="Weight and BMI"){
   						subhealthdatatypes=['Weight','BMI','',''];
   					}
   					else if(healthdatatracker=="Blood Pressure"){
   						subhealthdatatypes=['BPS','BPD','',''];
   					}
   					else if(healthdatatracker=="Cholesterol"){
   						subhealthdatatypes=['LDL','HDL','Cholesterol','Triglycerides'];
   					}

   					var keydate;
   					var child=new Object();
   					var group=new Object();
   					for(var i=0;i<len;i++){
						if(responses[i].healthDataType==subhealthdatatypes[0] || responses[i].healthDataType==subhealthdatatypes[1] || responses[i].healthDataType==subhealthdatatypes[2] || responses[i].healthDataType==subhealthdatatypes[3]){
							healthdata.push(responses[i]);
						}
					}
					
					var keysarray=[];
					for(var i in healthdata)
					{
						keysarray[i]=[];
						keysarray[i][0]=healthdata[i]["measurementDate"];
						keysarray[i][1]=i;
					}
					keysarray.sort();
					
					var sorteddata=[];
					for(var i in keysarray){
						sorteddata.push(healthdata[keysarray[i][1]]);
					}
					console.log(sorteddata);
					//alert(arr.length);
					len=sorteddata.length;
					for(var i=0;i<len;i++){
						keydate=sorteddata[i].measurementDate;
						//alert(keydate);
						if(group.hasOwnProperty(keydate))
						{
							if(child['measurementDate']==keydate)
								child[sorteddata[i].healthDataType]=sorteddata[i].value;
							else
								console('problem');
						}
						else
						{	
							child=new Object();
							child['comments']=sorteddata[i].comments;
							child['measurementDate']=sorteddata[i].measurementDate;
							child[sorteddata[i].healthDataType]=sorteddata[i].value;	
						}
						group[keydate]=child;
					}
					console.log(group);
					trackerdata=group;
					$.mobile.changePage('showjournal.html');
   				}
   	
   }
	
	
	
});
                            
