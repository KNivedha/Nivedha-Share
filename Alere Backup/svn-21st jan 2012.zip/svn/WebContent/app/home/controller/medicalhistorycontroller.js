/*
@name
medicalHistoryController

@purpose
Medical history navigation
Medical history data processing
Medical history service call
*/
mHealth.controllers.MedicalHistoryController = Spine.Controller.sub({
el: 'body',
elements: {
'#condition_history': 'con_hist'
},
service : mHealth.util.RemoteServiceProxy.getInstance(),

events: {
'click #condition_history': 'getCondition',
'click #index_prev': 'setPrev',
'click #con_save': 'saveCondition',
'click #con_update': 'updateCondition',
'pagebeforeshow #condition_index': 'showCondition',
'pagebeforeshow #add_condition': 'addCondition',
'pagebeforeshow #editCondition': 'editCondition',
'click .search_name': 'addConditionDetails',
'click #condition': 'getSubCondition',
'pagebeforeshow #condition_search': 'showSubCondition',
'click .edit': 'editConditionDetails'
},



/*
conditionindex.html
@purpose
updates condition after it has been edited by the user 

*/
updateCondition: function () {

editconval = $('#conditionName').val();
mHealth.models.ConditionModel.each(function (record) {
                                   if (record.conditionName === editconval) {
                                   
                                   recordupdt = record;
                                   
                                   
                                   }
                                   
                                   
                                   });



recordupdt.fromForm('#confirm_condition').save();



var dateObject=new Date(recordupdt.diagnosisDate.substr(6,4),recordupdt.diagnosisDate.substr(0,2)-1,recordupdt.diagnosisDate.substr(3,2)); 

recordupdt.updateAttributes({diagnosisDate: dateObject.format("yyyy-mm-dd")});

var body = JSON.stringify([recordupdt]);



this.service.postRequest(mHealth.uat.condition_url, body, this.postSuccess, this.postError);


},



postSuccess:function(output){
var response = output.responseText;
$.mobile.changePage('conditionindex.html');

},

postError:function (jqXHR, textStatus, errorThrown) {
alert("Information not available");
}, 






/*

@purpose
sets the values of the fields present in confirmCondition.html

*/

editCondition: function () {

trimmedConditionName = renderConditionName.replace(/^\s+|\s+$/g, '');

trimmedDate = renderDate.replace(/^\s+|\s+$/g, '');

$('#conditionName').val(trimmedConditionName);
$('#diagnosisDate').val(trimmedDate);





},


/*@purpose
gets the value of the available conditions
navigates to the confirmCondition.html page
*/

editConditionDetails: function (e) {
item = e.target;
renderConditionName = $(item).parents().children('div[id="conditionname"]').text();
renderDate = $(item).parents().children('div[id="diagnosisdate"]').text();
$.mobile.changePage('confirmcondition.html');
},

/*
@purpose
saves  a new condition
*/
saveCondition: function () {

var recIcd9Id = '';

var recSubConditionName = '';

if (mHealth.controllers.MedicalHistoryController.prev !== 'condition_index') {

if (mHealth.controllers.MedicalHistoryController.flagShow === true) {

sub_condition_selected = $('select#subcondition option:selected').val();
sub_Conditions = renderRecord.SubCondition

for (i = 0; i < sub_Conditions.length; i++) {

if (sub_Conditions[i].subConditionName === sub_condition_selected) {
recIcd9Id = sub_Conditions[i].icd9Id;

recSubConditionName = sub_Conditions[i].subConditionName;

}

}

} else {
recIcd9Id = renderRecord.icd9Id;

recSubConditionName = '';


}
} else {
recIcd9Id = '';

recSubConditionName = '';
}

var dateObject=new Date($('#dt').val().substr(6,4),$('#dt').val().substr(0,2)-1,$('#dt').val().substr(3,2)); 

var dateValue = dateObject.format("yyyy-mm-dd");



var conditionRecord = new mHealth.models.ConditionModel({
                                                        
                                                        participantId: '',
                                                        memberEligId: '',
                                                        participantConditionId: '',
                                                        icd9Id: recIcd9Id,
                                                        conditionName: renderRecord.conditionName,
                                                        subConditionName: recSubConditionName,
                                                        diagnosisDate: dateValue,
                                                        conditionComment: '',
                                                        statusId: '',
                                                        sourceId: '',
                                                        applicationId: ''
                                                        
                                                        
                                                        
                                                        
                                                        });

if (!conditionRecord.save()) {
msg = conditionRecord.validate();
alert(msg);
} else {
var keys = ['participantId', 'memberEligId', 'participantConditionId', 'icd9Id', 'conditionName', 'subConditionName', 'diagnosisDate', 'conditionComment', 'statusId', 'sourceId', 'applicationId'];

var body = JSON.stringify([conditionRecord], keys);

this.service.postRequest(mHealth.uat.condition_url, body, this.postSuccess, this.postError);


}





},

setPrev: function () {
mHealth.controllers.MedicalHistoryController.flagShow = false;
mHealth.controllers.MedicalHistoryController.prev = "condition_index";




},




addConditionDetails: function (e) {
mHealth.controllers.MedicalHistoryController.prev = "condition_search"
n = $(e.target);
b = n.html();


mHealth.models.SearchConditionModel.each(function (record) {
                                         if (record.conditionName === b) {
                                         
                                         
                                         if (_.isEmpty(record.SubCondition)) {
                                         mHealth.controllers.MedicalHistoryController.flagShow = false;
                                         } else {
                                         mHealth.controllers.MedicalHistoryController.flagShow = true;
                                         
                                         }
                                         renderRecord = record;
                                         
                                         }
                                         
                                         
                                         
                                         
                                         
                                         
                                         });


},



/*

Calling service for authentication.
Encoding user credentials to base64 encoding
*/
getCondition: function () {
var modelCount = mHealth.models.ConditionModel.count();
if (modelCount === 0) {


var header;

header = ALSECTOKEN;

this.service.getResponse(mHealth.uat.condition_url, header,this.conditionSuccess,this.conditionError);


}
else
{
$.mobile.changePage("../view/conditionindex.html");
}
},

subConditionSuccess:function(output){



var response = output.responseText;                

mHealth.controllers.MedicalHistoryController.saveSubCondition(response);
$.mobile.changePage("../view/conditionsearch.html");




},
conditionSuccess: function (output) {

var response = output.responseText;                
//var conditions = new mHealth.controllers.MedicalHistoryController
mHealth.controllers.MedicalHistoryController.processConditionData(response);
$.mobile.changePage("../view/conditionindex.html");
},



conditionError: function (jqXHR, textStatus, errorThrown) {
alert("Information not available");
}, 


showCondition: function () {


var conditionData = mHealth.models.ConditionModel.select(function(record){
                                                         
                                                         
                                                         
                                                         if(record.statusId==='1'){
                                                         
                                                         
                                                         
                                                         return record;
                                                         
                                                         }
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         
                                                         });


$('#condition_div').html(_.template($('#conditionDataList').html(), {
                                    conditionData: conditionData
                                    }));
$('#condition_list').listview();
},

addCondition: function () {

$('#dt').val(mHealth.util.getCurrentDate());

if (mHealth.controllers.MedicalHistoryController.flagShow === true) {

$('#subconditiondiv').show();
$('#con_div').html(_.template($('#con_script').html(), {
                              renderRecord: renderRecord
                              }));
$('#con').textinput();
sub_condition = renderRecord.SubCondition;
$('#subconditiondiv').html(_.template($('#subcon_script').html(), {
                                      sub_condition: sub_condition
                                      }));
$('#subcondition').selectmenu();

}
if (mHealth.controllers.MedicalHistoryController.flagShow === false) {
if (mHealth.controllers.MedicalHistoryController.prev === 'condition_index') {



renderRecord = '';
renderRecord.conditionName = '';



}


$('#subconditiondiv').hide();
$('#con_div').html(_.template($('#con_script').html(), {
                              renderRecord: renderRecord
                              }));
$('#con').textinput();

}




},

getSubCondition: function () {
                                                                    
                                                                    
                                                                    


                                                                    var modelCount = mHealth.models.SearchConditionModel.count();
                                                                    if (modelCount === 0) {

var header;

header = ALSECTOKEN;


this.service.getResponse(mHealth.uat.searchcondition_url, header, this.subConditionSuccess,this.conditionError);

                                                                    }
                                                                    else{
                                                                    $.mobile.changePage("../view/conditionsearch.html");
                                                                    
                                                                    
                                                                    }
                                                                    



},



showSubCondition: function () {

searchConditionData = mHealth.models.SearchConditionModel.all();

$('#search_div').html(_.template($('#search_script').html(), {
                                 searchConditionData: searchConditionData
                                 }));
$('#search_ul').listview();


},





init: function () {}
});

mHealth.controllers.MedicalHistoryController.extend({

flagShow: false,
prev: '',
processConditionData: function (responseText) {


var responseData;
responseData = JSON.parse(responseText);

for (i = 0; i < responseData.length; i++) {

mHealth.models.ConditionModel.create({
                     participantId: responseData[i].participantId,
                     memberEligId: responseData[i].memberEligId,
                     participantConditionId: responseData[i].participantConditionId,
                     icd9Id: responseData[i].icd9Id,
                     conditionName: responseData[i].conditionName,
                     subConditionName: responseData[i].subConditionName,
                     diagnosisDate: responseData[i].diagnosisDate,
                     conditionComment: responseData[i].conditionComment,
                     statusId: responseData[i].statusId,
                     sourceId: responseData[i].sourceId,
                     applicationId: responseData[i].applicationId
                     
                     });

}




},

saveSubCondition: function (response) {

responseObject = JSON.parse(response);
for (i = 0; i < responseObject.length; i++) {
mHealth.models.SearchConditionModel.create({
                           conditionName: responseObject[i].conditionName,
                           icd9Id: responseObject[i].icd9Id,
                           SubCondition: responseObject[i].SubCondition
                           
                           
                           
                           
                           });



}




}







});