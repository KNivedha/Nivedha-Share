mHealth.controllers.SettingsController=Spine.Controller.sub({
                        el:'body',
                        elements:
                        {

                        },
                        service : mHealth.util.RemoteServiceProxy.getInstance(),
                        events :
                        {
                                'click #logout_id' : 'doLogout',
                                'click #showabout' :'getFeatures',
                                'click #sendfb' : 'callEmail',
                                 'pagebeforeshow #aboutsDetail' :'renderDetail'

                        },
                        

                        doLogout : function()
                        {  
                            jConfirm('Are you sure to logout', 'Logout', function(r){
                                if(r){
     //                                mHealth.models.AnswerModel.destroyAll();
     //                                mHealth.models.ParticipantAnswerModel.destroyAll();
                                       mHealth.models.ConditionModel.destroyAll();
                                       mHealth.models.MedicationModel.destroyAll();
                                       mHealth.models.ParticipantModel.destroyAll();
     //                                mHealth.models.SpaceModel.destroyAll();
     //                                mHealth.models.ViewModel.destroyAll();
     //                                mHealth.models.ZoneModel.destroyAll();
                                       mHealth.models.HealthDataModel.destroyAll();
                                       $.mobile.changePage("../../rootview/view/login.html");
                                            location.href="mHealth?eventname=logOut";
                                       }                                    
                               });
                          
                        },
                                                            
            renderDetail:function()
            {
                                                                       
            $('#aboutDevices').html(_.template($('#deviceDetails').html(),{deviceinfo:deviceinfo}));
            $('#aboutsDetail').trigger('create'); 

            },
                getFeatures:function()
                {
                location.href="mHealth?eventName=getDeviceFeatures";
                },
                callEmail :function()
                {
                location.href="mHealth?eventName=sendMail&mailto=corpfeedback@alere.com&subject=Alere+mHealth"
                }
                });
mHealth.controllers.SettingsController.extend({
              getDevicesFeature : function(device,osversion){
              mHealth.util.osversion=osversion;
              mHealth.util.device=device;
          deviceinfo=[{'reguser':mHealth.util.participantemail,
                      'version':'2.5.4',
                      'platform':'APPLE',
                      'devname':mHealth.util.device,
                      'devmodel':mHealth.util.osversion}];
                                              //alert(deviceinfo[0]);
                                              
               //$.mobile.changePage("../../settings/view/about.html");                      
              }
              });
