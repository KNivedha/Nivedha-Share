mHealth.controllers.ActivityController=Spine.Controller.sub({
el:'body',
                                                                                                                                            service : mHealth.util.RemoteServiceProxy.getInstance(),
events :
{

'click #activity' : 'getActivity' ,
                    'pagebeforeshow #showActivity' : 'showView'                                                         
},

showView : function()
{

$('#activityTitle').text(activity[0].space[0].title); 

if(activity[0].zone.length > 1 )
{
$('#activity_zone').show();
$('#activity_zone').html(_.template($('#navDataList').html(),activity[0].zone));
}
$('#activity_div').html(_.template($('#activityDataList').html(),activity[0].view));
$('#showActivity').trigger('create');
},
                    getActivity : function()
                    {
                    
                    var decision = mHealth.models.SpaceViewZoneModel.each(function(record){
                    
                    if(record.pageName==='Activity'){
                    
                    return true;
                    
                    }
                    
                    });
                    
                    if(decision===true){
                    
                    $.mobile.changePage('../../activities/view/showactivity.html');
                    
                    }
                    else{
                    
                    var body=JSON.stringify([{"ActivityCount":"","AppName":"Mobile Main","RelatedActivityCount":"","Mode":"","ActivityID":"","StatusID":"","SessionID":"1326387223","ResponseType":"1003","EffectiveDate":""}]);
                    
                    this.service.postRequest(mHealth.uat.recommendation_json_url,body,this.recommendationSuccess,this.recommendationFailure);

                    
                    
                    }
                    
                    
                    
                    
                                                                                                                                            },
                                                                                init:function(){},
recommendationSuccess: function(output){
var	response = output.responseText;
                    
                var recommandationData=JSON.parse(response);
var spaceData =JSON.stringify(recommandationData.Space);
var zoneData =JSON.stringify(recommandationData.Zone);
var viewData =JSON.stringify(recommandationData.View);
                    
                    var spaceviewzone = new mHealth.models.SpaceViewZoneModel({
                    
                    pageName:'Activity',
                    space:mHealth.models.SpaceModel.fromJSON(spaceData),
                    view:mHealth.models.ViewModel.fromJSON(viewData),
                    zone:mHealth.models.ZoneModel.fromJSON(zoneData)
                    
                    
                    });
                    
                    
                    
                    
                    
                    
                    spaceviewzone.save();
                    
                    
                    activity = mHealth.models.SpaceViewZoneModel.each(function(record){
                    
                    if(record.pageName==='Activity'){
                    return record;
                    }
                    });
                    
                    
                    

     
$.mobile.changePage('../../activities/view/showactivity.html');
},
recommendationFailure: function(jqXHR, textStatus, errorThrown){

}



});