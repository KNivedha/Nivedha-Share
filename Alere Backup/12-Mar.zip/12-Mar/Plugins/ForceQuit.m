//
//  ForceQuit.m
//  Alere
//
//  Created by Nivedha Kaliaperumal on 2/27/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "ForceQuit.h"
#import "AlereAppDelegate.h"
#import "AlereViewController.h"
@implementation ForceQuit

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action

{
     if([action isEqualToString:@"Accepted"]) 
     {
         NSArray *paths = NSSearchPathForDirectoriesInDomains
         (NSDocumentDirectory, NSUserDomainMask, YES);
         NSString *documentsDirectory = [paths objectAtIndex:0];
         
         //make a file name to write the data to using the documents directory:
         NSString *fileName = [NSString stringWithFormat:@"%@/textfile.txt", 
                               documentsDirectory];
        
         BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:fileName];
         if (!fileExists) {
                 NSString *content = @"Yes";
                 //save content to the documents directory
                 [content writeToFile:fileName 
                           atomically:NO 
                            encoding:NSStringEncodingConversionAllowLossy 
                               error:nil];

         }
//         AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
//         
//         app.viewController.webView.scrollView.scrollEnabled = YES; 
         
     }
}
@end
