/**
 * Controller : SettingsController
 * Controller to do logic of settings
 **/
mHealth.controllers.DebugController = Spine.Controller.sub({
	el : 'body',
    assetID : null,
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
        'click #clientCode' : 'clientRegistration',
        'click #dummyVideo' : 'openVideo',
        'click #alfArticle' : 'getAlfrescoArticle',
        'pagebeforeshow #alfrescoDIV' : 'preloadAlfresco',
        'click #brightcove' : 'openVideo',
        'click #brightcoveAlere' : 'openAlereVideo',
        'click .video' : 'parseVideo',
        'click .healthArticle' : 'parseArticle'
    },
    
    parseVideo : function(event){
        
        var target = event.target || event.srcElement
        if (target.href){
            var targetValue = target.href;
            var videoId = targetValue.substring(3, targetValue.length);
            assetID = videoId;
            $.mobile.changePage('../../debug/view/'+assetID+'.html',{role:'dialog'});
            
            event.preventDefault();
        } else {
            mHealth.util.customAlert("No url found to navigate", '');	
            // HMM CHECK YOUR ID ON WHICH YOU ARE TRIGGERING THE EVENT
        }    
        
    },
    parseArticle : function(event){
        var target = event.target || event.srcElement
        if (target.href){
            var targetValue = target.href;
            var articleId = targetValue.substring(3, targetValue.length);
            //alert("ARTICLE : "+articleId);
            
            assetID = articleId;
            $.mobile.changePage('../../debug/view/alfrescocontainer.html',{role:'dialog'});
            
        } else {
            mHealth.util.customAlert("No url found to navigate", '');	
            // HMM CHECK YOUR ID ON WHICH YOU ARE TRIGGERING THE EVENT
        }   
        
    },
    
    
    clientRegistration : function (event){
        var target = event.target || event.srcElement
        if (target.href){
            
            //alert("Trying to open "+target.href);
            target.href = 'http://google.com';
            window.open(target.href, '_blank');
            //window.open(target.href, '_blank');
            //event.preventDefault();
        } else {
            mHealth.util.customAlert("No url found to navigate", '');	
        }
    },
    openVideo : function (event){
        $.mobile.changePage('../../debug/view/dummyvideo.html');
    },
    
    //This function preloads the contents into an IFRAME which is defined in alfrescocontainer.html
    //
    preloadAlfresco : function(){
        $('#iframePage').html('<iframe width="100%" height="100%" src="http://secure.uat.alerehealth.com:13085/api/health-articles/hwMCnt?id=healthwise://'+assetID+'" ></iframe>');
        $('#iframePage').trigger('create');
    },
    
    /*
     This function is been called on clicked of the link on debug and it just redirects it to 
     alfrescocontainer.html which has some blank divs which are been populated in preloadAlfresco
     */
    getAlfrescoArticle : function(){
        //$.mobile.changePage('../../debug/view/alfrescocontainer.html');
    },
    
    //
    openVideo : function(){
        //alert("In OPEN VIDEO");
        $.mobile.changePage('../../debug/view/brightcove.html');
    },
    //
    openAlereVideo : function(){
        //alert("In OPEN ALERE VIDEO");
        $.mobile.changePage('../../debug/view/brightcoveAlere.html');
    }
    
    
});

mHealth.controllers.DebugController.extend({
    
    
});
