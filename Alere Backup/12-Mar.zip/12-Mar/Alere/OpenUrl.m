//
//  OpenUrl.m
//  Alere
//
//  Created by virtusa on 09/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OpenUrl.h"

@implementation OpenUrl
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
//    NSLog(@"values is %@",action);
//    NSString* urlValue=[[action componentsSeparatedByString:@"://"]objectAtIndex:2] ;
//    NSString* urlString= [NSString stringWithFormat:@"http://%@",urlValue];
//    NSString* actionValue=[[[[action componentsSeparatedByString:@"://"]objectAtIndex:1]componentsSeparatedByString:@"?"]objectAtIndex:0] ;
//    
    
       [[UIApplication sharedApplication]openURL:[NSURL URLWithString:action  ]];
   
}
@end
