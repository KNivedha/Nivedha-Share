//
//  TabBar.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TabBar.h"
#import "AlereAppDelegate.h"
#import "TabBarController.h"
#import "AlereViewController.h"

@implementation TabBar
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
     AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    if ([action isEqualToString:@"login"] )  
    {
      if ( !app.viewController.login)
      {
        UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];
        if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
            app.viewController.webView.frame=CGRectMake(0,0,320,414);
        }
        if (interfaceOrientation==UIInterfaceOrientationLandscapeRight||interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
            app.viewController.webView.frame=CGRectMake(0,0,480,260);
        }
        app.viewController.baseTabBar.hidden=NO;
        UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:0];
        app.viewController.baseTabBar.selectedItem=homeTab;
        app.viewController.login=YES;
        [app.viewController resetAppIdleTimer];
        webViewFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:app.viewController action:@selector(handleTapOnWebView)];
		webViewFingerTap.delegate=app.viewController;
          tabBarFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:app.viewController action:@selector(handleTapOnWebView)];
          tabBarFingerTap.delegate=app.viewController;

       [app.viewController.webView addGestureRecognizer:webViewFingerTap];
    // [app.viewController.baseTabBar addGestureRecognizer:tabBarFingerTap];
       [UIApplication sharedApplication].idleTimerDisabled=YES;
        [app.viewController resetAppIdleTimer];
      }
    }
   else if ([action isEqualToString:@"logout"] )
    {
        [[UIApplication sharedApplication]setStatusBarHidden:NO];

		  app.viewController.baseTabBar.userInteractionEnabled=YES;

        UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];

        if (interfaceOrientation==UIInterfaceOrientationPortrait) {
             app.viewController.view.frame=CGRectMake(0,20,320,460);
            app.viewController.webView.frame=CGRectMake(0,0,320,460);
        }
        if (interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
            app.viewController.view.frame=CGRectMake(0,00,320,460);
            app.viewController.webView.frame=CGRectMake(0,0,320,460);
        }
        if (interfaceOrientation==UIInterfaceOrientationLandscapeRight) {
              app.viewController.view.frame=CGRectMake(0,0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);
        }   
        else  if (interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
            app.viewController.view.frame=CGRectMake(20,0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);
        }   
        app.viewController.baseTabBar.hidden=YES;  
        app.viewController.login=NO;
        [app.viewController cancelTimer];
        [app.viewController.webView removeGestureRecognizer:webViewFingerTap];
        // [app.viewController.baseTabBar removeGestureRecognizer:tabBarFingerTap];
        [webViewFingerTap release];
    }
    if ([action isEqualToString:@"showTabBar"] )  
    {
        
        {
            UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];
            if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
                app.viewController.webView.frame=CGRectMake(0,0,320,414);
            }
            if (interfaceOrientation==UIInterfaceOrientationLandscapeRight||interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
                app.viewController.webView.frame=CGRectMake(0,0,480,260);
            }
            app.viewController.baseTabBar.hidden=NO;
            //UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:0];
            //app.viewController.baseTabBar.selectedItem=homeTab;
            // app.viewController.login=YES;
            // [app.viewController resetAppIdleTimer];
            // webViewFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:app.viewController action:@selector(handleTapOnWebView)];
            // webViewFingerTap.delegate=app.viewController;
            // tabBarFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:app.viewController action:@selector(handleTapOnWebView)];
            // tabBarFingerTap.delegate=app.viewController;
            
            //[app.viewController.webView addGestureRecognizer:webViewFingerTap];
            // [app.viewController.baseTabBar addGestureRecognizer:tabBarFingerTap];
            //[UIApplication sharedApplication].idleTimerDisabled=YES;
            //[app.viewController resetAppIdleTimer];
        }
    }
    else if ([action isEqualToString:@"hideTabBar"] )
    {
        [[UIApplication sharedApplication]setStatusBarHidden:NO];
        
        app.viewController.baseTabBar.userInteractionEnabled=YES;
        
        UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];
        
        if (interfaceOrientation==UIInterfaceOrientationPortrait) {
            app.viewController.view.frame=CGRectMake(0,20,320,460);
            app.viewController.webView.frame=CGRectMake(0,0,320,460);
        }
        if (interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
            app.viewController.view.frame=CGRectMake(0,00,320,460);
            app.viewController.webView.frame=CGRectMake(0,0,320,460);
        }
        if (interfaceOrientation==UIInterfaceOrientationLandscapeRight) {
            app.viewController.view.frame=CGRectMake(0,0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);
        }   
        else  if (interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
            app.viewController.view.frame=CGRectMake(20,0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);
        }   
        app.viewController.baseTabBar.hidden=YES;  
        // app.viewController.login=NO;
        // [app.viewController cancelTimer];
        // [app.viewController.webView removeGestureRecognizer:webViewFingerTap];
        // [app.viewController.baseTabBar removeGestureRecognizer:tabBarFingerTap];
        // [webViewFingerTap release];
    }
    

		else if ([action isEqualToString:@"loadHome"] )
    {
	  app.viewController.baseTabBar.userInteractionEnabled=YES;
					 	 app.viewController.webView.userInteractionEnabled=YES;
       UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:0];
       app.viewController.baseTabBar.selectedItem=homeTab;
    }
    else if ([action isEqualToString:@"loadTrackers"] )
    {
	  app.viewController.baseTabBar.userInteractionEnabled=YES;
      app.viewController.webView.userInteractionEnabled=YES;
       UITabBarItem *trackersTab=[[app.viewController.baseTabBar items]objectAtIndex:2];
       app.viewController.baseTabBar.selectedItem=trackersTab;
    }
	 else if ([action isEqualToString:@"loadActivities"] )
   {
	  app.viewController.baseTabBar.userInteractionEnabled=YES;
					 	 app.viewController.webView.userInteractionEnabled=YES;
       UITabBarItem *activitiesTab=[[app.viewController.baseTabBar items]objectAtIndex:2];
       app.viewController.baseTabBar.selectedItem=activitiesTab;
   }
	  else if ([action isEqualToString:@"loadMessages"] )
   {
	  app.viewController.baseTabBar.userInteractionEnabled=YES;
					 	 app.viewController.webView.userInteractionEnabled=YES;
       UITabBarItem *messagesTab=[[app.viewController.baseTabBar items]objectAtIndex:1];
       app.viewController.baseTabBar.selectedItem=messagesTab;
   }
	 
	 else if ([action isEqualToString:@"addMask"] )
   {
	         app.viewController.baseTabBar.userInteractionEnabled=YES;
		  
	     app.viewController.baseTabBar.userInteractionEnabled=NO;
		
			 //flag="true";
   }
	 else if ([action isEqualToString:@"removeMask"] )
   {
	 //if flag="true";
           app.viewController.baseTabBar.userInteractionEnabled=YES;
		
						 //flag="false";
   }
    
    if([action isEqualToString:@"Accepted"]) 
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains
        (NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        
        //make a file name to write the data to using the documents directory:
        NSString *fileName = [NSString stringWithFormat:@"%@/textfile.txt", 
                              documentsDirectory];
        
        BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:fileName];
        if (!fileExists) {
            NSString *content = @"Yes";
            //save content to the documents directory
            [content writeToFile:fileName 
                      atomically:NO 
                        encoding:NSStringEncodingConversionAllowLossy 
                           error:nil];
            
        }
        
        
    }

	 

} 
//UIDevice* myDevice=[UIDevice currentDevice];
//w[myDevice beginGeneratingDeviceOrientationNotifications];
@end
