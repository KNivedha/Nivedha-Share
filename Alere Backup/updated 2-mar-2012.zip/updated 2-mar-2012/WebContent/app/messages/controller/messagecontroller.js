/**
 * Controller : MessageController
 * This is the controller to do the  logic of message
 **/
mHealth.controllers.MessageController = Spine.Controller.sub({
	el : 'body',
	elements : {},

	tabbarloaded : false,

	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		'pagebeforeshow #home' : 'showMessages',
		'click #messageCenter' : 'loadMessageTab',
		'click #displayMessage' : 'loadMessage',
		'pagebeforeshow #detailMessage' : 'renderMessage',
		'pagebeforeshow #showMessage' : 'getMessages',
		'click #submitButton' : 'submitAssessment'
	},
	/**
	 * Name    : messageSuccess
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	messageSuccess : function(output) {
		var response = output.responseText;
		var bundleMessage = JSON.parse(response);
		var messages = JSON.stringify(bundleMessage[0].Message);
		mHealth.models.MessageModel.customFromJSON(messages);
		$.mobile.changePage("../../home/view/home.html");
		mHealth.HealthDataControllerObject.loadTrackerData();
	},
	/**
	 * Name    : showHome
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	showHome : function() {
		$.mobile.changePage("../../home/view/home.html");
		mHealth.HealthDataControllerObject.loadTrackerData();
	},
	/**
	 * Name    : messageServiceFailure
	 * Purpose : Method on failure of message header service
	 * Params  : output
	 * Return  : --
	 **/
	messageServiceFailure : function() {
		$.mobile.changePage("../../home/view/home.html");
		mHealth.util.hideMask();
	},
	/**
	 * Name    : showMessages
	 * Purpose : Load the message from the Model and Show the Result in the Message Center of the Home Tab
	 * Params  : --
	 * Return  : --
	 **/
	showMessages : function() {
		var len = mHealth.models.MessageModel.count();
		var messages_val = mHealth.models.MessageModel.all();
		if(len > 0) {
			$('#messages_div').html(_.template($('#messageList').html(), {
				messages_val : messages_val
			}));
			$('#home').trigger('create');
		} else {
			var message = "There are no messages for you to view at this time.";
			$('#messages_div').text(message);
		}

		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}
	},
	/**
	 * Name    : loadMessage
	 * Purpose : Calls webservice to get message details page
	 * Params  : --
	 * Return  : --
	 **/
	loadMessage : function(event) {
		var eventTarget = event.target;
		var messageID = $(eventTarget).parents().children('input[type="hidden"]').val();
		var URL = mHealth.env.messagedetails_url + messageID;
		this.proxy(this.service.getResponse(URL, mHealth.MessageControllerObject.displayMessage, mHealth.MessageControllerObject.loadMessageTab1, true));
	},
	/**
	 * Name    : displayMessage
	 * Purpose : Loads message details in to model
	 * Params  : --
	 * Return  : --
	 **/
	displayMessage : function(output) {
		var response = output.responseText;

		var messageResponse = JSON.stringify(response);
		var messagesData = JSON.parse(messageResponse);

		mHealth.models.MessageDetailsModel.customFromJSON(messagesData);

		mHealth.models.MessageDetailsModel.each(function(message) {
			var sectionData = message.cachedPersonalizedMessage.messageContent.sections.section;
			if(sectionData) {
				var questionnaireData = sectionData[0].questionnaire;
				if(questionnaireData) {
					mHealth.models.QuestionnaireModel.customFromJSON(questionnaireData);
					mHealth.models.QuestionnaireModel.each(function(questionnaire) {
						var groupQuestion = questionnaire.qGroups.qGroup;
						mHealth.models.QuestionGroupModel.customFromJSON(groupQuestion);
						mHealth.models.QuestionGroupModel.each(function(questionnaire) {
							var questions = questionnaire.questions.question;
							mHealth.models.MessageQuestionModel.customFromJSON(questions);
						});
					});
				}
			}
		});


		$.mobile.changePage("../../messages/view/displaymessage.html");
	},
	/**
	 *Name   : submitAssessment
	 *Purpose: Method to submit mini assessment
	 *Params : --
	 *Return : --
	 **/
	submitAssessment : function() {
		//if(this.validateParticipantAnswer()) {
		//	$.mobile.changePage("../../home/view/home.html");
		var oForm = document.forms["messageform"];
		var answers = oForm.elements["form[dropdown]"];
		var questions = oForm.elements["form[questions]"];
		var requestData = {
			"saveUserFeedbackRequest" : {
				"transactionID" : 1234,
				"userFeedback" : {
					"messageID" : 9999
				}
			}
		};
		var messagesDetails = mHealth.models.MessageDetailsResponse.first();
		requestData.saveUserFeedbackRequest.transactionID = (messagesDetails.transactionID);
		requestData.saveUserFeedbackRequest.userFeedback.messageID = messagesDetails.message.messageID;
		var questionResponse = new Array();
		for( i = 0; i < answers.length; i++) {
			var questionId;
			if(document.getElementById('answerId[' + i + ']')) {
				var answerId = document.getElementById('answerId[' + i + ']').value;
			}
			var setAnswerId = answerId.replace(/\{|\}/gi, '');
			if(document.getElementById('question[' + i + ']')) {
				questionId = document.getElementById('question[' + i + ']').value;
			}
			var simpleQuestionResponse = {};
			var questionResponseMap = {};
			var simpleQuestionResponse = {};
			simpleQuestionResponse["answer"] = setAnswerId;
			simpleQuestionResponse["question"] = questionId;
			questionResponseMap["simpleQuestionResponse"] = simpleQuestionResponse;
			questionResponse.push(questionResponseMap);
		}
		var questionResponseMap = {};
		questionResponseMap["questionResponse"] = questionResponse;
		requestData.saveUserFeedbackRequest.userFeedback['questionResponses'] = questionResponseMap;
		alert("Yoour record has been saved successfully."+JSON.stringify(requestData));
		//}
	},
	/**
	 *Name   : validateParticipantAnswer
	 *Purpose: Method to validate Participant Answer
	 *Params : Number of question
	 *Return : --
	 **/
	validateParticipantAnswer : function() {
		var question1 = document.getElementById("questionId[0]").value;
		var question2 = document.getElementById("questionId[1]").value;
		var question3 = document.getElementById("questionId[2]").value;
		if(question1 == "default" && question2 == "default" && question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidAssessment, '', false);
			return false;
		}
		if(question1 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidFirstQuesAssessment, '', false);
			return false;
		}
		if(question2 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidSecondQuesAssessment, '', false);
			return false;
		}
		if(question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidThirdQuesAssessment, '', false);
			return false;
		}
		return true;
	},
	/**
	 * Name    : loadMessageTab1
	 * Purpose : To deal webservice failure scenario
	 * Params  : --
	 * Return  : --
	 **/
	loadMessageTab1 : function() {
		$.mobile.changePage("../../messages/view/showmessage.html");
		location.href = "tabbar://loadMessages?";
	},
	/**
	 * Name    : renderMessage
	 * Purpose : Method to render data on html page
	 * Params  : --
	 * Return  : --
	 **/
	renderMessage : function() {
		var len = mHealth.models.MessageQuestionModel.count();

		if(len > 0) {
			var messageType = 1;
			mHealth.models.MessageDetailsModel.each(function(message) {
				messageType = message.msgTypeID;
			})
			
			
		var displayViewMessages = "";
		   switch(messageType) {
	       		case "1":
					displayViewMessages = mHealth.assessment.generate_assesment("", "");
					break;
	            case "2":
					displayViewMessages = mHealth.assessment.generate_messageDetailsHtml("", "");	
					break;	
	        }
			
			
			mHealth.models.MessageQuestionModel.destroyAll();
			mHealth.models.QuestionGroupModel.destroyAll();
			mHealth.models.QuestionnaireModel.destroyAll();
			mHealth.models.MessageDetailsModel.destroyAll();
			
			$('#messagedetails').append(displayViewMessages);
			// $('#answerId').scroller({
			// dateFormat : 'yyyy-mm-dd',
			// preset : 'datetime',
			// seconds : true,
			// timeFormat : 'hh:ii:ss A',
			// theme : 'ios',
			// beforeShow : function(input, inst){
			// nativeCommunication.callNativeMethod("tabbar://addMask?");
			//
			// },
			// onClose:function(valueText, inst){
			// nativeCommunication.callNativeMethod("tabbar://removeMask?");
			// },
			// onCancel:function(valueText, inst){
			//
			// nativeCommunication.callNativeMethod("tabbar://removeMask?");
			// }
			// });
		} else {
			var message = "There are no details messages for you to view at this time.";
			$('#messagedetails').text(message);
		}
		$('#messagedetails').trigger('create');
		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}
	},
	/**
	 * Name    : getMessages
	 * Purpose : Load the message from the Model and Show the Result in the  Message Tab
	 * Params  : --
	 * Return  : --
	 **/
	getMessages : function() {
		var len = mHealth.models.MessageModel.count();
		var messages_val = mHealth.models.MessageModel.all();
		if(len < 0) {
			messages_val = "There are no messages for you to view at this time.";
		}
		$('#message').html(_.template($('#messageList1').html(), {
			messages_val : messages_val
		}));
		$('#showMessage').trigger('create');
	},
	/**
	 * Name    : loadMessageTab
	 * Purpose : Highlight the Message when we redirect the shorcut from the Home to message TAB.
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageTab : function() {
		$.mobile.changePage("../../messages/view/showmessage.html");
		location.href = "tabbar://loadMessages?";
	}
});
