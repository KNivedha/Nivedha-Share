//
//  TabBar.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TabBar.h"
#import "AlereAppDelegate.h"

@implementation TabBar
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    NSArray* keys=[parameters allKeys];
    NSString* value=[parameters objectForKey:[keys objectAtIndex:0]];
    if ([action isEqualToString:@"login"] )  
    {
        AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
        [app loadTabBar];
    }

   else if ([action isEqualToString:@"logout"] )
    {
        NSLog(@"logout in viewcontroler");
        AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
        [app logout];
    }
} 
@end
