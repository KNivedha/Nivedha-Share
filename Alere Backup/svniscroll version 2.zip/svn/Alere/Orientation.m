//
//  Orientation.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Orientation.h"
#import "AlereAppDelegate.h"
#import "TabBarController.h"
#import "OrientationConstants.h"
@implementation Orientation
#define DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) / 180.0 * M_PI)
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    
    AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    NSArray* keys=[parameters allKeys];
    NSString* value=[parameters objectForKey:[keys objectAtIndex:0]];
    if( [value isEqualToString:@"startRotation"])       
    {
       
        NSLog(@"start rotated method");
        UIInterfaceOrientation orientation =(UIInterfaceOrientation) [[UIDevice currentDevice] orientation];
        if (orientation==UIDeviceOrientationPortrait||orientation==UIDeviceOrientationPortraitUpsideDown) 
        {
            //app.tabBarController.rotated=YES;
            [OrientationConstants setRotated:YES];
            NSLog(@"rotating to landscape");
            [ app.tabBarController.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(-90));
            app.tabBarController.view.transform = cgCTM;
            app.tabBarController.view.bounds = CGRectMake(0, 20, 480, 320);
        }
        else
        {
           //app.tabBarController.landscp=YES;
            [OrientationConstants setLandscp:YES];
            
        }
    }
    else if( [value isEqualToString:@"stopRotation"])       
    {
        if([OrientationConstants rotated]==YES) //(app.tabBarController.rotated==YES) 
        {
            NSLog(@"rotating to portrait");
            [ app.tabBarController.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(0));
            app.tabBarController.view.transform = cgCTM;
            app.tabBarController.view.bounds = CGRectMake(0, 20, 320, 480);
           // app.tabBarController.rotated=NO;
            [OrientationConstants setRotated:NO];
        }
        else
        {
            // app.tabBarController.landscp=NO;
            [OrientationConstants setLandscp:NO];
        }
        
    }

}
@end
