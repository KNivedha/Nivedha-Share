//
//  AlereViewController.h
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Calendar.h"
#import "EMail.h"
#import "Devices.h"
#import "TabBar.h"
#import "Orientation.h"
@protocol DeviceDelegate; 

@interface AlereViewController : UIViewController <UIWebViewDelegate>
{
    IBOutlet UIWebView* webView;
    NSMutableData* responseData;
    NSString* token;
    NSString* eventname;
    BOOL landscp;
    BOOL returnType;
    BOOL rotated;
    Calendar* calObj;
    EMail* emailObj;
    Devices* deviceObj;
    Orientation* orientationObj;
    TabBar* tabBarObj;
    NSMutableDictionary* pluginObjects;
    
    
    
   // UIInterfaceOrientation orientation;
    BOOL cameBack;
    
}
@property(nonatomic,retain) IBOutlet UIWebView* webView;
@property(nonatomic)BOOL rotated;
@property(nonatomic)BOOL landscp;
@property(nonatomic)BOOL insideTabBar;

//-(void)setCalendarEvent:(NSMutableArray*)params;
//-(void)callNumber:(NSMutableArray*)number;
//-(void)startRotation;
//-(void)stopRotation;
//-(void)loadTabBar;

@end

