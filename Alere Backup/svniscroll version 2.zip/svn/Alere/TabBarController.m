//
//  TabBarController.m
//  Alere
//
//  Created by virtusa5 on 18/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TabBarController.h"

@implementation TabBarController
@synthesize rotated,landscp,alereViewController,tabBar;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    tabBar.delegate=self;
    //tabBar.view.frame=CGRectMake(0, 0, 320, 480);
    [self.view addSubview:tabBar.view];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    NSLog(@"selected %d",[tabBarController selectedIndex]);
    NSString* callBackFunction;
    switch ([tabBarController selectedIndex])
    {
        case 0:
            callBackFunction=@"loadHome()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
        case 1:
            callBackFunction=@"loadMessages()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
        case 2:
            callBackFunction=@"loadActivities()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
        case 3:
            callBackFunction=@"loadTrackers()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
        case 4:
            callBackFunction=@"loadSettings()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
    }
    [viewController setView:alereViewController.view];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    
    
    if ( [OrientationConstants rotated]== YES) {
        return NO;
    }
    if ([OrientationConstants landscp] ==YES) {
        return NO;
    }
    
    return YES;
    // Return YES for supported orientations
   
}

@end
