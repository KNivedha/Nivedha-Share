//
//  TabBarController.h
//  Alere
//
//  Created by virtusa5 on 18/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OrientationConstants.h"
#import "AlereViewController.h"
#import "OrientationConstants.h"

@interface TabBarController : UIViewController<UITabBarControllerDelegate>
{
  IBOutlet  AlereViewController* alereViewController;
  IBOutlet UITabBarController* tabBar ;
    BOOL rotated;
}
@property(nonatomic)BOOL rotated;
@property(nonatomic)BOOL landscp;
@property(nonatomic,assign)IBOutlet UITabBarController* tabBar ;
@property(nonatomic,assign)IBOutlet  AlereViewController* alereViewController;
-(void)setRotated:(BOOL)rotated;
@end
