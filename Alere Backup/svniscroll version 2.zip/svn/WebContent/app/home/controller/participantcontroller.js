/**
 * Controller :Participant controller
 * Logic for profile is added here
 **/

mHealth.controllers.ParticipantController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #showProfile' : 'getProfileData',
		'click #saveProfile' : 'saveProfileData',
		'pagebeforeshow #profilePage' : 'showProfileData',
		'pageshow #profilePage' : 'processData'
	},

	/**
	 *Name: getProfileData
	 *Purpose: get the response for profile
	 **/

	getProfileData : function() {
		var modelCount = mHealth.models.ParticipantModel.count();
		if(modelCount === 0) {
			this.service.getResponse(mHealth.uat.message_get_url, null, this.proxy(this.participantSuccess), this.proxy(this.participantFailure));
		} else {
			$.mobile.changePage("../../home/view/profile.html");
		}
	},
	/**
	 *Name: participantSuccess
	 *Purpose: Success callback method of Service call
	 **/

	participantSuccess : function(output) {
		var response = output.responseText;
		this.proxy(this.processProfileData(response));
		$.mobile.changePage("../../home/view/profile.html");
	},
	/**
	 *Name: participantFailure
	 *Purpose: Failure callback method of Service call
	 **/

	participantFailure : function(jqXHR, textStatus, errorThrown) {
		alert("Information not available");
	},
	/**
	 *Name: showProfileData
	 *Purpose: Method to show the profile data
	 Rendering the data with the help of underscore
	 **/

	showProfileData : function() {
		var participantData = mHealth.models.ParticipantModel.all();
		$('#profiles').html(_.template($('#participantList').html(), {
			participantData : participantData
		}));
		$('#profilePage').trigger('create');
	},
	/**
	 *Name: saveProfileData
	 *Purpose:  Method to save profile data
	 Updating the participant model with preferred name and height attributes
	 **/

	saveProfileData : function() {
		var participantData = mHealth.models.ParticipantModel.first();
		participantData.updateAttributes({
			preferredName : $("#preferredName").val(),
			height : $('select#height option:selected').val()
		});
		mHealth.index = $('select#height option:selected').val();
		$.mobile.changePage("home.html");
	},
	/**
	 *Name: processData
	 *Purpose:  Method to process height units from settings controller
	 **/

	processData : function() {
		var index = "30";
		// default height
		if(mHealth.util.selUnits == undefined || 'ft-inch') {
			if(mHealth.index != undefined || "") {
				setHeight('ft-inch', (mHealth.index - 36));
			} else {
				setHeight('ft-inch', index);
			}
		}
		if(mHealth.util.selUnits == "cm") {
			if(mHealth.index1 != undefined || "") {
				setHeight('cm', (mHealth.index - 36));
			} else {
				setHeight('cm', index);
			}
		}
	},
	/**
	 *Name: processProfileData
	 *Purpose:  Method for process response from service
	 Binding the response from the service to participant model
	 **/

	processProfileData : function(response) {
		if(response !== '') {
			var data = JSON.parse(response);
			var participant = JSON.stringify(data);
			mHealth.models.ParticipantModel.customFromJSON(participant);

		}
	}
});
