mHealth.models.ParticipantModel = Spine.Model.sub();
mHealth.models.ParticipantModel.configure("ParticipantModel",'participantID','message','programName','memberEligID','preferredName','lastName','dateOfBirth','gender','height','emailAddress','firstName','createTimestamp','loggedIn','username','alsectoken','transactionID','contentBody');
