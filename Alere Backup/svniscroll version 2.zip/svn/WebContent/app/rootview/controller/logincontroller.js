mHealth.controllers.LoginController = Spine.Controller.sub({
	el : 'body',
	elements : {
		'#name' : 'uname',
		'#password' : 'pwd'
	},
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	proxied : ['recommendationSuccess'],
	events : {
		'click #loginbutton' : 'callLogin',
		'click #sendMail' : 'callMail'
	},
	callEmail : function() {
		location.href = "email://?sendEmail?mailto=service.desk@alere.com&subject="
	},
	loginSuccess : function(output) {

		var body = JSON.stringify([{
			"ActivityCount" : "",
			"AppName" : "Mobile Main",
			"RelatedActivityCount" : "",
			"Mode" : "",
			"ActivityID" : "",
			"StatusID" : "",
			"SessionID" : "1326387223",
			"ResponseType" : "1020",
			"EffectiveDate" : ""
		}]);

		var newService = mHealth.util.RemoteServiceProxy.getInstance();
		//           var obj = new mHealth.controllers.LoginController;
		newService.postRequest(mHealth.uat.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.recommendationFailure));

	},
	loginFailure : function(jqXHR, textStatus, errorThrown) {

		$('#splash_message').show();
		if(errorThrown == 'Unauthorized') {
			$('#splash_message').html('Invalid login credentials.');
		} else {

			$('#splash_message').html('An error occurred while communicating with the server.');

		}
	},
	/*
	 Calling service for authentication.
	 Encoding user credentials to base64 encoding
	 */

	callLogin : function() {

		var username = this.uname.val();
		var password = this.pwd.val();
		mHealth.util.participantemail = username;
		$('#splash_message').hide();
		if((username != '') && (password != '')) {
			var loginServiceUrl;
			var credentials;
			/* The Username and Password has to be converted to base64 Enocede using the below Line*/
			credentials = $.base64Encode(username + ":" + password);
			/* The Service Call for the authentication of the token */
			this.service.authenticateUser(mHealth.uat.authtoken_get_url, null, credentials, this.proxy(this.loginSuccess), this.proxy(this.loginFailure));
		} else {
			$('#splash_message').show();
			$('#splash_message').html('Enter the Username and password');
		}
	},
	recommendationSuccess : function(output) {

		//    var response = output.responseText;
		//
		//    responseData = JSON.parse(response);
		//    _.map(responseData, function (value, key) {
		//
		//          });

		$.mobile.changePage("../../home/view/home.html");
		//location.href = "tabbar://?login";
	},
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {

		alert('The Service is not available');
	}
});
