// Todo : Namespace everything
// All ajax calls to the server are done here.
mHealth.util.RemoteServiceProxy = Spine.Class.sub({
	init : function() {
	},
	/*
	 @params
	 url : The service url to call.
	 header : Initially null.
	 credentials : base64 encoded user credentials.
	 @purpose
	 Service call for user authentication.*/
	authenticateUser : function(url, header, credentials, successCallback, errorCallback) {
		$.mobile.showPageLoadingMsg();
		$.ajax({
			url : url,
			async : true,
			type : 'GET',
			success : function(output, textStatus, jqXHR) {
				ALSECTOKEN = jqXHR.getResponseHeader('ALSECTOKEN');
				$.mobile.hidePageLoadingMsg();
				successCallback();
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				$.mobile.hidePageLoadingMsg();
				errorCallback(jqXHR, textStatus, errorThrown);
			},
			beforeSend : function(xhr) {
				xhr.withCredentials = true;
				xhr.setRequestHeader('Authorization', 'Basic ' + credentials);
				xhr.setRequestHeader('ssl_verify_peer', 'false');
			}
		});
	},
	/*
	 @params
	 url : The service url to call.
	 header : Alsectoken to be passed as header.
	 @purpose
	 Service call for getting response data from server.
	 */
	getResponse : function(url, header, successCallback, errorCallback) {
		$.mobile.showPageLoadingMsg();
		$.ajax({
			url : url,
			async : true,
			type : 'GET',
			success : function(output, textStatus, jqXHR) {
				$.mobile.hidePageLoadingMsg();
				successCallback(jqXHR);
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				$.mobile.hidePageLoadingMsg();
				errorCallback(jqXHR, textStatus, errorThrown);
			},
			beforeSend : function(xhr) {
				xhr.setRequestHeader('ALSECTOKEN', ALSECTOKEN);
			}
		});
	},
	postRequest : function(url, body, postSuccessCallback, errorCallback) {
		$.mobile.showPageLoadingMsg();

		var request = $.ajax({
			url : url,
			async : true,
			data : body,
			type : 'POST',
			success : function(output, textStatus, jqXHR) {
				$.mobile.hidePageLoadingMsg();
				postSuccessCallback(jqXHR);
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				$.mobile.hidePageLoadingMsg();

				errorCallback(jqXHR, textStatus, errorThrown);
			},
			beforeSend : function(xhr) {

				xhr.setRequestHeader('ALSECTOKEN', ALSECTOKEN);
			}
		});
	}
});
mHealth.util.RemoteServiceProxy.extend({

	/* This method is to create Singleton object for RemoteServiceProxy class*/
	getInstance : function() {
		if(mHealth.util.RemoteServiceProxy.instance == null) {
			mHealth.util.RemoteServiceProxy.instance = new mHealth.util.RemoteServiceProxy();
		}
		return mHealth.util.RemoteServiceProxy.instance;
	}
});
