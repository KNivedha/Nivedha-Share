       
       /**
        <script type="text/javascript" src="../../utilities/tabhelper.js"></script>
        **/
        loadHome =function(){
            // alert("load home");
            $.mobile.changePage("../../home/view/home.html");
        },
        
        /**  
         Method to call Activities web view
         on clicking the activities tab
         **/  
        loadActivities=function(){

        // mHealth.controllers.ActivityController.getActivity();
},
        /**  
         Method to call Messages web view
         on clicking the messages tab
         **/  
        loadMessages =function(){
        
        },
        /**  
         Method to call trackers web view
         on clicking the trackers tab
         **/  
        loadTrackers =function(){
           // alert("load tracker");
           // location.href="../../trackers/view/showtracker.html";
       $.mobile.changePage("../../trackers/view/showtracker.html");
        },
        /**  
         Method to call setings web view
         on clicking the settings tab
         **/  
        loadSettings =function(){
        $.mobile.changePage("../../settings/view/index.html");
        }

