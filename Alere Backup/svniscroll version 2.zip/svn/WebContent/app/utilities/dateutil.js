mHealth.util.parseUTC = function(date){
var year = date.substring(0,4);
var mon = date.substring(4,6);
var day = date.substring(6,8);
var hr = date.substring(9,11);
var min = date.substring(11,13);
var sec = date.substring(13,15);

var d = new Date(year, mon, day, hr, min, sec);
var dstring = d.getMonth()+'/'+d.getDate()+'/'+d.getFullYear()+' '+d.toLocaleTimeString();
return dstring;
},
mHealth.util.getCurrentDate = function(date)
{
today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; 

var yyyy = today.getFullYear();
if(dd<10){dd='0'+dd} if(mm<10){mm='0'+mm}  today = mm+'/'+dd+'/'+yyyy;
return today;
}
