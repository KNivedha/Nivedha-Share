//
//  Calendar.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Calendar.h"
#import <EventKit/EventKit.h>
@implementation Calendar
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    NSArray* keys=[parameters allKeys];
    NSDate *startdate ;
    NSDate *enddate ;
    
    //***********setting date format*********
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"yyyy-MM-dd"];
    
    //*********** setting event store*********
    
    EKEventStore *eventStore = [[EKEventStore alloc] init];
    
    //************adding events****************
    EKEvent *event  = [EKEvent eventWithEventStore:eventStore];
    
    event.title =[parameters objectForKey:[keys objectAtIndex:0]] ;
    startdate =[dateFormatter dateFromString:[keys objectAtIndex:1]];
	enddate = [dateFormatter dateFromString:[keys objectAtIndex:2]];
    NSLog(@"storing in calander %@ sring : %@",enddate,startdate);
    event.startDate =  startdate;
    event.endDate   = enddate;
    
    [event setCalendar:[eventStore defaultCalendarForNewEvents]];
    
    NSError *err;
    [eventStore saveEvent:event span:EKSpanThisEvent error:&err];  
}
@end
