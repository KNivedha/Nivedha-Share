/**
 * Class : RemoteServiceProxy
 * Utility class for making ajax calls to the server.
 **/
mHealth.util.RemoteServiceProxy = Spine.Class.sub({
	/**
	 * Name    : init
	 * Purpose : Initialize the oontroller.
	 * Params  : --
	 * Returns : --
	 **/
	init : function() {
	},
	/**
	 * Name    : getToken
	 * Purpose : Method to make service call for user authentication.
	 * Params  : url - The service url to call,
	 credentials - base64 encoded username and password combination.
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	getToken : function(url, credentials, successCallback, errorCallback) {
		$.ajax({
			url : url,
			async : true,
			type : 'GET',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				if(mHealth.LoginControllerObject.environment == "dev") {
					mHealth.util.RemoteServiceProxy.alSecToken = jqXHR.getResponseHeader('Pragma');
				} else {
					mHealth.util.RemoteServiceProxy.alSecToken = jqXHR.getResponseHeader('ALSECTOKEN');
				}

				successCallback();
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				errorCallback(errorThrown);
			},
			beforeSend : function(xhr) {
				xhr.withCredentials = true;
				xhr.setRequestHeader('Authorization', 'Basic ' + credentials);
			}
		});
	},
	/**
	 * Name    : getResponse
	 * Purpose : Method for making the GET request service call.
	 * Params  : url - The service url to call,
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	getResponse : function(url, successCallback, errorCallback, indicatorFlag) {

		$.ajax({
			url : url,
			async : true,
			type : 'GET',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				successCallback(jqXHR);
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				if(errorThrown == mHealth.SettingsController.timeOut && indicatorFlag === true) {
					mHealth.util.hideMask();
					mHealth.util.customAlert(mHealth.SettingsController.errTimeout);
				} else {
					errorCallback( errorThrown);
				}
			},
			beforeSend : function(xhr) {
				xhr.setRequestHeader('ALSECTOKEN', mHealth.util.RemoteServiceProxy.alSecToken);
			}
		});
	},
	/**
	 * Name    : authenticateUser
	 * Purpose : Method for making the POST request service call
	 * Params  : url - The service url to call,
	 body - Request body to be sent to the server
	 successCallback  - On Success, the control will be given back to the function
	 errorCallback - On Error, the control will be given back to the function
	 * Returns : --
	 **/
	postRequest : function(url, body, postSuccessCallback, errorCallback, indicatorFlag) {

		
		$.ajax({
			url : url,
			async : true,
			data : body,
			type : 'POST',
			timeout : mHealth.service_timeout,
			success : function(output, textStatus, jqXHR) {
				postSuccessCallback(jqXHR);
			},
			complete : function(output) {

			},
			error : function(jqXHR, textStatus, errorThrown) {
				if(errorThrown == mHealth.SettingsController.timeOut && indicatorFlag === true) {
					mHealth.util.hideMask();
					mHealth.util.customAlert(mHealth.SettingsController.errTimeout);
				} else {
					errorCallback(errorThrown);
				}
			},
			beforeSend : function(xhr) {
				xhr.setRequestHeader('ALSECTOKEN', mHealth.util.RemoteServiceProxy.alSecToken);
			}
		});
	}
});

mHealth.util.RemoteServiceProxy.extend({

	alSecToken : null,

	/**
	 * Name    : getInstance
	 * Purpose : Method to create Singleton object for RemoteServiceProxy class
	 * Params  : --
	 * Returns : --
	 **/
	getInstance : function() {

		if(mHealth.util.RemoteServiceProxy.instance == null) {

			mHealth.util.RemoteServiceProxy.instance = new mHealth.util.RemoteServiceProxy();
		}
		return mHealth.util.RemoteServiceProxy.instance;
	}
});
