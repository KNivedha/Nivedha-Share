/**
 * Native Functions
 **/

/**
 * Name    : setCalendarEvent
 * Purpose : Method to call the native calendar
 * Params  : Start Date, End Date, Title
 * Returns : dateString
 **/
mHealth.util.callCalendarEvent = function(title,sDate,eDate) {
	//location.href = "cal://setEvent?eventTitle=" + title + "&startDate=" + sDate + "&endDate=" + eDate;
},

/**
  * Name   : sendEmail
  * Purpose: Method to send email.
  * Params : --
  * Return : --
  **/
mHealth.util.sendEmailEvent = function(to,subject) {
  
	//location.href = "email://sendEmail?mailto="+ to +"&subject="+subject;
},

/**
  * Name   : callNativeBarEvent
  * Purpose: Method to call native bars on login
  * Params : --
  * Return : --
  **/
mHealth.util.callNativeBarEvent = function() {
  	//location.href = "tabbar://login?";
},

/**
  * Name   : removeNativeBarEvent
  * Purpose: Method to remove native bars on logout
  * Params : --
  * Return : --
  **/
mHealth.util.removeNativeBarEvent = function() {
	//location.href = "tabbar://logout?";
},

/**
  * Name   : getDeviceFeatures
  * Purpose: Method to get the device feature like version,device id,...
  * Params : --
  * Return : Device features like version,device id,...
  **/
mHealth.util.getDeviceFeatures = function() {
	location.href = "about://getdevicefeatues?";
},

/**
  *Call back of native functions 
  **/ 

/**
  * Name   : loadHome
  * Purpose: Callback method of native tabbar
  * Params : --
  * Return : --
  **/
loadHome = function() {
	$.mobile.changePage("../../home/view/home.html");
},

/**
  * Name   : loadActivities
  * Purpose: Method to call Activities web view on clicking the activities tab
  * Params : --
  * Return : --
  **/
loadActivities = function() {
    //mHealth.controllers.ActivityController.trigger('getservice');
  //  $.mobile.showPageLoadingMsg();
    mHealth.ActivityControllerObject.getActivity();
    	// $.mobile.changePage("../../activities/view/showactivity.html");
    	
    
		
},

/**
  * Name   : loadMessages
  * Purpose: Method to call Messages web view on clicking the messages tab
  * Params : --
  * Return : --
  **/
loadMessages = function() {

},

/**
  * Name   : loadTrackers
  * Purpose: Method to call trackers web view on clicking the trackers tab
  * Params : --
  * Return : --
  **/
loadTrackers = function() {
	$.mobile.changePage("../../trackers/view/showtracker.html");
},

/**
  * Name   : loadSettings
  * Purpose: Method to call setings web view on clicking the settings tab
  * Params : --
  * Return : --
  **/
loadSettings = function() {
	$.mobile.changePage("../../settings/view/index.html");
}