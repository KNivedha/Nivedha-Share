/**
  * Controller : MedicationController
  * This is the controller to do the  logic of medications
  **/
mHealth.controllers.MedicationController = Spine.Controller.sub({
	el : 'body',
	elements : {},

	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		'click #show_medication' : 'getMedicationList',
		'pagebeforeshow #medication_index' : 'showMedicationList',
		'click .medicationUniqueId' : 'getDetailedMedication',
		'pagebeforeshow #detail_medication' : 'showDetailedMedication',
	},
	
	/** 
	  * Name    : getMedicationList
	  * Purpose : Method to fetch the medication history
	  * Params  : --
	  * Returns : --
	  **/
	getMedicationList : function(event) {
		var modelCount;
		modelCount = mHealth.models.MedicationModel.count();
		
		if(modelCount === 0) {
			this.service.getResponse(mHealth.dev.medication_url,  this.proxy(this.medicationSuccess), this.proxy(this.medicationFailure));
		} else {
			$.mobile.changePage("../view/medicationindex.html");
		}
	},
	
	/** 
	  * Name    : medicationSuccess
	  * Purpose : Success callback of medication service call
	  * Params  : output - response from the server
	  * Returns : --
	  **/
	medicationSuccess : function(output) {
		var response;
		response = output.responseText;
		this.proxy(this.setMedicationData(response));
		$.mobile.changePage("../view/medicationindex.html");
	},
	
	/** 
	  * Name    : medicationFailure
	  * Purpose : Error callback of medication service call
	  * Params  : jqXHR - XMLHttpRequestObject,
	              textStatus - Status text message of the response,
	              errorThrown - Error message recieved from the server
	  * Returns : Alerts 'Information not available'
	  **/
	medicationFailure : function(jqXHR, textStatus, errorThrown) {
		jAlert("Information not available");
	},
	
	/**
	  * Name    : showMedicationList
	  * Purpose : Method to render the medication history in the view
	  * Params  : --
	  * Returns : medicationData
	  **/
	showMedicationList : function() {
		var medicationData;
		medicationData = mHealth.models.MedicationModel.all();
		$('#data_div').html(_.template($('#medicationDataList').html(), {
			medicationData : medicationData
		}));
		$('#medication_index').trigger('create');

	},
	
	/** 
	  * Name    : getDetailedMedication
	  * Purpose : Method to get the detailed view of medication data
	  * Params  : e - event object
	  * Returns : detailedMedications
	  **/
	getDetailedMedication : function(e) {
		var medication_ID, detailedMedication;
		medication_ID = $(e.target).siblings('input[type="hidden"]').val();
		$.mobile.changePage("../view/displaymedication.html");
		detailedMedication = mHealth.models.MedicationModel.select(function(record) {
			if(record.medicationId == medication_ID) {
				detailedMedications = record; // TODO : detailedMedications should not be global
			}
		});
	},
	
	/** 
	  * Name    : showDetailedMedication
	  * Purpose : Method to render the detailed view of medication data
	  * Params  : --
	  * Returns : detailedMedications
	  **/
	showDetailedMedication : function() {
		$('#detailed_data').html(_.template($('#medicationDetails').html(), {
			detailedMedications : detailedMedications
		}));
		$('#detail_medication').trigger('create');
	},
	
	/** 
	  * Name    : setMedicationData
	  * Purpose : Method to set the data from server to the medication model
	  * Params  : response - response data from the server
	  * Returns : --
	  **/
	setMedicationData : function(response) {
			mHealth.models.MedicationModel.customFromJSON(response);
			}
});
