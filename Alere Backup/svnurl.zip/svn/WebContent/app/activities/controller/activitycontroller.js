
/**
  *Controller : ActivityController
  *Controller to do Activity Tab functionality. 
  **/

mHealth.controllers.ActivityController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	subActivityView : "",
	events : {
		'pagebeforeshow #showActivity' : 'getActivity',
		'pageshow #showActivity' : 'showActivity',
		'click .detailActivity' : 'getSubActivity',
		'pageshow #detailActivity' : 'showSubActivity',

	},

	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showSubActivity : function() {
		$('#detailActivity_div').html(_.template($('#detailActivityDataList').html(), recordRequired));
		$('#detailActivity').trigger('create');
	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showActivity : function() {
		$('#activityTitle').text(activity[0].space[0].title);
		if(activity[0].zone.length > 1) {
			$('#activity_zone').show();
			$('#activity_zone').html(_.template($('#navDataList').html(), activity[0].zone));
		}
		$('#activity_div').html(_.template($('#activityDataList').html(), activity[0].view));
		$('#showActivity').trigger('create');
	},
	/**
	 *Name: init
	 *Purpose: initialize the Controller
	 **/
	init : function() {
	},
	/**
	 *Name: getSubActivity
	 *Purpose: On click the View of the Activity, the Function will be 
	 *Params
	 *Returns
	 **/
	getSubActivity : function(event) {
		var view = event.target;
		// var html = $(event.target).html();
		var selectedViewName = $(view).parents('li').children('div').children('div').children('a').children('h3').text();
		
		mHealth.models.SpaceViewZoneModel.each(function(record) {
			if(record.pageName === 'Activity') {
				for(i = 0; i < record.view.length; i++) {
					if(record.view[i].title.trim() === selectedViewName.trim()) {
						this.subActivityView = record.view[i];
						break;
					}
				}
			}
		});

		$.mobile.changePage("detailactivity.html");

	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	getActivity : function() {
		var isExists = mHealth.models.SpaceViewZoneModel.each(function(record) {
			if(record.pageName === 'Activity') {
				return true;
			}
		});
		if(isExists === true) {
			$.mobile.changePage('../../activities/view/showactivity.html');
		} else {
			var body = mHealth.recommandation.createRecommendationRequestJSON("1003");
			this.proxy(this.service.postRequest(mHealth.dev.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.recommendationFailure)));
		}
	},
	/**
	 *Name: recommendationSuccess
	 *Purpose: After getting the response from the recommandation Service, the functon will parse the space, View and ZOne
	 		 Set the value in the respective model.
	 *Params: output
	 *Returns: null
	 **/
	recommendationSuccess : function(output) {
		var response, recommandationData, spaceData, zoneData, viewData, spaceviewzone;
		response = output.responseText;
		recommandationData = JSON.parse(response);
		spaceData = JSON.stringify(recommandationData.Space);
		zoneData = JSON.stringify(recommandationData.Zone);
		viewData = JSON.stringify(recommandationData.View);
		spaceviewzone = new mHealth.models.SpaceViewZoneModel({

			pageName : 'Activity',
			space : mHealth.models.SpaceModel.fromJSON(spaceData),
			view : mHealth.models.ViewModel.fromJSON(viewData),
			zone : mHealth.models.ZoneModel.fromJSON(zoneData)

		});

		/*		spaceviewzone.save*/

		activity = mHealth.models.SpaceViewZoneModel.each(function(record) {
        // TODO : activity should not be global.
			if(record.pageName === 'Activity') {
				return record;
			}
		});

		$.mobile.changePage("../../activities/view/showactivity.html");
	},
	/**
	 *Name : recommendationFailure
	 *Purpose: On the Failure of the recommandation service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {

	}
});
