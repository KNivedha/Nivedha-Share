/**
  *Controller : LoginController
  *Controller to do login functionality. 
  **/

mHealth.controllers.LoginController = Spine.Controller.sub({
	el : 'body',
	elements : {
		'#name' : 'uname',
		'#password' : 'pwd'
	},
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #loginbutton' : 'doLogin',
		'click #sendMail' : 'sendEmail'
	},
	
	/** 
      *Name   : sendEmail
      *Purpose: Method to send email. 
      *Params : --
      *Return : --
      **/
	sendEmail : function() {
		location.href = "email://sendEmail?mailto=service.desk@alere.com&subject="
	},
	
	/** 
      *Name   : loginSuccess
      *Purpose: Success callback to authenticate user. 
      *Params : output - response from the server
      *Return : --
      **/
	loginSuccess : function(output) {
		var body;
		body = mHealth.recommendation.createRecommendationRequestJSON("1020");
		this.proxy(this.service.postRequest(mHealth.dev.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.recommendationFailure)));
	},
	
	/** 
      *Name   : loginFailure
      *Purpose: Failure callback to authenticate user. 
      *Params : jqXHR - XMLHttpRequestObject,
                textStatus - Status text message of the response,
                errorThrown - Error message recieved from the server. 
      *Return : Displays error message.
      **/
	loginFailure : function(jqXHR, textStatus, errorThrown) {

		$('#splash_message').show();
		if(errorThrown == 'Unauthorized') {
			$('#splash_message').html('Invalid login credentials.');
		} else {

			$('#splash_message').html('An error occurred while communicating with the server.');

		}
	},
	
	/** 
      *Name   : doLogin
      *Purpose: Method to encode user credential to base64 encoding. 
      *Params : --
      *Return : --
      **/
	doLogin : function() {
		
		var username, password, credentials;
		username = this.uname.val();
		password = this.pwd.val();
		mHealth.util.participantemail = username;
		$('#splash_message').hide();
		if((username != '') && (password != '')) {
			credentials = $.base64Encode(username + ":" + password);
			this.service.authenticateUser(mHealth.dev.authtoken_get_url, credentials, this.proxy(this.loginSuccess), this.proxy(this.loginFailure));
		} else {
			$('#splash_message').show();
			$('#splash_message').html('Enter the Username and password');
		}
	},
	
	/** 
      *Name   : recommendationSuccess
      *Purpose: Success callback for getting home recommendation type.
      *Params : output - response from the server.
      *Return : --
      **/
	recommendationSuccess : function(output) {
		var response, recommandationData, viewData; 
		response = output.responseText;
		recommandationData = JSON.parse(response);
		viewData = JSON.stringify(recommandationData.View); mHealth.models.ViewModel.customFromJSON(viewData), $.mobile.changePage("../../home/view/home.html");
		//location.href = "tabbar://login?";
	},
	
	/** 
      *Name   : recommendationFailure
      *Purpose: Failure callback for getting home recommendation type. 
      *Params : jqXHR - XMLHttpRequestObject,
                textStatus - Status text message of the response,
                errorThrown - Error message recieved from the server.
      *Return : Alerts 'The service is not available'.
      **/
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {
		alert('The service is not available');
	}
});
