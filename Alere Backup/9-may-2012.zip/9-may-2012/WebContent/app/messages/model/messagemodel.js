/* Models for Messages*/
mHealth.models.MessageModel = Spine.Model.sub();
mHealth.models.MessageModel.configure("MessageModel", "messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "sentDate", "deliveredDate", "expiredDate", "sections");

mHealth.models.MessageDetailsResponse = Spine.Model.sub();
mHealth.models.MessageDetailsResponse.configure("MessageDetailsResponse", "transactionID", "message");

mHealth.models.MessageDetailsModel = Spine.Model.sub();
mHealth.models.MessageDetailsModel.configure("MessageDetailsModel","messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "sentDate", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "cachedPersonalizedMessage");

mHealth.models.MessageSectionModel = Spine.Model.sub();
mHealth.models.MessageSectionModel.configure("MessageSectionModel", "messageText", "suggestedCalendarEvent", "questionnaire", "articles");

mHealth.models.QuestionnaireModel = Spine.Model.sub();
mHealth.models.QuestionnaireModel.configure("QuestionnaireModel", "id", "introCopy", "qGroups");

mHealth.models.QuestionGroupModel = Spine.Model.sub();
mHealth.models.QuestionGroupModel.configure('QuestionGroupModel', "id", "seq", "type", "title", "questions");

mHealth.models.MessageQuestionModel = Spine.Model.sub();
mHealth.models.MessageQuestionModel.configure('MessageQuestionModel', "id", "seq", "questionText", "answerType", "defaultAnswer", "answerOptions");

mHealth.models.QuestionMsgModel = Spine.Model.sub();
mHealth.models.QuestionMsgModel.configure('QuestionMsgModel', "id", "seq", "questionText", "answerType", "defaultAnswer", "answerOptions");

mHealth.models.MessageAnswerModel = Spine.Model.sub();
mHealth.models.MessageAnswerModel.configure('MessageAnswerModel', 'id', 'seq', 'label');

/* Models for Archive messages*/
mHealth.models.ArchiveModel = Spine.Model.sub();
mHealth.models.ArchiveModel.configure("ArchiveModel", "messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "sentDate", "deliveredDate", "expiredDate", "sections");

mHealth.models.UserFeedbackModel = Spine.Model.sub();
mHealth.models.UserFeedbackModel.configure('UserFeedbackModel','questionID','questionSubID','answer');