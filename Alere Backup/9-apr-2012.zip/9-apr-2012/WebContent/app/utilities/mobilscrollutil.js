mHealth.mobiscrollutil = {

	mobiScollDateTime : function(id) {
		$(id).scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'datetime',
			seconds : true,
			timeFormat : 'hh:ii:ss A',
			theme : 'ios',
			beforeShow : function(input, inst) {
				nativeCommunication.callNativeMethod("tabbar://hideTabBar?");
			},
			onClose : function(valueText, inst) {
				nativeCommunication.callNativeMethod("tabbar://showTabBar?");
			}
		});

	}
}