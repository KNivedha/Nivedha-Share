/**
 *Controller : LoginController
 *Controller to do login functionality.
 **/
mHealth.controllers.LoginController = Spine.Controller.sub({
	el : 'body',
	environment : null,
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #loginbutton' : 'validateLogin',
		//'click #loginbutton' : 'doLogin',
		'submit #login-form' : 'doLogin',
		'click #debugToggle' : 'toggleDebugOptions',
		'click #sendMail' : 'sendEmail',
		'pageshow #loginPage' : 'setPrevLogin',
		'click #contactEmail' : 'sendContactMail',
		'click #mailToCreig' : 'mailToCreig',
		'click #clientAccessButton' : 'clientRegistration',
		'pagebeforeshow div[data-role="page"]' : 'setDocumentHeight',
		'pagebeforeshow #home' : 'setHomeShortcuts',
		'click #showDebug' : 'showDebugPage',
		'click #callNurseId' : 'callNursePrompt'
	},

	/**
	 *Name    : toggleDebugOptions
	 *Purpose : Method to toggle debug options
	 *Params  : --
	 *Return  : --
	 **/
	toggleDebugOptions : function() {

		if(!($('#loginDiv').css('display') == 'none')) {
			$("#debug-options").fadeToggle("slow", "linear", function() {
				$('#loginPage').css({
					'height' : 'auto'
				});
				$('#loginPage').trigger('create');
				$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');

			});
		}
	},
	/**
	 *Name    : setHomeShortcuts
	 *Purpose : Method to set shortcuts in home
	 *Params  : --
	 *Return  : --
	 **/
	setHomeShortcuts : function() {

		$('#showHomeShortcut').html(_.template($('#homeScript').html(), {
			homeFeature : mHealth.util.homeFeatures
		}));
		$('#showHomeShortcut').trigger('create');
	},
	/**
	 *Name    : showDebugPage
	 *Purpose : Method to show debug page
	 *Params  : --
	 *Return  : --
	 **/
	showDebugPage : function() {
		$.mobile.changePage('../../debug/view/debugindex.html');
	},
	/**
	 *Name    : setDocumentHeight
	 *Purpose : Method to set the document height dynamically to avoid white strip.
	 *Params  : --
	 *Return  : --
	 **/
	setDocumentHeight : function() {

		$('div[data-role="page"]').css({
			'height' : document.height
		});
	},
	/**
	 *Name    : callNursePrompt
	 *Purpose : Method to alert the custom prompt for calling nurse.
	 *Params  : --
	 *Return  : --
	 **/
	callNursePrompt : function(){
		mHealth.util.callNursecustomPrompt(mHealth.GuiHelper.callNurseAlert,mHealth.HomeFeatures.call_nurse_number,function(){
			   location.href="tel://callNumber?number="+mHealth.HomeFeatures.call_nurse_number;
		},function(){
		});
	},
	/**
	 *Name    : clientRegistration
	 *Purpose : Method to register a new user.
	 *Params  : --
	 *Return  : --
	 **/
	clientRegistration : function() {
		var clientAcess = $('#clientAccess').val().trim();
		//Current using mHealth.uat as we get undefined
		var registrationURL = mHealth.uat.registration_url + '?keycode=' + clientAcess;
		//URL DEFINED IN config.js

		window.open(registrationURL, '_blank');
	},
	/**
	 *Name    : validateLogin
	 *Purpose : Method to validate login credentials.
	 *Params  : --
	 *Return  : --
	 **/
	validateLogin : function() {

		var username = $('#username').val().trim();
		var password = $('#password').val().trim();
		if((username == '') || (password == '')) {
			$('#username').val("");
			$('#password').val("");
			$('#errorMessage').html(mHealth.Login.msgEmptyField);
			$('#loginPage').css({
				'height' : 'auto'
			});
			$('#loginPage').trigger('create');
		}
	},
	/**
	 *Name    : mailToCreig
	 *Purpose : Method to Send email to the Craig.Apolinsky of the Alere
	 *Params  : --
	 *Return  : --
	 **/
	mailToCreig : function() {
		mHealth.util.sendEmail('Craig.Apolinsky@alere.com', '');
	},
	/**
	 *Name    : sendContactMail
	 *Purpose : Method to Send email to the corp feedback of the Alere
	 *Params  : --
	 *Return  : --
	 **/
	sendContactMail : function() {
		mHealth.util.sendEmail('Corpfeedback@alere.com', '');
	},
	/**
	 *Name   : setPrevLogin
	 *Purpose: Method to set the previous User Id and Setting the splash message.
	 *Params : --
	 *Return : --
	 **/
	setPrevLogin : function() {
		var rememberMe = mHealth.models.RememberMeModel.first();

		if(rememberMe != undefined) {
			$('#username').val(rememberMe.username);
		}
		var activePage = $('.ui-page-active').attr('data-url');
		var splashMessage = mHealth.util.getParameterByName('splashMessage', activePage);
		if(splashMessage !== null) {

			$('#errorMessage').text(splashMessage);
		}

		if($('#username').val().length > 0) {
			$('#loginDiv').show();
		}
		$('#loginFormButton').click(function() {
			$('#loginDiv').show();
			$('#clientAccessDiv').hide();
			$('#loginPage').css({
				'height' : 'auto'
			});
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
		});
		$('#clientAccessFormButton').click(function() {
			$('#loginDiv').hide();
			$('#clientAccessDiv').show();
			$('#loginPage').css({
				'height' : 'auto'
			});
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
		});
		$('#loginPage').trigger('create');
	},
	/**
	 *Name   : sendEmail
	 *Purpose: Method to send email.
	 *Params : --
	 *Return : --
	 **/
	sendEmail : function() {
		var subject = "";
		if(mHealth.SettingsLogin.emailSubject != undefined) {
			subject = mHealth.SettingsLogin.emailSubject;
		}
		mHealth.util.sendEmail(mHealth.SettingsLogin.email, '', subject);
	},
	/**
	 *Name   : loginSuccess
	 *Purpose: Success callback to authenticate user.
	 *Params : output - response from the server
	 *Return : --
	 **/
	loginSuccess : function(output) {

		//URL for Messages
		var URL = mHealth.env.messageheaders_url;
		this.proxy(this.service.getResponse(URL, mHealth.MessageControllerObject.messageSuccess, mHealth.MessageControllerObject.showHome, true));
		
		// Get features
		this.proxy(this.service.getSyncResponse(mHealth.env.mobile_app_config_url, this.proxy(this.featureListSuccess), this.proxy(this.featureListFailure), false));
		
		// URL for Profile
		this.proxy(this.service.getResponse(mHealth.env.profile_url, this.proxy(this.participantSuccess), null, false));

	},
	
	/**
	 * Name    : featureListFailure
	 * Purpose : Get list of enabled features for the user
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	featureListFailure : function(output) {
		// Hard coded configuration
		
		var appConfig = [{
			"mobileAppFeaturesConfig" : {
				"featureGroup" : [{
					"groupId" : "standard",
					"feature" : [
                    {"id" : "medHistory"},
                    {"id" : "challenges"},
                    {"id" : "call_nurse","phone" : "18662017919"},
                    {"id" : "debug"}
                    ]
				}, {
					"groupId" : "trackers",
					"feature" : [
                    {"id" : "tracker_bg","intraGroupRank" : 900},
                    {"id" : "tracker_wtbmi","intraGroupRank" : 850},
                    {"id" : "tracker_bp","intraGroupRank" : 800},
                    {"id" : "tracker_a1c","intraGroupRank" : 750},
                    {"id" : "tracker_cholesterol","intraGroupRank" : 700}, 
                    {"id" : "tracker_exams","intraGroupRank" : 675}
                    ]
				}]
			}
		}];		
		this.buildFeatureList(appConfig);
	},
	
	/**
	 * Name    : buildFeatureList
	 * Purpose : Biuld list of enabled features for the user
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	buildFeatureList : function(appConfig) {
		var length = appConfig[0].mobileAppFeaturesConfig.featureGroup.length;
		mHealth.models.FeatureGroupModel.destroyAll();
        for(var i = 0; i < length; i++) {
			mHealth.models.FeatureGroupModel.customFromJSON(appConfig[0].mobileAppFeaturesConfig.featureGroup[i]);
		}
		var homeFeature = mHealth.models.FeatureGroupModel.findByAttribute('groupId', 'standard');
		var trackerFeature = mHealth.models.FeatureGroupModel.findByAttribute('groupId', 'trackers');
		var homeFeatureLength = homeFeature.feature.length;
		var homeFeatures=[];
		for(var i=0;i<homeFeatureLength;i++){
			if(homeFeature.feature[i].id != 'debug') {
				homeFeatures.push(homeFeature.feature[i]);
					//homeFeatures.splice(i, 1);
				}
		}
		if(homeFeatureLength < 5) {
			var sortData = mHealth.util.getSortData(trackerFeature.feature);
			for(var j = 0; j <= (5 - homeFeatureLength); j++) {
				homeFeatures.push(sortData[j]);	
			}
		}
        mHealth.util.homeFeatures = homeFeatures;
	},
				
	/**
	 * Name    : featureListSuccess
	 * Purpose : Get list of enabled features for the user
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	featureListSuccess : function(output) {
		//var appConfig = output.responseText;
		this.buildFeatureList(JSON.parse(output.responseText));
	},
	
	/**
	 * Name    : participantSuccess
	 * Purpose : Success callback for getting participant data.
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	participantSuccess : function(output) {
		var response = output.responseText;
		mHealth.models.ParticipantModel.customFromJSON(response);
	},
	/**
	 *Name   : loginFailure
	 *Purpose: Failure callback to authenticate user.
	 *Params : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server.
	 *Return : Displays error message.
	 **/
	loginFailure : function(errorThrown) {
		var splashMessage = null;
		if(errorThrown == mHealth.SettingsController.timeOut) {
			splashMessage = mHealth.SettingsController.errTimeout;
		} else if(errorThrown == mHealth.SettingsController.unauthorized) {
			splashMessage = mHealth.Login.msgEmptyField;
		} else {
			splashMessage = mHealth.SettingsController.msgErrorCommunication;
		}

		$('#loginPage').detach();
		$.mobile.changePage("../../rootview/view/login.html", {
			data : {
				splashMessage : splashMessage
			}
		});

	},
	/**
	 *Name   : doLogin
	 *Purpose: Method to encode user credential to base64 encoding.
	 *Params : --
	 *Return : --
	 **/
	doLogin : function() {
		var username = $('#username').val();
		var password = $('#password').val();

		if((username != '') && (password != '')) {
			$.mobile.changePage("../../rootview/view/wait.html");
			environment = $('select#server option:selected').val();
			mHealth.util.setEnvironment(environment);
			// var mobileConfigUrl = mHealth.env.mobile_app_config_url;
			// this.proxy(this.service.getResponse(mobileConfigUrl, this.proxy(this.configSuccess),this.proxy(this.configFailure),true));
			mHealth.util.participantEmail = username;
			mHealth.models.RememberMeModel.destroyAll();
			var rememberMe = new mHealth.models.RememberMeModel({
				"username" : username
			});
			rememberMe.save();
			var credentials = $.base64Encode(username + ":" + password);
			this.service.getToken(mHealth.env.authtoken_get_url, credentials, this.proxy(this.loginSuccess), this.proxy(this.loginFailure));
		} else {
			$('errorMessage').html(mHealth.Login.msgEmptyField);
			$('#loginPage').css({
				'height' : 'auto'
			});
			$('#loginPage').trigger('create');
		}

	},
	// configSuccess:function(output){
		// var response = output.responseText;
		// alert('Response'+response);
	// },
	// configFailure:function(){
		// alert('Failure');
	// }
// 	
});
