//
//  PList.h
//  Alere
//
//  Created by AlereMobility on 17/02/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DeviceDelegate.h"
@interface PList : NSObject<DeviceDelegate>

@end
