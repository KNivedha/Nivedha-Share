//
//  OrientationConstants.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OrientationConstants.h"
static BOOL rotated =NO;
static BOOL landscp =NO;

@implementation OrientationConstants
+(void)setRotated:(BOOL)value
{
    rotated=value;
}
+(BOOL)rotated
{
    return rotated;
}
+(void)setLandscp:(BOOL)value
{
    landscp=value;   
}
+(BOOL)landscp
{
    return landscp;
}


@end
