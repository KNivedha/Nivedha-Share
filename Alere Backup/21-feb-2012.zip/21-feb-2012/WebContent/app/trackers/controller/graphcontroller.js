mHealth.controllers.GraphController = Spine.Controller.sub({
	healthDataTracker : '',
	
	currentView : "Month",

	currentTime : new Date(),
	cyear : new Date().getFullYear(),
	cmonth : new Date().getMonth() + 1,

	lastDateM : new Date(this.cyear, this.cmonth, 0),
	gTitleM : '',
	xMaxDate : '',
	xMinDate : '',

	currentTimeM : this.currentTime,
	cyearM : this.cyear,
	cmonthM : this.cmonth,

	maxWeekDate : '',
	maxDateW : '',
	minWeekDate : '',
	minDateW : '',
	gTitleW : '',
	gTitleWmax : '',
	gTitleWmin : '',

	maxDayDate : '',
	maxDateD : '',
	minDayDate : '',
	minDateD : '',
	gTitleD : '',

	xMaxDateMonth : '',
	xMaxDateWeek : '',
	xMaxDateDay : '',

	dataPoints : '',
	getPlotOptions : '',

	seriesDataSet1 : '',
	seriesDataSet2 : '',

	glucosePlotOptions : '',
	avgCords : '',
	plotCords : '',
	glucoseData: '',
	filteredGlucoseData: '',
	thresholdMinGlucose : '',
	thresholdMaxGlucose : '',
	maxHealthDataValue : 0,
	
	//for flot
	plotData: '',
	plotOptions: '',
	graphPlot: '',
	dataSeries1: '',
	dataSeries2: '',
	plotxMin: '',
	plotxMax: '',
	xTickInterval: '',
	xTimeformat: '',

	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click .tracker' : 'setTrackerType',
		'click #showTrackerPage' : 'setGlucoseTracker',
		'click #viewGraph' : 'getGraphData',
		'pageshow #glucosegraphpage' : 'drawGlucoseGraph',
		'pageshow #weightgraph' : 'drawWBMIGraph',
		'click #daybutton' : 'setDayView',
		'click #weekbutton' : 'setWeekView',
		'click #monthbutton' : 'setMonthView',
		'click #showLabel' : 'showLabels',
		'click #back' : 'unloadChart',
		'click #track' : 'unloadChart',
		'click #previousbutton' : 'previousButton',
		'click #nextbutton' : 'nextButton'

	},
	
	
		/**
	 *Name: unloadChart
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	unloadChart : function(e) {
		location.href = "gyro://unLoadChart?";
	},
	
		/**
	 *Name: setTrackerType
	 *Purpose: Sets Tracker type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setTrackerType : function(e) {
		this.healthDataTracker = $(e.target).parents(".tracker").attr('name');
	},
	
	/**
	 *Name: setGlucoseTracker
	 *Purpose: Opens detailtracker.html when blood glucose icon is clicked on home page. sets the healthDataTracker to Blood Glucose.
	 *Params: No params
	 *Returns::
	 **/
	setGlucoseTracker : function() {
		this.healthDataTracker = 'Blood Glucose';
		location.href = "tabbar://loadTrackers?";
		$.mobile.changePage('../../trackers/view/detailtracker.html');
	},
	
	/**
	 *Name: setTrackerId
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
	setTrackerId : function() {
		var trackerId = '';
		if(this.healthDataTracker == 'Blood Glucose') {
			trackerId = 'Bloodglucose';
		} else if(this.healthDataTracker == 'Dilated Retinal Exam') {
			trackerId = 'RetinalExam';
		} else if(this.healthDataTracker == 'Foot Exam - Self') {
			trackerId = 'FootSelfExam';
		} else if(this.healthDataTracker == 'Foot Exam - Provider') {
			trackerId = 'FootExam';
		} else if(this.healthDataTracker == 'Microalbumin') {
			trackerId = 'MAU';
		} else if(this.healthDataTracker == 'A1c') {
			trackerId = 'A1C';
		} else if(this.healthDataTracker == 'Weight & BMI') {
			trackerId = 'Weight';
		} else if(this.healthDataTracker == 'Blood Pressure') {
			trackerId = 'BPS';
		} else if(this.healthDataTracker == 'Cholesterol') {
			trackerId = 'Cholesterol';
		}
		return trackerId;
	},
	
	/**
	 *Name: getHealthTrackerData
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/	
		getHealthTrackerData : function(healthDataType) {
		var healthDataResponse = [];
		var modelResponse = mHealth.models.HealthDataModel.findAllByAttribute("healthDataType", healthDataType);
		modelResponse.map(function(response) {
			healthDataResponse.push(response);
		});
		return healthDataResponse;
	},
	
	/**
	 *Name: plotWBMIGraph
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/	
		plotWBMIGraph : function(healthDataValue1, healthDataValue2) {
		this.seriesDataSet1 = healthDataValue1;
		this.seriesDataSet2 = healthDataValue2;
		location.href = "gyro://loadChart?";
		this.monthView();
		$.mobile.changePage('weightgraph.html');
	},
	
	/**
	 *Name: plotBloodGlocuseGraph
	 *Purpose: 
	 *Params: 
	 *Returns: 
	 **/
		plotBloodGlocuseGraph : function(healthDataValue) {
		this.seriesDataSet1 = healthDataValue;
		location.href = "gyro://loadChart?";
		this.monthView();
		$.mobile.changePage('glucosegraph.html');
	},
	
	/**
	 *Name: getGraphData
	 *Purpose:  gets the Graph Data using getResponse service call. Called on view my graph click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getGraphData : function() {
		this.cmonth=new Date().getMonth()+1;
		this.cyear=new Date().getFullYear();
		this.currentTime=new Date();
		var healthDataResponse = [];
		var healthDataResponseDouble = [];
		var trackerId = this.setTrackerId();
		if(this.healthDataTracker == "Cholesterol") {
			$.mobile.changePage('detailscholesterol.html');
		} else {
			if(trackerId == 'Bloodglucose') {
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotBloodGlocuseGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'Weight & BMI') {
				trackerId1 = "Weight";
				trackerId2 = "BMI";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotWBMIGraph(healthDataResponse, healthDataResponseDouble);
			} else if(this.healthDataTracker == 'Blood Pressure') {
				trackerId1 = "BPS";
				trackerId2 = "BPD";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotDoubleGraph(healthDataResponse, healthDataResponseDouble);
			} else if(this.healthDataTracker == 'LDL & HDL') {
				trackerId1 = "LDL";
				trackerId2 = "HDL";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotDoubleGraph(healthDataResponse, healthDataResponseDouble);
			} else if(this.healthDataTracker == 'Triglycerides') {
				healthDataResponse = this.getHealthTrackerData(this.healthDataTracker);
				this.plotSingleGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'Total Cholesterol') {
				trackerId = 'Cholesterol';
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotSingleGraph(healthDataResponse);
			} else if(this.healthDataTracker == 'A1c') {
				trackerId = 'A1C';
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotSingleGraph(healthDataResponse);
			}
			return;
		}

	},
	
	
	/**
	 *Name: monthView
	 *Purpose:sets the month view for the graph when landing on the graph for the first time, and when clicked on the month button
	 *Params:
	 *Returns:
	 **/
	monthView : function() {
		if(parseInt(this.cmonth,10)==(new Date().getMonth()+1) && this.cyear==new Date().getFullYear())
			$("#nextbutton").css("display", "none");
		//alert("monthView");
		this.currentView = "Month";
		this.lastDateM = new Date(this.cyear, this.cmonth, 0);
		this.gTitleM = this.setTitle(this.lastDateM, this.currentView);
		this.xMaxDate = this.calculateDate(this.lastDateM, 2);
		if(this.cmonth <= 9)
			this.cmonth = "0" + parseInt(this.cmonth, 10);
		this.xMinDate = this.cyear + "-" + this.cmonth + "-" + "01" + " " + "00" + ":" + "00";
		this.cyearM = this.cyear;
		this.cmonthM = parseInt(this.cmonth, 10);
		this.xMaxDateMonth = this.xMaxDate;
		if(this.healthDataTracker == "Blood Glucose"){
		this.dataSeries1=this.calculateSingleLineDataPoints(this.seriesDataSet1, this.xMinDate, this.xMaxDate);
		this.plotGlucoseCords(this.dataSeries1);
		}
		else if(this.healthDataTracker == "Weight & BMI"){
			this.dataSeries1=this.calculateSingleLineDataPoints (this.seriesDataSet1,this.xMinDate, this.xMaxDate);
			this.dataSeries2=this.calculateSingleLineDataPoints (this.seriesDataSet2, this.xMinDate, this.xMaxDate);
			this.plotxMax=new Date(this.lastDateM.getFullYear(),this.lastDateM.getMonth(),this.lastDateM.getDate()).getTime()-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
			this.plotxMin=new Date(this.lastDateM.getFullYear(),this.lastDateM.getMonth(),1).getTime()-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
			this.xTickInterval=[1,"day"];
			this.xTimeformat="%d";
			this.wbmiGraph();
		}
		else
		this.setGraph(this.currentView, this.xMinDate, this.xMaxDate, this.gTitleM);
	},

		/**
	 *Name: wbmiGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	wbmiGraph : function(){
		var bmiDataLow=[];
		var bmiDataAvg =[];
		var bmiDataHigh =[];
		for(var i=0;i<this.dataSeries2.length;i++)
		{	
			if(this.dataSeries2[i][1]<=25){
				bmiDataLow.push(this.dataSeries2[i]);
			}else if(this.dataSeries2[i][1]>25 && this.dataSeries2[i][1]<=30){
				bmiDataAvg.push(this.dataSeries2[i]);
			}else{
				bmiDataHigh.push(this.dataSeries2[i]);
			}
				
		}
    	var markings = [
    				{ color: '#ff8c00',
    				 lineWidth: 1, 
    				 xaxis: { 
    				 	from: new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()).getTime()-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000), 
    				 	to: new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()).getTime()-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000)
    				 	} 
    				 }
	 			   ];
    	this.plotData=[{     //$('#DIV NAME'), data
			data: this.dataSeries1,
			//points: {show: true},
			label : 'Weight',
			color : '#BB6AAB'
		},{     //$('#DIV NAME'), data
			data: bmiDataLow,
			label : 'BMI-Low',
			points: {show: true,
				fillColor:'#7C92CA',
				fill : true,
				radius: 3},
			color : '#7C92CA',
		},{     //$('#DIV NAME'), data
			data: bmiDataAvg,
			label : 'BMI-Average',
			points: {show: true,
				fillColor:'#92C83E',
				fill : true,
				radius: 3},
			color : '#92C83E',
		},{     //$('#DIV NAME'), data
			data: bmiDataHigh,
			label : 'BMI-High',
			points: {show: true,
				fillColor:'#FFA01B',
				fill : true,
				radius: 3},
			color : '#FFA01B',
		}];
		this.plotOptions={
			xaxis : {
				mode: "time",
				tickSize: this.xTickInterval,
				min: this.plotxMin,
                max: this.plotxMax,
                timeformat: this.xTimeformat,
				tickColor : '#574F52',
				color : '#574F52'
				},
			yaxis : {
				min : 0,
				tickSize : 40,
				decimal : 0,
				tickColor : '#574F52',
				color : '#574F52'
				},
			series : {
				grow:{
					active: true,
		            valueIndex: 1,
		           // stepDelay: 20,
		            steps:5,
		            stepMode: "maximum",
		            stepDirection: "up"
            	}
			},
			grid : {
				hoverable : false,
				backgroundColor : '#463E41',
				markings: markings
			},
			legend : {
				show: false,
				position: "se",
				margin: 2
			}
		};   
	},
	
	/**
	 *Name: drawWBMIGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	drawWBMIGraph : function(){
			this.graphPlot = $.plot($("#graphdiv"), this.plotData,this.plotOptions); 
			//setTimeout("$('#showLabel').css('visibility','visible');",1200);
		},
	
	/**
	 *Name: previousButton
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	previousButton : function(){
		$("#showLabel").attr("src", "../../../assets/images/flot_images/viewreadings_grey.png");
		$("#nextbutton").css("display", "block");
               if(this.cmonth=="1"||this.cmonth=='01'){
                       this.cmonth='12';
                       this.cyear=String(parseInt(this.cyear,10)-1);        
               }
               else
                       this.cmonth=String(parseInt(this.cmonth,10)-1);
               if(this.currentView == "Week")
               {
                       //alert(this.currentTime);
                       this.currentTime=new Date(this.currentTime.getTime() - (7 * 24 * 60 * 60 * 1000));
                      // alert(this.currentTime);
                       this.weekView();
               }else if(this.currentView == "Day"){
                       this.currentTime=new Date(this.currentTime.getTime() - (1 * 24 * 60 * 60 * 1000));
                      // alert(this.currentTime);
                       this.dayView();
               }else{
                       this.monthView();
               }if(this.healthDataTracker=='Blood Glucose')
               this.drawGlucoseGraph();
               else
               this.drawWBMIGraph();
       },
	
	/**
	 *Name: nextButton
	 *Purpose:
	 *Params:
	 *Returns:
	 **/	
	 nextButton : function(){
	 	$("#showLabel").attr("src", "../../../assets/images/flot_images/viewreadings_grey.png");
               //alert(this.cmonth);
               if(this.cmonth=="12"){
                       this.cmonth='1';
                       this.cyear=String(parseInt(this.cyear,10)+1);        
               }else
                       this.cmonth=String(parseInt(this.cmonth,10)+1);
                 //alert(this.cmonth);
               if(this.currentView == "Week")
               {
                       //alert(this.currentTime);
                       this.currentTime=new Date(this.currentTime.getTime()+(7 * 24 * 60 * 60 * 1000));
                       //alert(this.currentTime);
                       this.weekView();
               }else if(this.currentView == "Day"){
                       this.currentTime=new Date(this.currentTime.getTime() + (1 * 24 * 60 * 60 * 1000));
                       //alert(this.currentTime);
                       this.dayView();
               }else{
                       this.monthView();
               }
               if(this.healthDataTracker=='Blood Glucose')
               this.drawGlucoseGraph();
               else
               this.drawWBMIGraph();
       },	
	
	/**
	 *Name: showLabels
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	showLabels : function() {
		$("#showLabel").attr("src", "../../../assets/images/flot_images/viewreadings_orange.png");
		var placeholder=$('#graphdiv');
		var xOffset=(new Date(this.cyear,parseInt(this.cmonth,10)-1,12)).getTime();
		var datestring=mHealth.util.getYearWithMonth(new Date(this.cyear,parseInt(this.cmonth,10)-1,1));
		if(this.currentView=="Month"){
            if(parseInt(this.cmonth,10)==(new Date().getMonth() + 1)){
                datestring=mHealth.util.getDateWithMonth(new Date());
            }
        }
        else if(this.currentView=='Week'){
        	var wday = this.currentTime.getDay();
			var xOffset=(new Date(this.currentTime.getTime() - ((wday-2.5) * 24 * 60 * 60 * 1000))).getTime();
            var datestring=mHealth.util.getYearWithMonth(new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),1));
        }
        else {
			var xOffset=((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTime()+(14)*60*60*1000);
            var datestring=mHealth.util.getYearWithMonth(new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()));
        }
        var yOffset=this.graphPlot.getAxes().yaxis.max;
        var o = this.graphPlot.pointOffset({ x: xOffset, y: yOffset});
        placeholder.append('<div style="position:absolute;left:' + (o.left + 4) + 'px;top:' + o.top + 'px;color:#CCCCCC;font-size:bigger">'+datestring+'</div>');
			 o = this.graphPlot.pointOffset({ x: new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()).getTime()-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000), y:0});
	   
	     var ctx = this.graphPlot.getCanvas().getContext("2d");
	     ctx.beginPath();
	     o.left -= 7;
	    ctx.moveTo(o.left, o.top);
	    ctx.lineTo(o.left+7, o.top - 5);
	    ctx.lineTo(o.left+14 , o.top);
	    ctx.lineTo(o.left, o.top);
	    ctx.fillStyle = "#FFA01B";
	    ctx.strokeStyle = "#FFA01B";
	    ctx.fill();
 		this.drawLabel();
		 // for(var i=0;i<10;i++){
					// //setTimeout(this.drawLabel(i),100*i);
// 					
				// }
		},
		
	/**
	 *Name: drawLabel
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	drawLabel: function() {
			var placeholder=$('#graphdiv');
		var ctx = this.graphPlot.getCanvas().getContext("2d");
		ctx.globalAlpha = 1; 
			 for(var i=0;i<this.dataSeries1.length;i++){
		var o=this.graphPlot.pointOffset({x:this.dataSeries1[i][0],y:this.dataSeries1[i][1]});
		
	    placeholder.append('<div style=opacity:'+(1)+';filter:alpha(opacity=60);background-color:#333333;position:absolute;z-index:1000;left:' + (o.left - 15) + 'px;top:' + (o.top-23) + 'px;color:#cccccc;font-size:smaller">&nbsp;&nbsp;'+this.dataSeries1[i][1]+'&nbsp;&nbsp;</div>');
// 		
		// y+=13;
		 ctx.moveTo(o.left,o.top);
		 ctx.lineTo(o.left-7,o.top-7);
 		 ctx.lineTo(o.left+7,o.top-7);
		 ctx.lineTo(o.left,o.top);
		
		// ctx.lineTo(x+10,y);
		// ctx.lineTo(x,y+10);
		 ctx.fillStyle="#ff8c00";
		 ctx.fill();

	}
 },


	/**
	 *Name: setTrackerType
	 *Purpose: Sets Tracker type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setTrackerType : function(e) {
		this.healthDataTracker = $(e.target).parents(".tracker").attr('name');
	},


	/**
	 *Name: setMonthView
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setMonthView : function() {
		this.cmonth=new Date().getMonth()+1;
		this.cyear=new Date().getFullYear();
		//alert("setMonthView");
		$("#monthbutton").attr("src", "../../../assets/images/flot_images/month_orange.png");
		$("#weekbutton").attr("src", "../../../assets/images/flot_images/week_grey.png");
		$("#daybutton").attr("src", "../../../assets/images/flot_images/day_grey.png");
		$("#showLabel").attr("src", "../../../assets/images/flot_images/viewreadings_grey.png");
		this.monthView();
		if(this.healthDataTracker == "Blood Glucose"){
			this.drawGlucoseGraph();
		}
		else{
			this.drawWBMIGraph();
		}
		
	},
	
	/**
	 *Name: setWeekView
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setWeekView : function() {
		this.currentTime=new Date();
		//alert("setWeekView");
		$("#monthbutton").attr("src", "../../../assets/images/flot_images/month_grey.png");
		$("#weekbutton").attr("src", "../../../assets/images/flot_images/week_orange.png");
		$("#daybutton").attr("src", "../../../assets/images/flot_images/day_grey.png");
		$("#showLabel").attr("src", "../../../assets/images/flot_images/viewreadings_grey.png");
		this.weekView();
		if(this.healthDataTracker == "Blood Glucose"){
			this.drawGlucoseGraph();
		}
		else{
			this.drawWBMIGraph();
		}
		
	},
	
		/**
	 *Name: setDayView
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setDayView : function() {
		this.currentTime=new Date();		//alert("setDayView");
		$("#monthbutton").attr("src", "../../../assets/images/flot_images/month_grey.png");
		$("#weekbutton").attr("src", "../../../assets/images/flot_images/week_grey.png");
		$("#daybutton").attr("src", "../../../assets/images/flot_images/day_orange.png");
		$("#showLabel").attr("src", "../../../assets/images/flot_images/viewreadings_grey.png");
		this.dayView();
		if(this.healthDataTracker == "Blood Glucose"){
			//alert("BG");
			this.drawGlucoseGraph();
		}
		else{
			this.drawWBMIGraph();
		}
		
	},
	
	/**
	 *Name: weekView
	 *Purpose:sets the week view for the graph
	 *Params:
	 *Returns:
	 **/
	weekView : function() {
		this.currentView = "Week";
		if((this.currentTime.getFullYear())==(new Date().getFullYear()) &&  (this.currentTime.getMonth())==(new Date().getMonth()) && (this.currentTime.getDate())==(new Date().getDate()))
			$("#nextbutton").css("display", "none");
		var wday = this.currentTime.getDay();
		this.minWeekDate = new Date(this.currentTime.getTime() - (wday * 24 * 60 * 60 * 1000));
		this.minDateW = this.calculateDate(this.minWeekDate, 1);
		this.gTitleWmin = this.setTitle(this.minWeekDate, this.currentView);
		this.maxWeekDate = new Date(this.currentTime.getTime() + ((6 - wday + 1) * 24 * 60 * 60 * 1000));
		this.maxDateW = this.calculateDate(this.maxWeekDate, 1);
		this.gTitleWmax = this.setTitle(this.maxWeekDate, this.currentView);
		this.gTitleW = this.gTitleWmin + "-" + this.gTitleWmax;
		this.xMaxDateWeek = this.maxDateW;
		if(this.healthDataTracker == "Blood Glucose"){
		//alert("week button glucose");
		this.dataSeries1=this.calculateSingleLineDataPoints(this.seriesDataSet1, this.minDateW, this.maxDateW);
		this.plotGlucoseCords(this.dataSeries1);
		}
		else if(this.healthDataTracker == "Weight & BMI"){
			this.dataSeries1=this.calculateSingleLineDataPoints (this.seriesDataSet1,this.minDateW, this.maxDateW);
			this.dataSeries2=this.calculateSingleLineDataPoints (this.seriesDataSet2,this.minDateW, this.maxDateW);
			this.plotxMin=new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()).getTime() - (wday * 24 * 60 * 60 * 1000)-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
			this.plotxMax=new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate()).getTime()+ ((6 - wday + 1) * 24 * 60 * 60 * 1000)-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
			this.xTickInterval=[1,"day"];
			this.xTimeformat="%d";
			this.wbmiGraph();
		}
		else
		this.setGraph(this.currentView, this.minDateW, this.maxDateW, this.gTitleW);
	},
	/**
	 *Name: setTitle
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setTitle : function(lastDateM, currentView) {
		var months = new Array(12);
		months[0] = "January";
		months[1] = "February";
		months[2] = "March";
		months[3] = "April";
		months[4] = "May";
		months[5] = "June";
		months[6] = "July";
		months[7] = "August";
		months[8] = "September";
		months[9] = "October";
		months[10] = "November";
		months[11] = "December";

		if(currentView == "Month")
			return months[lastDateM.getMonth()] + "-" + lastDateM.getFullYear();
		else if(currentView == "Week")
			return months[lastDateM.getMonth()].substr(0, 3) + " " + lastDateM.getDate();
		else
			return months[lastDateM.getMonth()].substr(0, 3) + lastDateM.getDate() + "," + lastDateM.getFullYear();
	},
	/**
	 *Name: calculateDate
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	calculateDate : function(currentTime, minmax) {
		var month = currentTime.getMonth() + 1;
		var day = currentTime.getDate();
		var year = currentTime.getFullYear();
		var hours = currentTime.getHours();
		var minutes = currentTime.getMinutes();
		var seconds = currentTime.getSeconds();
		if(month <= 9)
			month = "0" + month;
		if(day <= 9)
			day = "0" + day;

		if(minmax == 1)
			return year + "-" + month + "-" + day + " " + "00" + ":" + "00";
		else
			return year + "-" + month + "-" + day + " " + "23" + ":" + "59";
	},
	/**
	 *Name: setGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setGraph : function(currentView, xMinDate, xMaxDate, gTitleM) {
		var xStringFormat = '';
		var yStringFormat = '%.0f';
		var xInterval = '';
		if(currentView == "Month") {
			xStringFormat = '%b %d';
			xInterval = '1 week';
		} else if(currentView == "Week") {
			xStringFormat = '%a';
			xInterval = '1 day';
		} else {
			xStringFormat = '%I %p';
			xInterval = '4 hour';
		}
		if(this.healthDataTracker == "Weight & BMI") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 400, 0, 0, xInterval, 50, xStringFormat, yStringFormat, gTitleM, '', 'Weight', 'BMI', "trackergraphs", "Weight & BMI");
		} else if(this.healthDataTracker == "Blood Pressure") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 200, 80, 40, xInterval, 40, xStringFormat, yStringFormat, gTitleM, '', 'Diastolic', 'Systolic', "trackergraphs", "Blood Pressure");
		} else if(this.healthDataTracker == "A1c") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 3, 10, 6, 1, xInterval, 1, xStringFormat, yStringFormat, gTitleM, '', 'A1c', null, "trackergraphs", "A1c");
			this.seriesDataSet2 = null;
		} else if(this.healthDataTracker == "LDL & HDL") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 200, 0, 0, xInterval, 40, xStringFormat, yStringFormat, gTitleM, '', 'LDL', 'HDL', "trackergraphs", "LDL & HDL");
		} else if(this.healthDataTracker == "Total Cholesterol") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 400, 0, 200, xInterval, 40, xStringFormat, yStringFormat, gTitleM, '', 'Cholesterol', null, "trackergraphs", "Total Cholesterol");
			this.seriesDataSet2 = null;
		} else if(this.healthDataTracker == "Triglycerides") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 160, 0, 150, xInterval, 50, xStringFormat, yStringFormat, gTitleM, '', 'Triglycerides', null, "trackergraphs", "Triglycerides");
			this.seriesDataSet2 = null;
		}
		this.dataPoints = this.calculateDataPoints(this.seriesDataSet1, this.seriesDataSet2, xMinDate, xMaxDate);
	},
	/**
	 *Name: setPlotOptions
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setPlotOptions : function(xMin, xMax, yMin, yMax, threshMin, threshMax, xTickInterval, yTickInterval, xstringFormat, ystringFormat, xLabel, yLabel, series1Label, series2Label, divname, graph_title) {
		var viewOptions = new Object();

		viewOptions['xMin'] = xMin;
		viewOptions['xMax'] = xMax;
		viewOptions['yMin'] = yMin;
		viewOptions['yMax'] = yMax;
		viewOptions['threshMin'] = threshMin;
		viewOptions['threshMax'] = threshMax;
		viewOptions['xTickInterval'] = xTickInterval;
		viewOptions['yTickInterval'] = yTickInterval;
		viewOptions['xstringFormat'] = xstringFormat;
		viewOptions['ystringFormat'] = ystringFormat;
		viewOptions['xLabel'] = xLabel;
		viewOptions['yLabel'] = yLabel;
		viewOptions['series1Label'] = series1Label;
		viewOptions['series2Label'] = series2Label;
		viewOptions['divname'] = divname;
		viewOptions['graph_title'] = graph_title;

		return viewOptions;
	},
	/**
	 *Name: calculateSingleLineDataPoints
	 *Purpose:
	 *Params:
	 *Returns:
	 **/

	calculateSingleLineDataPoints : function(trackerData, xMinDate, xMaxDate) {
		//alert("xmindate: "+xMinDate+"xmaxdate: "+xMaxDate);
		//alert("inside calculateSingleLineDataPoints");
		var graphCoordinates = new Array();
		var dataGlucose=new Array();
		var counterTrackerData = 0;
		var  dataSeries1=[];
		if(trackerData) {
		
			for(var counter = 0; counter < trackerData.length; counter++) {
				var usrtmeYear = parseInt((trackerData[counter].measurementDate).substr(0, 4), 10);
				var usrtmeMonth = parseInt((trackerData[counter].measurementDate).substr(4, 2), 10);
				var usrtmeDay1 = parseInt((trackerData[counter].measurementDate).substr(6, 2), 10);
				var usrtmeHours = parseInt((trackerData[counter].measurementDate).substr(9, 2), 10);
				var usrtmeMinutes = parseInt((trackerData[counter].measurementDate).substr(11, 2), 10);
				var usrtmeSeconds = parseInt((trackerData[counter].measurementDate).substr(13, 2), 10);

				var hlthData = parseInt(trackerData[counter].value);
				if(usrtmeMonth <= 9)
					usrtmeMonth = "0" + usrtmeMonth;
				if(usrtmeDay1 <= 9)
					usrtmeDay1 = "0" + usrtmeDay1;
				usrtmeDay = usrtmeYear + '-' + usrtmeMonth + '-' + usrtmeDay1 + ' ' + usrtmeHours + ':' + usrtmeMinutes;

				if(usrtmeDay >= xMinDate && usrtmeDay <= xMaxDate) {
					if(this.healthDataTracker == "Blood Glucose"){
						dataGlucose[counterTrackerData]=new Array();
					dataGlucose[counterTrackerData]=trackerData[counter];
					}
					else if(this.healthDataTracker == "Weight & BMI"){
						if(hlthData<1000)
						{dataSeries1[counterTrackerData]=new Array(2);
						dataSeries1[counterTrackerData][0]=(new Date(usrtmeYear,parseInt(usrtmeMonth,10)-1,parseInt(usrtmeDay1,10),usrtmeHours,usrtmeMinutes).getTime())-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
						dataSeries1[counterTrackerData][1]=hlthData;}
						else
							counterTrackerData--;
					}
					else{
					graphCoordinates[counterTrackerData] = new Array(2);
					graphCoordinates[counterTrackerData][0] = usrtmeDay;
					graphCoordinates[counterTrackerData][1] = hlthData;
					if(this.maxHealthDataValue < hlthData)
						this.maxHealthDataValue = hlthData;
					}
					counterTrackerData = counterTrackerData + 1;
				}
			}
		}
		if(this.healthDataTracker == "Blood Glucose"){
			return dataGlucose;
		}
		else
			return dataSeries1;
	},

	/**
	 *Name: dayView
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	dayView : function(e) {
		this.currentView = "Day";
		if((this.currentTime.getFullYear())==(new Date().getFullYear()) &&  (this.currentTime.getMonth())==(new Date().getMonth()) && (this.currentTime.getDate())==(new Date().getDate()))
			$("#nextbutton").css("display", "none");
		this.minDayDate = new Date(this.currentTime.getTime());
		this.minDateD = this.calculateDate(this.minDayDate, 1);
		this.gTitleD = this.setTitle(this.minDayDate, this.currentView);
		$("#spantitle span").text(this.gTitleD);
		$("#rightbutton").css("display", "none");
		this.maxDayDate = new Date(this.currentTime.getTime() + (24 * 60 * 60 * 1000));
		this.maxDateD = this.calculateDate(this.maxDayDate, 1);
		this.xMaxDateDay = this.maxDateD;
		if(this.healthDataTracker == "Blood Glucose"){
		//alert("day button glucose");
		this.dataSeries1=this.calculateSingleLineDataPoints(this.seriesDataSet1, this.minDateD, this.maxDateD);
		this.plotGlucoseCords(this.dataSeries1);
		}
		else if(this.healthDataTracker == "Weight & BMI"){
			this.dataSeries1=this.calculateSingleLineDataPoints (this.seriesDataSet1, this.minDateD, this.maxDateD);
			this.dataSeries2=this.calculateSingleLineDataPoints (this.seriesDataSet2, this.minDateD, this.maxDateD);
			this.plotxMin=new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate(),00,00).getTime()-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
			this.plotxMax=new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate(),00,00).getTime()+ (24 * 60 * 60 * 1000)-((new Date(this.currentTime.getFullYear(),this.currentTime.getMonth(),this.currentTime.getDate())).getTimezoneOffset()*60*1000);
			this.xTickInterval=[4,"hour"];
			this.xTimeformat="%H:%M";
			this.wbmiGraph();
		}
		else{
		this.setGraph(this.currentView, this.minDateD, this.maxDateD, this.gTitleD);
		this.plotGraph(this.getPlotOptions, this.dataPoints);
		}
	},
	/**
	 *Name: plotGlucoseCords
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	plotGlucoseCords : function(glucosedata) {
		var storeCords = new Array();
		var plotData = glucosedata;
		for(var counter = 0; counter < plotData.length; counter++) {
			var userTime = parseInt((plotData[counter].measurementDate).substr(9, 2), 10);
			var healthData = parseInt(plotData[counter].value);
			storeCords[counter] = new Array(2)
			if(userTime >= 6 && userTime < 9)
				storeCords[counter][0] = 2;
			else if(userTime >= 9 && userTime < 11)
				storeCords[counter][0] = 6;
			else if(userTime >= 11 && userTime < 14)
				storeCords[counter][0] = 10;
			else if(userTime >= 14 && userTime < 17)
				storeCords[counter][0] = 14;
			else if(userTime >= 17 && userTime < 20)
				storeCords[counter][0] = 18;
			else if(userTime >= 20 && userTime < 23)
				storeCords[counter][0] = 22;
			else if(userTime >= 23 || userTime < 6)
				storeCords[counter][0] = 26;

			storeCords[counter][1] = healthData;
		}
		var groupSixAm = 0, groupNineAm = 0, groupElevenAm = 0, groupTwoPm = 0, groupSixPm = 0, groupEightPm = 0, groupElevenPm = 0;
		var countGroupSixAm = 0, countGroupNineAm = 0, countGroupElevenAm = 0, countGroupTwoPm = 0, countGroupSixPm = 0, countGroupEightPm = 0, countGroupElevenPm = 0;
		this.plotCords = storeCords;
		var plotCords_length = this.plotCords.length;
		for(var i = 0; i < plotCords_length; i++) {
			if(this.plotCords[i][0] == 2) {
				groupSixAm = groupSixAm + this.plotCords[i][1];
				countGroupSixAm = countGroupSixAm + 1;
			} else if(this.plotCords[i][0] == 6) {
				groupNineAm = groupNineAm + this.plotCords[i][1];
				countGroupNineAm = countGroupNineAm + 1;
			} else if(this.plotCords[i][0] == 10) {
				groupElevenAm = groupElevenAm + this.plotCords[i][1];
				countGroupElevenAm = countGroupElevenAm + 1;
			} else if(this.plotCords[i][0] == 14) {
				groupTwoPm = groupTwoPm + this.plotCords[i][1];
				countGroupTwoPm = countGroupTwoPm + 1;
			} else if(this.plotCords[i][0] == 18) {
				groupSixPm = groupSixPm + this.plotCords[i][1];
				countGroupSixPm = countGroupSixPm + 1;
			} else if(this.plotCords[i][0] == 22) {
				groupEightPm = groupEightPm + this.plotCords[i][1];
				countGroupEightPm = countGroupEightPm + 1;
			} else {
				groupElevenPm = groupElevenPm + this.plotCords[i][1];
				countGroupElevenPm = countGroupElevenPm + 1;
			}
		}
		this.avgCords = [[2, groupSixAm / countGroupSixAm], [6, groupNineAm / countGroupNineAm], [10, groupElevenAm / countGroupElevenAm], [14, groupTwoPm / countGroupTwoPm], [18, groupSixPm / countGroupSixPm], [22, groupEightPm / countGroupEightPm], [26, groupElevenPm / countGroupElevenPm]];

    this.glucoseData = [

        { 	
        	data: this.plotCords,
        	//label: 'Data',
        	color: 'white', 
        	points: { 
        		symbol: "cross",
        		show: true,
        		radius: 3
        		}
		},
		{ 
			data: this.avgCords, 
			//label: 'Average',
			color: 'orange',
			points: { 
				symbol: "square",
				show: true,
        		radius: 4
				} 
		}
    ];
	this.glucosePlotOptions={
        xaxis: {
        	min: 0, 
            max: 28,
            tickSize: 4,
            labelWidth: -25, 
            ticks: [[0, "6am-9am"], [4, "9am-11am"], [8, "11am-2pm"], [12,"2pm-5pm"],[16,"5pm-8pm"],[20,"8pm-11pm"],[24,"11pm-6am"],[28,""]]
        },
        yaxis: {
        	min: 0, 
            //max: 350,
            tickSize: 50
        },
        legend : {
				show : false,
				//container : '#legendcontainer',
				backgroundOpacity : 0
			},
		series : {
			grow:{
				active: true,
	            valueIndex: 1,
	           // stepDelay: 20,
	            steps:30,
	            stepMode: "maximum",
	            stepDirection: "up"
	    	}
		},
        grid: { 
        	//hoverable: true 
        	color: '#FFFFFF',
        	backgroundColor: '#463E41',
        	borderColor: '#463E41'
        	//tickColor: '#FFFFFF'
        },
        selection: {
        	mode: "y",
        	color: '#C38EC7'
        }
        };
	},
	
	/**
	 *Name: drawGlucoseGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	drawGlucoseGraph : function() {
		var plot_data=$.plot($("#glucosegraph"), this.glucoseData, this.glucosePlotOptions);
    	plot_data.setSelection({yaxis: {from: 80, to: 120}});
	},

	/**
	 *Name: setHealthData
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setHealthData : function(output) {
		var response = JSON.parse(output.responseText);
		var modelData = JSON.stringify(response);
		mHealth.models.HealthDataModel.customFromJSON(modelData);
	},

	/**
	 *Name: plotSingleGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	// plotSingleGraph : function(healthDataValue) {
		// this.seriesDataSet1 = healthDataValue;
		// this.showGraph();
		// location.href = "gyro://loadChart?";
		// $.mobile.changePage('showgraph.html');
	// }

});
