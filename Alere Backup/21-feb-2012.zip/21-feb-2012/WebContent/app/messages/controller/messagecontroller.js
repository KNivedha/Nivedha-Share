/**
 * Controller : MessageController
 * This is the controller to do the  logic of message
 **/
mHealth.controllers.MessageController = Spine.Controller.sub({
	el : 'body',
	elements : {},

	tabbarloaded : false,

	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		'pagebeforeshow #home' : 'showMessages',
		'click #messageCenter' : 'loadMessageTab',
		'pagebeforeshow #showMessage' : 'getMessages'
	},
	/**
	 * Name    : messageSuccess
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	messageSuccess : function(output) {
		var response = output.responseText;
		var bundleMessage = JSON.parse(response);

		var messages = JSON.stringify(bundleMessage[0].Message);
		mHealth.models.MessageModel.customFromJSON(messages);

	},
	/**
	 * Name    : showMessages
	 * Purpose : Load the message from the Model and Show the Result in the Message Center of the Home Tab
	 * Params  : --
	 * Return  : --
	 **/
	showMessages : function() {
		var len = mHealth.models.MessageModel.count();

		var messages_val = mHealth.models.MessageModel.all();

		if(len > 0) {

			$('#messages_div').html(_.template($('#messageList').html(), {
				messages_val : messages_val
			}));
			$('#home').trigger('create');
		} else {
			var message = "There are no messages for you to view at this time.";
			$('#messages_div').text(message);
		}
		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}
	},
	/**
	 * Name    : getMessages
	 * Purpose : Load the message from the Model and Show the Result in the  Message Tab
	 * Params  : --
	 * Return  : --
	 **/
	getMessages : function() {
		var len = mHealth.models.MessageModel.count();

		var messages_val = mHealth.models.MessageModel.all();

		if(len < 0) {
			messages_val = "There are no messages for you to view at this time.";
		}

		$('#message').html(_.template($('#messageList1').html(), {
			messages_val : messages_val
		}));
		$('#showMessage').trigger('create');

	},
	
	/**
	 * Name    : loadMessageTab
	 * Purpose : Highlight the Message when we redirect the shorcut from the Home to message TAB.
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageTab : function() {

		$.mobile.changePage("../../messages/view/showmessage.html");
		location.href = "tabbar://loadMessages?";
	}
});
