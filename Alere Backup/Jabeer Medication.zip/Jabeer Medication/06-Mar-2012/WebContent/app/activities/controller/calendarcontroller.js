/**
  *Controller : CalendarController
  *Controller to do Calendar functionality. 
  **/
mHealth.controllers.CalendarController = Spine.Controller.sub({
	el : 'body',
	events : {
		'click #calendar_save' : 'getCalendarData',
	},
	
	
	/**
	 * Name    : getCalendarData
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	getCalendarData : function() {
		var title, sDate, eDate;
		title = $('#eventName').val();
		sDate = $('#startDate').val();
		eDate = $('#endDate').val();
		mHealth.util.callCalendarEvent(title,sDate,eDate);
	

	}
});
