/**
 *Controller : ActivityController
 *Controller to do Activity Tab functionality.
 **/

mHealth.controllers.ActivityController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	subActivityView : "",
	activity : null,
	activityDetailRecord : null,
	spaceviewzone : null,
	events : {

		'pagebeforeshow #showActivity' : 'showActivity',
		'click .detailActivity' : 'getSubActivity',
		'pagebeforeshow #detailActivity' : 'showDetailActivity',
		'pagebeforeshow #calendarPage' : 'showCalendar',
		'click #calendarSave' : 'getCalendarData',
		'click #challengesShortCut' : 'getActivity'

	},

	/**
	 *Name        : showDetailActivity
	 *Purpose
	 *Params
	 *Returns
	 **/
	showDetailActivity : function() {
		$('#detailActivity_div').html(_.template($('#detailActivityDataList').html(), {
			activityDetailRecord : mHealth.ActivityControllerObject.activityDetailRecord
		}));
		$('#detailActivity').trigger('create');
	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showActivity : function() {

		$('#activityTitle').text(this.activity[0].space[0].title);

		if(this.activity[0].zone.length > 1) {

			$('#activity_zone').show();
			var activityZone = this.activity[0].zone[0].isInset;

			$('#activity_zone').html(_.template($('#navDataList').html(), activityZone));
		}

		var activityView = this.activity[0].view;

		$('#activity_div').html(_.template($('#activityDataList').html(), {
			activityView : activityView
		}));
		$('#showActivity').trigger('create');
	},
	/**
	 *Name: getSubActivity
	 *Purpose: On click the View of the Activity, the Function will be
	 *Params
	 *Returns
	 **/
	getSubActivity : function(event) {
		var view = event.target;
		selectedViewName = $(view).parents('li').children('div').children('div').children('a').children('h3').text();
		mHealth.models.SpaceViewZoneModel.each(function(record) {
			if(record.pageName === 'Activity') {
				for( i = 0; i < record.view.length; i++) {
					if(record.view[i].title.trim() === selectedViewName.trim()) {
						this.subActivityView = record.view[i];
						mHealth.ActivityControllerObject.activityDetailRecord = this.subActivityView;
						break;
					}
				}
			}
		});
		//this.getAssessmentData(selectedViewName);
		$.mobile.changePage("detailactivity.html");

	},
	
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	getActivity : function() {
		if(this.spaceviewzone != null) {
			mHealth.util.showMask();
			var isExists = mHealth.models.SpaceViewZoneModel.each(function(record) {
				if(record.pageName === 'Activity') {
					return true;
				}
			});
			if(isExists !== true) {
				var body = mHealth.recommendation.createRecommendationRequestJSON("", "", "1003");
				this.proxy(this.service.postRequest(mHealth.env.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.recommendationFailure), true));

			}
		}
		else
		{
		$.mobile.changePage("../../activities/view/showactivity.html");
		//location.href = "tabbar://loadActivities?";
			
		}
	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showCalendar : function() {
		$("#eventName").val(selectedViewName);
		$('#startDate').scroller({
			preset : 'datetime',
			theme : 'ios'
		});
		$('#endDate').scroller({
			preset : 'datetime',
			theme : 'ios'
		});
	},
	/**
	 * Name    : getCalendarData
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	getCalendarData : function() {
		var title, startDate, endDate;
		title = $('#eventName').val();
		startDate = $('#startDate').val();
		endDate = $('#endDate').val();
		mHealth.util.callCalendar(title, startDate, endDate);
		$.mobile.changePage("../../activities/view/detailactivity.html");

	},
	/**
	 * Name    : setActivityData
	 * Purpose : Method to set the value 
	 * Params  : --
	 * Return  : --
	 **/
	setActivityData : function(output)
	{
		
		var response, recommandationData, spaceData, zoneData, viewData;
		response = output.responseText;
		recommandationData = JSON.parse(response);
		spaceData = JSON.stringify(recommandationData.Space);
		zoneData = JSON.stringify(recommandationData.Zone);
		viewData = JSON.stringify(recommandationData.View);
		spaceviewzone = new mHealth.models.SpaceViewZoneModel({

			pageName : 'Activity',
			space : mHealth.models.SpaceModel.fromJSON(spaceData),
			view : mHealth.models.ViewModel.fromJSON(viewData),
			zone : mHealth.models.ZoneModel.fromJSON(zoneData)

		});
		spaceviewzone.save();
		mHealth.ActivityControllerObject.activity = mHealth.models.SpaceViewZoneModel.select(function(record) {

			
			if(record.pageName === 'Activity') {

				return record;
			}
		});
	},
	/**
	 *Name: recommendationSuccess
	 *Purpose: After getting the response from the recommandation Service, the functon will parse the space, View and ZOne
	 Set the value in the respective model.
	 *Params: output
	 *Returns: null
	 **/
	recommendationSuccess : function(output) {

		this.proxy(this.setActivityData(output));
		
		$.mobile.changePage("../../activities/view/showactivity.html");
		mHealth.util.hideMask();
		//location.href = "tabbar://loadActivities?";
	},
	/**
	 *Name : recommendationFailure
	 *Purpose: On the Failure of the recommandation service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.hideMask();

	}
});
