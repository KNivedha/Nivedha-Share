//
//  Calendar.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Calendar.h"
#import <EventKit/EventKit.h>
@implementation Calendar
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    NSDate *startdate ;
    NSDate *enddate ;
    
    //***********setting date format*********
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
	[dateFormatter setDateFormat:@"MM/dd/yyyy hh:mm a"];
    
    //*********** setting event store*********
    
    EKEventStore *eventStore = [[EKEventStore alloc] init];
    
    //************adding events****************
    EKEvent *event  = [EKEvent eventWithEventStore:eventStore];
     NSLog(@"storing in calander startdate : %@ enddate : %@",[parameters objectForKey:@"startDate"],[parameters objectForKey:@"endDate"]);
    event.title =[parameters objectForKey:@"eventTitle"] ;
    startdate =[dateFormatter dateFromString:[parameters objectForKey:@"startDate"]];
	enddate = [dateFormatter dateFromString:[parameters objectForKey:@"endDate"]];
    NSLog(@"storing in calander startdate: %@ enddate : %@",enddate,startdate);
    event.startDate =  startdate;
    event.endDate   = enddate;
    
    [event setCalendar:[eventStore defaultCalendarForNewEvents]];
    
    NSError *err;
    [eventStore saveEvent:event span:EKSpanThisEvent error:&err];  
}
@end
