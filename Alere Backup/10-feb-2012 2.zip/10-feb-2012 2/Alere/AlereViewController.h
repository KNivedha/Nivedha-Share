//
//  AlereViewController.h
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Calendar.h"
#import "EMail.h"
#import "Devices.h"
#import "TabBar.h"
#import "Orientation.h"


@protocol DeviceDelegate; 

@interface AlereViewController : UIViewController <UIWebViewDelegate>
{
    IBOutlet UITabBar* baseTabBar;
    IBOutlet UIWebView* webView;
    NSMutableData* responseData;
    NSString* token;
    NSString* eventname;
    BOOL landscp;
    BOOL returnType;
    BOOL rotated;
   
    BOOL cameBack;
    BOOL enteredGraph;
    BOOL resized;
    
		BOOL enteredGlucose;
    NSMutableDictionary* pluginObjects;
    //**********plugin objects***************
    Calendar* calObj;
    EMail* emailObj;
    Devices* deviceObj;
    Orientation* orientationObj;
    TabBar* tabBarObj;
    

    
}
@property(nonatomic,retain)IBOutlet UIWebView* webView;
@property(nonatomic,retain)IBOutlet UITabBar* baseTabBar;
@property(nonatomic)BOOL rotated;
@property(nonatomic)BOOL landscp;
@property(nonatomic)BOOL insideTabBar;
@property(nonatomic)BOOL enteredGlucose;
@property(nonatomic)BOOL enteredGraph;
@property(nonatomic)BOOL resized;

-(IBAction)clickd:(id)sender;

@end

