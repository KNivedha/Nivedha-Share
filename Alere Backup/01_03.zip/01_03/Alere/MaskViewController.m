//
//  MaskViewController.m
//  TreatmentCostCalculator
//
//  Created by virtusa virtusa on 2/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MaskViewController.h"
static MaskViewController *sharedMyMaskController = nil;
@implementation MaskViewController

+ (id)sharedMaskController {
    @synchronized(self) {
        if(sharedMyMaskController == nil)
            sharedMyMaskController = [[super allocWithZone:NULL] init];
    }
    
    CGRect frame = sharedMyMaskController.view.frame;
    frame.size.height = 420;
    sharedMyMaskController.view.frame = frame;
    NSLog(@"height: %f", sharedMyMaskController.view.frame.size.height);
    NSLog(@"width: %f", sharedMyMaskController.view.frame.size.width);
    return sharedMyMaskController;
}
+ (id)allocWithZone:(NSZone *)zone {
    return [[self sharedMaskController] retain];
}
- (id)copyWithZone:(NSZone *)zone {
    return self;
}
- (id)retain {
    return self;
}
- (unsigned)retainCount {
    return UINT_MAX; //denotes an object that cannot be released
}
- (oneway void)release {
    
}
- (id)autorelease {
    return self;
}
- (id)init {
    if (self = [super init]) {
       
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:nil];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
