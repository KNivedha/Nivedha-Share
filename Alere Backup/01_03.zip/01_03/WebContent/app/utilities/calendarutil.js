function openDate() {

var now = new Date();
var days = { };
var years = { };
var months = { 1: '01', 2: '02', 3: '03', 4: '04', 5: '05', 6: '06', 7: '07', 8: '08', 9: '09', 10: '10', 11: '11', 12: '12' };
//	var hours={ };
//    var minutes ={ };
//    //var seconds= { };
//     var format= {1:'AM',2:'PM'};
//    for(var i=0;i<25;i+=1){
//        hours[i]=i;  
//    }
//    for(var i=0;i<61;i+=1){
//        minutes[i]=i;  
//    }
//    for(var i=0;i<61;i+=1){
//        seconds[i]=i;  
//    }
for( var i = 1; i < 32; i += 1 ) {
days[i] = i;
}

for( i = now.getFullYear()-100; i < now.getFullYear()+1; i += 1 ) {
years[i] = i;
}
SpinningWheel.addSlot(months, 'right', 4);
    SpinningWheel.addSlot(days, 'right', 12);
SpinningWheel.addSlot(years, 'right', 1999);


//	SpinningWheel.addSlot(hours, '', 4);
//    SpinningWheel.addSlot(minutes, '', 23);
//    SpinningWheel.addSlot(format, '', 2);
//    
SpinningWheel.setCancelAction(cancel);
SpinningWheel.setDoneAction(done);

SpinningWheel.open();
}
function done() {

results = SpinningWheel.getSelectedValues();
start=results.values.join('/');
$('#startDate').val(start);
$('#dt').val(start);
$('#diagnosisDate').val(start);
SpinningWheel.close();
}

function cancel() {
SpinningWheel.close();
}
function openDate1() {

var now = new Date();
var days = { };
var years = { };
var months = { 1: '01', 2: '02', 3: '03', 4: '04', 5: '05', 6: '06', 7: '07', 8: '08', 9: '09', 10: '10', 11: '11', 12: '12' };
//	var hours={ };
//    var minutes ={ };
//    var format= {1:'AM',2:'PM'};
//    for(var i=0;i<13;i+=1){
//        hours[i]=i;  
//    }
//    for(var i=0;i<61;i+=1){
//        minutes[i]=i;  
//    }
//    for(var i=0;i<61;i+=1){
//        seconds[i]=i;  
//    }
for( var i = 1; i < 32; i += 1 ) {
days[i] = i;
}

for( i = now.getFullYear()-100; i < now.getFullYear()+1; i += 1 ) {
years[i] = i;
}

SpinningWheel.addSlot(years, 'right', 1999);
SpinningWheel.addSlot(months, '', 4);
SpinningWheel.addSlot(days, 'right', 12);
//	SpinningWheel.addSlot(hours, '', 4);
//    SpinningWheel.addSlot(minutes, '', 23);
//    SpinningWheel.addSlot(format, '', 1);

SpinningWheel.setCancelAction(cancel1);
SpinningWheel.setDoneAction(done1);

SpinningWheel.open();
}
function done1() {

results1 = SpinningWheel.getSelectedValues();
end = results1.values.join('-');
$('#endDate').val(end);
SpinningWheel.close();
}

function cancel1() {

//$('#endDate').val('');
SpinningWheel.close();


}

//Trackers track DatePicker
function openDate2() {
    
	var now = new Date();
	var days = { };
	var years = { };
	var months = { 1: '01', 2: '02', 3: '03', 4: '04', 5: '05', 6: '06', 7: '07', 8: '08', 9: '09', 10: '10', 11: '11', 12: '12' };
	for( var i = 1; i < 32; i += 1 ) {
		days[i] = i;
	}
    
	for( i = now.getFullYear()-100; i < now.getFullYear()+1; i += 1 ) {
		years[i] = i;
	}
    
	SpinningWheel.addSlot(years, 'right', 1999);
	SpinningWheel.addSlot(months, '', 4);
	SpinningWheel.addSlot(days, 'right', 12);
    //	SpinningWheel.addSlot(hours, '', 4);
    //    SpinningWheel.addSlot(minutes, '', 23);
    //    SpinningWheel.addSlot(format, '', 1);
    
	SpinningWheel.setCancelAction(cancel1);
	SpinningWheel.setDoneAction(done1);
	
	SpinningWheel.open();
}
function done1() {
    //alert("Done1");
    results1 = SpinningWheel.getSelectedValues();
    end = results1.values.join('-');
    //alert("inside done1:"+results1.values[1])
    $('#selectDate').val(end);
    SpinningWheel.close();
}

function cancel1() {
    //alert('Cancelled');
    //$('#endDate').val('');
    SpinningWheel.close();
    
    
}