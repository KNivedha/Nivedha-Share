mHealth.models.MessageModel = Spine.Model.sub();
// mHealth.models.MessageModel.configure('MessageModel','messageID',
// 'msgTypeID','title','sentDate','msgFolderID','healthTopicID',
// 'isRead','isReplied','isUrgent');

mHealth.models.MessageModel.configure("MessageModel", "messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "sentDate", "deliveredDate", "expiredDate", "sections");

// mHealth.models.MessageDetailsModel = Spine.Model.sub();
// mHealth.models.MessageDetailsModel.configure("MessageDetailsModel", "messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "sentDate", "deliveredDate", "expiredDate", "summary", "sections");

// mHealth.models.SectionModel = Spine.Model.sub();
// mHealth.models.SectionModel.configure("SectionModel", "videos", "messageText", "questionnaire", "articles");

// mHealth.models.QuestionnaireModel = Spine.Model.sub();
// mHealth.models.QuestionnaireModel.configure("QuestionnaireModel", "learnMore", "introCopy", "qSections");

// mHealth.models.QuestionSectionModel = Spine.Model.sub();
// mHealth.models.QuestionSectionModel.configure('QuestionSectionModel', 'questions', 'id', 'seq', 'learnMore', 'ImageURL');

// mHealth.models.MessageQuestionModel = Spine.Model.sub();
// mHealth.models.MessageQuestionModel.configure('MessageQuestionModel', 'id', 'seq', 'questionText', 'answerType', 'ImageURL', 'answerOptions', 'learnMore');

// mHealth.models.AnswerModel = Spine.Model.sub();
// mHealth.models.AnswerModel.configure('AnswerModel', 'id', 'seq', 'Label', 'ImageURL');

/*  Commentted out the above model creation as for new json format*/
mHealth.models.MessageDetailsResponse = Spine.Model.sub();
mHealth.models.MessageDetailsResponse.configure("MessageDetailsResponse", "transactionID", "message");

mHealth.models.MessageDetailsModel = Spine.Model.sub();
//mHealth.models.MessageDetailsModel.configure("MessageDetailsModel", "messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "sentDate", "deliveredDate", "expiredDate", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "cachedPersonalizedMessage");

mHealth.models.MessageDetailsModel.configure("MessageDetailsModel","messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "sentDate", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "cachedPersonalizedMessage");

mHealth.models.MessageSectionModel = Spine.Model.sub();
mHealth.models.MessageSectionModel.configure("MessageSectionModel", "messageText", "suggestedCalendarEvent", "questionnaire", "articles");

mHealth.models.QuestionnaireModel = Spine.Model.sub();
mHealth.models.QuestionnaireModel.configure("QuestionnaireModel", "id", "introCopy", "qGroups");

mHealth.models.QuestionGroupModel = Spine.Model.sub();
mHealth.models.QuestionGroupModel.configure('QuestionGroupModel', "id", "seq", "type", "title", "questions");

mHealth.models.MessageQuestionModel = Spine.Model.sub();
mHealth.models.MessageQuestionModel.configure('MessageQuestionModel', "id", "seq", "questionText", "answerType", "defaultAnswer", "answerOptions");

mHealth.models.QuestionMsgModel = Spine.Model.sub();
mHealth.models.QuestionMsgModel.configure('QuestionMsgModel', "id", "seq", "questionText", "answerType", "defaultAnswer", "answerOptions");

mHealth.models.MessageAnswerModel = Spine.Model.sub();
mHealth.models.MessageAnswerModel.configure('MessageAnswerModel', 'id', 'seq', 'label');
messageHardBody = [{
	"GETMessageDetailsResponse" : {
		"transactionID" : "String",
		"message" : {
			"messageID" : 9999,
			"msgTypeID" : 1,
			"senderID" : "virtual Coach",
			"senderTypeID" : 2,
			"recipientID" : 27458,
			"recipientTypeID" : 1,
			"concernedPartyID" : 1,
			"concernedPartyTypeID" : 1,
			"title" : "Diabetes MiniAssessment",
			"conversationID" : 0,
			"sentDate" : "2012-02-20 00:00:00",
			"deliveredDate" : "2012-02-20 00:00:00",
			"expiredDate" : "nil",
			"msgFolderID" : 1,
			"healthTopicID" : 0,
			"msgTemplateID" : 0,
			"targetPresentationLayerID" : 1,
			"isRead" : false,
			"isReplied" : false,
			"isUrgent" : false,
			"cachedPersonalizedMessage" : {
				"messageContent" : {
					"summary" : "String",
					"sections" : {
						"section" : {
							"messageText" : "String",
							"questionnaire" : {
								"id" : 100001,
								"introCopy" : "Diabetes Mini Assessment",
								"qGroups" : {
									"qGroup" : [{
										"id" : 300001,
										"seq" : 1,
										"type" : "text",
										"title" : "text",
										"questions" : {
											"question" : {
												"id" : 8001,
												"seq" : 1,
												"questionText" : "are you currently affected by diabetes? If so, which type?",
												"answerType" : "FixedListSingleSelect",
												"defaultAnswer" : 99001,
												"answerOptions" : {
													"answerOption" : [{
														"id" : 99001,
														"seq" : 1,
														"label" : "type I"
													}, {
														"id" : 99002,
														"seq" : 2,
														"label" : "type II"
													}, {
														"id" : 99003,
														"seq" : 3,
														"label" : "Unknown"
													}, {
														"id" : 99004,
														"seq" : 4,
														"label" : "I don't have diabetes"
													}]
												}
											}
										}
									}, {
										"id" : 300002,
										"seq" : 2,
										"type" : "text",
										"title" : "text",
										"questions" : {
											"question" : {
												"id" : 8002,
												"seq" : 2,
												"questionText" : "How do you manage your diabetes?",
												"answerType" : "FixedListSingleSelect",
												"answerOptions" : {
													"answerOption" : [{
														"id" : 99005,
														"seq" : 1,
														"label" : "Diet and exercise"
													}, {
														"id" : 99006,
														"seq" : 2,
														"label" : "Oral medication"
													}, {
														"id" : 99007,
														"seq" : 3,
														"label" : "insulin or insulin pump"
													}]
												}
											}
										}
									}, {
										"id" : 300003,
										"seq" : 3,
										"type" : "text",
										"title" : "text",
										"questions" : {
											"question" : {
												"id" : 8003,
												"seq" : 3,
												"questionText" : "What glucometer do you predominantly use?",
												"answerType" : "FixedListSingleSelect",
												"answerOptions" : {
													"answerOption" : [{
														"id" : 99008,
														"seq" : 1,
														"label" : "None"
													}, {
														"id" : 99009,
														"seq" : 2,
														"label" : "glucometer ABC"
													}, {
														"id" : 99010,
														"seq" : 3,
														"label" : "glucometer XYZ"
													}]
												}
											}
										}
									}, {
										"id" : 300004,
										"seq" : 4,
										"type" : "Form_Ht_Wt",
										"title" : "Please Enter your Height and Weight",
										"questions" : {
											"question" : [{
												"id" : 8004,
												"seq" : 1,
												"questionText" : "select Date",
												"answerType" : "Date"
											}, {
												"id" : 8005,
												"seq" : 2,
												"questionText" : "select Height",
												"answerType" : "height"
											}, {
												"id" : 8006,
												"seq" : 3,
												"questionText" : "select Weight",
												"answerType" : "Weight"
											}]
										}
									}, {
										"id" : 300005,
										"seq" : 5,
										"type" : "Form_A1c",
										"title" : "Please enter your latest Hemoglobin A1c test result",
										"questions" : {
											"question" : [{
												"id" : 8007,
												"seq" : 1,
												"answerType" : "FixedListSingleSelect",
												"answerOptions" : {
													"answerOption" : [{
														"id" : 100001,
														"seq" : 1,
														"label" : "I have never had the test completed"
													}, {
														"id" : 100002,
														"seq" : 2,
														"label" : "I have had the test but don't remember the values"
													}, {
														"id" : 100003,
														"seq" : 3,
														"label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
													}]
												}
											}, {
												"id" : 8008,
												"seq" : 2,
												"questionText" : "select Date",
												"answerType" : "Date"
											}, {
												"id" : 8009,
												"seq" : 3,
												"questionText" : "Enter A1c",
												"answerType" : "Float"
											}]
										}
									}, {
										"id" : 300006,
										"seq" : 6,
										"type" : "Form_CholesterolLipid",
										"title" : "Please enter your latest Cholesterol or Lipid Panel test",
										"questions" : {
											"question" : [{
												"id" : 8010,
												"seq" : 1,
												"answerType" : "FixedListSingleSelect",
												"answerOptions" : {
													"answerOption" : [{
														"id" : 100001,
														"seq" : 1,
														"label" : "I have never had the test completed"
													}, {
														"id" : 100002,
														"seq" : 2,
														"label" : "I have had the test but don't remember the values"
													}, {
														"id" : 100003,
														"seq" : 3,
														"label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
													}]
												}
											}, {
												"id" : 8011,
												"seq" : 2,
												"questionText" : "select Date",
												"answerType" : "Date"
											}, {
												"id" : 8012,
												"seq" : 3,
												"questionText" : "Enter LDL",
												"answerType" : "decimal"
											}, {
												"id" : 8013,
												"seq" : 4,
												"questionText" : "Enter HDL",
												"answerType" : "decimal"
											}, {
												"id" : 8014,
												"seq" : 5,
												"questionText" : "Enter Triglycerides",
												"answerType" : "decimal"
											}, {
												"id" : 8015,
												"seq" : 6,
												"questionText" : "Enter Total Cholesterol",
												"answerType" : "decimal"
											}]
										}
									}, {
										"id" : 300007,
										"seq" : 7,
										"type" : "Form_DiabetesLabs",
										"title" : "Please tell us about your latest lab tests for Diabetes",
										"questions" : {
											"question" : [{
												"id" : 8016,
												"seq" : 1,
												"questionText" : "Dilated Retinal Exam",
												"answerType" : "FixedListSingleSelect",
												"answerOptions" : {
													"answerOption" : [{
														"id" : 100001,
														"seq" : 1,
														"label" : "I have never had the test completed"
													}, {
														"id" : 100003,
														"seq" : 2,
														"label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
													}]
												}
											}, {
												"id" : 8017,
												"seq" : 2,
												"questionText" : "select Date",
												"answerType" : "Date"
											}, {
												"id" : 8018,
												"seq" : 3,
												"questionText" : "Dilated Retinal Exam",
												"answerType" : "FixedListSingleSelect",
												"answerOptions" : {
													"answerOption" : [{
														"id" : 100001,
														"seq" : 1,
														"label" : "I have never had the test completed"
													}, {
														"id" : 100003,
														"seq" : 2,
														"label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
													}]
												}
											}, {
												"id" : 8019,
												"seq" : 4,
												"questionText" : "select Date",
												"answerType" : "Date"
											}, {
												"id" : 8020,
												"seq" : 5,
												"questionText" : "Dilated Retinal Exam",
												"answerType" : "FixedListSingleSelect",
												"answerOptions" : {
													"answerOption" : [{
														"id" : 100001,
														"seq" : 1,
														"label" : "I have never had the test completed"
													}, {
														"id" : 100003,
														"seq" : 2,
														"label" : "I have had the test and remember approximately the date it was completed and the value of the test result"
													}]
												}
											}, {
												"id" : 8021,
												"seq" : 6,
												"questionText" : "select Date",
												"answerType" : "Date"
											}]
										}
									}]
								}
							},
							"videos" : "text",
							"articles" : "text"
						}
					}
				}
			}
		}
	}
}];
