//
//  AlereViewController.m
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "AlereViewController.h"
#import <EventKit/EventKit.h>
#import "AlereAppDelegate.h"
#import "Reachability.h"
#import "OpenUrl.h"
#import "Calendar.h"
#import "EMail.h"
#import "Devices.h"
#import "TabBar.h"
#import "Orientation.h"
#import "ForceQuit.h"
#import "NetworkCheck.h"

#define DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) / 180.0 * M_PI)
@implementation AlereViewController
@synthesize webView,rotated,landscp,insideTabBar,enteredGraph,resized,baseTabBar,enteredGlucose,login,logoImage;
- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle
- (void)handleNetworkChange
{
    NSLog(@"staus check");
    NSString *str;
    NetworkStatus status = [reachability currentReachabilityStatus];
    if (status == NotReachable) 
    {
        //status Offline
        NSLog(@"Offline");
        str=@"networkStatus([\"false\"])";
        [webView stringByEvaluatingJavaScriptFromString:str];
    }
    else 
    {
        //status online
        NSLog(@"Online");
        str=@"networkStatus([\"true\"])";
        [webView stringByEvaluatingJavaScriptFromString:str];
    }
}  

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    UIApplication* app=[UIApplication sharedApplication];
    CGRect statusBarFrame=app.statusBarFrame;
    if (statusBarFrame.size.height>20) {
        logoImage.frame=CGRectMake(0,-40, 320, 500);
    }
    Calendar* callPlugin;
    EMail* emailPlugin;
    Devices* devicePlugin;
    Orientation* orientationPlugin;
    TabBar* tabBarPlugin;
    OpenUrl* urlPlugin;
    ForceQuit* forceQuitPugin;
    NetworkCheck* networkPlugin;
    
    callPlugin=[[Calendar alloc]init];
    emailPlugin=[[EMail alloc]init];
    devicePlugin=[[Devices alloc]init];
    orientationPlugin=[[Orientation alloc]init];
    tabBarPlugin=[[TabBar alloc]init];
    urlPlugin=[[OpenUrl alloc]init];
    forceQuitPugin=[[ForceQuit alloc]init];
    networkPlugin=[[NetworkCheck alloc]init];
    
    pluginObjects=[[NSMutableDictionary alloc]init];
    
    [pluginObjects setValue:callPlugin forKey:@"cal"];
    [pluginObjects setValue:emailPlugin forKey:@"email"];
    [pluginObjects setValue:devicePlugin forKey:@"about"];
    [pluginObjects setValue:orientationPlugin forKey:@"gyro"];
    [pluginObjects setValue:tabBarPlugin forKey:@"tabbar"];
    [pluginObjects setValue:urlPlugin forKey:@"openurl"];
    [pluginObjects setValue:forceQuitPugin forKey:@"forcequit"];
    [pluginObjects setValue:forceQuitPugin forKey:@"networkcheck"];
    

    [callPlugin release];
    [emailPlugin release];
    [devicePlugin release];
    [orientationPlugin release];
    [tabBarPlugin release];
    [urlPlugin release];
    [forceQuitPugin release];
    [networkPlugin release];
    
    enteredGraph=NO;
    resized=NO;
    landscp=NO;
    returnType=YES;
    rotated=NO;
    cameBack=NO;
    login=NO;
    
   
    
   	 NSArray *paths = NSSearchPathForDirectoriesInDomains
         (NSDocumentDirectory, NSUserDomainMask, YES);
         NSString *documentsDirectory = [paths objectAtIndex:0];
         
         //make a file name to write the data to using the documents directory:
         NSString *fileName = [NSString stringWithFormat:@"%@/textfile.txt", 
                               documentsDirectory];
        NSURL *url;
        if ([[NSFileManager defaultManager] fileExistsAtPath:fileName])
				 {
          url=[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"login" ofType:@"html" inDirectory:@"WebContent/app/rootview/view"]];
         }
				 else
				 {
				  url=[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"termsandconditions" ofType:@"html" inDirectory:@"WebContent/app/rootview/view"]];
				 } 
        
    
    //***************************hitting service*****************
    
       NSURLRequest* request=[NSURLRequest requestWithURL:url ];
    [webView loadRequest:request];
    [super viewDidLoad]; 
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleNetworkChange) 
                                                                      name:kReachabilityChangedNotification object:nil];
    reachability =[[Reachability reachabilityForInternetConnection] retain];
    [reachability startNotifier];
		 //[self performSelector:@selector(handleNetworkChange) withObject:nil afterDelay:1];

   }   

-(void)createTabbar:(NSArray*)tabs
{
  UITabBarItem* tabItem;
	int tabsCount=[tabs count];
	NSMutableArray *tabItems=[[NSMutableArray alloc]initWithCapacity:tabsCount];
	for (id name in tabs) {
    tabItem =[[UITabBarItem alloc]initWithTitle:name image:[UIImage imageNamed:[NSString stringWithFormat:@"%@.png",name]] tag:0];
		[tabItems addObject:tabItem];
		[tabItem release];
  }
	
 UIApplication* app=[UIApplication sharedApplication];
 UIInterfaceOrientation currentOrientation= app.statusBarOrientation;
if (currentOrientation==UIInterfaceOrientationPortrait||currentOrientation==UIInterfaceOrientationPortraitUpsideDown) {
   baseTabBar=[[UITabBar alloc]initWithFrame:CGRectMake(0, 415, 320, 44)];
}
else 
 if (currentOrientation==UIInterfaceOrientationLandscapeRight||currentOrientation==UIInterfaceOrientationLandscapeLeft) {
   baseTabBar=[[UITabBar alloc]initWithFrame:CGRectMake(0, 258, 480, 44)];
}
	baseTabBar.items=tabItems;
	baseTabBar.delegate=self;
	baseTabBar.autoresizesSubviews=YES;
	[tabItems release];
  [self.view addSubview:baseTabBar];
}

#pragma mark - webview delegate methods

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    
    NSString* scheme;
    NSString* action;
    NSLog(@"webView : delegate method");
    NSString* urlString=[[request URL] absoluteString]; 
    urlString=[urlString stringByReplacingPercentEscapesUsingEncoding:NSStringEncodingConversionAllowLossy];
    NSLog(@"url from webView is %@",urlString);
    BOOL returnType1;
    NSMutableDictionary* paramData=nil;
    @try 
    {
        scheme=[[urlString  componentsSeparatedByString:@"://"]objectAtIndex:0] ; 
        eventname=[[urlString componentsSeparatedByString:@"://"]objectAtIndex:1] ; 
        NSLog(@"scheme from webView is %@",scheme);
        NSLog(@"eventmane from webView is %@",eventname);
        
        if ([scheme isEqualToString:@"http"] || [scheme isEqualToString:@"https"]) {
            NSLog(@"loading inside webview");
            return YES;
        }
        else if([scheme isEqualToString:@"openurl"])
        {
            NSString* urlValue=[[urlString componentsSeparatedByString:@"://"]objectAtIndex:2] ;
            NSString* newUrlString= [NSString stringWithFormat:@"https://%@",urlValue];
            NSLog(@"new url : %@",newUrlString);
            NSString* actionValue=[[[[urlString componentsSeparatedByString:@"://"]objectAtIndex:1]componentsSeparatedByString:@"?"]objectAtIndex:0] ;
            
            if ([actionValue isEqualToString:@"external"]) {
                [[pluginObjects objectForKey:@"openurl"] accessDeviceFeature:nil forAction:newUrlString];
                return NO;
            }
        }
        
        NSArray* urlArray=[eventname componentsSeparatedByString:@"?"];
        NSLog(@"count %d ",[urlArray count]);
        if([urlArray count]>1)
        {
            action=[urlArray objectAtIndex:0];
            if (![[urlArray objectAtIndex:1] isEqualToString:@""] ) 
            {
                NSArray* paramArray=[[urlArray objectAtIndex:1]componentsSeparatedByString:@"&"];
                NSLog(@" %@",paramArray);
                int paramcount=[paramArray count];
                NSLog(@"param count %d",paramcount);
                if(paramcount>=1)
                {
                    NSLog(@"more than one parameter");
                    int index=0;
                    paramData=[[NSMutableDictionary alloc]initWithCapacity:4];
                    for(int i = 0; i < paramcount; i++)
                    {
                        NSString *value = [[[paramArray objectAtIndex:i] componentsSeparatedByString:@"="] objectAtIndex:1];
                        NSString *key  = [[[paramArray objectAtIndex:i] componentsSeparatedByString:@"="] objectAtIndex:0];
                        [paramData setValue:value forKey:key];
                        index++;
                    }	
                }
            }
            NSLog(@"scheme : %@ ,action : %@ , params : %@",scheme,action,paramData);
            [[pluginObjects objectForKey:scheme] accessDeviceFeature:paramData forAction:action ];
            returnType1=NO;
        }
        else
        {
            NSLog(@"open url");
            returnType1=YES;
        }
    }
    @catch (NSException *exception) 
    {
        returnType1=NO;
        NSLog(@"thrown execption %@",exception);
    }
    return returnType1;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
 

    NSLog(@"webview : started");
}
-(void) resetAppIdleTimer 
{    
    // Cancel the Timer
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(elapsedAppIdleTimer) object:nil];
    int idleTimeOutValue =900; 
    [self performSelector:@selector(elapsedAppIdleTimer) withObject:nil afterDelay:idleTimeOutValue];
}
-(void)cancelTimer
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(elapsedAppIdleTimer) object:nil];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView1
{
    webView.hidden=NO;
    logoImage.hidden=YES;
    [webView stringByEvaluatingJavaScriptFromString:@"document.body.style.webkitTouchCallout='none';document.body.style.KhtmlUserSelect='none'"];
    NSLog(@"webview : finiscvc	");
    
    ((UIScrollView *)[[webView valueForKey:@"_internal"] valueForKey:@"scroller"]).scrollsToTop = NO;
    
}
- (void)handleTapOnWebView{
    NSLog(@"tapped");
    [self resetAppIdleTimer];
}
-(void) elapsedAppIdleTimer 
{
    NSLog(@"\n\n\nIdle Time Elapsed and so Logging out of Application\n\n\n");
    [webView stringByEvaluatingJavaScriptFromString:@"sessionExpired()"];
}

// Enabling Tap Recognition for UIWebView (which is self.view)
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return  YES;
}


- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"webview : loading error %@",error);
}
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    UITabBarItem *messageTab=[[baseTabBar items]objectAtIndex:1];
    messageTab.badgeValue=nil;
    NSString* callBackFunction;
    if (enteredGraph) 
    {
      if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationPortrait)
      {
            self.view.frame = CGRectMake(0, 20, 320, 460);
            self.webView.frame=CGRectMake(0, 0, 320, 416);
             [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortrait animated:YES];
      }
      else if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationPortraitUpsideDown)
      {
            self.view.frame = CGRectMake(0, 0, 320, 460);
            self.webView.frame=CGRectMake(0, 0, 320, 416);
            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortraitUpsideDown animated:YES];

      }
      else if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationLandscapeLeft)
      {
            self.view.frame = CGRectMake(20, 0, 300, 480);
            self.webView.frame=CGRectMake(0,0,480,272);
        
      }
      else if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationLandscapeRight)
      {
      
        self.view.frame=CGRectMake(0, 0,300,480);
        self.webView.frame=CGRectMake(0,0,480,272);
      }
    }
    enteredGlucose=NO;
    enteredGraph=NO;
    [[UIApplication sharedApplication]setStatusBarHidden:NO];
		NSString* titleValue=item.title;

    if ([titleValue isEqualToString:@"Home"]) 
    {
        callBackFunction=@"loadHome()";
        [webView stringByEvaluatingJavaScriptFromString:callBackFunction];
				return;
    }
    else if ([titleValue isEqualToString:@"Messages"]) 
    {
        callBackFunction=@"loadMessages()";
        [  webView stringByEvaluatingJavaScriptFromString:callBackFunction];  
				return;
    }
		else if ([titleValue isEqualToString:@"Challenges"]) 
    {
        callBackFunction=@"loadActivities()";
        [  webView stringByEvaluatingJavaScriptFromString:callBackFunction];
				return;
    }
    else if ([titleValue isEqualToString:@"Trackers"]) 
    {
        callBackFunction=@"loadTrackers()";
        [  webView stringByEvaluatingJavaScriptFromString:callBackFunction];
				return;
    }
   else if ([titleValue isEqualToString:@"Settings"]) 
    {
        callBackFunction=@"loadSettings()";
        [  webView stringByEvaluatingJavaScriptFromString:callBackFunction];
				return;
    }
    

    
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
-(void)currentOrientation
{
    UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
    if ((interfaceOrientation==UIInterfaceOrientationPortrait)||(interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown)) 
    {
        
        NSString* callBackFunction=@"currentOrientation([\"portrait\"])";
        [webView stringByEvaluatingJavaScriptFromString:callBackFunction];
    }
    else  if ((interfaceOrientation==UIInterfaceOrientationLandscapeLeft)||(interfaceOrientation==UIInterfaceOrientationLandscapeRight)) 
    {
        NSString* callBackFunction=@"currentOrientation([\"landscape\"])";
        [webView stringByEvaluatingJavaScriptFromString:callBackFunction];
    }
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if (login) {
			 if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
           baseTabBar.frame=CGRectMake(0, 413, 320, 44);
          }
else 
       if (interfaceOrientation==UIInterfaceOrientationLandscapeRight||interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
   baseTabBar.frame=CGRectMake(0, 255, 480, 44);
          }
       }
        [self performSelector:@selector(currentOrientation) withObject:nil afterDelay:0.15];
    //}
    return YES;
}
@end
