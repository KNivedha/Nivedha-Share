/*
 Controller : MedicationController
 This is the controller to do the  logic of medications 
 */
mHealth.controllers.MedicationController = Spine.Controller.sub({
            el: 'body',
            elements: {},

            service: mHealth.util.RemoteServiceProxy.getInstance(),

            events: {
                'click #show_medication'           : 'getMedicationDetails',
                'pagebeforeshow #medication_index' : 'showMedicationDetails',
                'click .medicationUniqueId'        : 'getDetailedMedication',
                'pagebeforeshow #detail_medication': 'showDetailedMedication',
                'click #back_btn_home'             : 'clearModelData'
            },
            init: function () {},

            /* Purpose: Method to fetch the medication history 
            Params : --
            Return : Medication model
            */
            getMedicationDetails: function (event) {
                modelCount = mHealth.models.MedicationModel.count();
                header = ALSECTOKEN;
                if(modelCount === 0){ 
                    this.service.getResponse(mHealth.uat.medication_url, header, this.medicationSuccess, this.medicationFailure);
                }  else{
                     $.mobile.changePage("../view/medicationindex.html");
                }
            },

            
            /* Purpose: Success method of Medication service call 
             Params : --
             Return : Response data
             */
            medicationSuccess: function (output) {
                var response = output.responseText;               
                mHealth.controllers.MedicationController.setMedicationData(response);
                $.mobile.changePage("../view/medicationindex.html");
            },
            
            
            /* Purpose: Error method of Medication service call 
             Params : --
             Return : --
             */
            medicationFailure: function (jqXHR, textStatus, errorThrown) {
                alert("Information not available");
            },  
                                                                

            /* Purpose: Method to render the medication history in the view 
            Params : Medication model
            Return : --
            */
            showMedicationDetails: function () {
                var medication_data = mHealth.models.MedicationModel.all();
                $('#data_div').html(_.template($('#medicationDataList').html(),{medication_data: medication_data}));
                $('#medication_list').listview();
            },



            /* Purpose: Method to get the detailed view of medication data
            Params : Selected record medication ID
            Return : Details of the selected medication
            */
            getDetailedMedication: function (e) {
                medication_ID = $(e.target).siblings('input[type="hidden"]').val();
                $.mobile.changePage("displayMedication.html");
                var detailedMedication = mHealth.models.MedicationModel.select(function (record) {
                  if (record.medicationId == medication_ID) {
                      detailedMedications = record;
                  }
                });
            },



            /* Purpose: Method to render the detailed view of medication data 
            Params : Detailed record of medication selected 
            Return : --
            */
            showDetailedMedication : function () {
            $('#detailed_data').html(_.template($('#medicationDetails').html(),{                                              detailedMedications: detailedMedications}));
            $('#medication_details').listview();
            },
            
                                                                
            /* Purpose: Method to clear medication and condition model 
             Params : --
             Return : --
            */
            clearModelData : function (){
                mHealth.models.ConditionModel.destroyAll();
                mHealth.models.MedicationModel.destroyAll();
                mHealth.models.SearchConditionModel.destroyAll();
            },


            /* Purpose: This is to set the data from server to the medication model
            Params : Response data from the server
            Return : medication model with data set
            */
           });






mHealth.controllers.MedicationController.extend({

setMedicationData: function (response) {
                                               

if (response !== '') {
data = JSON.parse(response);
for (i = 0; i < data.length; i++) {
mHealth.models.MedicationModel.create({
                                      participantId: data[i].participantId,
                                      partMedId: data[i].partMedId,
                                      medicationId: data[i].medicationId,
                                      medicationName: data[i].medicationName,
                                      startDate: data[i].startDate,
                                      endDate: data[i].endDate,
                                      strength: data[i].strength,
                                      dosage: data[i].dosage,
                                      frequency: data[i].frequency,
                                      refillFrequency: data[i].refillFrequency,
                                      nextRefillDate: data[i].nextRefillDate,
                                      medicationType: data[i].medicationType,
                                      route: data[i].route,
                                      form: data[i].form,
                                      source: data[i].source,
                                      complianceStatus: data[i].complianceStatus
                                      // comments:data[i].comments,
                                      // compliance:data[i].compliance                                 
                                      });
}
}
}
                                                });
