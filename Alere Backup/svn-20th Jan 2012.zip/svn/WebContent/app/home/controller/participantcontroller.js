/**
 
  * Controller for getting the participant data
  * Logic for profile is added here
 
 **/

mHealth.controllers.ParticipantController=Spine.Controller.sub({
       el:'body',
       service : mHealth.util.RemoteServiceProxy.getInstance(),
                                                               
       events :
       {
       'click #show_profile'    : 'getProfileData',
       'click #saveProfile' :'saveProfileData',
       'pagebeforeshow #profile_page' :'showProfiledata'
       },
      
       /**  
        Method to call healthdata service
        Calling processProfiledata with returned response
       **/                                                             
       getProfileData : function(){
                                                               
           modelCount = mHealth.models.ParticipantModel.count();
           header = ALSECTOKEN;
           if(modelCount === 0){ 
               this.service.getResponse(mHealth.uat.message_get_url,header, this.participantSuccess, this.participantFailure);           
               participantdata=mHealth.models.ParticipantModel.first(); 
           }  else{
               $.mobile.changePage("../../home/view/profile.html");           
           }         
       },
       
       /**  
       Success method of Service call       
       **/ 
       participantSuccess: function (output) {
           var response = output.responseText; 
           var participant = new mHealth.controllers.ParticipantController
           participant.processProfileData(response);
           $.mobile.changePage("../../home/view/profile.html");
       },
       
       
       /**  
        Error method of Service call       
       **/ 
       participantFailure: function (jqXHR, textStatus, errorThrown) {
       alert("Information not available");
       },  
                                                               
       /**  
        Method to show the profile data 
        Rendering the data with the help of underscore
        **/                                                          
       showProfiledata :function()
       {  
       participantdata=mHealth.models.ParticipantModel.all();
       $('#profiles').html(_.template($('#ParticipantList').html(),{participantdata:participantdata}));
       $('#profile_page').trigger('create');          
       },
        
       /**  
        Method to save profile data
        Updating the participant model with preferred name and height attributes
        **/                                                         
       saveProfileData :function()
       {    
                                                               
       participantdata = mHealth.models.ParticipantModel.first();                                                            
       participantdata.updateAttributes({
       preferredName : $("#preferredName").val(),
       height :$('#height').val()
       });
                                                              

       mHealth.models.HealthDataModel.create({
                 healthDataId:"10",
                 participantId:participantdata.pdashID,
                 memberEligId:participantdata.memberEligID ,               
                 healthDataType :"height",
                 measurementDate :"",
                 collectedDate :"",
                 value :participantdata.height,
                 unit :"",
                 source :"",
                 appSource :"",
                 comments :"",
                 longitude :"",
                 latitude :"",
      });    
                                                               
           formdata = mHealth.models.HealthDataModel.all(); 
           
          
           var body = JSON.stringify([formdata]);
                                                               
   this.service.postRequest(mHealth.uat.healthdata_url+"height", formdata, this.participantSaveSuccess, this.participantSaveError);
      $.mobile.changePage("home.html");
       },

                                                               
       participantSaveSuccess:function(){
                                                               //alert("Record saved successfully");
       },
       participantSaveError:function(){
                                                               //alert("Record error");
       },

       /**  
        Method for process response from service
        Binding the response from the service to participant model
        **/                                                            
       processProfileData : function(response){
       if(response!=='')
       {
       data=JSON.parse(response);
       for(i=0;i<data.length;i++){
       
       /**
        Binding the data to participant model
       **/
       mHealth.models.ParticipantModel.create({
              pdashID:data[i].pdashID,
              message:data[i].message,
              programName:data[i].programName,
              memberEligID:data[i].memberEligID,
              preferredName:data[i].preferredName,
              lastName:data[i].lastName,
              dateOfBirth:data[i].dateOfBirth,
              gender:data[i].gender,
              height:data[i].height,
              emailAddress:data[i].emailAddress,
              firstName:data[i].firstName,
              createTimestamp:data[i].createTimestamp,
              loggedIn:data[i].loggedIn,
              username:data[i].username,
              alsectoken:data[i].alsectoken
              });
       }
       participantdata=mHealth.models.ParticipantModel.all();
       }    
       }
       });

