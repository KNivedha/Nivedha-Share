/**
 * Controller : SettingsController
 * Controller to do logic of settings
 **/
mHealth.controllers.DebugController = Spine.Controller.sub({
	el : 'body',
    assetID : null,
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
        'click #clientCode' : 'clientRegistration',
        'click #dummyVideo' : 'openVideo',
        'click #alfArticle' : 'getAlfrescoArticle',
        'pagebeforeshow #alfrescoDIV' : 'preloadAlfresco',
        'click #brightcove' : 'openVideo',
        'click #brightcoveAlere' : 'openAlereVideo',
        'click .video' : 'parseVideo',
        'click .healthArticle' : 'parseArticle',
        'click #videolink1':'openVideo1',
        'click #videolink2':'openVideo2',
        'click #videolink3':'openVideo3',
        'click #videolink4':'openVideo4',
        'click #videolink5':'openVideo5',
        'click #videolink6':'openVideo6',
        'click #videolink7':'openVideo7',
        'click #backBtn1':'showVideoIndex'
    },
    openVideo1:function(){
    	videoLinkId='abn0453';
    	 $.mobile.changePage('../../debug/view/videotest.html');
    },
    openVideo2:function(){
    	videoLinkId='abo2010';
    	 $.mobile.changePage('../../debug/view/videotest.html');
    },
    openVideo3:function(){
    	videoLinkId='ab02019';
    	 $.mobile.changePage('../../debug/view/videotest.html');
    },
    openVideo4:function(){
    	videoLinkId='abo2037';
    	 $.mobile.changePage('../../debug/view/videotest.html');
    },
     openVideo5:function(){
    	videoLinkId='abo2064';
    	 $.mobile.changePage('../../debug/view/videotest.html');
    },
     openVideo6:function(){
    	videoLinkId='abo2157';
    	 $.mobile.changePage('../../debug/view/videotest.html');
    },
     openVideo7:function(){
    	videoLinkId='abo2314';
    	 $.mobile.changePage('../../debug/view/videotest.html');
    },
    showVideoIndex:function(){
    	alert('back');
    	$.mobile.changePage('../../debug/view/videoindex.html');
    },
    parseVideo : function(event){
        
        var target = event.target || event.srcElement
        if (target.href){
            var targetValue = target.href;
            var videoId = targetValue.substring(3, targetValue.length);
            assetID = videoId;
            $.mobile.changePage('../../debug/view/'+assetID+'.html',{role:'dialog'});
            
            event.preventDefault();
        } else {
            mHealth.util.customAlert("No url found to navigate", '');	
            // HMM CHECK YOUR ID ON WHICH YOU ARE TRIGGERING THE EVENT
        }    
        
    },
    parseArticle : function(event){
        var target = event.target || event.srcElement
        if (target.href){
            var targetValue = target.href;
            var articleId = targetValue.substring(3, targetValue.length);
            //alert("parseArticle : "+articleId);
            
            assetID = articleId;
                                 
            // Overlay display
            $.mobile.changePage('../../debug/view/alfrescocontainer.html',{role:'dialog'});
                              
                                                           
            // Browser display 
            //var hwUrl = "openurl://external?url=http://secure.uat.alerehealth.com:13085/api/health-articles/hwMCnt?id=healthwise://"+assetID;                                                           
            //alert("hwUrl: "+ hwUrl);
            //window.open(hwUrl, '_blank');
                                                           
            
        } else {
            mHealth.util.customAlert("No url found to navigate", '');	
            // HMM CHECK YOUR ID ON WHICH YOU ARE TRIGGERING THE EVENT
        }   
        
    },
    
    
    clientRegistration : function (event){
        var target = event.target || event.srcElement
        if (target.href){
            
            //alert("Trying to open "+target.href);
            target.href = 'http://google.com';
            window.open(target.href, '_blank');
            //window.open(target.href, '_blank');
            //event.preventDefault();
        } else {
            mHealth.util.customAlert("No url found to navigate", '');	
        }
    },
    openVideo : function (event){
        $.mobile.changePage('../../debug/view/dummyvideo.html');
    },
    
    //This function preloads the contents into an IFRAME which is defined in alfrescocontainer.html
    //
    preloadAlfresco : function(){
                                                                                                                      
                                                           
        //alert("in preloadAlfresco ");
        
        // hardcoded host works
        //$('#iframePage').html('<iframe width="100%" height="100%" src="http://secure.uat.alerehealth.com:13085/api/health-articles/hwMCnt?id=healthwise://'+assetID+'" ></iframe>');
                               

       var srcUrl = "" + mHealth.env.healthwise_url + assetID;
                                                           
        $('#iframePage').html('<iframe width="100%" height="100%" src="' + srcUrl +'" ></iframe>');
                                                           
        $('#iframePage').trigger('create');
                                                           
                                                           
                                                           
    },
    
    /*
     This function is been called on clicked of the link on debug and it just redirects it to 
     alfrescocontainer.html which has some blank divs which are been populated in preloadAlfresco
     */
    getAlfrescoArticle : function(){
        //$.mobile.changePage('../../debug/view/alfrescocontainer.html');
    },
    
    //
    openVideo : function(){
        //alert("In OPEN VIDEO");
        $.mobile.changePage('../../debug/view/brightcove.html');
    },
    //
    openAlereVideo : function(){
        //alert("In OPEN ALERE VIDEO");
        $.mobile.changePage('../../debug/view/brightcoveAlere.html');
    }
    
    
});

mHealth.controllers.DebugController.extend({
    
    
});
