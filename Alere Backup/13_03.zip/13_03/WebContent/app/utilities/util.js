/**
 * Object - util
 * Utilities - Common Functions
 **/
mHealth.util = {

	version : '1.0',
	tcScroll : null,
    prevDefault : function(){
        return false;
    },

	setEnvironment : function(environment) {
		switch(environment) {
			case "dev":
				mHealth.env = mHealth.dev
				break;
			case "uat":
				mHealth.env = mHealth.uat
				break;
			case "local":
				mHealth.env = mHealth.local
				break;
			case "prod":
				mHealth.env = mHealth.prod
				break;
			case "qa":
				mHealth.env = mHealth.uat
				break;
			default:
				mHealth.env = mHealth.dev
				break;

		}
	},
	/**
	 * Name    : parseUTC
	 * Purpose : Method to convert date from UTC format to mm/dd/yyyy hrs:min format
	 * Params  : utcDate - UTC date string
	 * Returns : dateString
	 **/
	parseUTC : function(utcDate) {
		var year, mon, day, hr, min, sec, date, dateString;
		year = utcDate.substring(0, 4);
		mon = utcDate.substring(4, 6);
		day = utcDate.substring(6, 8);
		hr = utcDate.substring(9, 11);
		min = utcDate.substring(11, 13);
		sec = utcDate.substring(13, 15);
		date = new Date(year, mon, day, hr, min, sec);
		dateString = date.getMonth() + '/' + date.getDate() + '/' + date.getFullYear() + ' ' + date.toLocaleTimeString();
		return dateString;
	},
	/**
	 * Name    : parseDate
	 * Purpose : Method to convert date from weekday, mmm dd,yyyy to day mmm dd yyyy hh:mm:ss GMT (Timestandard)
	 * Params  : date in format weekday, mmm dd,yyyy Ex:Sunday,Feb 5,2012
	 * Returns : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 **/
	parseDate : function(day) {
		var date = day.split(',');
		//var dates=date[1].split(' ');
		var parseDate = date[1] + ',' + date[2];
		var dateObj = Date.parse(parseDate);
		return dateObj;
	},
	/**
	 * Name    : parseday
	 * Purpose : Method to convert date from UTC format to mm/dd/yyyy hrs:min format
	 * Params  : utcDate - UTC date string
	 * Returns : dateString
	 **/
	parseday : function(day) {
		var day = day.split(',');
		var month = day[1];
		var date = month.split(' ');
		switch (date[0]) {
			case 'Jan':
				date[0] = 0;
				break;
			case 'Feb':
				date[0] = 1;
				break;
			case 'Mar':
				date[0] = 2;
				break;
			case 'Apr':
				date[0] = 3;
				break;
			case 'May':
				date[0] = 4;
				break;
			case 'Jun':
				date[0] = 5;
				break;
			case 'Jul':
				date[0] = 6;
				break;
			case 'Aug':
				date[0] = 7;
				break;
			case 'Sep':
				date[0] = 8;
				break;
			case 'Oct':
				date[0] = 9;
				break;
			case 'Nov':
				date[0] = 10;
				break;
			case 'Dec':
				date[0] = 11;
				break;
		}
		parsedDate = new Date(day[2], date[0], date[1]);
		return parsedDate;
	},
	/**
	 * Name    : getCurrentDate
	 * Purpose : Method to get the current date in mm/dd/yyyy format
	 * Params  : --
	 * Returns : today
	 **/
	getCurrentDate : function() {
		var today, mm, yyyy;
		today = new Date();
		dd = today.getDate();
		mm = today.getMonth() + 1;
		yyyy = today.getFullYear();
		if(dd < 10) {
			dd = '0' + dd;
		}
		if(mm < 10) {
			mm = '0' + mm;
		}
		today = mm + '/' + dd + '/' + yyyy;
		return today;
	},
	/**
	 * Name    : getDatewithDay
	 * Purpose : Method to get the current date in Day,Month dd,yyyy format
	 * Params  : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 * Returns : date in format weekday, mmm dd,yyyy Ex:Sunday,Feb 5,2012
	 **/
	getDateWithDay : function(date) {

		var dates = date.format("dddd, mmm d, yyyy");

		return dates;
	},
	/**
	 * Name    : getDateWithMonth
	 * Purpose : Method to get the current date in Full Month Name date, Year format
	 * Params  : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 * Returns : date in format Month Name date, Year Ex:February 12, 2012
	 **/
	getDateWithMonth : function(date) {
		var endDate = date;
		var startDate = new Date(date.getTime() - 29 * 24 * 60 * 60 * 1000);
		return (startDate.format('mmm dd, yyyy') + ' - ' + endDate.format('mmm dd, yyyy'));
	},
	/**
	 * Name    : getDateWithWeek
	 * Purpose : Method to get the Week title for the graphs
	 * Params  : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 * Returns : Week Title for graph Ex:Feb 12 - Feb 19
	 **/
	getDateWithWeek : function(date) {
		var wday = date.getDay();
		// var startDate=new Date(date.getTime() - (wday * 24 * 60 * 60 * 1000));
		// var endDate = new Date(date.getTime() + ((7-wday)*24 * 60 * 60 * 1000));
		var endDate = date;
		var startDate = new Date(date.getTime() - 6 * 24 * 60 * 60 * 1000);
		return (startDate.format('mmm dd, yyyy') + ' - ' + endDate.format('mmm dd, yyyy'));
	},
	/**
	 * Name    : getYearWithMonth
	 * Purpose : Method to get the current date in Full Month name year format (January 2012)
	 * Params  : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 * Returns : date in format Month name Year Ex: December 2011
	 **/
	getYearWithMonth : function(date) {
		var endDate = date;
		var startDate = new Date(date.getTime() - 364 * 24 * 60 * 60 * 1000);
		return (startDate.format('mmm yyyy') + ' - ' + endDate.format('mmm yyyy'));
	},
	/**
	 * Name    : getCurrentDay
	 * Purpose : Method to get the current day in Day,Month dd,yyyy format
	 * Params  : --
	 * Returns : date in Day,Month dd,yyyy format
	 **/
	getCurrentDay : function() {
		var currentDay = new Date();
		currentDay = this.getDateWithDay(currentDay);
		return currentDay;
	},
	/**
	 * Name    : getPrevYearDate
	 * Purpose : Method to get the previous day pegadate format
	 * Params  : --
	 * Returns : previousyeardate(today - 364 days) in pegadate format
	 **/
	getPrevYearDate : function(){
		var today=new Date();
		today= new Date(today.getFullYear(),today.getMonth(),today.getDate());
		var prevYearDate = new Date(today.getTime() - 364 * 24 * 60 * 60 * 1000)
		return prevYearDate.format(mHealth.pegadateformat);
	},
	/**
	 * Name    : getPreviousDay
	 * Purpose : Method to get the previous day in Day,Month dd,yyyy format
	 * Params  : day in format day,mmm dd,yyy
	 * Returns : previousday in format day,mmm dd,yyy
	 **/
	getPreviousDay : function(currentDay) {
		var previousDay = this.parseday(currentDay);
		previousDay.setDate(previousDay.getDate() - 1);
		//previousDay=previousDay-(24*60*60);
		//previousDay=new Date(previousDay);
		previousDay = this.getDateWithDay(previousDay);
		return previousDay;
	},
	/**
	 * Name    : getNextDay
	 * Purpose : Method to get the Next day in Day,Month dd,yyyy format
	 * Params  : day in format day,mmm dd,yyy
	 * Returns : nextDay in format day,mmm dd,yyy
	 **/
	getNextDay : function(currentDay) {
		var nextDay = this.parseday(currentDay);
		nextDay.setDate(nextDay.getDate() + 1);
		nextDay = this.getDateWithDay(nextDay);
		return nextDay;
	},
	/**
	 * Name    : slideToggle
	 * Purpose : Method to hide or show any HTML element
	 * Params  : element - id of HTML element
	 bShow -
	 duration -
	 slider -
	 * Returns : --
	 **/
	slideToggle : function(element, bShow, duration, slider) {
		var $el = $(element), visible = $el.is(":visible");

		// if the bShow isn't present, get the current visibility and reverse it
		if(arguments.length == 1)
			bShow = !visible;

		// if the current visiblilty is the same as the requested state, cancel
		if(bShow == visible) {
			return false;
		}

		$.each($el, function(i, e) {
			var $e = $(e);
			var visible = $e.is(":visible");
			var height = $e.show().height();
			if(!$e.data("originalHeight")) {
				$e.data("originalHeight", height);
			};
			if(!visible)
				$e.hide().css({
					height : 0
				});
		})
		if(bShow) {
			$.each($el, function(i, e) {
				$e = $(e);
				$e.show().animate({
					height : $e.data("originalHeight")
				}, {
					duration : duration,
					complete : function() {
						if(slider) {
							slider.slider("enable");
						}
					}
				});
			})
		} else {
			$el.animate({
				height : 0
			}, {
				duration : duration,
				complete : function() {
					$el.hide();

					if(slider) {
						slider.slider("enable");
					}
				}
			});
		}
	},
	/**
	 * Name    : getParameterByName
	 * Purpose : Method to get the query parameter values from the url
	 * Params  : name - Name of the query parameter
	 url - URL that contains the query parameters
	 * Returns : paramValue
	 **/
	getParameterByName : function(name, url) {

		var match, paramValue;
		match = RegExp('[?&]' + name + '=([^&]*)').exec(url);
		paramValue = match && decodeURIComponent(match[1].replace(/\+/g, ' '));
		return paramValue;

	},
	/**
	 * Name    : showMask
	 * Purpose : Method to show the masking layer.
	 * Params  : --
	 * Returns : --
	 **/
	showMask : function() {
		var requested_page = $('.ui-page-active').attr('id');

		var content = $('div[id=' + requested_page + ']');

		$('<div>', {
			'class' : 'ui-actionsheet-wallpaper'
		}).appendTo(content).show();

		$.mobile.showPageLoadingMsg();
		
		 nativeCommunication.callNativeMethod("tabbar://addMask?");
		// location.href = "tabbar://addMask?";

	},
	/**
	 * Name    : hideMask
	 * Purpose : Method to hide the masking layer,
	 * Params  : --
	 * Returns : --
	 **/
	hideMask : function() {

		$(':jqmData(role="page")').children('div').removeClass('ui-actionsheet-wallpaper');
		$.mobile.hidePageLoadingMsg();
		nativeCommunication.callNativeMethod("tabbar://removeMask?");

	},
	customAlert : function(message, okcallback) {

		nativeCommunication.callNativeMethod("tabbar://addMask?");
		var mobFunc = function(){
			return false;
		}
		$(document).bind('touchmove', mobFunc());
		if(okcallback === '') {
			okcallback = function() {
			};
		}
		var height = window.innerHeight + 2;
		var top = document.body.scrollTop;
		var width = window.innerWidth;
		var messageString;

		if( typeof message === 'string') {
			messageString = message;
		} else if( typeof message === 'object') {
			messageString = message;
		} else if( typeof message === undefined) {
			messageString = 'undefined';
		} else {
			messageString = message.toString();

		}

		var alertHtml = '<div class="ui-alert-wallpaper" ><div class="back_container"></div>' + '<table class="alertable"><tr><td valign="middle" >' + '<div class="back">' + '<div class="back_top header">' + mHealth.GuiHelper.alerttitle + '</div>' + '<div class="back_mid msg">' + messageString + '</div>' + '<div class="back_mid button_container">' + '<div class="but">' + '<div class="but_left"></div>' + '<div class="but_mid">OK</div>' + '<div class="but_right"></div>' + '</div>' + '</div>' + '<div class="back_bottom"></div>' + '</div>' + '</td></tr></table>' + '</div>';

		var requested_page = $('.ui-page-active').attr('id');

		var content = $('div[id=' + requested_page + ']');

		$(alertHtml).appendTo(content).show();
		$('.alertable').css({
			'height' : height,
			'width' : width
		});
		$('.ui-alert-wallpaper').css({
			'height' : height,
			'width' : width,
			'top' : top
		});

		
		$('.but_mid').click(function() {

			okcallback();
			$(document).unbind('touchmove', mobFunc());
            $('.ui-alert-wallpaper').remove();
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
			nativeCommunication.callNativeMethod("tabbar://removeMask?");
			
		});
		
		
	},
	customPrompt : function(message, noCallback, yesCallback) {
    nativeCommunication.callNativeMethod("tabbar://addMask?");

		var mobFunc = function(){
			return false;
		}
		$(document).bind('touchmove', mobFunc());
		var height = window.innerHeight + 2;
		var top = document.body.scrollTop;
		var width = window.innerWidth;

		var promptHtml = '<div class="ui-alert-wallpaper"><div class="back_container"></div>' + '<table class="alertable"><tr><td valign="middle">' + '<div class="back">' + '<div class="back_top header">' + mHealth.GuiHelper.alerttitle + '</div>' + '<div class="back_mid msg">' + message + '</div>' + '<div class="back_mid button_container">' + '<div class="but_ok">' + '<div class="but_left"></div>' + '<div class="but_mid">Yes</div>' + '<div class="but_right"></div>' + '</div>' + '<div class="but_cancel">' + '<div class="but_left"></div>' + '<div class="but_mid">No</div>' + '<div class="but_right"></div>' + '</div>' + '</div>' + '<div class="back_bottom"></div>' + '</div>' + '</td></tr></table>' + '</div>';

		var requested_page = $('.ui-page-active').attr('id');

		var content = $('div[id=' + requested_page + ']');

		$(promptHtml).appendTo(content).show();
		$('.alertable').css({
			'height' : height,
			'width' : width
		});
		$('.ui-alert-wallpaper').css({
			'height' : height,
			'width' : width,
			'top' : top
		});

		
		$('.but_ok>.but_mid').click(function() {
			yesCallback();
			$(document).unbind('touchmove', mobFunc());
			$('.ui-alert-wallpaper').remove();
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
            nativeCommunication.callNativeMethod("tabbar://removeMask?");

		});

		$('.but_cancel>.but_mid').click(function() {
			noCallback();
			$(document).unbind('touchmove', mobFunc());
			$('.ui-alert-wallpaper').remove();
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
            nativeCommunication.callNativeMethod("tabbar://removeMask?");

		});
		
		
	},
	
	animateProgress : function(progress, callback) {
		return $('#progress_bar .ui-progress').each(function() {
			$('#progress_bar .ui-progress').animate({
				width : progress + '%'
			}, {
				duration : 2000,

				easing : 'swing',

				step : function(progress) {
					var labelEl = $('.ui-label', this), valueEl = $('.value', labelEl);

					if(Math.ceil(progress) < 0 && $('.ui-label', this).is(":visible")) {
						labelEl.hide();
					} else {
						if(labelEl.is(":hidden")) {
							labelEl.fadeIn();
						};
					}

					if(Math.ceil(progress) == 100) {
						labelEl.text('Processing 100%');
						// setTimeout(function() {
						// labelEl.fadeOut();
						// }, 1000);
					} else {
						valueEl.text(Math.ceil(progress) + '%');
					}
				},
				complete : function(scope, i, elem) {
					if(callback) {
						callback.call(this, i, elem);
					};
				}
			});
		});
	},
	/**
	 *Name : showCalendar
	 *Purpose : Show clendar page
	 *Params: --
	 *Returns: --
	 **/
	showCalendar : function(eventDisplayName) {		
		$("#eventName").val(eventDisplayName);
		$('#startDate').scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'datetime',
			seconds : true,
			timeFormat : 'hh:ii:ss A',
			theme : 'ios',
			beforeShow : function(input, inst) {
				nativeCommunication.callNativeMethod("tabbar://hideTabBar?");

			},
			onClose : function(valueText, inst) {
				nativeCommunication.callNativeMethod("tabbar://showTabBar?");
			},
			onCancel : function(valueText, inst) {

				//nativeCommunication.callNativeMethod("tabbar://showTabBar?");
			}
		});
		$('#endDate').scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'datetime',
			seconds : true,
			timeFormat : 'hh:ii:ss A',
			theme : 'ios',
			beforeShow : function(input, inst) {
				nativeCommunication.callNativeMethod("tabbar://hideTabBar?");

			},
			onClose : function(valueText, inst) {
				nativeCommunication.callNativeMethod("tabbar://showTabBar?");
			},
			onCancel : function(valueText, inst) {

				//nativeCommunication.callNativeMethod("tabbar://showTabBar?");
			}
		});
	},
};
