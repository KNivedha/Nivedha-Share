mHealth.models.MedicationModel = Spine.Model.sub();
mHealth.models.MedicationModel.configure("MedicationModel",'participantId','partMedId','medicationId','medicationName','startDate',
		'endDate','strength','dosage','frequency','refillFrequency','nextRefillDate','medicationType',
		'route','form','source','complianceStatus','comments','compliance');
   

    