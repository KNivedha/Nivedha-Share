/**
 *Controller : ActivityController
 *Controller to do Activity Tab functionality.
 **/

mHealth.controllers.ActivityController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	subActivityView : "",
	events : {

		'pagebeforecreate #showActivity' : 'getActivity',
		'pageshow #showActivity' : 'loadMask',
		//'pagebeforeshow #showActivity' : 'showActivity',
		'click .detailActivity' : 'getSubActivity',
		'pagebeforeshow #detailActivity' : 'showSubActivity',
		'pagebeforeshow #calendarPage':'showCalendar',
		'click #calendarSave' : 'getCalendarData',

	},
	
	/**
	 *Name    : loadMask
	 *Purpose : Show loading mask when fetching data from the server
	 *Params  : --
	 *Returns :--
	 **/
	loadMask : function(){		
		 $.mobile.showPageLoadingMsg();
	},
	
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showSubActivity : function() {
		$('#detailActivity_div').html(_.template($('#detailActivityDataList').html(), {recordRequired:recordRequired}));
		$('#detailActivity').trigger('create');
	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showActivity : function() {
		
		$('#activityTitle').text(activity[0].space[0].title);

		if(activity[0].zone.length > 1) {

			$('#activity_zone').show();
			var activityZone = activity[0].zone[0].isInset;

			$('#activity_zone').html(_.template($('#navDataList').html(), activityZone));
		}
		var activityView = activity[0].view;

		$('#activity_div').html(_.template($('#activityDataList').html(), {
			activityView : activityView
		}));
		$('#showActivity').trigger('create');
	},
	/**
	 *Name: init
	 *Purpose: initialize the Controller
	 **/
	init : function() {		
		this.bind('getservice', this.proxy(this.showActivity));		
		$.mobile.showPageLoadingMsg();	
	},
	/**
	 *Name: getSubActivity
	 *Purpose: On click the View of the Activity, the Function will be
	 *Params
	 *Returns
	 **/
	getSubActivity : function(event) {
		var view = event.target;
		// var html = $(event.target).html();
	  selectedViewName = $(view).parents('li').children('div').children('div').children('a').children('h3').text();
		mHealth.models.SpaceViewZoneModel.each(function(record) {
			if(record.pageName === 'Activity') {
				for( i = 0; i < record.view.length; i++) {
					if(record.view[i].title.trim() === selectedViewName.trim()) {
						this.subActivityView = record.view[i];
						recordRequired=this.subActivityView;
						break;
					}
				}
			}
		});

		$.mobile.changePage("detailactivity.html");

	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	getActivity : function() {		
		var isExists = mHealth.models.SpaceViewZoneModel.each(function(record) {
			if(record.pageName === 'Activity') {
				return true;
			}
		});
		if(isExists !== true) {
			var body = mHealth.recommendation.createRecommendationRequestJSON("1003");
			this.proxy(this.service.postRequest(mHealth.env.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.recommendationFailure)),true);

		}
	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showCalendar :function(){
	$("#eventName").val(selectedViewName);
	$('#startDate').scroller({preset:'datetime',theme:'ios'});
	$('#endDate').scroller({preset:'datetime',theme:'ios'});
	},
	/**
	 * Name    : getCalendarData
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	getCalendarData : function() {
		var title, startDate, endDate;
		title = $('#eventName').val();
		startDate = $('#startDate').val();
		endDate = $('#endDate').val();
		mHealth.util.callCalendarEvent(title,startDate,endDate);
		//location.href = "cal://?eventname=setEvent&eventTitle=" + title + "&startDate=" + sDate + "&endDate=" + eDate;

	},
	/**
	 *Name: recommendationSuccess
	 *Purpose: After getting the response from the recommandation Service, the functon will parse the space, View and ZOne
	 Set the value in the respective model.
	 *Params: output
	 *Returns: null
	 **/
	recommendationSuccess : function(output) {

		var response, recommandationData, spaceData, zoneData, viewData, spaceviewzone;
		response = output.responseText;
		recommandationData = JSON.parse(response);
		spaceData = JSON.stringify(recommandationData.Space);
		zoneData = JSON.stringify(recommandationData.Zone);
		viewData = JSON.stringify(recommandationData.View);
		spaceviewzone = new mHealth.models.SpaceViewZoneModel({

			pageName : 'Activity',
			space : mHealth.models.SpaceModel.fromJSON(spaceData),
			view : mHealth.models.ViewModel.fromJSON(viewData),
			zone : mHealth.models.ZoneModel.fromJSON(zoneData)

		});
		spaceviewzone.save();
		activity = mHealth.models.SpaceViewZoneModel.select(function(record) {

			// TODO : activity should not be global.
			if(record.pageName === 'Activity') {

				return record;
			}
		});

		this.proxy(this.trigger('getservice'));

		//$.mobile.changePage("../../activities/view/showactivity.html");
	},
	/**
	 *Name : recommendationFailure
	 *Purpose: On the Failure of the recommandation service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {
		alert('failure');

	}
});

// mHealth.controllers.ActivityController.extend({
//
// getcall : function(){
// alert('getcall');
// mHealth.controllers.ActivityController.bind('getservice', function(){
// alert('triggered');
// });
//
// this.trigger('getservice');
//
// }

// });