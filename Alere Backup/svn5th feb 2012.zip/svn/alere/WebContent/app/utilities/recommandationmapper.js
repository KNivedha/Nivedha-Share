/**
  * Object : recommendation
  * Recommendation default settings
  **/
mHealth.recommendation = {};

/**
  * Name    : createRecommendationRequestJSON
  * Purpose : Method to create request body for recommendation Service.
  * Params  : responseType -  recommendation type
  * Returns : bodyContent
  **/
mHealth.recommendation.createRecommendationRequestJSON = function(responseType) {
	var bodyContent;
    bodyContent = JSON.stringify([{
		"ActivityCount" : "",
		"AppName" : "Mobile Main",
		"RelatedActivityCount" : "",
		"Mode" : "",
		"ActivityID" : "",
		"StatusID" : "",
		"SessionID" : "1326387223",
		"ResponseType" : responseType,
		"EffectiveDate" : ""
	}]);
	return bodyContent;
};
mHealth.recommendation.createAssessment = function(startToken,endToken,participantAnswer) {
	var bodyContent;
    bodyContent = JSON.stringify([{
                                  "StartToken" : startToken,
                                  "EndToken" : endToken,
                                  "ParticipantAnswerClientUpdates" : ""
                                  }]);
	return bodyContent;
};