/**
 *Controller : LoginController
 *Controller to do login functionality.
 **/

mHealth.controllers.LoginController = Spine.Controller.sub({
	el : 'body',
	elements : {
		'#name' : 'uname',
		'#password' : 'pwd',
		'#server' : 'serverlogin'
	},
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #loginbutton' : 'doLogin',
		'click #sendMail' : 'sendEmail'
	},

	init : function() {

		//		if( mHealth.previousLogin != null){
		//		$('#login').html(mHealth.previousLogin);
		//		}
	},
	/**
	 *Name   : sendEmail
	 *Purpose: Method to send email.
	 *Params : --
	 *Return : --
	 **/
	sendEmail : function() {
		//location.href = "email://sendEmail?mailto=&subject="
		mHealth.util.customPrompt('Do you want to send email ?', function(){
			alert('cancel');
		}, function(){
			alert('ok');
		});
                                                           
		//mHealth.util.customAlert('Send the Email ?');
      // mHealth.util.sendEmailEvent("service.desk@alere.com","Alere mHealth");
		
	},
	/**
	 *Name   : loginSuccess
	 *Purpose: Success callback to authenticate user.
	 *Params : output - response from the server
	 *Return : --
	 **/
	loginSuccess : function(output) {
		var body = mHealth.recommendation.createRecommendationRequestJSON("1020");
		this.proxy(this.service.getResponse(mHealth.env.message_get_url, this.proxy(this.participantSuccess), "", false));
		this.proxy(this.service.postRequest(mHealth.env.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.loginFailure), true));
	},
	
	
	/**
	 * Name    : participantSuccess
	 * Purpose : Success callback for getting participant data.
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	participantSuccess : function(output) {
		var response;
		response = output.responseText;
		mHealth.models.ParticipantModel.customFromJSON(response);
	},
	/**
	 *Name   : loginFailure
	 *Purpose: Failure callback to authenticate user.
	 *Params : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server.
	 *Return : Displays error message.
	 **/
	loginFailure : function(jqXHR, textStatus, errorThrown) {

		$('#splash_message').show();
		if(errorThrown == mHealth.SettingsController.timeOut) {
			$('#splash_message').html(mHealth.SettingsController.errTimeout);
		} else if(errorThrown == mHealth.SettingsController.unauthorized) {
			$('#splash_message').html(mHealth.SettingsController.msgBadLogin);
		} else {
			$('#splash_message').html(mHealth.SettingsController.msgErrorCommunication);

		}
	},
	/**
	 *Name   : doLogin
	 *Purpose: Method to encode user credential to base64 encoding.
	 *Params : --
	 *Return : --
	 **/
	doLogin : function() {

		var username, password, credentials;
		username = $('#name').val();
		password = $('#password').val();
		environment = $('select#server option:selected').val();
		switch(environment) {
			case "dev":
				mHealth.env = mHealth.dev
				break;
			case "uat":
				mHealth.env = mHealth.uat
				break;
			case "prod":
				mHealth.env = mHealth.prod
				break;
			case "qa":
				mHealth.env = mHealth.uat
				break;
			default:
				mHealth.env = mHealth.dev
				break;

		}
		mHealth.util.participantEmail = username;
		$('#splash_message').hide();
		if((username != '') && (password != '')) {
			credentials = $.base64Encode(username + ":" + password);
			this.service.authenticateUser(mHealth.env.authtoken_get_url, credentials, this.proxy(this.loginSuccess), this.proxy(this.loginFailure));
		} else {
			$('#splash_message').show();
			$('#splash_message').html('Enter the Username and password');
		}
	},
	/**
	 *Name   : recommendationSuccess
	 *Purpose: Success callback for getting home recommendation type.
	 *Params : output - response from the server.
	 *Return : --
	 **/

	recommendationSuccess : function(output) {		
		var response = output.responseText;
		var recommandationData = JSON.parse(response);
		var viewData = JSON.stringify(recommandationData.View);
		mHealth.models.ViewModel.customFromJSON(viewData);
		var assessment = mHealth.recommendation.createAssessment("20120101T141339.000 GMT", "20120101T141339.000 GMT", "");
		this.proxy(this.service.postRequest(mHealth.env.assessment_json_url, assessment, this.proxy(this.assessmentSuccess), this.proxy(this.assessmentFailure)), false);
		$.mobile.changePage("../../home/view/home.html");
		//mHealth.util.callNativeBarEvent();
	},
	/**
	 *Name   : recommendationFailure
	 *Purpose: Failure callback for getting home recommendation type.
	 *Params : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server.
	 *Return : Alerts 'The service is not available'.
	 **/
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {
		jAlert('The service is not available');
	},
	/**
	 *Name : assessmentSuccess
	 *Purpose: After getting the response from the assessment Service, the functon will parse the participant,assessment,section,question,answer and participantanswer
	 Set the value in the respective model.
	 *Params: output
	 *Return: null
	 **/
	assessmentSuccess : function(output) {
		var response, assessmentsData, participantData, assessmentData, sectionData, questionData, answerData, participantAnswerData;
		response = output.responseText;
		assessmentsData = JSON.parse(response);
		participantData = JSON.stringify(assessmentsData.Participant);
		assessmentData = JSON.stringify(assessmentsData.Assessment);
		sectionData = JSON.stringify(assessmentsData.Section);
		questionData = JSON.stringify(assessmentsData.Question);
		answerData = JSON.stringify(assessmentsData.Answer);
		participantAnswerData = JSON.stringify(assessmentsData.ParticipantAnswer);
		mHealth.models.AssessmentModel.customFromJSON(assessmentData);
		mHealth.models.SectionModel.customFromJSON(sectionData);
		mHealth.models.QuestionModel.customFromJSON(questionData);
		mHealth.models.AnswerModel.customFromJSON(answerData);
		mHealth.models.ParticipantAnswerModel.customFromJSON(participantAnswerData);
		mHealth.models.ParticipantModel.customFromJSON(participantData);
		this.getMiniAssessmentData();		
	},
	/**
	 *Name   : getMiniAssessmentData
	 *Purpose: Method to fetch the questions & answers for mini assessment
	 *Params : --
	 *Return : mini assessment questions & answers
	 **/
	getMiniAssessmentData : function() {				
		DIABETES_MINI_ASSESSMENT = "Diabetes Assessment";
		var assessData = mHealth.models.AssessmentModel.findByAttribute("assessmentId", "Diabetes Mini Assessment");
		var questions = [];
		var sections = [];
		var answers = [];
		var outputHTML = '';
		mHealth.models.SectionModel.select(function(section) {
			if(section.assessmentId == assessData.assessmentId) {
				sections += section;				
				mHealth.models.QuestionModel.select(function(question) {
					if(question.assessmentId == section.assessmentId && question.sectionId == section.sectionId) {
						mHealth.models.AnswerModel.select(function(answer) {
							if(answer.assessmentId == question.assessmentId && answer.sectionId == question.sectionId && answer.questionId == question.questionId) {								
								answers += answer;																
							}																		
						});	
						question.answers=answers;
						// alert("Anser "+question.answers);
					    questions+=question;		 					
					}
				});
			}
		});		
		// alert("Questions" +questions);
		var miniassessmentHTML = mHealth.assessment.get_dropdown_html(questions);
		
		// alert("HTML"+miniassessmentHTML);
	},	
	
	
	/**
	 *Name : assessmentFailure
	 *Purpose: On the Failure of the assessment service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	assessmentFailure : function(jqXHR, textStatus, errorThrown) {
		//alert('failure');
	}
});
