mHealth.models.AssessmentModel =  Spine.Model.sub();
mHealth.models.AssessmentModel.configure('AssessmentModel','assessmentId',
		'participantId','language','title','frequencyHours','recurringFlag','rank',
                     'dashboardModuleId','introCopy','maxCredits','earnedCredits','status ','image',
                     'imageURL','createTimestamp','updateTimestamp','startDate ','endDate',
                     'learnMore','triggers','nextTierPoints','earnedPts ');
 
 

 