//
//  TabBarController.m
//  Alere
//
//  Created by virtusa5 on 18/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TabBarController.h"

@implementation TabBarController
#define DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) / 180.0 * M_PI)
@synthesize rotated,landscp,alereViewController,tabBar,returnType,orientation,portrait;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    NSLog(@"view did oad in tabbar");
    returnType=NO;
    alereViewController.view.frame=CGRectMake(0, 0, 320, 460);
    tabBar.delegate=self;
    //tabBar.view.frame=CGRectMake(0, 0, 320, 480);
    [self.view addSubview:tabBar.view];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    NSLog(@"selected %d",[tabBarController selectedIndex]);
    NSString* callBackFunction;
    switch ([tabBarController selectedIndex])
    {
        case 0:
            callBackFunction=@"loadHome()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
        case 1:
            callBackFunction=@"loadMessages()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
        case 2:
            callBackFunction=@"loadActivities()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
        case 3:
            callBackFunction=@"loadTrackers()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
        case 4:
            callBackFunction=@"loadSettings()";
            [alereViewController.webView stringByEvaluatingJavaScriptFromString:callBackFunction];
            break;
    }
    [viewController setView:alereViewController.view];
    
}
-(void)setInitialOrientation
    {
     UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];

     if (interfaceOrientation==UIDeviceOrientationPortraitUpsideDown) 
     {
        NSLog(@"rotating to landscape");
       [ self.view setCenter:CGPointMake(160, 240)];
       CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
       self.view.transform = cgCTM;
       self.view.bounds = CGRectMake(0, 0, 320, 480);
       [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortraitUpsideDown];
     }
     if(interfaceOrientation==UIDeviceOrientationLandscapeLeft) //(app.tabBarController.rotated==YES) 
     {
        NSLog(@"rotating to portrait");
        [ self.view setCenter:CGPointMake(160, 240)];
        CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(90));
        self.view.transform = cgCTM;
        self.view.bounds = CGRectMake(0, 0,  480,300);
        [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationLandscapeRight];
     }
    if(interfaceOrientation==UIDeviceOrientationLandscapeRight) //(app.tabBarController.rotated==YES) 
    {
        NSLog(@"rotating to portrait");
        [self.view setCenter:CGPointMake(160, 240)];
        CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(-90));
        self.view.transform = cgCTM;
        self.view.bounds = CGRectMake(0, 0, 480,300);
        [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationLandscapeLeft];
    }
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    
    orientation=interfaceOrientation;
    if ( (rotated== YES)&&( interfaceOrientation==UIDeviceOrientationPortrait || interfaceOrientation==UIDeviceOrientationPortraitUpsideDown )) {
       return NO;
    }
    if( (landscp ==YES )&&(interfaceOrientation==UIDeviceOrientationPortrait || interfaceOrientation==UIDeviceOrientationPortraitUpsideDown)) {
      return NO;
    }
    
    return YES;
    // Return YES for supported orientations
    
}
-(void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event 
{
    NSSet *allTouches = [event allTouches];
    switch ([allTouches count])
    {
        case 1: 
        {
            UITouch *touch =[[allTouches allObjects] objectAtIndex:0];
            switch ([touch tapCount])
            {
                case 1: 
                {
                    UIInterfaceOrientation interfaceOrientation= [[UIApplication sharedApplication] statusBarOrientation];
                    
                    NSLog(@"single tap");
//                    if (enteredGraph&& !resized) 
//                    {
//                        if (interfaceOrientation==UIDeviceOrientationLandscapeRight||interfaceOrientation==UIDeviceOrientationLandscapeLeft )
//                        {
//                            tabBarControllerObj.tabBar.view.frame=CGRectMake(0, 0, 480, 370);
//                        }
//                        else
//                        {
//                            tabBarControllerObj.tabBar.view.frame=CGRectMake(0, 0, 320, 510);
//                            
//                        }
//                        resized=YES;
//                    }
//                    else if(enteredGraph&& resized)
//                    {
//                        if (interfaceOrientation==UIDeviceOrientationLandscapeRight||interfaceOrientation==UIDeviceOrientationLandscapeLeft )
//                        {
//                            tabBarControllerObj.tabBar.view.frame=CGRectMake(0, -20, 480, 320);
//                        }
//                        else
//                        {
//                            tabBarControllerObj.tabBar.view.frame=CGRectMake(0, 0, 320, 460);
//                            
//                        }
//                    } 
                    
                }
                    
                    break;
            }
            
            
        }
    }
} 

@end
