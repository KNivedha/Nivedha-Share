/**
  * Controller : ActivityController
  * Controller to do Activity Tab functionality.
  **/

mHealth.controllers.ActivityController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	subActivityView : "",
	events : {

		// 'pagebeforecreate #showActivity' : 'getActivity',

		'pagebeforeshow #showActivity' : 'showActivity',
		'click .detailActivity' : 'getSubActivity',
		'pagebeforeshow #detailActivity' : 'showSubActivity',
		'pagebeforeshow #calendarPage' : 'showCalendar',
		'click #calendarSave' : 'getCalendarData',
		'click #challengesShortCut' : 'getActivity'

	},

		/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showSubActivity : function() {
		$('#detailActivity_div').html(_.template($('#detailActivityDataList').html(), {
			recordRequired : recordRequired
		}));
		$('#detailActivity').trigger('create');
	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showActivity : function() {
	
	

		$('#activityTitle').text(activity[0].space[0].title);

	
		if(activity[0].zone.length > 1) {

			$('#activity_zone').show();
			var activityZone = activity[0].zone[0].isInset;

			$('#activity_zone').html(_.template($('#navDataList').html(), activityZone));
		}
		
	
		var activityView = activity[0].view;

		$('#activity_div').html(_.template($('#activityDataList').html(), {
			activityView : activityView
		}));
		$('#showActivity').trigger('create');
	},
	
	/**
	 *Name: getSubActivity
	 *Purpose: On click the View of the Activity, the Function will be
	 *Params
	 *Returns
	 **/
	getSubActivity : function(event) {
		var view = event.target;
		// var html = $(event.target).html();
		selectedViewName = $(view).parents('li').children('div').children('div').children('a').children('h3').text();
		mHealth.models.SpaceViewZoneModel.each(function(record) {
			if(record.pageName === 'Activity') {
				for( i = 0; i < record.view.length; i++) {
					if(record.view[i].title.trim() === selectedViewName.trim()) {
						this.subActivityView = record.view[i];
						recordRequired = this.subActivityView;
						break;
					}
				}
			}
		});
		//this.getAssessmentData(selectedViewName);
		$.mobile.changePage("detailactivity.html");

	},
	/**
	 *Name   : getAssessmentData
	 *Purpose: Method to fetch the questions & answers for assessment
	 *Params : --
	 *Return : assessment questions & answers
	 **/
	getAssessmentData : function(activity) {
		var assessData = mHealth.models.AssessmentModel.findByAttribute("assessmentId", activity);
		var questions = [];
		var sections = [];
		var outputHTML = '';
		var sectionData = [];
		var answerData = [];
		var questionData = [];
		sectionData.push({
			'object' : 'ChallengeStrivefor5Challenges',
			'assessmentId' : 'Challenge Strive for 5',
			'sectionId' : 'Challenges',
			'title' : '',
			'rank' : '4',
			'image' : '',
			'createTimestamp' : '20110106T071627.000 GMT',
			'updateTimestamp' : '20110308T213023.000 GMT',
			'startDate' : '20100301',
			'endDate' : '20110228',
			'learnMore' : ''
		}, {
			'object' : 'ChallengeStrivefor5Challenges',
			'assessmentId' : 'Challengehfgh',
			'sectionId' : 'Challenges',
			'title' : '',
			'rank' : '4',
			'image' : '',
			'createTimestamp' : '20110106T071627.000 GMT',
			'updateTimestamp' : '20110308T213023.000 GMT',
			'startDate' : '20100301',
			'endDate' : '20110228',
			'learnMore' : ''
		});
		questionData.push({
			'questionId' : 'SubAct Eat 1 Cup of Fruit and 1 Cup of Vegetables',
			'startDate' : '20100301T050000.000 GMT',
			'endDate' : '20151231T050000.000 GMT',
			'learnMore' : 'SubAct Eat 1 Cup of Fruit and 1 Cup of Vegetables',
			'assessmentId' : 'Challenge Strive for 5',
			'sectionId' : 'Challenges',
			'rank' : '1',
			'theQuestion' : 'Enter your cups here'
		}, {
			'questionId' : 'SubAct Eat 1 Cup of Fruit and 1 Cup of Vegetables',
			'startDate' : '20100301T050000.000 GMT',
			'endDate' : '20151231T050000.000 GMT',
			'learnMore' : 'SubAct Eat 1 Cup of Fruit and 1 Cup of Vegetables',
			'assessmentId' : 'Challeng',
			'sectionId' : 'Challenges',
			'rank' : '1',
			'theQuestion' : 'Enter your cups here'
		});

		answerData.push({
			'source_id' : '19',
			'object' : 'ChallengeStrivefor5ChallengesSubActEat1CupofFruitand1CupofVegetablesSubActEat1CupofFruitand1CupofVegetables',
			'answerId' : 'SubAct Eat 1 Cup of Fruit and 1 Cup of Vegetables',
			'startDate' : '20100301T050000.000 GMT',
			'endDate' : '20151231T050000.000 GMT',
			'assessmentId' : 'Challenge Strive for 5',
			'sectionId' : 'Challenges',
			'questionId' : 'SubAct Eat 1 Cup of Fruit and 1 Cup of Vegetables',
			'rank' : '1',
			'entryType' : 'NumberEdit',
			'theAnswer' : 'Enter your cups here'
		}, {
			'source_id' : '19',
			'object' : 'ChallengeStrivefor5ChallengesSubActEat1CupofFruitand1CupofVegetablesSubActEat1CupofFruitand1CupofVegetables',
			'answerId' : 'SubAct Eat 1 Cup of Fruit and 1 Cup of Vegetables',
			'startDate' : '20100301T050000.000 GMT',
			'endDate' : '20151231T050000.000 GMT',
			'assessmentId' : 'Challenge Sv',
			'sectionId' : 'Challenges',
			'questionId' : 'SubAct Eat 1 Cup of Fruit and 1 Cup of Vegetables',
			'rank' : '1',
			'entryType' : 'NumberEdit',
			'theAnswer' : 'Enter your cups here'
		});
		sectionData.map(function(section) {
			if(section.assessmentId == assessData.assessmentId) {
				assessData.section = mHealth.models.SectionModel.fromJSON(section);
				questionData.map(function(question) {
					if(question.assessmentId == section.assessmentId && question.sectionId == section.sectionId) {
						assessData.section.question = mHealth.models.QuestionModel.fromJSON(question);
						answerData.map(function(answer) {
							if(answer.assessmentId == question.assessmentId && answer.sectionId == question.sectionId && answer.questionId == question.questionId) {
								assessData.section.question.answer = mHealth.models.AnswerModel.fromJSON(answer);
							}
						});
					}
				});
			}

		});
		assessData.save();
		displayques = mHealth.assessment.get_numberedit_html(assessData);
		
	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	getActivity : function() {
	mHealth.util.showMask();
		var isExists = mHealth.models.SpaceViewZoneModel.each(function(record) {
			if(record.pageName === 'Activity') {
				return true;
			}
		});
		if(isExists !== true) {
			var body = mHealth.recommendation.createRecommendationRequestJSON("","","1003");
			this.proxy(this.service.postRequest(mHealth.env.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.recommendationFailure), true));

		}
	},
	/**
	 *Name
	 *Purpose
	 *Params
	 *Returns
	 **/
	showCalendar : function() {
		$("#eventName").val(selectedViewName);
		$('#startDate').scroller({
			preset : 'datetime',
			theme : 'ios'
		});
		$('#endDate').scroller({
			preset : 'datetime',
			theme : 'ios'
		});
	},
	/**
	 * Name    : getCalendarData
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	getCalendarData : function() {
		var title, startDate, endDate;
		title = $('#eventName').val();
		startDate = $('#startDate').val();
		endDate = $('#endDate').val();
		mHealth.util.callCalendarEvent(title, startDate, endDate);
		$.mobile.changePage("../../activities/view/detailactivity.html");

	},
	/**
	 *Name: recommendationSuccess
	 *Purpose: After getting the response from the recommandation Service, the functon will parse the space, View and ZOne
	 Set the value in the respective model.
	 *Params: output
	 *Returns: null
	 **/
	recommendationSuccess : function(output) {
		
		var response, recommandationData, spaceData, zoneData, viewData, spaceviewzone;
		response = output.responseText;
		recommandationData = JSON.parse(response);
		spaceData = JSON.stringify(recommandationData.Space);
		zoneData = JSON.stringify(recommandationData.Zone);
		viewData = JSON.stringify(recommandationData.View);

		spaceviewzone = new mHealth.models.SpaceViewZoneModel({

			pageName : 'Activity',
			space : mHealth.models.SpaceModel.fromJSON(spaceData),
			view : mHealth.models.ViewModel.fromJSON(viewData),
			zone : mHealth.models.ZoneModel.fromJSON(zoneData)

		});
		spaceviewzone.save();
		activity = mHealth.models.SpaceViewZoneModel.select(function(record) {

			// TODO : activity should not be global.
			if(record.pageName === 'Activity') {

				return record;
			}
		});
	
       $.mobile.changePage("../../activities/view/showactivity.html");
       mHealth.util.hideMask();
        location.href = "tabbar://loadActivities?";
			},
	/**
	 *Name : recommendationFailure
	 *Purpose: On the Failure of the recommandation service call, the function will get executed.
	 *Params: jqXHR, textStatus, errorThrown
	 *Return: null
	 **/
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {
	 mHealth.util.hideMask();
	
		

	}
});
