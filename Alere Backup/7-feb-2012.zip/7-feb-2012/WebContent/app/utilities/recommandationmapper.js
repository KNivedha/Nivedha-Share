/**
  * Object : recommendation
  * Recommendation default settings
  **/
mHealth.recommendation = {};

/**
  * Name    : createRecommendationRequestJSON
  * Purpose : Method to create request body for recommendation Service.
  * Params  : responseType -  recommendation type
  * Returns : bodyContent
  **/
mHealth.recommendation.createRecommendationRequestJSON = function(activityID, statusID, responseType) {
	var bodyContent;
    bodyContent = JSON.stringify([{
		"ActivityCount" : "",
		"AppName" : "Mobile Main",
		"RelatedActivityCount" : "",
		"Mode" : "",
		"ActivityID" : activityID,
		"StatusID" : statusID,
		"SessionID" : "asdf",
		"ResponseType" : responseType+"",
		"EffectiveDate" : ""
	}]);

	return bodyContent;
};
mHealth.recommendation.createAssessment = function(startToken,endToken,participantAnswer) {
	var bodyContent;	
    bodyContent = JSON.stringify([{
                                  "StartToken" : startToken,
                                  "EndToken" : endToken,
                                  "ParticipantAnswerClientUpdates" : participantAnswer
                                  }]);
	return bodyContent;
};