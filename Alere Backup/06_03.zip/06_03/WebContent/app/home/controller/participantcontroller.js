/**

 * Controller :Participant controller
 * Logic for profile is done here
 **/
mHealth.controllers.ParticipantController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #showProfile' : 'getProfileData',
		'click #saveProfile' : 'saveProfileData',
		'pagebeforeshow #profilePage' : 'showProfileData',
		'pageshow #profilePage' : 'processData'
	},

	/**
	 * Name    : getProfileData
	 * Purpose : Method to get the response for profile
	 * Params  : --
	 * Returns : --
	 **/
	getProfileData : function() {
		mHealth.util.heightFlag = true;
		var modelCount = mHealth.models.ParticipantModel.count();
		if(modelCount === 0) {
			mHealth.util.showMask();
			this.service.getResponse(mHealth.env.message_get_url, this.proxy(this.participantSuccess), this.proxy(this.participantFailure), true);
		} else {
			$.mobile.changePage("../../home/view/profile.html");
		}
	},
	/**
	 * Name    : participantSuccess
	 * Purpose : Success callback for getting participant data.
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	participantSuccess : function(output) {
		var response = output.responseText;
		this.proxy(this.processProfileData(response));
		mHealth.util.hideMask();
		$.mobile.changePage("../../home/view/profile.html");
	},
	/**
	 * Name    : participantFailure
	 * Purpose : Failure callback for getting participant data
	 * Params  : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server
	 * Returns : Alerts 'Information not available'
	 **/
	participantFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.customAlert(mHealth.Condition.informationErrMsg, '', false);
		mHealth.util.hideMask();
	},
	/**
	 * Name    : showProfileData
	 * Purpose : Method to render profile data
	 * Params  : --
	 * Returns : --
	 **/
	showProfileData : function() {

		var participantData;
		var profileDetail;
		profileDetail = mHealth.PersonalInfo;
		$('#profileHeader').html(_.template($('#headerScript').html(), {
			profileDetail : profileDetail
		}));
		participantData = mHealth.models.ParticipantModel.all();

		$('#profiles').html(_.template($('#participantList').html(), {
			participantData : participantData
		}));
alert(participantData);
		$('#profileHeader').trigger('create');
		$('#profiles').trigger('create');

	},
	/**
	 * Name    : saveProfileData
	 * Purpose : Method to update profile data in model
	 * Params  : --
	 * Returns : --
	 **/
	saveProfileData : function() {

		var participantData;
		participantData = mHealth.models.ParticipantModel.first();
		var tempEmailId = participantData.emailAddress;
		var tempPrefName = participantData.preferredName;
		var emailReg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
		var validEmailFlag = false;
		mHealth.util.showMask();
		// Only Update the profile if the User Changes
		var emailValue = $("#email").val();
		if(!(tempPrefName == $("#preferredName").val()) || !(tempEmailId == $("#email").val())) {

			if(emailReg.test(emailValue) == true) {

				var bodyContent = JSON.stringify([{
					"preferredName" : $("#preferredName").val().trim(),
					"emailAddress" : $("#email").val()
				}]);

				this.service.postRequest((mHealth.env.profile_url), bodyContent, "", "", false);
			} else {
				mHealth.util.customAlert(mHealth.Validation.emailValidation, '', false);
			}
		}

		participantData.updateAttributes({
			preferredName : $("#preferredName").val().trim(),
			emailAddress : $("#email").val(),
			height : $('select#height option:selected').val()
		});
		mHealth.index = $('select#height option:selected').val();
		var hDataObject = mHealth.recommendation.ParticipantMapper(mHealth.models.ParticipantModel.first().participantID, mHealth.index);
		this.service.postRequest((mHealth.env.healthdata_url + "Height"), hDataObject, this.proxy(this.heightSaveSuccess), this.proxy(this.heightSaveFailure), true);

	},
	profileSaveFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.customAlert(mHealth.SyncProcessController.msgErrorCommunication, '', false);
		mHealth.util.hideMask();

	},
	profileSaveSuccess : function(output) {
		$.mobile.changePage("../../home/view/home.html");
		mHealth.util.hideMask();
	}, /**
	 *Name: heightSaveFailure
	 *Purpose: Failure callback function for saving profile data
	 *Params: Implict failure callback params
	 *Returns: Doesn't return
	 **/
	heightSaveFailure : function(jqXHR, textStatus, errorThrown) {
		//ID: 40679: Profile save should thorw an Error when the Service is Down.
		// All the Alert should have the Mya
		mHealth.util.customAlert(mHealth.SyncProcessController.msgErrorCommunication, '', false);
		mHealth.util.hideMask();

	},
	/**
	 *Name: heightSaveSuccess
	 *Purpose: success callback function for saving profile data
	 *Params: output from postRequest as implicit param
	 *Returns: Doesn't return
	 **/
	heightSaveSuccess : function(output) {
		var response = output.responseText;
		var responses = JSON.parse(response);
		if(mHealth.util.heightFlag == true)
			$.mobile.changePage("home.html");
		else {
			location.href = "tabbar://loadTrackers?";
			$.mobile.changePage("../../trackers/view/showtrackertrack.html");
		}
		mHealth.util.hideMask();
	},
	/**
	 * Name    : processData
	 * Purpose : Method to process height units from settings controller
	 * Params  : --
	 * Returns : --
	 **/
	processData : function() {

		var index = "30";
		mHealth.index = mHealth.models.ParticipantModel.first().height;
		if(mHealth.util.selUnits == undefined || mHealth.util.selUnits == 'ft-inch') {
			if(mHealth.index != undefined || "") {
				setHeight('ft-inch', (mHealth.index - 36));
			} else {
				setHeight('ft-inch', index);
			}
		}
		if(mHealth.util.selUnits == "cm") {
			if(mHealth.index != undefined || mHealth.index == "") {
				setHeight('cm', (mHealth.index - 36));
			} else {
				setHeight('cm', index);
			}
		}
	},
	/**
	 * Name    : processProfileData
	 * Purpose : Method to set ParticipantModel with response from the server
	 * Params  : response - response from the server
	 * Returns : --
	 **/
	processProfileData : function(response) {
		mHealth.models.ParticipantModel.customFromJSON(response);
	}
});
