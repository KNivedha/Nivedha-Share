//
//  NetworkCheck.m
//  Alere
//
//  Created by virtusa5 on 15/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "NetworkCheck.h"
#import "AlereViewController.h"
#import "AlereAppDelegate.h"
#import "Reachability.h"
@implementation NetworkCheck
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
if ([action isEqualToString:@"networkStatus"]) {
  
    AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication]delegate];
    NetworkStatus status =[[Reachability reachabilityForInternetConnection] currentReachabilityStatus];
    NSString* str;

    
    if (status == NotReachable) 
    {
        //status Offline
        NSLog(@"Offline");
        str=@"networkStatus([\"false\"])";
        [app.viewController.webView stringByEvaluatingJavaScriptFromString:str];
    }
    else 
    {
        //status onlin
        NSLog(@"Online");
        str=@"networkStatus([\"true\"])";
        [app.viewController.webView stringByEvaluatingJavaScriptFromString:str];
    }
    

}    
}
@end


