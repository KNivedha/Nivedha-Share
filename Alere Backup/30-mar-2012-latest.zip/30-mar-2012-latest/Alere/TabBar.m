//
//  TabBar.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TabBar.h"
#import "AlereAppDelegate.h"

#import "AlereViewController.h"

@implementation TabBar
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
     AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    if ([action isEqualToString:@"login"] )  
    {
      if ( !app.viewController.login)
      {
        UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];
        if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
            app.viewController.webView.frame=CGRectMake(0,0,320,418);
        }
        if (interfaceOrientation==UIInterfaceOrientationLandscapeRight||interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
            app.viewController.webView.frame=CGRectMake(0,0,480,265);
        }
        app.viewController.baseTabBar.hidden=NO;
				NSInteger count=[parameters count];
				NSMutableArray* tabIems=[[NSMutableArray alloc]initWithCapacity:count];
			
			  for (int i=0;i<count;i++) {
         [tabIems addObject:[parameters objectForKey:[NSString stringWithFormat:@"tab%d",i]]];
        }
				[app.viewController createTabbar:tabIems];
				[tabIems release];
        UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:0];
        app.viewController.baseTabBar.selectedItem=homeTab;
        app.viewController.login=YES;
          
        webViewFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:app.viewController action:@selector(handleTapOnWebView)];
		webViewFingerTap.delegate=app.viewController;
        [app.viewController.webView addGestureRecognizer:webViewFingerTap];
        [UIApplication sharedApplication].idleTimerDisabled=YES;
        [app.viewController resetAppIdleTimer];
      }
    }
   else if ([action isEqualToString:@"logout"] )
    {
        [[UIApplication sharedApplication]setStatusBarHidden:NO];
        app.viewController.baseTabBar.userInteractionEnabled=YES;
        UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];

        if (interfaceOrientation==UIInterfaceOrientationPortrait)
        {
            UIApplication* application=[UIApplication sharedApplication];
            CGRect statusBarHeight=application.statusBarFrame;
            app.viewController.view.frame = CGRectMake(0, statusBarHeight.size.height, 320, statusBarHeight.size.height>20?440:460);
            app.viewController.webView.frame=CGRectMake(0,0,320,460);
        }
        if (interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) 
        {
            UIApplication* application=[UIApplication sharedApplication];
            CGRect statusBarHeight=application.statusBarFrame;
            app.viewController.view.frame = CGRectMake(0, 0, 320,  statusBarHeight.size.height>20?440:460);     
            app.viewController.webView.frame=CGRectMake(0,0,320,460);
        }
        if (interfaceOrientation==UIInterfaceOrientationLandscapeRight) {
              app.viewController.view.frame=CGRectMake(0,0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);
        }   
        else  if (interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
            app.viewController.view.frame=CGRectMake(20,0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);
        }   
        app.viewController.baseTabBar.hidden=YES; 
				[app.viewController.baseTabBar removeFromSuperview];
				NSLog(@"retain count of basetab : %d",[app.viewController.baseTabBar retainCount]);
				//[app.viewController.baseTabBar release]; 
        app.viewController.login=NO;
        [app.viewController cancelTimer];
        [app.viewController.webView removeGestureRecognizer:webViewFingerTap];
        [webViewFingerTap release];
    }
    if ([action isEqualToString:@"showTabBar"] )  
    {
       {
        UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];
        if (interfaceOrientation==UIInterfaceOrientationPortrait||interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
            app.viewController.webView.frame=CGRectMake(0,0,320,418);
        }
        if (interfaceOrientation==UIInterfaceOrientationLandscapeRight||interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
            app.viewController.webView.frame=CGRectMake(0,0,480,265);
        }
        app.viewController.baseTabBar.hidden=NO;
       }
    }
    else if ([action isEqualToString:@"hideTabBar"] )
    {
        [[UIApplication sharedApplication]setStatusBarHidden:NO];
        
        app.viewController.baseTabBar.userInteractionEnabled=YES;
        
        UIInterfaceOrientation interfaceOrientation=[[UIApplication sharedApplication]statusBarOrientation];
        
        if (interfaceOrientation==UIInterfaceOrientationPortrait) {
            app.viewController.view.frame=CGRectMake(0,20,320,460);
            app.viewController.webView.frame=CGRectMake(0,0,320,460);
        }
        if (interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
            app.viewController.view.frame=CGRectMake(0,00,320,460);
            app.viewController.webView.frame=CGRectMake(0,0,320,460);
        }
        if (interfaceOrientation==UIInterfaceOrientationLandscapeRight) {
            app.viewController.view.frame=CGRectMake(0,0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);
        }   
        else  if (interfaceOrientation==UIInterfaceOrientationLandscapeLeft) {
            app.viewController.view.frame=CGRectMake(20,0,300,480);
            app.viewController.webView.frame=CGRectMake(0,0,480,320);
        }   
        app.viewController.baseTabBar.hidden=YES;  
    }
    
      NSArray* baseTabbarItems=[app.viewController.baseTabBar items];
       for (UITabBarItem *tabItem in baseTabbarItems)
			  {
	        if ([tabItem.title isEqualToString:action]) {
	        app.viewController.baseTabBar.selectedItem=tabItem;
          }
        }
//    else if ([action isEqualToString:@"loadHome"] )
//    {
//	  app.viewController.baseTabBar.userInteractionEnabled=YES;
//       app.viewController.webView.userInteractionEnabled=YES;
//       UITabBarItem *homeTab=[objectAtIndex:0];
//       app.viewController.baseTabBar.selectedItem=homeTab;
//    }
//    else if ([action isEqualToString:@"loadMessages"] )
//    {
//        app.viewController.baseTabBar.userInteractionEnabled=YES;
//        app.viewController.webView.userInteractionEnabled=YES;
//        UITabBarItem *messagesTab=[[app.viewController.baseTabBar items]objectAtIndex:1];
//        app.viewController.baseTabBar.selectedItem=messagesTab;
//    }
//    else if ([action isEqualToString:@"Challenges"] )
//    {
//        app.viewController.baseTabBar.userInteractionEnabled=YES;
//        app.viewController.webView.userInteractionEnabled=YES;
//        UITabBarItem *activitiesTab=[[app.viewController.baseTabBar items]objectAtIndex:2];
//        app.viewController.baseTabBar.selectedItem=activitiesTab;
//    }
//
//    else if ([action isEqualToString:@"loadTrackers"] )
//    {
//	  app.viewController.baseTabBar.userInteractionEnabled=YES;
//      app.viewController.webView.userInteractionEnabled=YES;
//       UITabBarItem *trackersTab=[[app.viewController.baseTabBar items]objectAtIndex:3];
//       app.viewController.baseTabBar.selectedItem=trackersTab;
//    }
		 	 
	  if ([action isEqualToString:@"addMask"] )
   {
       app.viewController.baseTabBar.userInteractionEnabled=YES;
	   app.viewController.baseTabBar.userInteractionEnabled=NO;
		
   }
	 else if ([action isEqualToString:@"removeMask"] )
   {
	
       app.viewController.baseTabBar.userInteractionEnabled=YES;
   }
	 

} 
@end
