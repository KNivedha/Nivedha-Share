//
//  AlereViewController.m
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "AlereViewController.h"
#import <EventKit/EventKit.h>
#import "AlereAppDelegate.h"
#import "OrientationConstants.h"
#define DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) / 180.0 * M_PI)
@implementation AlereViewController
@synthesize webView,rotated,landscp,insideTabBar;
- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle


 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad
 {
     calObj=[[Calendar alloc]init];
     emailObj=[[EMail alloc]init];
     deviceObj=[[Devices alloc]init];
     orientationObj=[[Orientation alloc]init];
     tabBarObj=[[TabBar alloc]init];
     
     pluginObjects=[[NSMutableDictionary alloc]init];
     [pluginObjects setValue:calObj forKey:@"calendar"];
     [pluginObjects setValue:emailObj forKey:@"email"];
     [pluginObjects setValue:deviceObj forKey:@"about"];
     [pluginObjects setValue:orientationObj forKey:@"gyro"];
     [pluginObjects setValue:tabBarObj forKey:@"tabbar"];
     
     
     landscp=NO;
     returnType=YES;
     rotated=NO;
     cameBack=NO;
      NSLog(@"view did load");
     webView.delegate=self;
     
     //****************************Native calander**************
     //  NSURL *url=[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"Calendar" ofType:@"html" inDirectory:@"Calendar"]];
     
     //****************************mHelath**************
     NSURL *url=[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"termsandconditions" ofType:@"html" inDirectory:@"WebContent/app/rootview/view"]];
     
     //***************************hitting service*****************
     
     //NSURL *url=[NSURL URLWithString:@"http://203.62.174.97/Cache/app/RootView/View/login.html"];
     
     NSURLRequest* request=[NSURLRequest requestWithURL:url ];
     [webView loadRequest:request];
     [super viewDidLoad];
 }


#pragma mark - webview delegate methods

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    
    NSString* scheme;
    NSString* action;
    NSLog(@"webView : delegate method");
    NSString* urlString=[[request URL] absoluteString]; 
    NSLog(@"url from webView is %@",urlString);
    BOOL returnType1;
    NSMutableDictionary* paramData=nil;
    @try 
    {
        scheme=[[urlString  componentsSeparatedByString:@"://"]objectAtIndex:0] ; 
        eventname=[[urlString componentsSeparatedByString:@"://"]objectAtIndex:1] ; 
        NSArray* urlArray=[eventname componentsSeparatedByString:@"?"];
        NSLog(@"count %d ",[urlArray count]);
        if([urlArray count]>1)
        {
            action=[urlArray objectAtIndex:0];
            if (![[urlArray objectAtIndex:1] isEqualToString:@""] ) 
            {
                NSArray* paramArray=[[urlArray objectAtIndex:1]componentsSeparatedByString:@"&"];
                NSLog(@" %@",paramArray);
                int paramcount=[paramArray count];
                NSLog(@"param count %d",paramcount);
                if(paramcount>=1)
                {
                    NSLog(@"more than one parameter");
                    int index=0;
                    paramData=[[NSMutableDictionary alloc]initWithCapacity:4];
                    for(int i = 0; i < paramcount; i++)
                    {
                        NSString *value = [[[paramArray objectAtIndex:i] componentsSeparatedByString:@"="] objectAtIndex:1];
                        NSString *key  = [[[paramArray objectAtIndex:i] componentsSeparatedByString:@"="] objectAtIndex:0];
                        
                        [paramData setValue:value forKey:key];
                        index++;
                    }	
                }
            }
            [[pluginObjects objectForKey:scheme] accessDeviceFeature:paramData forAction:action ];
            NSLog(@"scheme : %@ ,action : %@ , params : %@",scheme,action,paramData);
            returnType1=NO;
        }
        else
        {
            NSLog(@"open url");
            returnType1=YES;
        }
        
    }
    @catch (NSException *exception) 
    {
        returnType1=NO;
        NSLog(@"thrown execption %@",exception);
    }
    return returnType1;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"webview : started");
}
- (void)webViewDidFinishLoad:(UIWebView *)webView1
{
    NSLog(@"webview : finished");
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"webview : loading error %@",error);
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if (insideTabBar==YES)
    {
        if (interfaceOrientation==UIDeviceOrientationPortrait) 
        {
            //app.tabBarController.rotated=YES;
           // [OrientationConstants setRotated:YES];
            NSLog(@"rotating to landscape");
            [ self.tabBarController.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(0));
            self.tabBarController.view.transform = cgCTM;
            self.tabBarController.view.bounds = CGRectMake(0, 20, 320, 480);
            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortrait];
        }
        if (interfaceOrientation==UIDeviceOrientationPortraitUpsideDown) 
        {
            //app.tabBarController.rotated=YES;
          //  [OrientationConstants setRotated:YES];
            NSLog(@"rotating to landscape");
            [ self.tabBarController.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
            self.tabBarController.view.transform = cgCTM;
            self.tabBarController.view.bounds = CGRectMake(0, -20, 320, 480);
            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortraitUpsideDown];
        }
        
        
        if(interfaceOrientation==UIDeviceOrientationLandscapeLeft) //(app.tabBarController.rotated==YES) 
        {
            NSLog(@"rotating to portrait");
            [ self.tabBarController.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(90));
            self.tabBarController.view.transform = cgCTM;
            self.tabBarController.view.bounds = CGRectMake(20, -10,  480,300);
           
            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationLandscapeRight];
            
            // app.tabBarController.rotated=NO;
            
        }
        if(interfaceOrientation==UIDeviceOrientationLandscapeRight) //(app.tabBarController.rotated==YES) 
        {
            NSLog(@"rotating to portrait");
            [ self.tabBarController.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(-90));
            self.tabBarController.view.transform = cgCTM;
            self.tabBarController.view.bounds = CGRectMake(-20, -10, 480,300);
            // app.tabBarController.rotated=NO;
            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationLandscapeLeft];
            
        }
        
        // return YES;
        return NO;

        
    }
    return YES;
        
}
@end
