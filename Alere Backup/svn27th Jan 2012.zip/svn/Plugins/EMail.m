//
//  EMail.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "EMail.h"

@implementation EMail
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    NSArray* keys=[parameters allKeys];
    NSLog(@"keys : %@",keys);
    NSString* toAddress=[parameters objectForKey:[keys objectAtIndex:0]];
    
    NSString* subject=[parameters objectForKey:[keys objectAtIndex:1]];
    NSString* urlString=[NSString stringWithFormat:@"mailto:?to=%@&subject=%@",toAddress,subject];
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlString]];

}

@end
