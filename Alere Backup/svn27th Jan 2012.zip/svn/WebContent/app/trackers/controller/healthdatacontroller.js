mHealth.controllers.HealthDataController = Spine.Controller.sub({
	healthDataTracker : '',
	trackerData : '',
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #viewJournal' : 'getJournalData',
		'click #viewGraph' : 'getGraphData',
		'pagebeforeshow #show_tracker_view' : 'showTracker',
		'pagebeforeshow #show_tracker_track' : 'newEntryTracker',
		'click #track_save' : 'newEntrySave',
		'click .tracker' : 'setTrackerType',
		'pagebeforeshow #show_journal' : 'showJournal',
		'pagebeforeshow #graphpage' : 'showGraphHeader',
		'click .chotype' : 'setChoType',
		'click #graphBack' : 'setBackPage'
	},

	/**
	 *Name: setTrackerType
	 *Purpose: Sets Tracker type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setTrackerType : function(e) {
		this.healthDataTracker = $(e.target).parents(".tracker").attr('name');
		if(this.healthDataTracker!='Exams')
		$.mobile.changePage('detailtracker.html');
		else
		$.mobile.changePage('examslist.html');
	},
	
	/**
	 *Name: setChoType
	 *Purpose: Sets Cholesterol type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setChoType : function(e) {
		this.healthDataTracker = $(e.target).parents(".chotype").attr('name');
		this.getGraphData();
	},
	
	/**
	 *Name: showGraphHeader
	 *Purpose: Sets Back button action depending on the tracker type
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	showGraphHeader : function(){
		var trackerType = {
			"name" : mHealth.controllers.HealthDataController.healthdatatracker
		};
		$('#graphHeader').html(_.template($('#graphtemplate').html(), {
			trackerType : trackerType
		}));
		$('#graphpage').page('destroy').page();
	},
	
	/**
	 *Name: setBackType
	 *Purpose: Sets Back Page from Cholesterol graph
	 *Params: no params
	 *Returns: doesn't return
	 **/
	setBackPage : function(e) {
		this.healthDataTracker =  "Cholesterol";
	},
	
	/**
	 *Name: showJournal
	 *Purpose: Renders the showjournal.html page content
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	showJournal : function() {
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#journal_content').html(_.template($('#journal_list').html(), {
			trackerData : this.trackerData,
			trackerType : trackerType
		}));
		
		$('#show_journal').trigger('create');
	},
	
	/**
	 *Name: showTracker
	 *Purpose: renders the showtracker.html page
	 *Params: No params required
	 *Returns: Doesn't return
	 **/
	showTracker : function() {
		// healthDataTracker has to change to class level.
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#trackviewcontent').html(_.template($('#trackerviewtemplate').html(), {
			trackerType : trackerType
		}));
		$('#headercontent').html(_.template($('#headertemplate').html(), {
			trackerType : trackerType
		}));
		//Usong the page id and trigger .create should populate the value
		$('#show_tracker_view').page('destroy').page();
		//$('#show_tracker_view').trigger('create');
	},
	
	/**
	 *Name: newEntryTracker
	 *Purpose: renders the showtrackertrack.html page
	 *Params: None
	 *Returns:Doesn't return
	 **/
	newEntryTracker : function() {
		// healthDataTracker has to change to class level.
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#showtrackertrackcontent').html(_.template($('#showtrackertracktemplate').html(), {
			trackerType : trackerType
		}));
		
		$('#show_tracker_track').trigger('create');
	},
	
	/**
	 *Name: newHDataObject
	 *Purpose: Creates new health data object to be saved
	 *Params: measurement date, collected date and value. These are set in json object that is created.
	 *Returns: returns a formatted object to be passed as a param in the postRequest service call
	 **/
	newHDataObject : function(measurementDate, collectedDate, value) {
		var hDataObject = [{
			"collectedDate" : collectedDate,
			"latitude" : "",
			"comments" : $('#comments').val(),
			"measurementDate" : measurementDate,
			"appSource" : "1",
			"value" : value,
			"longitude" : "",
			"groupId" : "",
			"source" : "1"
		}];
		return (JSON.stringify(hDataObject));
	},
	
	/**
	 *Name: newEntrySave
	 *Purpose: Saves new tracker entry
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	newEntrySave : function() {
		if(validForm) {//validForm is a global varaible set to true if the submitted form is valid. It should be eliminated.
			var dateSelected = $('#selectDate').val();
			var dateObject;
			if(this.healthDataTracker=='Blood Pressure' || this.healthDataTracker=='Blood Glucose' || this.healthDataTracker=='Weight and BMI')
			{
				var hour = dateSelected.substr(11, 2);
				hour = parseInt(hour, 10);
				if(dateSelected.substr(17, 2) == "PM") {
					if(hour != 12)
						hour = hour + 12;
				} else {
					if(hour == 12)
						hour = 0;
				}
				dateObject = new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2), hour, dateSelected.substr(14, 2));
			}
			else
				dateObject=new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2));
			var measurementDate = dateObject.format('yyyymmdd"T"HHMMss".000 GMT"');
			var collectedDate = (new Date()).format('yyyymmdd"T"HHMMss".000 GMT"');
			if(this.healthDataTracker == "Weight and BMI") {
				var weightHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Weight').val());
				var bmiHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Bmi').val());
				this.service.postRequest((mHealth.uat.healthdata_url + "Weight"), weightHDataObject, "", this.proxy(this.trackerSaveFailure));
				this.service.postRequest((mHealth.uat.healthdata_url + "BMI"), bmiHDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure));
			} else if(this.healthDataTracker == "A1C") {
				var hDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_A1C').val());
				this.service.postRequest((mHealth.uat.healthdata_url + "A1C"), hDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure));
			} else if(this.healthDataTracker == "Blood Glucose") {
				var hDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Glucose').val());
				this.service.postRequest((mHealth.uat.healthdata_url + "Bloodglucose"), hDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure));
			} else if(this.healthDataTracker == "Blood Pressure") {
				var sysHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Sys').val());
				var diaHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Dia').val());
				this.service.postRequest((mHealth.uat.healthdata_url + "BPS"), sysHDataObject, "", this.proxy(this.trackerSaveFailure));
				this.service.postRequest((mHealth.uat.healthdata_url + "BPD"), diaHDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure));
			} else if(this.healthDataTracker == "Cholesterol") {
				var ldlHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_LDL').val());
				var hdlHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_HDL').val());
				var triHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Tri').val());
				var choHDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Cholesterol').val());
				this.service.postRequest((mHealth.uat.healthdata_url + "LDL"), ldlHDataObject, "", this.proxy(this.trackerSaveFailure));
				this.service.postRequest((mHealth.uat.healthdata_url + "HDL"), hdlHDataObject, "", this.proxy(this.trackerSaveFailure));
				this.service.postRequest((mHealth.uat.healthdata_url + "Triglycerides"), triHDataObject, "", this.proxy(this.trackerSaveFailure));
				this.service.postRequest((mHealth.uat.healthdata_url + "Cholesterol"), choHDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure));
			} else if(this.healthDataTracker == "Microalbumin") {
				var hDataObject = this.newHDataObject(measurementDate, collectedDate, $('#value_Microalbumin').val());
				this.service.postRequest((mHealth.uat.healthdata_url + "MAU"), hDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure));
			} else if(this.healthDataTracker=='Foot Exam - Provider' || this.healthDataTracker=='Dilated Retinal Exam' || this.healthDataTracker=='Foot Exam - Self') {
				var hDataObject = this.newHDataObject(measurementDate, collectedDate, '');
				var trackerId;
				if(this.healthDataTracker=='Foot Exam - Provider')
					trackerId='FootExam';
				else if(this.healthDataTracker=='Dilated Retinal Exam')
					trackerId='RetinalExam';
				else
				 	trackerId='FootSelfExam';
				alert(mHealth.uat.healthdata_url + trackerId);
				this.service.postRequest((mHealth.uat.healthdata_url + trackerId), hDataObject, this.proxy(this.trackerFinalSaveSuccess), this.proxy(this.trackerFinalSaveFailure));
			}
		}
	},
	
	/**
	 *Name: trackerFinalSaveSuccess
	 *Purpose: success callback function for new entry tracker save
	 *Params: output from postRequest as implicit param
	 *Returns: Doesn't return
	 **/
	trackerFinalSaveSuccess : function(output) {
		this.proxy(this.getJournalData());
		//mHealth.controllers.HealthDataController.getJournalData(mHealth.controllers.HealthDataController.healthDataTracker);
	},
	
	/**
	 *Name: trackerSaveFailure
	 *Purpose: Failure callback function for new entry tracker save. This is used in case of cholesterol, weight & bmi and blood pressure where all the postRequest service calls except last call uses this failure callback function.
	 *Params: Implicit callback function params
	 *Returns: Doesn't return
	 **/
	trackerSaveFailure : function(jqXHR, textStatus, errorThrown) {

	},
	
	/**
	 *Name: trackerFinalSaveFailure
	 *Purpose: Failure callback function for new entry tracker save. Used by all trackers, this is failure callback function of last service call.
	 *Params: Implicit callback function params
	 *Returns: Doesn't return
	 **/
	trackerFinalSaveFailure : function(jqXHR, textStatus, errorThrown) {
		
	},
	
	 /**
	 *Name: getJournalData
	 *Purpose:  gets the Journal Data using getResponse service call. Called on view my journal click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getJournalData : function() {
		this.service.getResponse(mHealth.uat.healthdata_url, ALSECTOKEN, this.proxy(this.getJournalSuccess), this.proxy(this.getJournalFailure));
		//mHealth.controllers.HealthDataController.getJournalData(mHealth.controllers.HealthDataController.healthDataTracker)
	},
	
	 /**
	 *Name: getGraphData
	 *Purpose:  gets the Graph Data using getResponse service call. Called on view my graph click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getGraphData : function() {
		this.service.getResponse(mHealth.uat.healthdata_url,  this.proxy(this.getGraphSuccess), this.proxy(this.getJournalFailure));
		//mHealth.controllers.HealthDataController.getGraphData(mHealth.controllers.HealthDataController.healthdatatracker)
	},
	
		 /**
	 *Name: getGraphSuccess
	 *Purpose: Success callback function for getting graph data.
	 *Params: Implicit callback function param
      *Returns: Doesn't return; passes healthdata value nad healthdata type as global to the html pages
	 **/
	getGraphSuccess : function(output) {
		var response = output.responseText;
		var responses = JSON.parse(response);
		console.log(responses);
		var len = responses.length;
		health = this.healthDataTracker;
		if(this.healthDataTracker == "Blood Glucose") {
			var glucoseHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "Bloodglucose") {
				glucoseHealthData.push(responses[i]);
				}
			}
			set1Data = glucoseHealthData;
			//alert("Glucose: "+glucoseData);
			$.mobile.changePage('glucosegraph.html');
		}
		if(this.healthDataTracker== "Weight and BMI") {
			//alert("inside graph weight and bmi");
			var set1HealthData = [];
			var set2HealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "Weight") {
					set1HealthData.push(responses[i]);
				}
				if(responses[i].healthDataType == "BMI") {
					set2HealthData.push(responses[i]);
				}

			}
			set1Data = set1HealthData;
			set2Data = set2HealthData;
			//health = this.healthDataTracker;
			//alert("Weight: "+weightData+": BMI: "+bmiData);
			$.mobile.changePage('showgraph.html');
		}
		if(this.healthDataTracker == "Blood Pressure") {
			var set1HealthData = [];
			var set2HealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "BPS") {
					set1HealthData.push(responses[i]);
				}
				if(responses[i].healthDataType == "BPD") {
					set2HealthData.push(responses[i]);
				}

			}
			set1Data = set1HealthData;
			set2Data = set2HealthData;
			//alert("BPS: "+weightData+"BPD: "+bmiData);
			$.mobile.changePage('showgraph.html');
		}
		if(this.healthDataTracker == "A1C") {
			var a1cHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "A1C") {
				a1cHealthData.push(responses[i]);
				}
			}
			set1Data = a1cHealthData;
			//alert("A1C: "+a1cData);
			$.mobile.changePage('showgraph.html');
                                               
		}
		
		if(this.healthDataTracker == "Cholesterol") {
               $.mobile.changePage('detailscholesterol.html');                                 
	
		}
		
			
		if(this.healthDataTracker == "LDL and HDL") {
			var ldlHealthData = [];
			var hdlHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "LDL") {
					ldlHealthData.push(responses[i]);
				}
				if(responses[i].healthDataType == "HDL") {
					hdlHealthData.push(responses[i]);
				}

			}
			set1Data = ldlHealthData;
			set2Data = hdlHealthData;
			//alert("LDL: "+ldlData+"HDL: "+hdlData);
			$.mobile.changePage('showgraph.html');
                                               
		}
		if(this.healthDataTracker == "Total Cholesterol") {
			var cholesterolHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "Cholesterol") {
					cholesterolHealthData.push(responses[i]);
				}
			}
			set1Data = cholesterolHealthData;
			//alert("Total Cholesterol: "+cholesterolData);
			$.mobile.changePage('showgraph.html');
                                               
		}
		if(this.healthDataTracker == "Triglycerides") {
			var triglyceridesHealthData = [];
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == "Triglycerides") {
					triglyceridesHealthData.push(responses[i]);
				}
			}
			set1Data = triglyceridesHealthData;
			//alert("triglyceridesDataL: "+triglyceridesData);
			$.mobile.changePage('showgraph.html');
                                               
		}
	},
	
	 /**
	 *Name: getJournalSuccess
	 *Purpose: Success callback function for get journal data. output Response is formatted to key value pairs and shows showjournal.html
	 *Params: Implicit callback function param
	 *Returns: Doesn't return
	 **/
	getJournalSuccess : function(output) {
		var response = output.responseText;
		var responses = JSON.parse(response);
		var len = responses.length;
		var healthData = [];
		var sortedData=[];
		if(this.healthDataTracker=='Blood Glucose')
			healthData=this.getHealthData(responses,'Bloodglucose');
		else if(this.healthDataTracker=='Dilated Retinal Exam')
			healthData=this.getHealthData(responses,'RetinalExam');	
		else if(this.healthDataTracker=='Foot Exam - Self')
			healthData=this.getHealthData(responses,'FootSelfExam');	
		else if(this.healthDataTracker=='Foot Exam - Provider')
			healthData=this.getHealthData(responses,'FootExam');	
		else if(this.healthDataTracker=='Microalbumin')
			healthData=this.getHealthData(responses,'MAU');
		else if(this.healthDataTracker=='A1C')
			healthData=this.getHealthData(responses,'A1C');	
		else if(this.healthDataTracker == "Weight and BMI" || this.healthDataTracker == "Blood Pressure" || this.healthDataTracker == "Cholesterol") 
		{
			var subHealthDataTypes = [];
			if(this.healthDataTracker == "Weight and BMI") {
				subHealthDataTypes = ['Weight', 'BMI', '', ''];
			} else if(this.healthDataTracker == "Blood Pressure") {
				subHealthDataTypes = ['BPS', 'BPD', '', ''];
			} else if(this.healthDataTracker == "Cholesterol") {
				subHealthDataTypes = ['LDL', 'HDL', 'Cholesterol', 'Triglycerides'];
			}
			
			for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == subHealthDataTypes[0] || responses[i].healthDataType == subHealthDataTypes[1] || responses[i].healthDataType == subHealthDataTypes[2] || responses[i].healthDataType == subHealthDataTypes[3]) {
					healthData.push(responses[i]);
				}
			}
		}
		sortedData=this.getSortedData(healthData);
		this.trackerData = this.getFormattedData(sortedData);
		$.mobile.changePage('showjournal.html');
	},
	
	
	/**
	 *Name: getHealthData
	 *Purpose: filter the health data responses based on tracker id.  
	 *Params: health data responses and tracker id are passed as params
	 *Returns: returns the health data corresponding to the tracker id.
	 **/
	getHealthData:function(responses,trackerId){
		var len = responses.length;
		var healthData = [];
		for(var i = 0; i < len; i++) {
				if(responses[i].healthDataType == trackerId) {
					healthData.push(responses[i]);
				}
		}
		return healthData;	
	},
	
	
	/**
	 *Name: getSortedData
	 *Purpose: sorts the health data based on measurement date.  
	 *Params: health data to be sorted is passed as param
	 *Returns: returns the sorted health data
	 **/
	getSortedData : function(healthData){
		var keys = [];
		var sortedData = [];
			for(var i in healthData) {
				keys[i] = [];
				keys[i][0] = healthData[i]["measurementDate"];
				keys[i][1] = i;

			}
			keys.sort();
			keys.reverse();
			
			for(var i in keys) {
				sortedData.push(healthData[keys[i][1]]);
			}
			return sortedData;
	},
	
	/**
	 *Name: getFormattedData
	 *Purpose:  formats the sorted health data to key value pairs based on measurement date. 
	 *Params: takes sorted health data as parameter
	 *Returns: returns the formatted hash object
	 **/
	getFormattedData: function(sortedData){
		var healthDataObjects=new Object();
		var len = sortedData.length;
		var child = new Object();
		if(this.healthDataTracker=='A1C' || this.healthDataTracker=='Blood Glucose'  || this.healthDataTracker=='Microalbumin' || this.healthDataTracker=='Foot Exam - Provider' || this.healthDataTracker=='Dilated Retinal Exam' || this.healthDataTracker=='Foot Exam - Self')
		{
			for(var i = 0; i < len; i++) {
				child = new Object();
				child['measurementDate'] = sortedData[i]['measurementDate'];
				child['value'] = sortedData[i]['value'];
				child['comments'] = sortedData[i]['comments'];
				healthDataObjects[sortedData[i].measurementDate] = child;
			}
		}
		else
		{
			var key;
			for(var i = 0; i < len; i++) {
				key = sortedData[i].measurementDate;
				if(healthDataObjects.hasOwnProperty(key)) {
					if(child['measurementDate'] == key)
						child[sortedData[i].healthDataType] = sortedData[i].value;
				} else {
					child = new Object();
					child['comments'] = sortedData[i].comments;
					child['measurementDate'] = sortedData[i].measurementDate;
					child[sortedData[i].healthDataType] = sortedData[i].value;
				}
				healthDataObjects[key] = child;
			}
		}
		return healthDataObjects;
	},
	
	/**
	 *Name: getJournalFailure
	 *Purpose: Failure callback function for get journal data. 
	 *Params: Implicit callback function params
	 *Returns:: Doesn't return
	 **/
	getJournalFailure : function(jqXHR, textStatus, errorThrown) {
		//alert('trackerGetFailure');
	},
	
	/**
	 *Name: init
	 *Purpose: 
	 *Params: 
	 *Returns:: Doesn't return
	 **/
	init : function() {
	},
});