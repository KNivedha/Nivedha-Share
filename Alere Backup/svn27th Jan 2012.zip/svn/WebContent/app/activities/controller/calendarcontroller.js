/**
 * Controller : CalendarController
 * Controller to do logic of calendar
 **/
mHealth.controllers.CalendarController = Spine.Controller.sub({
	el : 'body',
	events : {
		'click #calendar_save' : 'getCalendarData',
	},
	
	/**
	 * Name    : init
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	init : function() {
	},
	
	/**
	 * Name    : getCalendarData
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	getCalendarData : function() {
		var title, sDate, eDate;
		title = $('#eventName').val();
		sDate = $('#startDate').val();
		eDate = $('#endDate').val();
		location.href = "cal://?eventname=setEvent&eventTitle=" + title + "&startDate=" + sDate + "&endDate=" + eDate;

	}
});
