/**
 * Controller : ActivityController
 * Controller to do logic of activities
 **/
mHealth.controllers.ActivityController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'pagebeforeshow #showActivity' : 'getActivity',
		'pageshow #showActivity' : 'showView',
		'click .detailActivity' : 'detailActivityView',
		'pageshow #detailActivity' : 'detailActivities',
		'click #activity' : 'getActivity'
	},

	/**
	 * Name    : detailActivities
	 * Purpose : --
	 * Params  : --
	 * Return : recordRequired
	 **/
	detailActivities : function() {
		//alert(recordRequired);
		$('#detailActivity_div').html(_.template($('#detailActivityDataList').html(), recordRequired));
		$('#detailActivity').trigger('create');
	},
	
	/**
	 * Name    : showView
	 * Purpose : --
	 * Params  : --
	 * Return  : activity[0].zone, activity[0].view, activity[0].space[0].title
	 **/
	showView : function() {
		$('#activityTitle').text(activity[0].space[0].title);

		if(activity[0].zone.length > 1) {
			$('#activity_zone').show();
			$('#activity_zone').html(_.template($('#navDataList').html(), activity[0].zone));
		}
		$('#activity_div').html(_.template($('#activityDataList').html(), activity[0].view));
		$('#showActivity').trigger('create');
	},
	
	/**
	 * Name    : init
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	init : function() {
	},
	
	/**
	 * Name    : detailActivityView
	 * Purpose : --
	 * Params  : --
	 * Return  : recordRequired
	 **/
	detailActivityView : function(event) {
		var view, html, showActivityViewName, i;
		view = event.target;
		html = $(event.target).html();
		showActivityViewName = $(view).parents('li').children('div').children('div').children('a').children('h3').text();
		recordRequired = ""; // TODO : recordRequired should not be global.

		mHealth.models.SpaceViewZoneModel.each(function(record) {

			if(record.pageName === 'Activity') {

				for(i = 0; i < record.view.length; i++) {

					if(record.view[i].title.trim() === showActivityViewName.trim()) {
						recordRequired = record.view[i];
						break;
					}
				}
			}
		});
	

		$.mobile.changePage("detailactivity.html");

	},
	
	/**
	 * Name    : getActivity
	 * Purpose : --
	 * Params  : --
	 * Return  : --
	 **/
	getActivity : function() {
		
		var decision, body;
		decision = mHealth.models.SpaceViewZoneModel.each(function(record) {

			if(record.pageName === 'Activity') {

				return true;

			}

		});
		//alert(decision);
		if(decision === true) {

			$.mobile.changePage('../../activities/view/showactivity.html');

		} else {
			body = JSON.stringify([{
				"ActivityCount" : "",
				"AppName" : "Mobile Main",
				"RelatedActivityCount" : "",
				"Mode" : "",
				"ActivityID" : "",
				"StatusID" : "",
				"SessionID" : "1326387223",
				"ResponseType" : "1003",
				"EffectiveDate" : ""
			}]);

			this.proxy(this.service.postRequest(mHealth.uat.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.recommendationFailure)));

			

		}

	},
	
	/** 
      *Name   : recommendationSuccess
      *Purpose: Success callback for getting activities space view zone information.
      *Params : output - response from the server.
      *Return : --
      **/
	recommendationSuccess : function(output) {
		var response, recommandationData, spaceData, zoneData, viewData, spaceviewzone;
		response = output.responseText;
		recommandationData = JSON.parse(response);
		spaceData = JSON.stringify(recommandationData.Space);
		zoneData = JSON.stringify(recommandationData.Zone);
		viewData = JSON.stringify(recommandationData.View);
		spaceviewzone = new mHealth.models.SpaceViewZoneModel({

			pageName : 'Activity',
			space : mHealth.models.SpaceModel.fromJSON(spaceData),
			view : mHealth.models.ViewModel.fromJSON(viewData),
			zone : mHealth.models.ZoneModel.fromJSON(zoneData)

		});

		spaceviewzone.save(); // TODO : save() should not be used. Have to use unsaved model instance.
		activity = mHealth.models.SpaceViewZoneModel.each(function(record) {
        // TODO : activity should not be global.
			if(record.pageName === 'Activity') {
				return record;
			}
		});

		$.mobile.changePage("../../activities/view/showactivity.html");
	},
	
	/** 
      *Name   : recommendationFailure
      *Purpose: Failure callback for getting activities space view zone information. 
      *Params : jqXHR - XMLHttpRequestObject,
                textStatus - Status text message of the response,
                errorThrown - Error message recieved from the server.
      *Return : --
      **/
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {

	}
});
