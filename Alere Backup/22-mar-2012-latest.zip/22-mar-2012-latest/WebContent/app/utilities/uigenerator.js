/**
 * Assessment UI generator
 **/
mHealth.assessment = {
	/**
	 * Name:generate_html
	 * purpose:to generate dynamic html according to entry
	 * type Params:entrytype and data with question and answers
	 * return : random generated html
	 */
	generate_html : function(data, entryType) {
		switch(entryType) {
			case "Dropdown":
				output_html = get_dropdown_html(data);
				break;
			case "RadioButton":
				get_radio_html(data);
				break;
			case "TwoNumberEdit":
				break;
			case "TextArea":
				break;
			case "NumberEdit":
				output_html = this.get_numberedit_html(data);
				break;
			case "Checkbox":
				output_html = this.get_checkbox_html(data);
				break;
			case "TextEdit":
				break;
			case "Likert":
				break;
			case "Date":
				break;
			case "Time":
				break;
			case "DateTime":
				break;
		}
		return output_html;
	},
	/**
	 * Name    : get_dropdown_html
	 * Purpose : Method to create request body for recommendation Service.
	 * Params  : responseType -  recommendation type
	 * Returns : bodyContent
	 **/
	get_dropdown_html : function(data) {
		answers = [];
		var disabled = false;
		var answersId = [];
		var instance_outputHTML = '';
		var i = 0;
		var j = 0;
		mHealth.models.ParticipantAnswerModel.each(function(participantAnswer) {
			data.section[0].question.map(function(question) {
				question.answer.map(function(answer) {
					if(participantAnswer.answerId === answer.answerId && participantAnswer.questionId === answer.questionId) {
						disabled = true;
						answersId.push(answer.answerId);
					}
				});
			});
		});
		if(!disabled) {
			data.section[0].question.map(function(question) {
				answers = [];
				instance_outputHTML += "<div data-content-theme='d' ><h1>" + question.theQuestion + "</h3>";
				instance_outputHTML += "<p>";
				instance_outputHTML += "<select data-native-menu='true' id='questionId[" + j + "]' name='form[dropdown]' class='selectValue'>";
				instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">Please Select One</option>";
				data.section[0].question[i].answer.map(function(answer) {
					if(question.questionId == "Question 3") {
						var medicalDevices = JSON.parse(devices);
						medicalDevices.map(function(device) {
							instance_outputHTML += "<option name ='form[dropdown]' value='{" + device.sku + "}'>";
							instance_outputHTML += device.description;
							instance_outputHTML += "</option>";
						});
						instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">None</option>";
						instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">Others</option>";
					} else {
						instance_outputHTML += "<option name ='form[dropdown]' value='{" + answer.answerOptionText + "}'>";
						instance_outputHTML += answer.answerOptionText;
						instance_outputHTML += "</option>";
					}
					answers.push(answer);
				});
				instance_outputHTML += "</select>";
				instance_outputHTML += "</p>";
				instance_outputHTML += "</div>";
				i++;
				j++;
			});
		} else if(disabled) {
			mHealth.LoginControllerObject.updateProgressBar(3);
			data.section[0].question.map(function(question) {
				answers = [];
				instance_outputHTML += "<div data-content-theme='d' ><h1>" + question.theQuestion + "</h3>";
				instance_outputHTML += "<p>";
				instance_outputHTML += "<select disabled id='questionId[" + j + "]' name='form[dropdown]' class='selectValue'>";
				question.answer.map(function(answer) {
					if(answer.answerId == answersId[i]) {
						instance_outputHTML += "<option selected='yes' ";
					} else if(answer.answerId != answersId[i]) {
						instance_outputHTML += "<option ";
					}
					if(question.questionId == "Question 3") {
						var medicalDevices = JSON.parse(devices);
						medicalDevices.map(function(device) {
							instance_outputHTML += "name ='form[dropdown]' value='{" + device.sku + "}'>";
							instance_outputHTML += device.description;
							instance_outputHTML += "</option>";
						});
					} else {
						instance_outputHTML += "name ='form[dropdown]' value='{" + answer.answerId + "}'>";
						instance_outputHTML += answer.answerOptionText;
						instance_outputHTML += "</option>";
					}
					answers.push(answer);
				});
				instance_outputHTML += "</select>";
				instance_outputHTML += "</p>";
				instance_outputHTML += "</div>";
				i++;
				j++;
			});
		}

		return instance_outputHTML;
	},
	
	/**
	 * Name:formatDate
	 * purpose:Converts date to mm/dd/yyyy hh:MM TT local time from yyyy-mm-dd HH-MM-ss GMT
	 * type Params:server date and format 
	 * return : formatted date
	 */	
	formatDate : function (input, newFormat) {
	  var parts = input.match(/(\d+)/g);
	  if (parts.length == 6) {
		  utcSec = Date.UTC(parts[0], parts[1]-1, parts[2], parts[3],parts[4],parts[5],0 ); // months are 0-based

		  d = new Date(utcSec);
		  return d.format(mHealth.messageDateFormat);
		} else {
			return input;
		}
	},

	/**
	 * Name:generate_messageDetailsHtml
	 * purpose:to generate dynamic html according to entry
	 * type Params:entrytype and data with question and answers
	 * return : random generated html
	 */
	generate_messageDetailsHtml : function(data,calendarResponse) {
		var messageDesc = "";
		var questionnaireCount = 0;
		mHealth.models.QuestionnaireModel.each(function(questionnaire1) {
			messageDesc += questionnaire1.introCopy;
			questionnaireCount++;
		});		
		var outputhtml = "";
		var questionCount = 1;
		var answerCount = 1;
		var messageModel = mHealth.models.MessageDetailsModel.first();		
		var sentDate = messageModel.sentDate;
		var title = messageModel.title;
		outputhtml += "<div class='ui-body ui-body-c ui-corner-all'  >";
		outputhtml += "<input type='hidden' id='mutliPart'  value='false'  name ='mutliPart'/>";
		if(title){
			outputhtml += "<div><b>" +  title  + "</b></div></br>";
		} 
		
		if(sentDate){

			outputhtml += "<div class='message-date'>Sent On " +  this.formatDate(sentDate)  + "</div>";
		} 
				
		mHealth.models.MessageSectionModel.each(function(section){		
			if(section.messageText){
				outputhtml += "<div>" + section.messageText + "</div>";
			}			
		});
		mHealth.models.QuestionGroupModel.each(function(questionnaire) {	
				if(questionnaire.title != null || messageDesc != null) {
					outputhtml += "<div class = 'message-desc'>" + messageDesc + "</div>";
				}
				
				var questions = questionnaire.questions.question;
				mHealth.models.MessageQuestionModel.destroyAll();
				mHealth.models.MessageQuestionModel.customFromJSON(questions);
				mHealth.models.MessageQuestionModel.each(function(question) {
					entryType = question.answerType;
					switch(entryType) {
						case "FixedListSingleSelect":
							outputhtml += mHealth.assessment.getSingleSelecthtml(question, questionCount, answerCount);
							break;
						case "Date":
							outputhtml += mHealth.assessment.getDatehtml(question, questionCount, answerCount);
							break;
						case "Float":
							outputhtml += mHealth.assessment.getFloathtml(question, questionCount, answerCount);
							break;
						case "decimal":
							outputhtml += mHealth.assessment.getFloathtml(question, questionCount, answerCount);
							break;
						case "Decimal":
							outputhtml += mHealth.assessment.getFloathtml(question, questionCount, answerCount);
							break;
						case "height":
							outputhtml += mHealth.assessment.getHeighthtml(question, questionCount, answerCount);
							break;
						case "Weight":
							outputhtml += mHealth.assessment.getFloathtml(question, questionCount, answerCount);
							break;
						case "Boolean":
							outputhtml += mHealth.assessment.getBooleanhtml(question, questionCount, answerCount);
							break;
						case "YesNo":
							outputhtml += mHealth.assessment.getBooleanSlidehtml(question, questionCount, answerCount);
							break;	
					}
					questionCount++;
					answerCount++;
			});
		});		
		outputhtml += "</div>";
		return outputhtml;
	},
	/**
	 * Name:generate_assesment
	 * purpose:to generate dynamic html according to entry
	 * type Params:entrytype and data with question and answers
	 * return : random generated html
	 */
	generate_assesment : function(data,calendarResponse) {
		var messageDesc = "";
		mHealth.models.QuestionnaireModel.each(function(questionnaire1) {
			//messageDesc = questionnaire1.introCopy;
			//questionnaireCount++;
		});
		var outputhtml = "";
		var questionCount = 1;
		var answerCount = 1;		
		outputhtml += "<div class='ui-body ui-body-c ui-corner-all'  >";
		mHealth.models.QuestionGroupModel.each(function(questionnaire) {
			var groupTitle = questionnaire.title;
			var groupType = questionnaire.type;			
			outputhtml += "<input type='hidden' id='mutliPart'  value='true'  name ='mutliPart' />";
			var groupId = questionnaire.id;
			var questionValue = questionnaire.questions.question;
			mHealth.models.MessageQuestionModel.destroyAll();
			if(groupType == "Form_Ht_Wt") {
				outputhtml += mHealth.assessment.getEmpoweredHtWt(questionValue, groupId);
			} else if(groupType == "Form_A1c") {
				outputhtml += mHealth.assessment.getEmpoweredA1c(questionValue, groupId);
			} else if(groupType == "Form_CholesterolLipid") {
				outputhtml += mHealth.assessment.getEmpoweredCholestrol(questionValue, groupId);
			} else if(groupType == "Form_DiabetesLabs") {
				outputhtml += mHealth.assessment.getEmpoweredSliderDiaLab(questionValue, groupId);
			} else {
				if(questionnaire.title != null && questionnaire.title != "text") {
					outputhtml += "<div>" + questionnaire.title + "</div>";
				}				
				mHealth.models.MessageQuestionModel.customFromJSON(questionValue);
				mHealth.models.MessageQuestionModel.each(function(question) {
					entryType = question.answerType;
					switch(entryType) {
						case "FixedListSingleSelect":
							outputhtml += mHealth.assessment.getSingleSelecthtml(question, questionCount, answerCount);
							break;
						case "Date":
							outputhtml += mHealth.assessment.getDatehtml(question, questionCount, answerCount);
							break;
						case "Float":
							outputhtml += mHealth.assessment.getFloathtml(question, questionCount, answerCount);
							break;
						case "decimal":
							outputhtml += mHealth.assessment.getFloathtml(question, questionCount, answerCount);
							break;
						case "Decimal":
							outputhtml += mHealth.assessment.getFloathtml(question, questionCount, answerCount);
							break;
						case "Boolean":
							outputhtml += mHealth.assessment.getBooleanhtml(question, questionCount, answerCount);
							break;
						case "YesNo":
							outputhtml += mHealth.assessment.getBooleanhtml(question, questionCount, answerCount);
							break;
					}
					questionCount++;
					answerCount++;
				});
			}
		});
		outputhtml += "</div>";
		return outputhtml;
	},
	/**
	 * Name    : getHeighthtml
	 * Purpose : Method to create html for height/weight group type
	 * Params  :  questions, questionCount,answerCount
	 * Returns : outputHTML
	 **/
	getEmpoweredHtWt : function(questions, groupId) {
		var instance_outputHTML = "";
		instance_outputHTML += "<div ><h3>Please enter your Height and Weight</h3></div>";
		instance_outputHTML += "<div class='form_htwt' style='width:100%'>";
		//instance_outputHTML += "<input type='hidden' id='groupHtWtId'  value=" + groupId + "  name ='groupHtWtId' />";
		instance_outputHTML += "<input type='hidden' id='groupHtWtId'  value=8004  name ='groupHtWtId' />";
		instance_outputHTML += "<input type='hidden' id='PT.HD.HTWTDT'  value=8004  name ='PT.HD.HTWTDT' />";
		instance_outputHTML += "<input type='text' id='answerDateId' style='font-size:11pt;' value='' name='answerDateId' class='mobiscroll validateDate' placeholder='Select Date' data-theme='c' />";
		instance_outputHTML += "<input type='hidden' id='PT.HD.HT'  value=8005  name ='PT.HD.HT' />";
		instance_outputHTML += "<table width='100%'><tr><td width='25%'><input type='number' style='font-size:11pt;' onblur='rangeValidation(this,3,8.11,this.id);' id='answerHtFtId'  placeholder='Ht(Ft)' value='' name ='answerHtFtId' /></td>";
		instance_outputHTML += "<td width='2%'></td><td width='25%'><input type='number'  style='font-size:11pt;' id='answerHtInId' placeholder='Ht(In)' value='' name= 'answerHtInId' onblur='rangeValidation(this,0,11,this.id);' /></td>";
		instance_outputHTML += "<td width='2%'></td><td width='50%'><input type='number' style='font-size:11pt;' onblur='rangeValidation(this,0.10,999,this.id);' id='answerIdWtId' placeholder='Weight' value='' name ='answerIdWtId' /></td></tr></table>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.WT'  value=8006  name ='PT.HD.WT' />";
		instance_outputHTML += "</div>";
		return instance_outputHTML;
	},
	/**
	 * Name    : getHeighthtml
	 * Purpose : Method to create html for height/weight group type
	 * Params  :  questions, questionCount,answerCount
	 * Returns : outputHTML
	 **/
	generateAssesDropDownOptions : function(formType) {
		var instance_outputHTML = "";
		instance_outputHTML += "<option style='font-size:11pt;'   value='default'>" + mHealth.AssesmentEntry.dropdownOptionDefault + "</option>";
		instance_outputHTML += "<option style='font-size:11pt;'  value='" + mHealth.AssesmentEntry.dropdownOption1Value + "'>" + mHealth.AssesmentEntry.dropdownOption1 + "</option>";
		instance_outputHTML += "<option style='font-size:11pt;'  value='" + mHealth.AssesmentEntry.dropdownOption2Value + "'>" + mHealth.AssesmentEntry.dropdownOption2 + "</option>";
		instance_outputHTML += "<option style='font-size:11pt;'  value='" + mHealth.AssesmentEntry.dropdownOption3Value + "'>" + mHealth.AssesmentEntry.dropdownOption3 + "</option>";
		return instance_outputHTML;
	},
	/**
	 * Name    : getEmpoweredA1c
	 * Purpose : Method to create html for A1C group type
	 * Params  : questions, questionCount,answerCount
	 * Returns : outputHTML
	 **/
	getEmpoweredA1c : function(questions, groupId) {
		var instance_outputHTML = "";
		instance_outputHTML += "<div ><h3>Please enter your latest Hemoglobin A1c test result</h3></div>";
		instance_outputHTML += "<div class='form_a1c' style='width:100%'>";
		//instance_outputHTML += "<input type='hidden' id='groupA1cId'  value=" + groupId + "  name ='groupA1cId' />";
		instance_outputHTML += "<input type='hidden' id='groupA1cId'  value=8009  name ='groupA1cId' />";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.A1C.TAKEN'  value=8009  name ='PT.HD.TESTS.A1C.TAKEN' />";
		instance_outputHTML += "<select  data-native-menu='true' id='answerA1cId' name='answerA1cId' class='selectValue'>";
		instance_outputHTML += mHealth.assessment.generateAssesDropDownOptions('Form_A1c');
		instance_outputHTML += "</select>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.A1C.DATE'  value=8008  name ='PT.HD.TESTS.A1C.DATE' />";
		instance_outputHTML += "<input type='text' id='answerA1cDateId' style='font-size:11pt;display:none;'  name='answerA1cDateId' class='mobiscroll validateDate' placeholder='Select Date' data-theme='c' />";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.A1C.VALUE'  value=8009  name ='PT.HD.TESTS.A1C.VALUE' />";
		instance_outputHTML += "<table width='100%'><tr><td width='100%'><input type='number' style='font-size:11pt;display:none;'  onblur='rangeValidation(this,3.2,30,this.id);'  id='answerTxtA1cId' placeholder='Enter A1c' min='1' max='5' name ='answerTxtA1cId' /></td></tr></table>";
		instance_outputHTML += "</div>";
		return instance_outputHTML;

	},

	/**
	 * Name    : getEmpoweredSliderDiaLab
	 * Purpose : Method to create html for Diabetes group type
	 * Params  : questions, questionCount,answerCount
	 * Returns : outputHTML
	 **/
	getEmpoweredSliderDiaLab : function(questions, groupId) {
		var instance_outputHTML = "";
		instance_outputHTML += "<div ><h3>Have you had the following lab tests completed?</h3></div>";
		instance_outputHTML += "<div class='form_a1c' style='width:100%'>";
		//instance_outputHTML += "<input type='hidden' id='groupDiaId'  value=" + groupId + "  name ='groupDiaId' />";
		instance_outputHTML += "<input type='hidden' id='groupDiaId'  value=8016  name ='groupDiaId' />";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.DIALATED.TAKEN' value=8016  name ='PT.HD.TESTS.DIALATED.TAKEN' />";
		instance_outputHTML += "<table width='100%'><tr><td width='65%' align = 'left'><label for='answerDiaId'>Dilated Retinal Exam</label></td><td width='2%'></td>";
		instance_outputHTML += "<td width='25%'><select name='slider' id='answerDiaId' data-role='slider' class='selectValue'><option value='" + mHealth.AssesmentEntry.dropdownOption1Value + "'>No</option><option value=" + mHealth.AssesmentEntry.dropdownOption4Value + ">Yes</option></select></td>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.DIALATED.DATE'  value=8017  name ='PT.HD.TESTS.DIALATED.DATE' />";
		instance_outputHTML += "<td width='8%'></td></tr></table><table width='100%'><tr>";
		instance_outputHTML += "<td align = 'center'><input type='text' id='answerDiaDateId' style='font-size:11pt;display:none;' value='' name='answerDiaDateId' class='mobiscroll validateDate' placeholder='Select Date' data-theme='c' /></td></tr></table>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.FOOT.TAKEN' value=8018   name ='PT.HD.TESTS.FOOT.TAKEN' />";
		instance_outputHTML += "<table width='100%'><tr><td width='65%' align = 'left'><label for='answerDiaFootId'>Foot Exam - Provider</label></td><td width='2%'></td>";
		instance_outputHTML += "<td width='25%'><select name='slider' class='selectValue' id='answerDiaFootId' data-role='slider'><option value='" + mHealth.AssesmentEntry.dropdownOption1Value + "'>No</option><option value=" + mHealth.AssesmentEntry.dropdownOption4Value + ">Yes</option><</select></td>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.FOOT.DATE'  value=8019  name ='PT.HD.TESTS.FOOT.DATE' />";
		instance_outputHTML += "<td width='8%'></td></tr></table><table width='100%'><tr>";
		instance_outputHTML += "<td align = 'center'><input type='text' id='answerFootDateId' style='font-size:11pt;display:none;' value='' name='answerFootDateId' class='mobiscroll validateDate' placeholder='Select Date' data-theme='c' /></td></tr></table>";
		instance_outputHTML += "</div>";
		
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.MICROALBUMIN.TAKEN' value=8020  name ='PT.HD.TESTS.MICROALBUMIN.TAKEN' />";
		instance_outputHTML += "<table width='100%'><tr><td width='65%' align = 'left'><label for='answerMicroId'>Microalbumin</label></td><td width='2%'></td>";
		instance_outputHTML += "<td width='25%'><select name='slider'class='selectValue' id='answerMicroId' data-role='slider'><option value='" + mHealth.AssesmentEntry.dropdownOption1Value + "'>No</option><option value=" + mHealth.AssesmentEntry.dropdownOption4Value + ">Yes</option><</select></td>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.MICROALBUMIN.DATE'  value=8021 name ='PT.HD.TESTS.MICROALBUMIN.DATE' />";
		instance_outputHTML += "<td width='8%'></td></tr></table><table width='100%'><tr>";
		instance_outputHTML += "<td align = 'center'><input type='text' id='answerMicroDateId' style='font-size:11pt;display:none;' value='' name='answerMicroDateId' class='mobiscroll validateDate' placeholder='Select Date' data-theme='c' /></td></tr></table>";
		return instance_outputHTML;
	},
	/**
	 * Name    : getEmpoweredCholestrol
	 * Purpose : Method to create html for cholestrol group type
	 * Params  : questions, questionCount,answerCount
	 * Returns : outputHTML
	 **/
	getEmpoweredCholestrol : function(questions, groupId) {
		var instance_outputHTML = "";
		instance_outputHTML += "<div ><h3>Please enter your latest Cholesterol or Lipid Panel test</h3></div>";
		instance_outputHTML += "<div class='form_a1c' style='width:100%'>";
		//instance_outputHTML += "<input type='hidden' id='groupChoId'  value=" + groupId + "  name ='groupChoId' />";
		instance_outputHTML += "<input type='hidden' id='groupChoId'  value=8015  name ='groupChoId' />";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.CHOL.TAKEN'  value=8015 name ='PT.HD.TESTS.CHOL.TAKEN' />";
		instance_outputHTML += "<select  data-native-menu='true' id='answerChoId' name='answerChoId' class='selectValue'>";
		instance_outputHTML += mHealth.assessment.generateAssesDropDownOptions('Form_CholesterolLipid');
		instance_outputHTML += "</select>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.CHOL.DATE'  value=8011  name ='PT.HD.TESTS.CHOL.DATE' />";
		instance_outputHTML += "<input type='text' id='answerChoDateId' style='font-size:11pt;display:none;' value='' name='answerChoDateId' class='mobiscroll validateDate' placeholder='Select Date' data-theme='c' />";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.CHOL.LDL'  value=8012  name ='PT.HD.TESTS.CHOL.LDL' />";
		instance_outputHTML += "<table width='100%'><tr><td width='49%'><input type='number' style='font-size:11pt;display:none;'  onblur='rangeValidation(this,30,500,this.id);' id='answerTxtLDLId' placeholder='Enter LDL' value='' name ='answerTxtLDLId' /></td>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.CHOL.HDL'  value=8013 name ='PT.HD.TESTS.CHOL.HDL' />";
		instance_outputHTML += "<td width='2%'></td><td width='49%'><input type='number' style='font-size:11pt;display:none;'  onblur='rangeValidation(this,10,120,this.id);'  id='answerTxtHDLId' placeholder='Enter HDL' value='' name ='answerTxtHDLId' /></td></tr>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.CHOL.TRIG'  value=8014 name ='PT.HD.TESTS.CHOL.TRIG' />";
		instance_outputHTML += "<tr><td width='49%'><input type='number' style='font-size:11pt;display:none;'  id='answerTxtTriId'  onblur='rangeValidation(this,75,600,this.id);' placeholder='Enter Triglycerides' value='' name ='answerTxtTriId' /></td>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.CHOL.TOTAL'  value=8015 name ='PT.HD.TESTS.CHOL.TOTAL' />";
		instance_outputHTML += "<td width='2%'></td><td width='49%'><input type='number' style='font-size:11pt;display:none;'  onblur='rangeValidation(this,75,600,this.id);' id='answerTxtTotalId' placeholder='Enter Total Cholesterol' value='' name ='answerTxtTotalId' /></td></tr></table>";
		instance_outputHTML += "</div>";
		return instance_outputHTML;
	},
 
 	/**
	 * Name    : getBooleanhtml
	 * Purpose : Method to create html for boolean entry type
	 * Params  : responseType -  recommendation type
	 * Returns : bodyContent
	 **/
	getBooleanSlidehtml : function(data, questionCount, answerCount) {
		var disabled = false;
		var instance_outputHTML = "";
		
		instance_outputHTML += "<div  >";
		instance_outputHTML += "<input type='hidden' id='question[" + questionCount + "]'   value='" + data.questionText + "'  name ='form[questions]' />";
		instance_outputHTML += "<table width='100%'><tr><td width='65%' align = 'left'><label for='question[" + questionCount + "]'>" + data.questionText + "</label></td><td width='2%'></td>";
		instance_outputHTML += "<td width='25%'><select name='slider' id='question[" + questionCount + "]' class='selectValue' data-role='slider'><option value='NO'>No</option><option value='YES'>Yes</option></select></td>";
		instance_outputHTML += "<input type='hidden' id='PT.HD.TESTS.MICROALBUMIN.DATE'  value=8021 name ='PT.HD.TESTS.MICROALBUMIN.DATE' />";
		instance_outputHTML += "<td width='8%'></td></tr></table><table width='100%'><tr>";

		instance_outputHTML += "</div>";

		return instance_outputHTML;
	},
	
	/**
	 * Name    : getBooleanhtml
	 * Purpose : Method to create html for boolean entry type
	 * Params  : responseType -  recommendation type
	 * Returns : bodyContent
	 **/
	getBooleanhtml : function(data, questionCount, answerCount) {
		var disabled = false;
		var instance_outputHTML = "";
		if(!disabled) {			
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='hidden' id='question[" + questionCount + "]'   value='" + data.questionText + "'  name ='form[questions]' />";
			if(!data.questionText) {
				instance_outputHTML += "<div data-content-theme='d'  ><h3 class='col'></h3>";
			} else {
				instance_outputHTML += "<div data-content-theme='d' style='font-size:11pt;'  ><h3 class='col'>" + data.questionText + "</h3>";
			}
			instance_outputHTML += "<p>";
			instance_outputHTML += "<select data-native-menu='true' data-role='slider' id='answerId[" + answerCount + "]' style='font-size:11pt;'  name='form[answers]' class='selectValue'>";
			instance_outputHTML += "<option style='font-size:11pt;'   value=\"default\">Please Select One</option>";
			var answerValues = data.answerOptions.answerOption;
			answerValues.map(function(answer) {
				instance_outputHTML += "<option style='font-size:11pt;'  value='{" + answer.id + "}'>";
				instance_outputHTML += answer.Label;
				instance_outputHTML += "</option>";
			});
			instance_outputHTML += "</select>";
			instance_outputHTML += "</p>";
			instance_outputHTML += "</div>";
			instance_outputHTML += "</div>";
		} else if(disabled) {			
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='hidden' id='question[" + questionCount + "]'  value='" + data.questionText + "'  name ='form[questions]' />";
			if(!data.questionText) {
				instance_outputHTML += "<div data-content-theme='d'  ><h3 class='col'></h3>";
			} else {
				instance_outputHTML += "<div data-content-theme='d'  style='font-size:11pt;' ><h3 class='col'>" + data.questionText + "</h3>";
			}
			instance_outputHTML += "<p>";
			instance_outputHTML += "<select data-native-menu='true' data-role='slider' id='answerId[" + answerCount + "]' style='font-size:11pt;'  name='form[answers]' class='selectValue'>";
			instance_outputHTML += "<option  value=\"default\">Please Select One</option>";
			var answerValues = data.answerOptions.answerOption;
			answerValues.map(function(answer) {
				instance_outputHTML += "<option style='font-size:11pt;'   value='{" + answer.id + "}'>";
				instance_outputHTML += answer.Label;
				instance_outputHTML += "</option>";
			});
			instance_outputHTML += "</select>";
			instance_outputHTML += "</p>";
			instance_outputHTML += "</div>";
			instance_outputHTML += "</div>";
		}
		return instance_outputHTML;
	},
	/**
	 * Name    : getDatehtml
	 * Purpose : Method to create html for date entry type
	 * Params  : responseType -  recommendation type
	 * Returns : bodyContent
	 **/
	getDatehtml : function(data, questionCount, answerCount) {
		var disabled = false;
		var instance_outputHTML = "";
		if(!disabled) {
			// instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='hidden' id='question[" + questionCount + "]'  value=" + data.id + "  name ='form[questions]' />";
			// if(!data.questionText){
			// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
			// } else{
			// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";
			// }
			// instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  style='margin-top:10px;'>";
			instance_outputHTML += "<div >";
			instance_outputHTML += "<input type='text' id='answerId[" + answerCount + "]' style='font-size:11pt;'   value='' name =\"form[dropdown]\" class='mobiscroll validateDate' placeholder='Date' data-theme='c'  readonly/>";
			instance_outputHTML += "</div>";
			instance_outputHTML += "</div>";
		} else if(disabled) {
			// instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='hidden' id='question[" + questionCount + "]'  value=" + data.id + "  name ='form[questions]' />";
			// if(!data.questionText){
			// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
			// } else{
			// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";
			// }
			// instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  style='margin-top:10px;'>";
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='text' id='answerId[" + answerCount + "]' style='font-size:11pt;'    value='' name =\"form[dropdown]\" class='mobiscroll validateDate' placeholder='Date' data-theme='c'  readonly/>";
			instance_outputHTML += "</div>";
			instance_outputHTML += "</div>";
		}
		return instance_outputHTML;
	},
	/**
	 * Name    : getFloathtml
	 * Purpose : Method to create html for float entry type
	 * Params  : responseType -  recommendation type
	 * Returns : bodyContent
	 **/
	getFloathtml : function(data, questionCount, answerCount) {
		var disabled = false;
		var instance_outputHTML = "";
		if(!disabled) {
			// instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='hidden' id='question[" + questionCount + "]'  value=" + data.id + "  name ='form[questions]' />";
			// if(!data.questionText){
			// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
			// } else{
			// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";
			// }
			// instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  >";
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='text' id='answerId[" + answerCount + "]' style='font-size:11pt;'   placeholder='" + data.questionText + "' value='' name =\"form[dropdown]\" />";
			instance_outputHTML += "</div>";
			instance_outputHTML += "</div>";
		} else if(disabled) {
			// instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='hidden' id='question[" + questionCount + "]'  value=" + data.id + "  name ='form[questions]' />";
			// if(!data.questionText){
			// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
			// } else{
			// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";
			// }
			// instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  style='margin-top:10px;'>";
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='text' id='answerId[" + answerCount + "]' style='font-size:11pt;'   placeholder='" + data.questionText + "' value='' name =\"form[dropdown]\" />";
			instance_outputHTML += "</div>";
			instance_outputHTML += "</div>";
		}
		return instance_outputHTML;
	},
	/**
	 * Name    : getSingleSelecthtml
	 * Purpose : Method to create html for select entry type
	 * Params  : responseType -  recommendation type
	 * Returns : bodyContent
	 **/
	getSingleSelecthtml : function(data, questionCount, answerCount) {
		
		var disabled = false;
		var instance_outputHTML = "";
		if(!disabled) {
			// instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='hidden' id='question[" + questionCount + "]'  value='" + data.id + "'  name ='form[questions]' />";
			if(!data.questionText) {
				instance_outputHTML += "<div data-content-theme='d'  ><h3 class='col'></h3>";
			} else {
				instance_outputHTML += "<div data-content-theme='d' style='font-size:11pt;'   ><h3 class='col'>" + data.questionText + "</h3>";
			}
			instance_outputHTML += "<p>";
			instance_outputHTML += "<select data-native-menu='true' id='answerId[" + answerCount + "]' style='font-size:11pt;'  class='selectValue' name='form[answers]' class='selectValue'>";
			instance_outputHTML += "<option style='font-size:11pt;' value=\"default\">Please Select One</option>";
			var answerValues = data.answerOptions.answerOption;
			answerValues.map(function(answer) {
				
				if (data.defaultAnswer != undefined && data.defaultAnswer == answer.id) {
					instance_outputHTML += "<option selected='yes' style='font-size:11pt;'   value='{" + answer.id + "}'>";
				} else {
					instance_outputHTML += "<option style='font-size:11pt;'   value='{" + answer.id + "}'>";
				}
				
				instance_outputHTML += answer.label;
				instance_outputHTML += "</option>";
			});
			instance_outputHTML += "</select>";
			instance_outputHTML += "</p>";
			instance_outputHTML += "</div>";
			instance_outputHTML += "</div>";
		} else if(disabled) {
			// instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";
			instance_outputHTML += "<div  >";
			instance_outputHTML += "<input type='hidden' id='question[" + questionCount + "]'  value='" + data.id + "'  name ='form[questions]' />";
			if(!data.questionText) {
				instance_outputHTML += "<div data-content-theme='d'  ><h3 class='col'></h3>";
			} else {
				instance_outputHTML += "<div data-content-theme='d' style='font-size:11pt;'   ><h3 class='col'>" + data.questionText + "</h3>";
			}
			instance_outputHTML += "<p>";
			instance_outputHTML += "<select data-native-menu='true' id='answerId[" + answerCount + "]' style='font-size:11pt;'   name='form[answers]' class='selectValue'>";
			instance_outputHTML += "<option  style='font-size:11pt;'   value=\"default\">Please Select One</option>";
			var answerValues = data.answerOptions.answerOption;
			answerValues.map(function(answer) {
				instance_outputHTML += "<option  style='font-size:11pt;'  value='{" + answer.id + "}'>";
				instance_outputHTML += answer.label;
				instance_outputHTML += "</option>";
			});
			instance_outputHTML += "</select>";
			instance_outputHTML += "</p>";
			instance_outputHTML += "</div>";
			instance_outputHTML += "</div>";
		}
		mHealth.util.singleQuestionCount=questionCount;
		return instance_outputHTML;
	},
	/**
	 * Name : get_checkbox_html
	 * Purpose :Method to get checkbox .
	 * Params:questions with answers
	 * Returns : checkbox html with question and answers
	 */
	get_checkbox_html : function(question, date) {
		disabled = false;
		id = "";
		var j = 0;
		var k = 0;
		class_outputHTML = "";
		class_outputHTML += "<div data-role='fieldcontain'>";
		class_outputHTML += "<fieldset>";

		if(!disabled) {
			for(var i = 0; i < question.length; i++) {
				class_outputHTML += "<legend>" + question[i].Title + "</legend>";
				class_outputHTML += "<label for='{" + question[i].ID + "}'>" + question[i].Title + "</label>";
				class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" + question[i].ID + "}' value='{" + question[i].Title + "}' />";

			}
		} else if(disabled) {
			for(var i = 0; i < question.length; i++) {
				class_outputHTML += "<legend>" + question[i].theQuestion + "</legend>";
				if(question[i].length > 1) {
					for(var k = 0; k < questions[k].length; k++) {
						class_outputHTML += "<label for='{" + question[k].ID + "}'>" + question[i].Title + "</label>";
						class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" + questions[i].questionId + "}' value='{" + questions[i].answer[k].theAnswer + "}' checked disabled />";
					}

				} else if(question[i].length == 1) {
					class_outputHTML += "<label for='{" + questions[i].questionId + "}'>" + questions[i].theQuestion + "</label>";
					class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" + questions[i].questionId + "}' value='{" + questions[i].answer[0].theAnswer + "}' disabled />";
				}
			}
		}
		class_outputHTML += "</fieldset></div>";
		return class_outputHTML;
	},
	/**
	 * Name : get_numberedit_html
	 * Purpose :Method to get number edit html .
	 * Params:questions with answers
	 * Returns : input type with number edit html with question and answers
	 */
	get_numberedit_html : function(question, date) {
		instance_outputHTML = "";
		instance_outputHTML += "<div data-role='fieldcontain'>";
		var ParticipantAnswer
		if(ParticipantAnswer) {
			value = ParticipantAnswer.getby_answer(question.answers[0], date).answerValue1;
			instance_outputHTML += "<label for=" + question[0].Title + ">" + question[0].Title + "</label>";
			instance_outputHTML += "<input type=\"tel\" id=\'{question.questionId}\
			' maxlength=\"3\" value=\"\" class='ui-disabled' style=\"width:50px\" name=\"form[{answer.object}}]\" disabled/>";

		} else {
			instance_outputHTML += "<label for=" + question[0].ID + ">" + question[0].Title + "</label>";
			instance_outputHTML += "<input type=\"tel\" pattern=\"[0-9]*\" style=\"width:50px\"  maxlength=\"3\" id=" + question[0].ID + " name=\"form[number]\"/>";
			instance_outputHTML += "<input type=\"hidden\" name=\"form[number]\" value=\"number\"/>";
		}
		instance_outputHTML += "</div>";
		return instance_outputHTML;

	}
};
