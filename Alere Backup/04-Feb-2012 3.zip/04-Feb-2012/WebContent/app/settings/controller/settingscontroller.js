/**
 * Controller : SettingsController
 * Controller to do logic of settings
 **/
mHealth.controllers.SettingsController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #logoutId' : 'doLogout',
		'click #showAbout' : 'getFeatures',
		'click #sendFeedBack' : 'sendMail',
		'pagebeforeshow #aboutsDetail' : 'showDetail',
		'change #HeightUnit' : 'getHeightUnits',
		'change #WeightUnit' : 'getWeightUnits',
		'pagebeforeshow #settingsPage' : 'showSettings',
		'click #debugId' : 'debug'
	},

	/**
	 * Name    : debug
	 * Purpose : Method to do Debug.
	 * Params  : --
	 * Return  : --
	 **/
	debug : function() {
		mHealth.util.customAlert("Under Contruction", '');
	},
	/**
	 * Name    : doLogout
	 * Purpose : Method to do required actions while logout.
	 * Params  : --
	 * Return  : --
	 **/
	doLogout : function() {
		mHealth.util.customPrompt("Are you sure to logout?","",
		function(){
			
		},
		function()
		{
			
			//mHealth.models.AnswerModel.destroyAll();
				//mHealth.models.ParticipantAnswerModel.destroyAll();
				mHealth.models.ConditionModel.destroyAll();
				mHealth.models.MedicationModel.destroyAll();
				mHealth.models.ParticipantModel.destroyAll();
				//mHealth.models.SpaceModel.destroyAll();
				//mHealth.models.ViewModel.destroyAll();
				//mHealth.models.ZoneModel.destroyAll();
				mHealth.models.HealthDataModel.destroyAll();
				$.mobile.changePage("../../rootview/view/login.html");
				//location.href = "tabbar://logout?";
				mHealth.util.removeNativeBarEvent();
		} );
		
		
	},
	/**
	 * Name    : getHeightUnits
	 * Purpose : Method to get the selected value of height units field on change of the select menu
	 * Params  : --
	 * Return  : --
	 **/
	getHeightUnits : function() {
		mHealth.util.selUnits = $('select#HeightUnit option:selected').val();
	},
	/**
	 * Name:WeightUnits
	 *Purpose:Method to get the selected value of weight units field
	 on change of the select menu
	 **/

	getWeightUnits : function() {
		mHealth.util.selWeightUnits = $('select#WeightUnit option:selected').val();
	},
	/**
	 * Name    : showSettings
	 * Purpose : Method to render the selected value of height units field on load of the page
	 * Params  : --
	 * Return  : --
	 **/
	showSettings : function() {
		if(mHealth.util.selUnits == 'cm') {
			$("select#HeightUnit option[value='cm']").attr("selected", "selected");
			$('select').selectmenu('refresh');

		}

		if(mHealth.util.selWeightUnits == 'Kg') {
			$("select#WeightUnit option[value='Kg']").attr("selected", "selected");
			$('select').selectmenu('refresh');

		}
	},
	/**
	 * Name    : showDetail
	 * Purpose : Method to render the values of device details
	 * Params  : --
	 * Return  : settingsDetail, deviceInfo
	 **/
	showDetail : function() {
		var settingsDetail;
		settingsDetail = mHealth.SettingsAbout;
		$('#settingsHeader').html(_.template($('#headerScript').html(), {
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').html(_.template($('#deviceDetails').html(), {
			deviceInfo : deviceInfo,
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').trigger('create');
		$('#settingsHeader').trigger('create');

	},
	/**
	 * Name    : getFeatures
	 * Purpose : Method to call the webview to get Device Features
	 * Params  : --
	 * Return  : --
	 **/
	getFeatures : function() {
		// location.href = "about://getdevicefeatues?";
		mHealth.util.getDeviceFeatures();
	},
	/**
	 * Name    : sendMail
	 * Purpose : Method to call the webview to call native email
	 * Params  : --
	 * Return  : --
	 **/
	sendMail : function() {
		//location.href = "email://sendEmail?mailto=corpfeedback@alere.com&subject=Alere+mHealth"
		mHealth.util.sendEmailEvent("corpfeedback@alere.com", "Alere mHealth");
	}
});

mHealth.controllers.SettingsController.extend({

	/**
	 * Name    : getDevicesFeature
	 * Purpose : Method to call from webview to get device features
	 * Params  : --
	 * Return  : --
	 **/
	getDevicesFeature : function(device, osversion) {
		mHealth.util.osversion = osversion;
		mHealth.util.device = device;
		deviceInfo = [{
			'regUser' : mHealth.util.participantEmail,
			'version' : mHealth.util.version,
			'platform' : 'APPLE',
			'deviceName' : mHealth.util.device,
			'deviceModel' : mHealth.util.osversion
		}];

	}
});
