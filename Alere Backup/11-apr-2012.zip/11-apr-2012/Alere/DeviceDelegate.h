//
//  DeviceDelegate.h
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol DeviceDelegate;
@interface DeviceDelegate : NSObject


@end

@protocol DeviceDelegate<NSObject>
@required
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action;
@end

