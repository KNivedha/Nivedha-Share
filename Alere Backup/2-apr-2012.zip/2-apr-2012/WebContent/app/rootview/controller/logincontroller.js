/**
 *Controller : LoginController
 *Controller to do login functionality.
 **/
mHealth.controllers.LoginController = Spine.Controller.sub({
	el : 'body',
	environment : null,
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #loginbutton' : 'validateLogin',
		// 'click #loginbutton' : 'doLogin',
		'submit #login-form' : 'doLogin',
		'click #debugToggle' : 'toggleDebugOptions',
		'click #sendMail' : 'sendEmail',
		'pageshow #loginPage' : 'setPrevLogin',
		'click #contactEmail' : 'sendContactMail',
		'click #mailToCreig' : 'mailToCreig',
		'click #clientAccessButton' : 'clientRegistration',
		'pagebeforeshow div[data-role="page"]' : 'whiteStripFix',
		'pagebeforeshow #home' : 'setShortcuts'
	},

	/**
	 *Name    : toggleDebugOptions
	 *Purpose : Method to toggle debug options
	 *Params  : --
	 *Return  : --
	 **/
	toggleDebugOptions : function() {

		if(!($('#loginDiv').css('display') == 'none')) {
			$("#debug-options").fadeToggle("slow", "linear", function() {
				$('#loginPage').css({
					'height' : 'auto'
				});
				$('#loginPage').trigger('create');
				$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');

			});
		}
	},
	/**
	 *Name    : setShortcuts
	 *Purpose : Method to set shortcuts in home
	 *Params  : --
	 *Return  : --
	 **/
	setShortcuts : function() {
		mHealth.util.homeFeature = mHealth.models.HomeFeaturesModel.first();
		$('#showHomeShortcut').html(_.template($('#homeScript').html(), {
			homeFeature : mHealth.util.homeFeature.feature
		}));
		$('#showHomeShortcut').trigger('create');

	},
	whiteStripFix : function() {

		$('div[data-role="page"]').css({
			'height' : document.height
		});
	},
	init : function() {

	},
	clientRegistration : function() {
		var clientAcess = $('#clientAccess').val().trim();
		//Current using mHealth.uat as we get undefined
		var registrationURL = mHealth.uat.registration_url + '?keycode=' + clientAcess;
		//URL DEFINED IN config.js

		window.open(registrationURL, '_blank');
	},
	validateLogin : function() {

		var username = $('#username').val().trim();
		var password = $('#password').val().trim();
		if((username == '') || (password == '')) {
			$('#username').val("");
			$('#password').val("");
			$('#errorMessage').html(mHealth.Login.msgEmptyField);
			$('#loginPage').css({
					'height' : 'auto'
				});
				$('#loginPage').trigger('create');
		}
	},
	/**
	 *Name    : mailToCreig
	 *Purpose : Method to Send email to the Craig.Apolinsky of the Alere
	 *Params  : --
	 *Return  : --
	 **/
	mailToCreig : function() {
		mHealth.util.sendEmail('Craig.Apolinsky@alere.com', '');
	},
	/**
	 *Name    : sendContactMail
	 *Purpose : Method to Send email to the corp feedback of the Alere
	 *Params  : --
	 *Return  : --
	 **/
	sendContactMail : function() {
		mHealth.util.sendEmail('Corpfeedback@alere.com', '');
	},
	/**
	 *Name   : setPrevLogin
	 *Purpose: Method to set the previous User Id and Setting the splash message.
	 *Params : --
	 *Return : --
	 **/
	setPrevLogin : function() {
		var rememberMe = mHealth.models.RememberMeModel.first();

		if(rememberMe != undefined) {
			$('#username').val(rememberMe.username);
		}
		var currentPageURL = $('.ui-page-active').attr('data-url');
		var splashMessage = mHealth.util.getParameterByName('splashMessage', currentPageURL);
		if(splashMessage !== null) {

			$('#errorMessage').text(splashMessage);			
		}

		if($('#username').val().length > 0) {
			$('#loginDiv').show();
		}
		$('#loginFormButton').click(function() {
			$('#loginDiv').show();
			$('#clientAccessDiv').hide();
			$('#loginPage').css({
				'height' : 'auto'
			});

			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
		});
		$('#clientAccessFormButton').click(function() {
			$('#loginDiv').hide();
			$('#clientAccessDiv').show();
			$('#loginPage').css({
				'height' : 'auto'
			});
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
		});
		$('#loginPage').trigger('create');
	},
	/**
	 *Name   : sendEmail
	 *Purpose: Method to send email.
	 *Params : --
	 *Return : --
	 **/
	sendEmail : function() {
		var subject = "";
		if(mHealth.SettingsLogin.emailSubject != undefined) {
			subject = mHealth.SettingsLogin.emailSubject;
		}
		mHealth.util.sendEmail(mHealth.SettingsLogin.email, '', subject);
	},
	/**
	 *Name   : loginSuccess
	 *Purpose: Success callback to authenticate user.
	 *Params : output - response from the server
	 *Return : --
	 **/
	loginSuccess : function(output) {

		//URL for Messages
		var URL = mHealth.env.messageheaders_url;
		this.proxy(this.service.getResponse(URL, mHealth.MessageControllerObject.messageSuccess, mHealth.MessageControllerObject.showHome, true));
		// URL for Profile
		this.proxy(this.service.getResponse(mHealth.env.profile_url, this.proxy(this.participantSuccess), null, false));

	},
	/**
	 * Name    : participantSuccess
	 * Purpose : Success callback for getting participant data.
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	participantSuccess : function(output) {
		var response = output.responseText;
		mHealth.models.ParticipantModel.customFromJSON(response);
	},
	/**
	 *Name   : loginFailure
	 *Purpose: Failure callback to authenticate user.
	 *Params : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server.
	 *Return : Displays error message.
	 **/
	loginFailure : function(errorThrown) {
		var splashMessage = null;
		if(errorThrown == mHealth.SettingsController.timeOut) {
			splashMessage = mHealth.SettingsController.errTimeout;
		} else if(errorThrown == mHealth.SettingsController.unauthorized) {
			splashMessage = mHealth.Login.msgEmptyField;
		} else {
			splashMessage = mHealth.SettingsController.msgErrorCommunication;
		}

		$('#loginPage').detach();
		$.mobile.changePage("../../rootview/view/login.html", {
			data : {
				splashMessage : splashMessage
			}
		});

	},
	/**
	 *Name   : doLogin
	 *Purpose: Method to encode user credential to base64 encoding.
	 *Params : --
	 *Return : --
	 **/
	doLogin : function() {
		var username = $('#username').val();
		var password = $('#password').val();

		mHealth.models.TabModel.create({
			id : "Home"
		});
		mHealth.models.TabModel.create({
			id : "Messages"
		});

		mHealth.models.TabModel.create({
			id : "Challenges"
		});

		mHealth.models.TabModel.create({
			id : "Trackers"
		});

		mHealth.models.TabModel.create({
			id : "Settings"
		});

		mHealth.models.TabsModel.create({
			tab : mHealth.models.TabModel.all()
		});

		mHealth.models.FeatureGroupModel.create({
			groupId : "standard",
			feature : ""
		});
		mHealth.models.FeatureGroupModel.create({
			groupId : "trackers",
			feature : [{
				"id" : "Weight & BMI",
				"trackerRank" : 900
			}, {
				"id" : "Blood Pressure",
				"trackerRank" : 850
			}, {
				"id" : "Blood Glucose",
				"trackerRank" : 800
			}, {
				"id" : "A1c",
				"trackerRank" : 750
			}, {
				"id" : "Cholesterol",
				"trackerRank" : 700
			}, {
				"id" : "Exams",
				"trackerRank" : 650
			}]
		});

		mHealth.models.NurseCallModel.create({
			promptText : "Call nurse now",
			phone : '8005551212'
		});

		mHealth.models.MyaFeaturesModel.destroyAll();

		mHealth.models.MyaFeaturesModel.create({
			tabs : mHealth.models.TabsModel.all(),
			homeFeatures : mHealth.models.HomeFeaturesModel.all(),
			features : mHealth.models.FeatureGroupModel.all(),
			nurseCall : mHealth.models.NurseCallModel.all()
		});

		if((username != '') && (password != '')) {
			$.mobile.changePage("../../rootview/view/wait.html");
			environment = $('select#server option:selected').val();
			mHealth.util.setEnvironment(environment);
			mHealth.util.participantEmail = username;
			mHealth.models.RememberMeModel.destroyAll();
			var rememberMe = new mHealth.models.RememberMeModel({
				"username" : username
			});
			rememberMe.save();
			var credentials = $.base64Encode(username + ":" + password);
			this.service.getToken(mHealth.env.authtoken_get_url, credentials, this.proxy(this.loginSuccess), this.proxy(this.loginFailure));
		} else {
			$('#errorMessage').html(mHealth.Login.msgEmptyField);
			$('#loginPage').css({
				'height' : 'auto'
			});
			$('#loginPage').trigger('create');
		}

	}
});
