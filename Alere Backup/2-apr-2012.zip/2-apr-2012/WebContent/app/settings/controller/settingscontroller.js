/**
 * Controller : SettingsController
 * Controller to do logic of settings
 **/
mHealth.controllers.SettingsController = Spine.Controller.sub({
	el : 'body',
    hwarticleID : null,
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #logoutId' : 'doLogout',
		'click #showAbout' : 'getFeatures',
		'click #sendFeedBack' : 'sendMail',
		'pagebeforeshow #aboutsDetail' : 'showDetail',
		'change #HeightUnit' : 'getHeightUnits',
		'change #WeightUnit' : 'getWeightUnits',
		'pagebeforeshow #settingsPage' : 'showSettings',
		'click #debugId' : 'debug',
		'click #measurementUnits' : 'setDocHeight'
    },
    
    /**
	 * Name    : setDocHeight
	 * Purpose : Method to set document height to fix white strip.
	 * Params  : --
	 * Return  : --
	 **/
	setDocHeight : function() {
		$('#settingsPage').css({
			'height' : 'auto'
		});
		$('#settingsPage').trigger('create');
	},
    
      /**
	 * Name    : debug
	 * Purpose : Method to do Debug.
	 * Params  : --
	 * Return  : --
	 **/
	debug : function() {
        $.mobile.changePage('../../debug/view/debugindex.html');
	},
	/**
	 * Name    : doLogout
	 * Purpose : Method to do required actions while logout.
	 * Params  : --
	 * Return  : --
	 **/
	doLogout : function() {
		mHealth.util.customPrompt(mHealth.SettingsController.logoutConfirm, function() {
			}, function() {
			var splashMessage = mHealth.SettingsLogin.logout;
			mHealth.models.ConditionModel.destroyAll();
			mHealth.models.MessageModel.destroyAll();
			mHealth.models.MedicationModel.destroyAll();
			mHealth.models.ParticipantModel.destroyAll();
			mHealth.models.HealthDataModel.destroyAll();
			mHealth.models.ChallengeResponseModel.destroyAll();
			mHealth.models.QuestionResponsesModel.destroyAll();
			$('#loginPage').detach();
			mHealth.HealthDataControllerObject.healthDataFlag=false;
			$.mobile.changePage("../../rootview/view/login.html", {
				data : {
					splashMessage : splashMessage
				}
			});

			mHealth.util.removeNativeBar();
			mHealth.MessageControllerObject.tabbarloaded= false;
		});
	},
	/**
	 * Name    : getHeightUnits
	 * Purpose : Method to get the selected value of height units field on change of the select menu
	 * Params  : --
	 * Return  : --
	 **/
	getHeightUnits : function() {
		mHealth.util.selUnits = $('select#HeightUnit option:selected').val();
	},
	/**
	 * Name:WeightUnits
	 *Purpose:Method to get the selected value of weight units field
	 on change of the select menu
	 **/

	getWeightUnits : function() {
		mHealth.util.selWeightUnits = $('select#WeightUnit option:selected').val();
	},
	/**
	 * Name    : showSettings
	 * Purpose : Method to render the selected value of height units field on load of the page
	 * Params  : --
	 * Return  : --
	 **/
	showSettings : function() {
       if(mHealth.util.selUnits == 'cm') {
			$("select#HeightUnit option[value='cm']").attr("selected", "selected");
			$('select').selectmenu('refresh');
        }
        if(mHealth.util.selWeightUnits == 'Kg') {
			$("select#WeightUnit option[value='Kg']").attr("selected", "selected");
			$('select').selectmenu('refresh');
        }
	},
	/**
	 * Name    : showDetail
	 * Purpose : Method to render the values of device details
	 * Params  : --
	 * Return  : settingsDetail, deviceInfo
	 **/
	showDetail : function() {
       var settingsDetail;
		settingsDetail = mHealth.SettingsAbout;
		$('#settingsHeader').html(_.template($('#headerScript').html(), {
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').html(_.template($('#deviceDetails').html(), {
			deviceInfo : deviceInfo,
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').trigger('create');
		$('#settingsHeader').trigger('create');

	},
	/**
	 * Name    : getFeatures
	 * Purpose : Method to call the webview to get Device Features
	 * Params  : --
	 * Return  : --
	 **/
	getFeatures : function() {
		mHealth.util.getDeviceFeatures();
		$.mobile.changePage("about.html");
	},
	/**
	 * Name    : sendMail
	 * Purpose : Method to call the webview to call native email
	 * Params  : --
	 * Return  : --
	 **/
	sendMail : function() {
        mHealth.util.sendEmail(mHealth.env.emailTo,mHealth.env.emailCC , mHealth.env.emailSubject);
	}
});

mHealth.controllers.SettingsController.extend({

	/**
	 * Name    : getDevicesFeature
	 * Purpose : Method to call from webview to get device features
	 * Params  : --
	 * Return  : --
	 **/
	getDevicesFeature : function(device, osversion, deviceId) {
		mHealth.util.osversion = osversion;
		mHealth.util.device = device;
		mHealth.util.deviceId = deviceId;
		deviceInfo = [{
			'regUser' : mHealth.util.participantEmail,
			'version' : mHealth.util.version,
			'platform' : 'APPLE',
			'deviceName' : mHealth.util.device,
			'deviceModel' : mHealth.util.osversion,
			'deviceId' : mHealth.util.deviceId
		}];

	}
});
