mHealth.models.AnswerModel=Spine.Model.sub();
mHealth.models.AnswerModel.configure('AnswerModel','participantId','answerId','createTimestamp','updateTimestamp','startDate',
		'endDate','learnMore','triggers','assessmentId','sectionId','questionId','language','rank',
		'entryType','theAnswer','imageURL','indicatorValue');




