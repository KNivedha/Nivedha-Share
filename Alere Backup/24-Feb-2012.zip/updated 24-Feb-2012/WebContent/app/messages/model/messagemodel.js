mHealth.models.MessageModel = Spine.Model.sub();
// mHealth.models.MessageModel.configure('MessageModel','messageID',
// 'msgTypeID','title','sentDate','msgFolderID','healthTopicID',
// 'isRead','isReplied','isUrgent');

mHealth.models.MessageModel.configure("MessageModel", "messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "sentDate", "deliveredDate", "expiredDate", "sections");

mHealth.models.MessageDetailsModel = Spine.Model.sub();
mHealth.models.MessageDetailsModel.configure("MessageDetailsModel", "messageID", "msgTypeID", "senderID", "senderTypeID", "recipientID", "recipientTypeID", "concernedPartyID", "concernedPartyTypeID", "title", "conversationID", "msgFolderID", "healthTopicID", "msgTemplateID", "targetPresentationLayerID", "isRead", "isReplied", "isUrgent", "sentDate", "deliveredDate", "expiredDate", "summary", "sections");

mHealth.models.SectionModel = Spine.Model.sub();
mHealth.models.SectionModel.configure("SectionModel", "videos", "messageText", "questionnaire","articles");

mHealth.models.QuestionnaireModel = Spine.Model.sub();
mHealth.models.QuestionnaireModel.configure("QuestionnaireModel", "learnMore", "introCopy", "qSections");

mHealth.models.QuestionSectionModel = Spine.Model.sub();
mHealth.models.QuestionSectionModel.configure('QuestionSectionModel', 'questions', 'id', 'seq', 'learnMore', 'ImageURL');

mHealth.models.MessageQuestionModel = Spine.Model.sub();
mHealth.models.MessageQuestionModel.configure('MessageQuestionModel', 'id', 'seq', 'questionText', 'answerType', 'ImageURL', 'answerOptions', 'learnMore');

// mHealth.models.AnswerModel = Spine.Model.sub();
// mHealth.models.AnswerModel.configure('AnswerModel', 'id', 'seq', 'Label', 'ImageURL');

