mHealth.models.ParticipantModel = Spine.Model.sub();
mHealth.models.ParticipantModel.configure("ParticipantModel", 'participantID', 'message', 'programName', 'memberEligID', 'preferredName', 'lastName', 'dateOfBirth', 'gender', 'height', 'emailAddress', 'firstName', 'createTimestamp', 'loggedIn', 'username', 'alsectoken', 'transactionID', 'contentBody','populationID','language','updateTimestamp','effectiveDate');

mHealth.models.RememberMeModel = Spine.Model.sub();
mHealth.models.RememberMeModel.configure("RememberMeModel", "username");
mHealth.models.RememberMeModel.extend(Spine.Model.Local);
mHealth.models.RememberMeModel.fetch();