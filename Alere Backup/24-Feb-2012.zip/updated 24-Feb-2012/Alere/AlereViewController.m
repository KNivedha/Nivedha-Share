//
//  AlereViewController.m
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "AlereViewController.h"
#import <EventKit/EventKit.h>
#import "AlereAppDelegate.h"
#import "OrientationConstants.h"
#define DEGREES_TO_RADIANS(__ANGLE__) ((__ANGLE__) / 180.0 * M_PI)
@implementation AlereViewController
@synthesize webView,rotated,landscp,insideTabBar,enteredGraph,resized,baseTabBar,enteredGlucose,login;
- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle


 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
 - (void)viewDidLoad
 {
     calObj=[[Calendar alloc]init];
     emailObj=[[EMail alloc]init];
     deviceObj=[[Devices alloc]init];
     orientationObj=[[Orientation alloc]init];
     tabBarObj=[[TabBar alloc]init];
     pluginObjects=[[NSMutableDictionary alloc]init];
     [pluginObjects setValue:calObj forKey:@"cal"];
     [pluginObjects setValue:emailObj forKey:@"email"];
     [pluginObjects setValue:deviceObj forKey:@"about"];
     [pluginObjects setValue:orientationObj forKey:@"gyro"];
     [pluginObjects setValue:tabBarObj forKey:@"tabbar"];
     
     
     enteredGraph=NO;
     resized=NO;
     landscp=NO;
     returnType=YES;
     rotated=NO;
     cameBack=NO;
     login=NO;
     
     
     
     [[UIDevice currentDevice]beginGeneratingDeviceOrientationNotifications];
     baseTabBar.hidden=YES;
     UITapGestureRecognizer *twoFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTwoFingerTap)];
     [twoFingerTap setNumberOfTouchesRequired:2];
     [webView addGestureRecognizer:twoFingerTap];
     
    // webView.frame=CGRectMake(0, 0, 320, 510);

     //****************************Native calander**************
     //  NSURL *url=[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"Calendar" ofType:@"html" inDirectory:@"Calendar"]];
     
     //****************************mHelath**************
     NSURL *url=[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"termsandconditions" ofType:@"html" inDirectory:@"WebContent/app/rootview/view"]];
     
     //***************************hitting service*****************
     
     //NSURL *url=[NSURL URLWithString:@"http://203.62.174.97/Cache/app/RootView/View/login.html"];
     
     NSURLRequest* request=[NSURLRequest requestWithURL:url ];
     [webView loadRequest:request];
     [super viewDidLoad];
 }

-(void)handleTwoFingerTap
{
    NSLog(@"resizening");
    UIApplication* application=[UIApplication sharedApplication];
     if (enteredGraph&& !resized) 
    { 
       application.statusBarHidden=YES;
       resized=YES;
       baseTabBar.hidden=YES;
       self.view.frame=CGRectMake(0, 0,320,480);
       webView.frame=CGRectMake(0,0,480,320);
        
    }
    else if(enteredGraph&& resized)
    {
        //self.view.frame=CGRectMake(0, 20,480,300);
        resized=NO;
        baseTabBar.hidden=NO;
        self.view.frame=CGRectMake(0, 0,320,480);
        webView.frame=CGRectMake(0,0,480,272);
        
    }
}
#pragma mark - webview delegate methods

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{

    NSString* scheme;
    NSString* action;
    NSLog(@"webView : delegate method");
    NSString* urlString=[[request URL] absoluteString]; 
    urlString=[urlString stringByReplacingPercentEscapesUsingEncoding:NSStringEncodingConversionAllowLossy];
    NSLog(@"url from webView is %@",urlString);
    BOOL returnType1;
    NSMutableDictionary* paramData=nil;
    @try 
    {
        scheme=[[urlString  componentsSeparatedByString:@"://"]objectAtIndex:0] ; 
        eventname=[[urlString componentsSeparatedByString:@"://"]objectAtIndex:1] ; 
        NSArray* urlArray=[eventname componentsSeparatedByString:@"?"];
        NSLog(@"count %d ",[urlArray count]);
        if([urlArray count]>1)
        {
            action=[urlArray objectAtIndex:0];
            if (![[urlArray objectAtIndex:1] isEqualToString:@""] ) 
            {
                NSArray* paramArray=[[urlArray objectAtIndex:1]componentsSeparatedByString:@"&"];
                NSLog(@" %@",paramArray);
                int paramcount=[paramArray count];
                NSLog(@"param count %d",paramcount);
                if(paramcount>=1)
                {
                    NSLog(@"more than one parameter");
                    int index=0;
                    paramData=[[NSMutableDictionary alloc]initWithCapacity:4];
                    for(int i = 0; i < paramcount; i++)
                    {
                        NSString *value = [[[paramArray objectAtIndex:i] componentsSeparatedByString:@"="] objectAtIndex:1];
                        NSString *key  = [[[paramArray objectAtIndex:i] componentsSeparatedByString:@"="] objectAtIndex:0];
                        [paramData setValue:value forKey:key];
                        index++;
                    }	
                }
            }
            [[pluginObjects objectForKey:scheme] accessDeviceFeature:paramData forAction:action ];
            NSLog(@"scheme : %@ ,action : %@ , params : %@",scheme,action,paramData);
            returnType1=NO;
        }
        else
        {
            NSLog(@"open url");
            returnType1=YES;
        }
    }
    @catch (NSException *exception) 
    {
        returnType1=NO;
        NSLog(@"thrown execption %@",exception);
    }
    return returnType1;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"webview : started");
}
- (void)webViewDidFinishLoad:(UIWebView *)webView1
{
   
    webView.hidden=NO;
    [webView stringByEvaluatingJavaScriptFromString:@"document.body.style.webkitTouchCallout='none';document.body.style.KhtmlUserSelect='none'"];
   // tabBarControllerObj.returnType=YES;
   // [tabBarControllerObj setInitialOrientation];
	  NSLog(@"webview : finished");
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"webview : loading error %@",error);
   // tabBarControllerObj.returnType=YES;
}
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    UITabBarItem *homeTab=[[baseTabBar items]objectAtIndex:1];
    homeTab.badgeValue=nil;
       NSString* callBackFunction;
    if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationPortrait)
    {
        if (enteredGraph) {
            [self.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(0));
            self.view.transform = cgCTM;
            self.view.frame = CGRectMake(0, 20, 320, 460);
            self.webView.frame=CGRectMake(0, 0, 320, 416);
            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortrait animated:YES];

        }
                
    }
   else if ([[UIDevice currentDevice]orientation]==UIInterfaceOrientationPortraitUpsideDown)
    {
        if (enteredGraph) {
            [self.view setCenter:CGPointMake(160, 240)];
            CGAffineTransform cgCTM = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(-180));
            self.view.transform = cgCTM;
            self.view.frame = CGRectMake(0, 0, 320, 460);
            self.webView.frame=CGRectMake(0, 0, 320, 416);
            [[UIApplication sharedApplication]setStatusBarOrientation:UIInterfaceOrientationPortraitUpsideDown animated:YES];
            
        }
        
    }
     else if (([[UIDevice currentDevice]orientation]==UIInterfaceOrientationLandscapeLeft)||([[UIDevice currentDevice]orientation]==UIInterfaceOrientationLandscapeLeft))
     {
         if (enteredGraph) {
             self.view.frame = CGRectMake(20, 0, 300, 480);
         }
         
     }
    
		enteredGlucose=NO;
		enteredGraph=NO;
    [[UIApplication sharedApplication]setStatusBarHidden:NO];
    if ([[[tabBar items] objectAtIndex:0]isEqual:item]) 
    {
        
        callBackFunction=@"loadHome()";
        [webView stringByEvaluatingJavaScriptFromString:callBackFunction];
    }
    if ([[[tabBar items] objectAtIndex:1]isEqual:item]) 
    {
        
        callBackFunction=@"loadMessages()";
        [  webView stringByEvaluatingJavaScriptFromString:callBackFunction];  
    }
    if ([[[tabBar items] objectAtIndex:2]isEqual:item]) 
    {
        
        callBackFunction=@"loadActivities()";
        [ webView stringByEvaluatingJavaScriptFromString:callBackFunction];
    }
    if ([[[tabBar items] objectAtIndex:3]isEqual:item]) 
    {
        
        callBackFunction=@"loadTrackers()";
        [  webView stringByEvaluatingJavaScriptFromString:callBackFunction];
    }
    if ([[[tabBar items] objectAtIndex:4]isEqual:item]) 
    {
        callBackFunction=@"loadSettings()";
        [  webView stringByEvaluatingJavaScriptFromString:callBackFunction];
    }
    
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
  if((enteredGraph)&&((interfaceOrientation==UIInterfaceOrientationPortrait)||(interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown))) 
  {
      return NO;
  }
  if((enteredGraph)&&((interfaceOrientation==UIInterfaceOrientationLandscapeLeft)||(interfaceOrientation==UIInterfaceOrientationLandscapeRight))) 
  {
      return YES;
  }
   return YES;
        
}
@end
