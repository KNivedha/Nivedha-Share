/**
 * Controller : MedicalHistoryController
 * Controller to do the  logic of conditions
 **/

mHealth.controllers.MedicalHistoryController = Spine.Controller.sub({
	el : 'body',
	isConditionFocus : false,
	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		'click #condition_history' : 'getCondition',
		'click #con_save' : 'saveCondition',
		'click #con_update' : 'updateCondition',
		'pagebeforeshow #condition_index' : 'showCondition',
		'pagebeforeshow #add_condition' : 'addCondition',
		'pagebeforeshow #editCondition' : 'editCondition',
		'click .search_name' : 'addConditionDetails',
		'click .edit' : 'editConditionDetails',
		'click #showHistory' : 'showMedConditions',
		'click #conditionback' : 'conditionBack',

	},

	conditionBack : function() {
		/*
		 * TFS: 43143
		 * Description:	Condition: 'Search result box' arised on writing in condition field is displayed even after navigation
		 */
		if(this.isConditionFocus) {
			$("#conditionName").autocomplete("close").focus();
		}
		$.mobile.changePage("conditionindex.html");
	},
	showMedConditions : function() {
		$.mobile.changePage("../../home/view/history.html");
	},
	/**
	 * Name    : searchCondition
	 * Purpose : Method to Search conditions
	 * Params  : --
	 * Return  : --
	 **/
	searchCondition : function(conditionName) {

		$('#subconditiondiv').hide();
		var modelResponse = mHealth.models.SearchConditionModel.findByAttribute("conditionName", conditionName);
		if(modelResponse != null) {
			if(modelResponse.SubCondition != '') {
				if(modelResponse.SubCondition != undefined) {
					$('#subconditiondiv').show();
					$('#subconditiondiv').html(_.template($('#con_script').html(), {
						modelResponse : modelResponse
					}));
					$('#subconditiondiv').trigger('create');
				}
			}
		}

	},
	/**
	 * Name    : getConditionRecord
	 * Purpose : Method to return record pertaining to condition and icd9ID that has to be saved.
	 * Params  : --
	 * Return  : returns the condition record
	 **/
	getConditionRecord : function() {
		var editConditionValue = $('#conditionName').val();
		var icd9Id = $('#ICD9IdName').val();
		var recordupdt;
		mHealth.models.ConditionModel.each(function(record) {
			if(record.conditionName === editConditionValue && record.icd9Id === icd9Id) {
				recordupdt = record;
			}
		});
		recordupdt.fromForm('#confirm_condition');
		var dateObject = new Date(recordupdt.diagnosisDate.substr(6, 4), recordupdt.diagnosisDate.substr(0, 2) - 1, recordupdt.diagnosisDate.substr(3, 2));
		recordupdt.diagnosisDate = dateObject.format("yyyy-mm-dd");
		return recordupdt;
	},
	/**
	 * Name    : updateCondition
	 * Purpose : Method to update conditions
	 * Params  : --
	 * Return  : --
	 **/
	updateCondition : function() {

		if(mHealth.SettingsAbout.networkStatus != 'false') {
			mHealth.util.showMask();
			var recordupdt, body;
			recordupdt = this.getConditionRecord();
			body = JSON.stringify([recordupdt]);
			this.service.postRequest(mHealth.env.condition_url, body, this.proxy(this.postSuccess), this.proxy(this.postError), true);
		} else {
			mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');
		}
	},
	/**
	 * Name    : postSuccess
	 * Purpose : Success callback for updating conditions to the server. Updates the record in model
	 * Params  : output - response from the server
	 * Return  : --
	 **/
	postSuccess : function(output) {
		mHealth.util.hideMask();
		this.getConditionRecord().save();
		$.mobile.changePage('conditionindex.html');
	},
	/**
	 * Name    :
	 * Purpose : Failure callback for updating conditions to the server
	 * Params  : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server
	 * Return  : Alerts 'Information not available'
	 **/
	postError : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.hideMask();
		mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');

	},
	/**
	 * Name    :
	 * Purpose : Method to set the values of the fields in confirmCondition.html
	 * Params  : --
	 * Return  : --
	 **/
	editCondition : function() {
		var activePage, renderDate, dateObject, close, validDate, renderICD9Id;
		activePage = $('div[id = "editCondition"]').attr('data-url');
		var renderConditionName = mHealth.util.getParameterByName('renderConditionName', activePage);
		renderConditionName = $.base64Decode(renderConditionName);
		renderICD9Id = mHealth.util.getParameterByName('renderICD9Id', activePage);
		renderDate = mHealth.util.getParameterByName('renderDate', activePage);
		dateObject = new Date(renderDate.substr(6, 4), renderDate.substr(0, 2) - 1, renderDate.substr(3, 2));
		close = false;
		validDate = dateObject;
		$('#diagnosisDate').scroller({
			preset : 'date',
			theme : 'ios',
			endYear : 2012,
			beforeShow : function(input, inst) {
				nativeCommunication.callNativeMethod("tabbar://hideTabBar?");

			},
			onCancel : function(valueText, inst) {
				close = true;
			},
			onClose : function(valueText, inst) {

				if(!close) {
					//nativeCommunication.callNativeMethod("tabbar://logout?");
					return false;
				} else {
					if(inst.getDate() > (new Date())) {
						inst.setDate(validDate);
					}
					nativeCommunication.callNativeMethod("tabbar://showTabBar?");

					return true;
				}
			},
			onSelect : function(valueText, inst) {
				if(inst.getDate() > (new Date())) {
					close = false;

					mHealth.util.customAlert(mHealth.Section.dateOutOfRange, '');

				} else {
					validDate = inst.getDate();
					close = true;
				}

			}
		});
		$('#conditionName').val(renderConditionName);
		$('#ICD9IdName').val(renderICD9Id);
		$('#diagnosisDate').val(renderDate);
	},
	/**
	 * Name    :
	 * Purpose : Method to get the rendered value of condition name and diagnosis date from conditionindex.html
	 * Params  : e - event object
	 * Return  : --
	 **/
	editConditionDetails : function(e) {
		var item, trimRenderDate, renderConditionName, renderDate, renderICD9Id;
		item = e.target;
		renderConditionName = $(item).parents().children('div[id="conditionname"]').text();
		var trimRenderConditionName = renderConditionName.trim();
		trimRenderConditionName = $.base64Encode(trimRenderConditionName);
		renderDate = $(item).parents().children('div[id="diagnosisdate"]').text();
		trimRenderDate = renderDate.trim();
		renderICD9Id = $(item).parents().children('div[id="icd9Id"]').text();
		var trimrenderICD9Id = renderICD9Id.trim();
		$.mobile.changePage('confirmcondition.html', {
			data : {
				renderConditionName : trimRenderConditionName,
				renderDate : trimRenderDate,
				renderICD9Id : trimrenderICD9Id
			}
		});
	},
	/**
	 * Name    : saveCondition
	 * Purpose : Method to save a new condition in the server
	 * Params  : --
	 * Return  : --
	 **/
	saveCondition : function(event) {

		var icd9Id, subConditionSelected;

		var conditionName = $('#conditionName').val();

		var modelResponse = mHealth.models.SearchConditionModel.findByAttribute(mHealth.Condition.conditionName, conditionName);

		if(modelResponse != null) {
			icd9Id = modelResponse.icd9Id;
			if(icd9Id === "" || icd9Id == undefined) {
				subConditionSelected = $('select#subConditionName option:selected').val();
				if(subConditionSelected != "" && subConditionSelected != mHealth.Condition.subConditionSelect) {
					var subConditions = modelResponse.SubCondition;
					for( i = 0; i < subConditions.length; i++) {
						if(subConditions[i].subConditionName === subConditionSelected) {
							icd9Id = subConditions[i].icd9Id;
						}
					}
					this.conditionSave(icd9Id);
				} else {
					mHealth.util.customAlert(mHealth.Condition.subConditionSelect, function() {
						event.preventDefault();
					});
				}
			} else {
				this.conditionSave(icd9Id);
			}

		} else {
			mHealth.util.customAlert(mHealth.Condition.invalidCondition, '');
		}

	},
	/**
	 * Name    : conditionSave
	 * Purpose : Method to make save condition call
	 * Params  : --
	 * Return  : --
	 **/
	conditionSave : function(icd9Id) {
		var dateObject = new Date($('#diagnosisDate').val().substr(6, 4), $('#diagnosisDate').val().substr(0, 2) - 1, $('#diagnosisDate').val().substr(3, 2));
		var dateValue = dateObject.format("yyyy-mm-dd");

		var isConditionExists = mHealth.models.ConditionModel.findByAttribute("icd9Id", icd9Id);
		if(isConditionExists !== null) {
			mHealth.util.customAlert(mHealth.Condition.conditionExist, '');
		} else {
			mHealth.util.showMask();

			var body = mHealth.recommendation.ConditionMapper(dateValue, icd9Id);

			this.service.postRequest(mHealth.env.condition_url, body, this.proxy(this.postConditionSuccess), this.proxy(this.postConditionError), false);
		}
	},
	/**
	 * Name    : postConditionSuccess
	 * Purpose : Success callback for saving conditions to the server. Saves the record into the model.
	 * Params  : output - response from the server
	 * Return  : --
	 **/
	postConditionSuccess : function(output) {
		var conditionName = $('#conditionName').val();
		var subConditionSelected = $('select#subConditionName option:selected').val();
		if(output.responseText) {
			var newRecord = JSON.parse(output.responseText);
			newRecord[0]['conditionName'] = conditionName;
			newRecord[0]['subConditionName'] = subConditionSelected;
			mHealth.models.ConditionModel.customFromJSON(JSON.stringify(newRecord));
		}
		mHealth.util.hideMask();
		$.mobile.changePage('conditionindex.html');
	},
	/**
	 * Name    :
	 * Purpose : Failure callback for saving conditions to the server
	 * Params  : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server
	 * Return  : Alerts 'Information not available'
	 **/
	postConditionError : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.hideMask();
		mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');
		//mHealth.util.hideMask();
	},
	/**
	 * Name    :
	 * Purpose : Method to get the associated record with the search condition clicked
	 * Params  : e - event object
	 * Return  : Condition model record associated with the fields
	 **/
	addConditionDetails : function(e) {
		var item, itemHtml, renderRecord, close, validDate, today;
		item = $(e.target);
		itemHtml = item.html();
		mHealth.models.SearchConditionModel.each(function(record) {
			if(record.conditionName === itemHtml) {
				if(_.isEmpty(record.SubCondition)) {
					mHealth.controllers.MedicalHistoryController.flagShow = false;
				} else {
					mHealth.controllers.MedicalHistoryController.flagShow = true;
				}
				renderRecord = record;

			}
		});

		$('#conditionForm').html(_.template($('#con_script').html(), {
			renderRecord : renderRecord
		}));

		if(mHealth.controllers.MedicalHistoryController.flagShow === true) {
			$('#subconditiondiv').show();

		}
		if(mHealth.controllers.MedicalHistoryController.flagShow === false) {

			$('#subconditiondiv').hide();

		}
		today = new Date();
		close = false;
		validDate = today;
		$('#diagnosisDate').scroller({
			preset : 'date',
			theme : 'ios',
			endYear : 2012,
			beforeShow : function(input, inst) {
				nativeCommunication.callNativeMethod("tabbar://hideTabBar?");

			},
			onCancel : function(valueText, inst) {
				close = true;
				//nativeCommunication.callNativeMethod("tabbar://logout?");

			},
			onClose : function(valueText, inst) {

				if(!close) {
					//nativeCommunication.callNativeMethod("tabbar://logout?");
					return false;
				} else {
					if(inst.getDate() > (new Date())) {
						inst.setDate(validDate);
					}
					nativeCommunication.callNativeMethod("tabbar://showTabBar?");

					return true;
				}
			},
			onSelect : function(valueText, inst) {
				if(inst.getDate() > (new Date())) {
					close = false;

					mHealth.util.customAlert(mHealth.Section.dateOutOfRange, '');

				} else {
					validDate = inst.getDate();
					close = true;
				}

			}
		});

		$('#search_div').hide();
		$('#add_condition').trigger('create');

	},
	/**
	 * Name    :
	 * Purpose : Method to make service call for fetching list of conditions from the server
	 * Params  : --
	 * Return  : --
	 **/
	getCondition : function() {
		mHealth.util.showMask();
		var modelCount;
		modelCount = mHealth.models.ConditionModel.count();
		if(modelCount === 0) {
			this.service.getResponse(mHealth.env.condition_url, this.proxy(this.conditionSuccess), this.proxy(this.conditionError), true);
		} else {
			$.mobile.changePage("../view/conditionindex.html");
		}
	},
	/**
	 * Name    :
	 * Purpose : Success callback for fetching search conditions from the server
	 * Params  : output - XMLHttpRequest object to get the response from the server
	 * Return  : --
	 **/
	subConditionSuccess : function(output) {

		$('#search_div').show();

		var response, searchConditionData;
		response = output.responseText;
		this.proxy(this.saveSubCondition(response));
		searchConditionData = mHealth.models.SearchConditionModel.all();

		$('#search_div').html(_.template($('#search_script').html(), {
			searchConditionData : searchConditionData
		}));
		$('#search_div').trigger('create');

	},
	/**
	 * Name    :
	 * Purpose : Success callback for fetching conditions from the server
	 * Params  : output - XMLHttpRequest object to get the response from the server
	 * Return  : --
	 **/
	conditionSuccess : function(output) {
		var response;
		response = output.responseText;
		this.proxy(this.processConditionData(response));
		$.mobile.changePage("../view/conditionindex.html");
	},
	/**
	 * Name    :
	 * Purpose : Failure callback for fetching conditions from the server
	 * Params  : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server
	 * Return  : Alerts 'Information not available'
	 **/
	conditionError : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.hideMask();
		mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');

	},
	/**
	 * Name    :
	 * Purpose : Render conditions in conditionindex.html
	 * Params  : --
	 * Return  : conditionData - list of conditions to be rendered
	 **/
	showCondition : function() {
		var conditionData;
		conditionData = mHealth.models.ConditionModel.select(function(record) {
			if(record.statusId !== '2') {
				return record;
			}
		});
		//conditionData = mHealth.models.ConditionModel.all();
		$('#condition_div').html(_.template($('#conditionDataList').html(), {
			conditionData : conditionData
		}));
		$('#condition_index').trigger('create');
		mHealth.util.hideMask();
	},
	/**
	 Purpose: Method to set the field values in addcondition.html
	 Params : --
	 Return : --
	 */
	addCondition : function() {

		var renderRecord, close, validDate, today;
		renderRecord = {
			conditionName : '',
			SubCondition : ''
		};

		$('#diagnosisDate').val(mHealth.util.getCurrentDate());

		$('#subconditiondiv').hide();
		today = new Date();
		close = false;
		validDate = today;
		$('#diagnosisDate').scroller({
			preset : 'date',
			theme : 'ios',
			endYear : 2012,
			beforeShow : function(input, inst) {
				nativeCommunication.callNativeMethod("tabbar://hideTabBar?");

			},
			onCancel : function(valueText, inst) {
				close = true;
				//nativeCommunication.callNativeMethod("tabbar://logout?");

			},
			onClose : function(valueText, inst) {

				if(!close) {
					//nativeCommunication.callNativeMethod("tabbar://logout?");
					return false;
				} else {
					if(inst.getDate() > (new Date())) {
						inst.setDate(validDate);
					}

					nativeCommunication.callNativeMethod("tabbar://showTabBar?");

					return true;
				}
			},
			onSelect : function(valueText, inst) {
				if(inst.getDate() > (new Date())) {
					close = false;

					mHealth.util.customAlert(mHealth.Section.dateOutOfRange, '');

				} else {
					validDate = inst.getDate();
					close = true;
				}

			}
		});
		$('#add_condition').trigger('create');
	},
	/**
	 * Name    : processConditionData
	 * Purpose : Method to set the condition data to condition model
	 * Params  : responseText - Response from the server
	 * Return  : --
	 **/
	processConditionData : function(responseText) {
		mHealth.models.ConditionModel.customFromJSON(responseText);
	},
	/**
	 * Name    : saveSubCondition
	 * Purpose : Method to set the search condition data to search condition model
	 * Params  : response - Response from the server
	 * Return  : --
	 **/
	saveSubCondition : function(response) {
		mHealth.models.SearchConditionModel.customFromJSON(response);
	},
	/**
	 * Name    : init
	 * Purpose : Method to initialise the controller
	 * Params  : --
	 * Return  : --
	 **/
	init : function() {
	}
});

mHealth.controllers.MedicalHistoryController.extend({

	flagShow : false, // Property that decides whether to hide or show the sub condition field in addcondition.html.

	prev : ''         // Property that contains the previous page of addcondition.html

});
