mHealth.models.MyaFeaturesModel=Spine.Model.sub();
mHealth.models.MyaFeaturesModel.configure("MyaFeaturesModel","tabs","homeFeatures","features","nurseCall");


mHealth.models.TabsModel = Spine.Model.sub();
mHealth.models.TabsModel.configure("TabsModel","tab");

mHealth.models.TabModel = Spine.Model.sub();
mHealth.models.TabModel.configure("TabModel","id");

mHealth.models.HomeFeaturesModel=Spine.Model.sub();
mHealth.models.HomeFeaturesModel.configure("HomeFeaturesModel","feature");


mHealth.models.FeatureModel = Spine.Model.sub();
mHealth.models.FeatureModel.configure("FeatureModel","id");

mHealth.models.FeaturesModel=Spine.Model.sub();
mHealth.models.FeaturesModel.configure("FeaturesModel","featureGroup");

mHealth.models.NurseCallModel=Spine.Model.sub();
mHealth.models.NurseCallModel.configure("NurseCallModel","promptText","phone");
  
mHealth.models.FeatureGroupModel=Spine.Model.sub();
mHealth.models.FeatureGroupModel.configure("FeatureGroupModel","groupId","feature");

var features=[
		{
			id : "profile",
			text:'Profile',
			imgsrc :'Profile',
			targetId:'showProfile'
		},
		{
			id : "tracker-glucose",
			text:'Glucose',
			imgsrc :'Glucose',
			targetId:'showTrackerPage'
		},
		{
			id : "med-history",
			text: 'Medical History',
			imgsrc :'History',
			targetId:'showHistory'
		},
		{
			id : "challenges",
			text:'Challenges',
			imgsrc :'Challenges_Home_Link',
			targetId:'challengesShortCut'
		},
		{
			id : "call-nurse",
			text:'Call Nurse',
			imgsrc :'Call_Nurse',
			targetId:'tel://8662017919'
		}
		];


mHealth.models.HomeFeaturesModel.customFromJSON({'feature':features});