/**
 *Controller : LoginController
 *Controller to do login functionality.
 **/
mHealth.controllers.LoginController = Spine.Controller.sub({
	el : 'body',
	quesType : false,
	quesManage : false,
	quesDevice : false,
	environment : null,
	message : null,
	count : 0,
	progressValue : 0,


	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		//'click #loginbutton' : 'doLogin',
		'submit #login-form' : 'doLogin',
		'click #sendMail' : 'sendEmail',
		'pagebeforeshow #showassessment' : 'showMiniAssessment',
		'pagebeforeshow #home' : 'showHomePage',
		'pagebeforeshow #loginPage' : 'setPrevLogin',
		'click #assessmentBtn' : 'submitAssessment',
		'change .selectValue' : 'setProgressBar',
		'click #skipBtn' : 'showHomePage',
		'pagebeforeshow #loginPage' : 'showSplashMessage',
		'click #contactEmail' : 'sendContactMail',
		'click #mailToCreig' : 'mailToCreig'

	},
	init : function() {

	},
	/**
	 *Name    : mailToCreig
	 *Purpose : Method to Send email to the Craig.Apolinsky of the Alere 
	 *Params  : --
	 *Return  : --
	 **/
	mailToCreig : function()
	{
				mHealth.util.sendEmail('Craig.Apolinsky@alere.com', '');
		
	},
	/**
	 *Name    : sendContactMail
	 *Purpose : Method to Send email to the corp feedback of the Alere 
	 *Params  : --
	 *Return  : --
	 **/
	sendContactMail : function()
	{
		mHealth.util.sendEmail('Corpfeedback@alere.com', '');
	},
	
	/**
	 *Name    : showSplashMessage
	 *Purpose : Method to render Mini assessment screen
	 *Params  : --
	 *Return  : --
	 **/
	showSplashMessage : function() {
		$('#username').val(mHealth.util.participantEmail);
		var currentPageURL = $('div[id = "loginPage"]').attr('data-url');
		var splashMessage = mHealth.util.getParameterByName('splashMessage', currentPageURL);
		$('#errorMessage').html(_.template($('#splash').html(), {
			splashMessage : splashMessage
		}));
		$('#errorMessage').trigger('create');
	},
	/**
	 *Name   : sendEmail
	 *Purpose: Method to send email.
	 *Params : --
	 *Return : --
	 **/
	setPrevLogin : function() {
		var rememberMe = mHealth.models.RememberMeModel.first();
		if(rememberMe != undefined) {
			$('#username').val(rememberMe.username);
		}
	},
	/**
	 *Name   : sendEmail
	 *Purpose: Method to send email.
	 *Params : --
	 *Return : --
	 **/
	sendEmail : function() {
		mHealth.util.sendEmail(mHealth.SettingsLogin.email, mHealth.SettingsLogin.emailTitle);
	},
	/**
	 *Name   : loginSuccess
	 *Purpose: Success callback to authenticate user.
	 *Params : output - response from the server
	 *Return : --
	 **/
	loginSuccess : function(output) {

		this.progressValue = 0;				
		mHealth.models.RememberMeModel.destroyAll();
		var rememberMe = new mHealth.models.RememberMeModel({
			"username" : $('#username').val()
		});
		rememberMe.save();
		var body = mHealth.recommendation.RecommendationMapper("", "", 1021);
		this.proxy(this.service.getResponse(mHealth.env.message_get_url, this.proxy(this.participantSuccess), this.proxy(this.loginFailure), false));
		this.proxy(this.service.postRequest(mHealth.env.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.loginFailure), false));
		var body = mHealth.recommendation.RecommendationMapper("", "", "1003");
		this.proxy(this.service.postRequest(mHealth.env.recommendation_json_url, body, mHealth.ActivityControllerObject.setActivityData, "", false));

		var URL = mHealth.env.healthdata_url + 'A1c' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'Bloodglucose' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'Weight' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'BMI' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'BPS' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'LDL' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'HDL' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'Cholesterol' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'Triglycerides' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'RetinalExam' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'FootSelfExam' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'FootExam' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		URL = mHealth.env.healthdata_url + 'MAU' + "?maxdays=45";
		this.proxy(this.service.getResponse(URL, mHealth.HealthDataControllerObject.setHealthData, this.proxy(this.loginFailure), false));
		var challenges = mHealth.recommendation.ChallengeMapper("20110101T141339.000 GMT", "20120101T141339.000", "");
		
		this.proxy(this.service.getResponse(mHealth.env.challenge_json_url+"[535]", mHealth.ActivityControllerObject.challengeSuccess, this.proxy(this.loginFailure), true));

	},
	/**
	 * Name    : participantSuccess
	 * Purpose : Success callback for getting participant data.
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	participantSuccess : function(output) {
		var response = output.responseText;
		mHealth.models.ParticipantModel.customFromJSON(response);
		var participantData = mHealth.models.ParticipantModel.first();
		var message = participantData.contentBody;
		this.proxy(this.showWelcomeMsg(message));
		this.proxy(this.showWelcomeMsg(message));
		this.showProgress(98);
	},
	/**
	 *Name   : loginFailure
	 *Purpose: Failure callback to authenticate user.
	 *Params : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server.
	 *Return : Displays error message.
	 **/
	loginFailure : function(errorThrown) {
		alert(' login failure');
		var splashMessage = null;
		if(errorThrown == mHealth.SettingsController.timeOut) {
			splashMessage = mHealth.SettingsController.errTimeout;
		} else if(errorThrown == mHealth.SettingsController.unauthorized) {
			splashMessage = mHealth.SettingsController.msgBadLogin;
		} else {
			splashMessage = mHealth.SettingsController.msgErrorCommunication;
		}
		$.mobile.changePage("login.html", {
			data : {
				splashMessage : splashMessage
			}
		});

	},
	/**
	 *Name   : doLogin
	 *Purpose: Method to encode user credential to base64 encoding.
	 *Params : --
	 *Return : --
	 **/
	doLogin : function() {
		this.progressValue = 0;	
		var username = $('#username').val();
		var password = $('#password').val();

		if((username != '') && (password != '')) {
			$.mobile.changePage("../../rootview/view/wait.html");
			environment = $('select#server option:selected').val();
			mHealth.util.setEnvironment(environment);
			mHealth.util.participantEmail = username;
			var credentials = $.base64Encode(username + ":" + password);
			this.service.getToken(mHealth.env.authtoken_get_url, credentials, this.proxy(this.loginSuccess), this.proxy(this.loginFailure));
		} else {
			$('#splash_message').show();
			$('#splash_message').html(mHealth.Login.msgEmptyField);
		}

	},
	/**
	 *Name   : recommendationSuccess
	 *Purpose: Success callback for getting home recommendation type.
	 *Params : output - response from the server.
	 *Return : --
	 **/

	recommendationSuccess : function(output) {
		this.showProgress(50);	
		var response = output.responseText;

		var recommandationData = JSON.parse(response);

		var viewData = JSON.stringify(recommandationData.View);

		mHealth.models.ViewModel.customFromJSON(viewData);

		var viewResponse = mHealth.models.ViewModel.findByAttribute("target", "Diabetes Mini Assessment");
/* comment for mini assessment to show */	
		if(viewResponse.status != "2") {
			/* comment for mini assessment to show */					
			this.proxy(this.service.getResponse(mHealth.env.medicaldevices_url, this.proxy(this.medicalSuccess), this.proxy(this.loginFailure), false));
			var assessment = mHealth.recommendation.AssessmentMapper("20120101T141339.000 GMT", "20120101T141339.000 GMT", "");
			this.proxy(this.service.postRequest(mHealth.env.assessment_json_url, assessment, this.proxy(this.assessmentSuccess), this.proxy(this.loginFailure), true));
/* comment for mini assessment to show */	
		} else {
			if(viewResponse.status == "0") {
				this.eventUpdate("1");
			} else if(viewResponse.status == "10") {
				this.eventUpdate("11");
			}			
			$.mobile.changePage("../../home/view/home.html");
		}
		/* comment for mini assessment to show */	

	},
	/**
	 *Name   : medicalSuccess
	 *Purpose: Method on success of medical devices
	 *Return : --
	 **/
	medicalSuccess : function(output) {
		var response = output.responseText;
		devices = response;
		mHealth.models.MedicalDevicesModel.customFromJSON(response);		
	},
	/**
	 *Name : assessmentSuccess
	 *Purpose: After getting the response from the assessment Service, the functon will parse the participant,assessment,section,question,answer and participantanswer
	 Set the value in the respective model.
	 *Params: output
	 *Return: null
	 **/
	assessmentSuccess : function(output) {		
		var response, sectionData, participantData, assessmentData, questionData, answerData, participantAnswerData;
		response = output.responseText;
		assessmentsData = JSON.parse(response);
		assessmentData = JSON.stringify(assessmentsData.Assessment);
		participantData = JSON.stringify(assessmentsData.ParticipantAnswer);
		sectionData = assessmentsData.Section;
		questionData = assessmentsData.Question;
		answerData = assessmentsData.Answer;
		mHealth.models.AssessmentModel.customFromJSON(assessmentData);
		mHealth.models.ParticipantAnswerModel.customFromJSON(participantData);
		this.getMiniAssessmentData(assessmentsData);
	},
	/**
	 *Name   : getMiniAssessmentData
	 *Purpose: Method to fetch the questions & answers for mini assessment
	 *Params : --
	 *Return : mini assessment questions & answers
	 **/

	getMiniAssessmentData : function(assessmentsData) {
		assessData = mHealth.models.AssessmentModel.findByAttribute("assessmentId", "Diabetes Mini Assessment");
		assessData.section = [];
		assessData.section.question = [];
		assessData.section.question.answer = [];
		assessmentsData.Section.map(function(section) {
			if(section.assessmentId == assessData.assessmentId) {
				assessData.section.push(mHealth.models.SectionModel.fromJSON(section));
				assessData.save();
			}
		});
		assessData.section.map(function(sectionmodel) {
			sectionmodel.question = [];
			assessmentsData.Question.map(function(question) {
				if(question.assessmentId === sectionmodel.assessmentId && question.sectionId === sectionmodel.sectionId) {
					sectionmodel.question.push(mHealth.models.QuestionModel.fromJSON(question));
					assessData.save();
				}
			});
		});
		assessData.section[0].question.map(function(question) {
			question.answer = [];
			assessmentsData.Answer.map(function(answer) {
				if(answer.assessmentId === question.assessmentId && answer.sectionId === question.sectionId && answer.questionId === question.questionId) {
					question.answer.push(mHealth.models.AnswerModel.fromJSON(answer));
					assessData.save();
				}
			});
		});
		outputHTML = mHealth.assessment.get_dropdown_html(assessData);
		mHealth.util.hideMask();
		$.mobile.changePage("../../rootview/view/showassessment.html", {
			data : {
				loginWorkflow : "true"
			}
		});
	},
	/**
	 *Name    : showMiniAssessment
	 *Purpose : Method to render Mini assessment screen
	 *Params  : --
	 *Return  : --
	 **/
	showWelcomeMsg : function(message) {
		var currentPageURL = $('div[id = "welcomeMsg"]').attr('data-url');
		//var message = mHealth.util.getParameterByName('message', currentPageURL);
		$('#showwelcomecontent').html(_.template($('#showwelcometemplate').html(), {
			message : message
		}));
		$('#showwelcomecontent').trigger('create');
	},
	/**
	 *Name    : showMiniAssessment
	 *Purpose : Method to render Mini assessment screen
	 *Params  : --
	 *Return  : --
	 **/
	showMiniAssessment : function() {
		var currentPageURL = $('div[id = "showassessment"]').attr('data-url');
		var loginWorkflow = mHealth.util.getParameterByName('loginWorkflow', currentPageURL);
		$('#showassessmentcontent').html(_.template($('#showassessmenttemplate').html(), {
			loginWorkflow : loginWorkflow
		}));
		$('#showassessmentcontent').trigger('create');
		$('#showassessmentcontent1').html(_.template($('#showassessmenttemplate1').html(), {
			loginWorkflow : loginWorkflow
		}));
		$('#showassessmentcontent1').trigger('create');
		$('#output').append(outputHTML);
		$('#output').trigger('create');
	},
	/**
	 *Name   : showHomePage
	 *Purpose: Method to call native bar on login
	 *Params : --
	 *Return : --
	 **/
	showHomePage : function() {
		mHealth.util.callNativeBar();
	},
	/**
	 *Name   : submitAssessment
	 *Purpose: Method to submit mini assessment
	 *Params : --
	 *Return : --
	 **/
	submitAssessment : function() {
		if(this.validateParticipantAnswer()) {
			$.mobile.changePage("../../home/view/home.html");
			var oForm = document.forms["assessmentform"];
			var questions = oForm.elements["form[dropdown]"];
			var participantdatas = [];
			var medicalDevices = JSON.parse(devices);
			for( i = 0; i < questions.length; i++) {
				var questionId = document.getElementById('questionId[' + i + ']').value;
				var setQuestionId = questionId.replace(/\{|\}/gi, '');
				assessData.section[0].question[i].answer.map(function(answer) {
					if(setQuestionId === answer.answerId) {
						mHealth.controllers.LoginController.setMiniAssessmentData(answer);
					} else {
						medicalDevices.map(function(device) {
							if(setQuestionId === device.sku) {
								mHealth.controllers.LoginController.setMiniAssessmentData(answer);
							}
						});
					}
				});
				if(i === questions.length - 1) {
					this.eventUpdate("2");
				}
			}
		}
	},
	/**
	 *Name   : eventUpdate
	 *Purpose: Method on update event
	 *Params : XHR object
	 *Return : --
	 **/
	eventUpdate : function(status) {
		var viewData = mHealth.models.ViewModel.all();
		var viewResponse = mHealth.models.ViewModel.findByAttribute("target", "Diabetes Mini Assessment");
		var updatedDate = (new Date()).format('yyyymmdd"T"HHMMss".000 GMT"');
		var body = mHealth.recommendation.EventMapper(viewResponse.activityId, status, updatedDate);
		this.proxy(this.service.postRequest(mHealth.env.event_json_url, body, this.proxy(this.eventSuccess), this.proxy(this.eventFailure), true));

	},
	/**
	 *Name   : recommendationPostFailure
	 *Purpose: Method on failure of Recommendation status
	 *Params : XHR object
	 *Return : --
	 **/
	eventFailure : function(jqXHR, textStatus, errorThrown) {
		$.mobile.changePage("../../rootview/view/showassessment.html");
	},
	/**
	 *Name   : recommendationPostFailure
	 *Purpose: Method on success of Recommendation status
	 *Params : Response
	 *Return : --
	 **/
	eventSuccess : function(output) {
		//mHealth.util.hideMask();
	},
	/**
	 *Name   : setProgressBar
	 *Purpose: Method to call progress bar
	 *Params : --
	 *Return : --
	 **/
	setProgressBar : function(e) {
		var curr = $(e.target).attr("id");
		var currQ;
		if(curr == "questionId[0]") {
			if(!this.quesType) {
				if(document.getElementById("questionId[0]").value != "default") {
					this.count++;
					this.quesType = true;
				}
			} else {
				if(document.getElementById("questionId[0]").value == "default") {
					this.count--;
					this.quesType = false;
				}
			}
		} else if(curr == "questionId[1]") {
			if(!this.quesManage) {
				if(document.getElementById("questionId[1]").value != "default") {
					this.count++;
					this.quesManage = true;
				}
			} else {
				if(document.getElementById("questionId[1]").value == "default") {
					this.count--;
					this.quesManage = false;
				}
			}
		} else if(curr == "questionId[2]") {
			if(!this.quesDevice) {
				if(document.getElementById("questionId[2]").value != "default") {
					this.count++;
					this.quesDevice = true;
				}
			} else {
				if(document.getElementById("questionId[2]").value == "default") {
					this.count--;
					this.quesDevice = false;
				}
			}

		}
		this.updateProgressBar(this.count);
	},
	/**
	 *Name   : updateProgressBar
	 *Purpose: Method to update progress bar
	 *Params : Number of question
	 *Return : --
	 **/
	updateProgressBar : function(numOfQues) {
		var numberQuestions = parseInt(numOfQues, 10);
		var numberDirtyQuestions = 3;
		var percent = (numberQuestions / numberDirtyQuestions) * 100;
		$('div.progress-bar').css('width', percent + '%');
		$('div.progress-bar-text').text(percent.toFixed(0) + '%');
	},
	/**
	 *Name   : validateParticipantAnswer
	 *Purpose: Method to validate Participant Answer
	 *Params : Number of question
	 *Return : --
	 **/
	validateParticipantAnswer : function() {
		var question1 = document.getElementById("questionId[0]").value;
		var question2 = document.getElementById("questionId[1]").value;
		var question3 = document.getElementById("questionId[2]").value;
		if(question1 == "default" && question2 == "default" && question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidAssessment, "mHealth");
			return false;
		}
		if(question1 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidFirstQuesAssessment, "mHealth");
			return false;
		}
		if(question2 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidSecondQuesAssessment, "mHealth");
			return false;
		}
		if(question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidThirdQuesAssessment, "mHealth");
			return false;
		}
		return true;
	},
	/**
	 *Name   : showProgress
	 *Purpose: Method to show progress bar on login
	 *Params : --
	 *Return : --
	 **/
	showProgress : function(progressVal) {
		this.progressValue = this.progressValue + progressVal;
		mHealth.util.animateProgress(this.progressValue, function() {
		});
		$('#progress_bar').show();
	}
});

mHealth.controllers.LoginController.extend({
	/**
	 *Name   : setMiniAssessmentData
	 *Purpose: Method to set the partcipant model and save the data
	 *Params : Response
	 *Return : --
	 **/
	setMiniAssessmentData : function(response) {
		var requestData = [{
			"answerId" : response.answerId,
			"answerValue1" : response.theAnswer,
			"assessmentId" : response.assessmentId,
			"createTimestamp" : response.createTimestamp,
			"entryType" : response.entryType,
			"language" : response.language,
			"origin" : "Mobile",
			"questionId" : response.questionId,
			"recordingTimestamp" : (new Date()).format('yyyymmdd'),
			"sectionId" : response.sectionId,
			"updateTimestamp" : (new Date()).format('yyyymmdd"T"HHMMss".000 GMT"')
		}];

		var body = JSON.stringify(requestData);
		var data = JSON.parse(body);
		var service = mHealth.util.RemoteServiceProxy.getInstance();
		var reqData = mHealth.recommendation.AssessmentMapper("20120101T141339.000 GMT", "20120101T141339.000 GMT", data);
		service.postRequest(mHealth.env.assessment_json_url, reqData, mHealth.controllers.LoginController.participantAnswerSuccess, mHealth.controllers.LoginController.participantAnswerFailure, false);
	},
	/**
	 *Name   : participantAnswerSuccess
	 *Purpose: Method on success on Participant answer submit
	 *Params : Response
	 *Return : --
	 **/
	participantAnswerSuccess : function(output) {
		// mHealth.util.hideMask();
		// $.mobile.changePage("../../home/view/home.html");
	},
	/**
	 *Name   : participantAnswerFailure
	 *Purpose: Method on failure on Participant answer submit
	 *Params : Response
	 *Return : --
	 **/
	participantAnswerFailure : function(jqXHR, textStatus, errorThrown) {
		// mHealth.util.hideMask();
		$.mobile.changePage("../../rootview/view/showassessment.html");
	}
});
