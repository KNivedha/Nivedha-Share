//
//  TabBar.m
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TabBar.h"
#import "AlereAppDelegate.h"
#import "TabBarController.h"
#import "AlereViewController.h"

@implementation TabBar
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
     AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    if ([action isEqualToString:@"login"] )  
    {
         app.viewController.baseTabBar.hidden=NO;
        UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:0];
        app.viewController.baseTabBar.selectedItem=homeTab;
       
    }

   else if ([action isEqualToString:@"logout"] )
    {
        NSLog(@"logout in viewcontroler");
        AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
       
           app.viewController.baseTabBar.hidden=YES;  
    }
		else if ([action isEqualToString:@"loadHome"] )
   {
       UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:0];
       app.viewController.baseTabBar.selectedItem=homeTab;
   }
   else if ([action isEqualToString:@"loadTrackers"] )
   {
       UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:3];
       app.viewController.baseTabBar.selectedItem=homeTab;
   }
	 else if ([action isEqualToString:@"loadActivities"] )
   {
       UITabBarItem *homeTab=[[app.viewController.baseTabBar items]objectAtIndex:2];
       app.viewController.baseTabBar.selectedItem=homeTab;
   }
	 else if ([action isEqualToString:@"addMask"] )
   {
//       app.viewController.baseTabBar.userInteractionEnabled=NO;
//			 app.viewController.webView.userInteractionEnabled=NO;
   }
	 else if ([action isEqualToString:@"removeMask"] )
   {
//           app.viewController.baseTabBar.userInteractionEnabled=YES;
//					 	 app.viewController.webView.userInteractionEnabled=YES;
   }

} 
//UIDevice* myDevice=[UIDevice currentDevice];
//w[myDevice beginGeneratingDeviceOrientationNotifications];
@end
