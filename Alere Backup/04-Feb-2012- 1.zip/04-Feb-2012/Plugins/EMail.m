//
//  EMail.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "EMail.h"

@implementation EMail
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    NSArray* keys=[parameters allKeys];
    NSLog(@"keys : %@",keys);
    NSString* toAddress=[parameters objectForKey:@"mailto"];
    
    NSString* subject=[parameters objectForKey:@"subject"];
    NSString* urlString=[NSString stringWithFormat:@"mailto:?to=%@&subject=%@",toAddress,subject];
		urlString=[urlString stringByAddingPercentEscapesUsingEncoding:NSStringEncodingConversionAllowLossy];
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlString]];

}

@end
