/**  
  * Assessment UI generator
  **/
mHealth.assessment = {

/**
  * Name    : createRecommendationRequestJSON
  * Purpose : Method to create request body for recommendation Service.
  * Params  : responseType -  recommendation type
  * Returns : bodyContent
  **/
	get_dropdown_html : function(data) {			
			
		var ParticipantAnswer;			
			answers=[];
			disabled = false;
			id = "";	
			var j = 0;		
			data.section[ 0].question.map(function(question){	
				data.section[0].question[j].answer.map(function(answer) {
					if(mHealth.models.ParticipantAnswerModel.exists(answer)) {
						disabled = true;
						id = answer.answerId;						
					}
				});
			 });
			instance_outputHTML ='';
			instance_outputHTML += "<div data-role='collapsible-set'>";	
			var i = 0;	
			var j =0;
							
				if(!disabled) {
					data.section[0].question.map(function(question){	
						answers=[];					
						instance_outputHTML += "<div data-role='fieldcontain'>";
						instance_outputHTML += "<div>";
						instance_outputHTML += "<div data-role='collapsible' data-content-theme='c' ><h1>"+question.theQuestion+"</h1>";		
						instance_outputHTML += "<p>";						
						instance_outputHTML += "<select id='questionId["+j+"]' name='form[dropdown]' class='selectValue'>";
						instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">Please Select One</option>";								
						data.section[0].question[i].answer.map(function(answer) {																														
								if(question.theQuestion == "What glucometer do you predominantly use?"){									
									var medicalDevices = JSON.parse(devices);									
									medicalDevices.map(function(device){										
										instance_outputHTML += "<option name ='form[dropdown]' value='{"+device.sku+"}'>";
									    instance_outputHTML += device.description;
									    instance_outputHTML += "</option>"	;
								    })	
								}else{
									instance_outputHTML += "<option name ='form[dropdown]' value='{"+answer.answerOptionText+"}'>";
									instance_outputHTML += answer.answerOptionText;
									instance_outputHTML += "</option>";	
							    }
							    answers.push(answer);																				
						});
						//instance_outputHTML += "<input type='hidden' name='answerObject["+i+"]' id='answerObject["+i+"]' value='{"+answers+"}' >"	;							
						instance_outputHTML += "</select>";
						instance_outputHTML += "</p>";	
						instance_outputHTML += "</div>";
						instance_outputHTML += "</div>";
						instance_outputHTML += "</div>";
						i++;
						j++;
					});
				}
			   else if(disabled) {
					data.section[ 0].question.map(function(question){	 	
					 	instance_outputHTML += "<div data-role='fieldcontain'>";
					 	instance_outputHTML += "<label for='{question.questionId}' class='select'><font color='white'>"+question.theQuestion+"</font></label>";
						instance_outputHTML += "<select   id='{"+question.questionId+"}' name='form[dropdown]'> disabled";	
						data.section[0].question[i].answer.map(function(answer) {		
							if(answer.answerId == id) {
								instance_outputHTML += "<option selected='yes' ";		
							} else if(answer.answerId != id) {
								instance_outputHTML += "<option ";		
							}
							instance_outputHTML += "id='#{answer.answerId}' value='#{answer.theAnswer}'>";
							instance_outputHTML += answer.theAnswer.to_s;
							instance_outputHTML += "</option>";
			
						});
						instance_outputHTML += "</select>";
						instance_outputHTML += "</div>";
						i++;
					});
				}
				
			instance_outputHTML += "</div>";	
			return instance_outputHTML;
	}
};