/**
 * Native Functions
 **/

/**
 * Name    : setCalendarEvent
 * Purpose : Method to call the native calendar
 * Params  : Start Date, End Date, Title
 * Returns : dateString
 **/
mHealth.util.callCalendar = function(title, sDate, eDate) {
	nativeCommunication.callNativeMethod("cal://setEvent?eventTitle=" + title + "&startDate=" + sDate + "&endDate=" + eDate);
};
/**
 * Name   : sendEmail
 * Purpose: Method to send email.
 * Params : --
 * Return : --
 **/
mHealth.util.sendEmail = function(to, toCopy, subject) {
	nativeCommunication.callNativeMethod("email://sendEmail?mailto=" + to + "&cc=" + toCopy + "&subject=" + subject);
	$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
};
/**
 * Name   : callNativeBarEvent
 * Purpose: Method to call native bars on login
 * Params : --
 * Return : --
 **/
mHealth.util.callNativeBar = function() {

	var tabs = "tab0=Home&tab1=Messages";
	var count = 2;
	//check if challenges is configured
	var hasChallenge = mHealth.models.FeatureGroupModel.findByAttribute("groupId", "standard");
	var length=hasChallenge.feature.length
	for(var i=0;i<=length;i++){
		if(hasChallenge.feature[i].id=='challenges')
		{
			tabs=tabs+'&tab'+count+'=Challenges';
			count=count+1;
			break;
		}
	}
	//check if trackers length is greater than 0
	var hasTracker = mHealth.models.FeatureGroupModel.findByAttribute("groupId", "trackers");
	var length=hasTracker.feature.length
		if(length >0)
		{
			tabs=tabs+'&tab'+count+'=Trackers';
						count=count+1;
		}
		tabs=tabs+'&tab'+count+'=Settings';
		
	    nativeCommunication.callNativeMethod("tabbar://login?"+tabs);
};
/**
 * Name   : removeNativeBarEvent
 * Purpose: Method to remove native bars on logout
 * Params : --
 * Return : --
 **/
mHealth.util.removeNativeBar = function() {
	nativeCommunication.callNativeMethod("tabbar://logout?");
};
/**
 * Name   : getDeviceFeatures
 * Purpose: Method to get the device feature like version,device id,...
 * Params : --
 * Return : Device features like version,device id,...
 **/
mHealth.util.getDeviceFeatures = function() {
	nativeCommunication.callNativeMethod("about://getdevicefeatues?");
};

mHealth.util.loadTrackerbar = function() {
	location.href = "tabbar://Trackers?";
}
/**
 * Name   : loadHomeBar
 * Purpose: Method to hightlight home tab
 * Params : --
 * Return : --
 **/
mHealth.util.loadHomeBar = function() {
	nativeCommunication.callNativeMethod("tabbar://Home?");
};

mHealth.util.loadChallengesBar = function() {
	nativeCommunication.callNativeMethod("tabbar://Challenges?");
};
/**
 * Name   : loadMessageBar
 * Purpose: Method to hightlight Message tab
 * Params : --
 * Return : --
 **/
mHealth.util.loadMessageBar = function() {
	nativeCommunication.callNativeMethod("tabbar://Messages?");
};
/**
 *Call back of native functions
 **/

/**
 * Name   : loadHome
 * Purpose: Callback method of native tabbar
 * Params : --
 * Return : --
 **/
loadHome = function() {
	/*
	 * TFS: 43143
	 * Description:	Condition: 'Search result box' arised on writing in condition field is displayed even after navigation
	 */
	$("#conditionName").autocomplete("close").focus();
	$.mobile.changePage("../../home/view/home.html");
};
/**
 * Name   : loadActivities
 * Purpose: Method to call Activities web view on clicking the activities tab
 * Params : --
 * Return : --
 **/
loadActivities = function() {
	//mHealth.controllers.ActivityController.trigger('getservice');
	//  $.mobile.showPageLoadingMsg();
	/*
	 * TFS: 43143
	 * Description:	Condition: 'Search result box' arised on writing in condition field is displayed even after navigation
	 */

	$("#conditionName").autocomplete("close").focus();
	mHealth.util.loadChallengesBar();
	mHealth.ActivityControllerObject.getActivity();
	// $.mobile.changePage("../../activities/view/showactivity.html");

};
/**
 * Name   : loadMessages
 * Purpose: Method to call Messages web view on clicking the messages tab
 * Params : --
 * Return : --
 **/
loadMessages = function() {
	/*
	 * TFS: 43143
	 * Description:	Condition: 'Search result box' arised on writing in condition field is displayed even after navigation
	 */
	$("#conditionName").autocomplete("close").focus();
	//$.mobile.changePage("../../messages/view/showmessage.html");
	mHealth.MessageControllerObject.loadMessageTabBar();
};
/**
 * Name   : loadTrackers
 * Purpose: Method to call trackers web view on clicking the trackers tab
 * Params : --
 * Return : --
 **/
loadTrackers = function() {
	/*
	 * TFS: 43143
	 * Description:	Condition: 'Search result box' arised on writing in condition field is displayed even after navigation
	 */
	$("#conditionName").autocomplete("close").focus();
	mHealth.HealthDataControllerObject.getTrackers();
	//$.mobile.changePage("../../trackers/view/showtracker.html");
};
sessionExpired = function() {

	mHealth.util.customAlert(mHealth.SettingsController.sessionTimeoutLogout, function() {
		$('.dw').detach();
		$('.dwo').detach();
		$('.ui-alert-wallpaper').detach();
		$('#loginPage').detach();
		mHealth.util.removeNativeBar();
		mHealth.MessageControllerObject.tabbarloaded = false;
		mHealth.models.ConditionModel.destroyAll();
		mHealth.models.MessageModel.destroyAll();
		mHealth.models.MedicationModel.destroyAll();
		mHealth.models.ParticipantModel.destroyAll();
		mHealth.models.HealthDataModel.destroyAll();
		mHealth.models.ChallengeResponseModel.destroyAll();
		mHealth.models.QuestionResponsesModel.destroyAll();
		$.mobile.changePage("../../rootview/view/login.html", {
			data : {
				splashMessage : mHealth.SettingsController.sessionTimeoutLogout
			}
		});
	});
};
/**
 * Name   : currentOrientationGraph
 * Purpose:
 * Params : --
 * Return : --
 **/
currentOrientationGraph = function(orientation) {
	if(mHealth.GraphControllerObject.currentView=='Day' || mHealth.GraphControllerObject.healthDataTracker=='Blood Glucose')
	{
		if(orientation == 'portrait') {
			mHealth.GraphControllerObject.plotOptions.xaxis.labelWidth = 0;
		} else if(orientation == 'landscape') {
			mHealth.GraphControllerObject.plotOptions.xaxis.labelWidth = -25;
		}
	}
};
/**
 * Name   : currentOrientation
 * Purpose:
 * Params : --
 * Return : --
 **/
currentOrientation = function(orientation) {

	if($('body').children().is('#tandcPage') == true) {

		mHealth.util.tcScroll.scroll.stop();
		$('#tandcPage').css({
			'height' : '100%'
		});

	} else {

		$('.ui-page-active').not('#show_journal').css({
			'height' : document.height
		});

		if($('.ui-page-active').attr('id') == "show_journal") {

			$('#show_journal').css({
				'height' : '100%'
			});
		}

	}

	if(orientation == 'portrait') {

		if($('body').children().is('#tandcPage') == true) {

			$('#tc').height(7400);
			mHealth.util.tcScroll.refresh();

		}
		if($('.ui-page-active').attr('id') == "show_journal") {

			$('#journalScroll').css({
				'height' : '81%'
			});
			mHealth.util.journalScroll.refresh();
		}

		$('.alertable').css({
			'height' : '460px',
			'width' : '320px',
			'top' : document.body.scrollTop + 'px'
		});
		$('.back_container').css({
			'height' : '100%',
			'width' : '100%'
		});
		$('.ui-alert-wallpaper').css({
			'height' : '100%',
			'width' : '100%'
		});

	}

	if(orientation == 'landscape') {
		if($('body').children().is('#tandcPage') == true) {
			$('#tc').height(5240);
			mHealth.util.tcScroll.refresh();

		}
		if($('.ui-page-active').attr('id') == "show_journal") {

			$('#journalScroll').css({
				'height' : '46.5%'
			});
			mHealth.util.journalScroll.refresh();
		}
		$('.alertable').css({
			'height' : '300px',
			'width' : '480px',
			'top' : document.body.scrollTop + 'px'
		});
		$('.back_container').css({
			'height' : '100%',
			'width' : '100%'
		});
		$('.ui-alert-wallpaper').css({
			'height' : '100%',
			'width' : '100%'
		});

	}
	if($('.ui-page-active').attr('id') == "multiplehealthdatapage" || $('.ui-page-active').attr('id') == "singlehealthdatapage") {
		mHealth.GraphControllerObject.drawMultipleHealthDataGraph();
		$('#daybutton').click(function() {
			mHealth.GraphControllerObject.dayButtonClick();
		});
		$('#weekbutton').click(function() {
			mHealth.GraphControllerObject.weekButtonClick();
		});
		$('#monthbutton').click(function() {
			mHealth.GraphControllerObject.monthButtonClick();
		});
		$('#showLabel').click(function() {
			mHealth.GraphControllerObject.showLabels();
		});
		$('#previousbutton').click(function() {
			mHealth.GraphControllerObject.previousButton();
		});
		$('#nextbutton').click(function() {
			mHealth.GraphControllerObject.nextButton();
		});
		$('#yearbutton').click(function() {
			mHealth.GraphControllerObject.yearButtonClick();
		});
		if(mHealth.GraphControllerObject.showLabel) {
			mHealth.GraphControllerObject.showLabel = false;
			mHealth.GraphControllerObject.showLabels();
		}
	}
};
/**
 * Name   : loadSettings
 * Purpose: Method to call setings web view on clicking the settings tab
 * Params : --
 * Return : --
 **/
loadSettings = function() {
	/*
	 * TFS: 43143
	 * Description:	Condition: 'Search result box' arised on writing in condition field is displayed even after navigation
	 */

	$("#conditionName").autocomplete("close").focus();
	$.mobile.changePage("../../settings/view/index.html");
};
networkStatus = function(status) {

	mHealth.SettingsAbout.networkStatus = status;
	if(mHealth.SettingsAbout.networkStatus == 'false') {
		mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');
	}

};
