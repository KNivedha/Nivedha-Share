/**
 * Object - util
 * Utilities - Common Functions
 **/
mHealth.util = {

	version : '1.1',
	
	prevDefault : function(){
		return false;
	},
	
	tcScroll : null,
	
	journalScroll : null,

	setEnvironment : function(environment) {
		switch(environment) {
			case "dev":
				mHealth.env = mHealth.dev
				break;
			case "uat":
				mHealth.env = mHealth.uat
				break;
			case "local":
				mHealth.env = mHealth.local
				break;
			case "prod":
				mHealth.env = mHealth.prod
				break;
			case "qa":
				mHealth.env = mHealth.uat
				break;
			default:
				mHealth.env = mHealth.dev
				break;

		}
	},
	/**
	 *Name		: getFormattedDate
	 *Purpose	: formats the measurement date to be passed as a parameter for challenge post service
	 *Params	: No params
	 *Returns	: returns formatted date object
	**/
	
	getFormattedDate : function(dateSelected) {
		var dateObject = new Date(dateSelected);
		return dateObject.format('yyyymmdd');
	},
	/**
	 * Name    : parseYear
	 * Purpose : Method to get the year alone
	 * Params  : date object
	 * Returns : yyyy
	 **/
	parseYear : function(date) {
		var year = date.substring(0, 4);
		return year;
	},
	
	/**
	 * Name    : parseDateObj
	 * Purpose : Method to convert String from yyyymmdd format to a date object
	 * Params  : date Object
	 * Returns : dateString
	 **/
	parseDateObj : function(utcDate) {
		var year, mon, day,date;
		year = utcDate.substring(0, 4);
		mon = utcDate.substring(4, 6);
		day = utcDate.substring(6, 8);
		date = new Date(year, mon-1, day);
		return date;
	},
	/**
	 * Name    : parseDate
	 * Purpose : Method to convert date from weekday, mmm dd,yyyy to day mmm dd yyyy hh:mm:ss GMT (Timestandard)
	 * Params  : date in format weekday, mmm dd,yyyy Ex:Sunday,Feb 5,2012
	 * Returns : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 **/
	parseDate : function(day) {
		var date = day.split(',');
		//var dates=date[1].split(' ');
		var parseDate = date[1] + ',' + date[2];
		var dateObj = Date.parse(parseDate);
		return dateObj;
	},
	/**
	 * Name    : getCurrentDate
	 * Purpose : Method to get the current date in mm/dd/yyyy format
	 * Params  : --
	 * Returns : today
	 **/
	getCurrentDate : function() {
		var today, mm, yyyy;
		today = new Date();
		dd = today.getDate();
		mm = today.getMonth() + 1;
		yyyy = today.getFullYear();
		if(dd < 10) {
			dd = '0' + dd;
		}
		if(mm < 10) {
			mm = '0' + mm;
		}
		today = mm + '/' + dd + '/' + yyyy;
		return today;
	},
	/**
	 * Name    : getDatewithDay
	 * Purpose : Method to get the current date in Day,Month dd,yyyy format
	 * Params  : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 * Returns : date in format weekday, mmm dd,yyyy Ex:Sunday,Feb 5,2012
	 **/
	getDateWithDay : function(date) {
		var dates = date.format("dddd, mmm d, yyyy");
		return dates;
	},
	/**
	 * Name    : getDateWithMonth
	 * Purpose : Method to get the current date in Full Month Name date, Year format
	 * Params  : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 * Returns : date in format Month Name date, Year Ex:February 12, 2012
	 **/
	getDateWithMonth : function(date) {
		var endDate = date;
		var startDate = new Date(date.getTime() - 29 * 24 * 60 * 60 * 1000);
		return (startDate.format('mmm dd, yyyy') + ' - ' + endDate.format('mmm dd, yyyy'));
	},
	/**
	 * Name    : getDateWithWeek
	 * Purpose : Method to get the Week title for the graphs
	 * Params  : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 * Returns : Week Title for graph Ex:Feb 12 - Feb 19
	 **/
	getDateWithWeek : function(date) {
		var wday = date.getDay();
		// var startDate=new Date(date.getTime() - (wday * 24 * 60 * 60 * 1000));
		// var endDate = new Date(date.getTime() + ((7-wday)*24 * 60 * 60 * 1000));
		var endDate = date;
		var startDate = new Date(date.getTime() - 6 * 24 * 60 * 60 * 1000);
		return (startDate.format('mmm dd, yyyy') + ' - ' + endDate.format('mmm dd, yyyy'));
	},
	/**
	 * Name    : getYearWithMonth
	 * Purpose : Method to get the current date in Full Month name year format (January 2012)
	 * Params  : dateObject in format day mmm dd yyyy hh:mm:ss GMT (Timestandard) Ex: Sun Feb 05 2012 00:00:00 GMT +0530(IST)
	 * Returns : date in format Month name Year Ex: December 2011
	 **/
	getYearWithMonth : function(date) {
		var endDate = date;
		var startDate = new Date(date.getTime() - 364 * 24 * 60 * 60 * 1000);
		return (startDate.format('mmm yyyy') + ' - ' + endDate.format('mmm yyyy'));
	},
	/**
	 * Name    : getCurrentDay
	 * Purpose : Method to get the current day in Day,Month dd,yyyy format
	 * Params  : --
	 * Returns : date in Day,Month dd,yyyy format
	 **/
	getCurrentDay : function() {
		var currentDay = new Date();
		currentDay = this.getDateWithDay(currentDay);
		return currentDay;
	},
	/**
	 * Name    : getPrevYearDate
	 * Purpose : Method to get the previous day pegadate format
	 * Params  : --
	 * Returns : previousyeardate(today - 364 days) in pegadate format
	 **/
	getPrevYearDate : function(){
		var today=new Date();
		today= new Date(today.getFullYear(),today.getMonth(),today.getDate());
		var prevYearDate = new Date(today.getTime() - 364 * 24 * 60 * 60 * 1000)
		return prevYearDate.format(mHealth.pegadateformat);
	},
	/**
	 * Name    : getPreviousDay
	 * Purpose : Method to get the previous day in Day,Month dd,yyyy format
	 * Params  : day in format day,mmm dd,yyy
	 * Returns : previousday in format day,mmm dd,yyy
	 **/
	getPreviousDay : function(currentDay) {
	var currentDay=new Date(currentDay);
	var previousDay = new Date(currentDay.getTime() - (1 * 24 * 60 * 60 * 1000));
	previousDay= dateFormat(previousDay, "fullLongDate");
	return previousDay;
	},
	/**
	* Name    : getNextDay
	* Purpose : Method to get the Next day in Day,Month dd,yyyy format
	* Params  : day in format day,mmm dd,yyy
	* Returns : nextDay in format day,mmm dd,yyy
	**/
	getNextDay : function(currentDay) {
	var currentDay = new Date(currentDay);
	var nextDay = new Date(currentDay.getTime() + (1 * 24 * 60 * 60 * 1000));
	nextDay = dateFormat(nextDay, "fullLongDate");
	return nextDay;
	},

	
	/**
	 * Name    : getParameterByName
	 * Purpose : Method to get the query parameter values from the url
	 * Params  : name - Name of the query parameter
	 url - URL that contains the query parameters
	 * Returns : paramValue
	 **/
	getParameterByName : function(name, url) {

		var match, paramValue;
		match = RegExp('[?&]' + name + '=([^&]*)').exec(url);
		paramValue = match && decodeURIComponent(match[1].replace(/\+/g, ' '));
		return paramValue;

	},
	/**
	 * Name    : showMask
	 * Purpose : Method to show the masking layer.
	 * Params  : --
	 * Returns : --
	 **/
	showMask : function() {
		var requested_page = $('.ui-page-active').attr('id');

		var content = $('div[id=' + requested_page + ']');

		$('<div>', {
			'class' : 'ui-actionsheet-wallpaper'
		}).appendTo(content).show();

		$.mobile.showPageLoadingMsg();
		
		 nativeCommunication.callNativeMethod("tabbar://addMask?");
		

	},
	/**
	 * Name    : hideMask
	 * Purpose : Method to hide the masking layer,
	 * Params  : --
	 * Returns : --
	 **/
	hideMask : function() {

		$(':jqmData(role="page")').children('div').removeClass('ui-actionsheet-wallpaper');
		$.mobile.hidePageLoadingMsg();
		nativeCommunication.callNativeMethod("tabbar://removeMask?");

	},
	customAlert : function(message, okcallback) {

		nativeCommunication.callNativeMethod("tabbar://addMask?");
		var mobFunc = function(){
			return false;
		}
		$(document).bind('touchmove', mobFunc());
		if(okcallback === '') {
			okcallback = function() {
			};
		}
        $('input').blur();
        $('textarea').blur();
        $('select').blur();
		var height = window.innerHeight + 2;
		var top = document.body.scrollTop;
		var width = window.innerWidth;
		var messageString;

		if( typeof message === 'string') {
			messageString = message;
		} else if( typeof message === 'object') {
			messageString = message;
		} else if( typeof message === undefined) {
			messageString = 'undefined';
		} else {
			messageString = message.toString();

		}

		var alertHtml = '<div class="ui-alert-wallpaper" ><div class="back_container"></div>' + '<table class="alertable"><tr><td valign="middle" >' + '<div class="back">' + '<div class="back_top header">' + mHealth.GuiHelper.alerttitle + '</div>' + '<div class="back_mid msg">' + messageString + '</div>' + '<div class="back_mid button_container">' + '<div class="but">' + '<div class="but_left"></div>' + '<div class="but_mid">OK</div>' + '<div class="but_right"></div>' + '</div>' + '</div>' + '<div class="back_bottom"></div>' + '</div>' + '</td></tr></table>' + '</div>';

		var requested_page = $('.ui-page-active').attr('id');

		var content = $('div[id=' + requested_page + ']');

		$(alertHtml).appendTo(content).show();
		$('.alertable').css({
			'height' : height,
			'width' : width,
			'top' : top
		});
				
		$('.but_mid').click(function(e) {

			okcallback();
			$(document).unbind('touchmove', mobFunc());
			var target = e.target;
            $(target).parents('.ui-alert-wallpaper').remove();
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
			nativeCommunication.callNativeMethod("tabbar://removeMask?");
			
		});
		
		
	},
	customPrompt : function(message, noCallback, yesCallback) {
    nativeCommunication.callNativeMethod("tabbar://addMask?");

		var mobFunc = function(){
			return false;
		}
		$(document).bind('touchmove', mobFunc());
		var height = window.innerHeight + 2;
		var top = document.body.scrollTop;
		var width = window.innerWidth;
		var messageString;

		if( typeof message === 'string') {
			messageString = message;
		} else if( typeof message === 'object') {
			messageString = message;
		} else if( typeof message === undefined) {
			messageString = 'undefined';
		} else {
			messageString = message.toString();

		}
		var promptHtml = '<div class="ui-alert-wallpaper"><div class="back_container"></div>' + '<table class="alertable"><tr><td valign="middle">' + '<div class="back">' + '<div class="back_top header">' + mHealth.GuiHelper.alerttitle + '</div>' + '<div class="back_mid msg">' + messageString + '</div>' + '<div class="back_mid button_container">' + '<div class="but_ok">' + '<div class="but_left"></div>' + '<div class="but_mid">Yes</div>' + '<div class="but_right"></div>' + '</div>' + '<div class="but_cancel">' + '<div class="but_left"></div>' + '<div class="but_mid">No</div>' + '<div class="but_right"></div>' + '</div>' + '</div>' + '<div class="back_bottom"></div>' + '</div>' + '</td></tr></table>' + '</div>';

		var requested_page = $('.ui-page-active').attr('id');
		var content = $('div[id=' + requested_page + ']');
		$(promptHtml).appendTo(content).show();
		$('.alertable').css({
			'height' : height,
			'width' : width,
			'top' : top
		});				
		$('.but_ok>.but_mid').click(function(e) {
			yesCallback();
			$(document).unbind('touchmove', mobFunc());
			var target = e.target;
			$(target).parents('.ui-alert-wallpaper').remove();
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
            nativeCommunication.callNativeMethod("tabbar://removeMask?");

		});
		$('.but_cancel>.but_mid').click(function(e) {
			noCallback();
			$(document).unbind('touchmove', mobFunc());
			var target = e.target;
			$(target).parents('.ui-alert-wallpaper').remove();
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
            nativeCommunication.callNativeMethod("tabbar://removeMask?");

		});
		},
		/**
	 *Name : callNursecustomPrompt
	 *Purpose : displays custom prompt for call nurse functionality
	 *Params: message , phone number and callback functions for call and cancel buttons
	 *Returns: --
	 **/
	callNursecustomPrompt : function(message, phoneNumber, noCallback, yesCallback) {
    	nativeCommunication.callNativeMethod("tabbar://addMask?");

		var mobFunc = function(){
			return false;
		}
		$(document).bind('touchmove', mobFunc());
		var height = window.innerHeight + 2;
		var top = document.body.scrollTop;
		var width = window.innerWidth;
		var messageString;
		if(parseInt(phoneNumber)){
			phoneNumber='('+phoneNumber.substr(0,3)+') '+phoneNumber.substr(3,3)+'-'+phoneNumber.substr(6,4);
		}
		if( typeof message === 'string') {
			messageString = message;
		} else if( typeof message === 'object') {
			messageString = message;
		} else if( typeof message === undefined) {
			messageString = 'undefined';
		} else {
			messageString = message.toString();

		}
		var promptHtml = '<div class="ui-alert-wallpaper call"><div class="back_container"></div>' + '<table class="alertable"><tr><td valign="middle">' + '<div class="back">' + '<div class="back_top header">' + mHealth.GuiHelper.alerttitle + '</div>' + '<div class="back_mid msg phonenumber" style="text-decoration:none !important; color:white !important;">'+ phoneNumber+'</div>' + '<div class="back_mid msg">' + messageString + '</div>' + '<div class="back_mid button_container">' + '<div class="but_ok">' + '<div class="but_left"></div>' + '<div class="but_mid">Cancel</div>' + '<div class="but_right"></div>' + '</div>' + '<div class="but_cancel">' + '<div class="but_left"></div>' + '<div class="but_mid">Call</div>' + '<div class="but_right"></div>' + '</div>' + '</div>' + '<div class="back_bottom"></div>' + '</div>' + '</td></tr></table>' + '</div>';

		var requested_page = $('.ui-page-active').attr('id');
		var content = $('div[id=' + requested_page + ']');
		$(promptHtml).appendTo(content).show();
		$('.alertable').css({
			'height' : height,
			'width' : width,
			'top' : top
		});		
		$('.but_ok>.but_mid').click(function(e) {
			yesCallback();
			$(document).unbind('touchmove', mobFunc());
			var target = e.target;
			$(target).parents('.ui-alert-wallpaper').remove();
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
            nativeCommunication.callNativeMethod("tabbar://removeMask?");

		});
		$('.but_cancel>.but_mid').click(function(e) {
			noCallback();
			$(document).unbind('touchmove', mobFunc());
			var target = e.target;
			$(target).parents('.ui-alert-wallpaper').remove();
			$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
            nativeCommunication.callNativeMethod("tabbar://removeMask?");

		});
	},
		
	animateProgress : function(progress, callback) {
		return $('#progress_bar .ui-progress').each(function() {
			$('#progress_bar .ui-progress').animate({
				width : progress + '%'
			}, {
				duration : 2000,
				easing : 'swing',
				step : function(progress) {
					var labelEl = $('.ui-label', this), valueEl = $('.value', labelEl);
					if(Math.ceil(progress) < 0 && $('.ui-label', this).is(":visible")) {
						labelEl.hide();
					} else {
						if(labelEl.is(":hidden")) {
							labelEl.fadeIn();
						};
					}
					if(Math.ceil(progress) == 100) {
						labelEl.text('Processing 100%');
						// setTimeout(function() {
						// labelEl.fadeOut();
						// }, 1000);
					} else {
						valueEl.text(Math.ceil(progress) + '%');
					}
				},
				complete : function(scope, i, elem) {
					if(callback) {
						callback.call(this, i, elem);
					};
				}
			});
		});
	},
	/**
	 *Name : showCalendar
	 *Purpose : Show clendar page
	 *Params: --
	 *Returns: --
	 **/
	showCalendar : function() {		
		$('#startDate').scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'datetime',
			seconds : true,
			timeFormat : 'hh:ii:ss A',
			theme : 'ios',
			beforeShow : function(input, inst) {
				nativeCommunication.callNativeMethod("tabbar://hideTabBar?");
			},
			onClose : function(valueText, inst) {
				nativeCommunication.callNativeMethod("tabbar://showTabBar?");
			},
			onCancel : function(valueText, inst) {
			}
		});
		$('#endDate').scroller({
			dateFormat : 'yyyy-mm-dd',
			preset : 'datetime',
			seconds : true,
			timeFormat : 'hh:ii:ss A',
			theme : 'ios',
			beforeShow : function(input, inst) {
				nativeCommunication.callNativeMethod("tabbar://hideTabBar?");
			},
			onClose : function(valueText, inst) {
				nativeCommunication.callNativeMethod("tabbar://showTabBar?");
			},
			onCancel : function(valueText, inst) {
			}
		});
	},
	
	/**
	 *Name: getDateFormat
	 *Purpose: Format date in the yyyymmdd T HHMMss.000 GMTformat
	 *Params: Date field id
	 *Returns: returns formatted date object
	 **/
	getDateFormat : function(dateSelected) {		
		if(dateSelected != "") {
			var hour = dateSelected.substr(12, 2);
			hour = parseInt(hour, 10);
			if(dateSelected != "") {
				var hour = dateSelected.substr(11, 2);
				hour = parseInt(hour, 10);
				if(dateSelected.substr(17, 2) == "PM") {
					if(hour != 12)
						hour = hour + 12;
				} else {
					if(hour == 12)
						hour = 0;
				}
				dateObject = new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2), hour, dateSelected.substr(14, 2));
			}			
			return dateObject.format('yyyymmdd"T"HHMMss".000 GMT"');
		}
	},
	/**
	 *Name: getSortData
	 *Purpose: sorts the health data based on measurement date.
	 *Params: health data to be sorted is passed as param
	 *Returns: returns the sorted health data
	 **/
	getSortData : function(healthDataData) {
		var keys = [];
		var sortedData = [];
		for(var i in healthDataData) {
			keys[i] = [];
			keys[i][0] = healthDataData[i]["trackerRank"];
			keys[i][1] = i;
		}
		keys.sort();
		// keys.reverse();
		for(var i in keys) {
			sortedData.push(healthDataData[keys[i][1]]);
		}
		return sortedData;
	},
};
