//
//  NetworkCheck.h
//  Alere
//
//  Created by virtusa5 on 15/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DeviceDelegate.h"
@interface NetworkCheck : NSObject <DeviceDelegate>

@end
