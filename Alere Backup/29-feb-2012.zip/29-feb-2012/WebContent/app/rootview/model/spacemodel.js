mHealth.models.SpaceModel = Spine.Model.sub();
mHealth.models.SpaceModel.configure('SpaceModel', 'participantID', 'appStyle', 'spaceStyle', 'appName', 'spaceName', 'isCleanForSession', 'recentlySynced', 'title', 'theme', 'localThemePath', 'updateTimestamp', 'effectiveDate ', 'language');

mHealth.models.SpaceViewZoneModel = Spine.Model.sub();
mHealth.models.SpaceViewZoneModel.configure('SpaceViewZoneModel', 'pageName', 'space', 'view', 'zone');

mHealth.models.ViewModel = Spine.Model.sub();
mHealth.models.ViewModel.configure('ViewModel', 'participantId', 'parentSpaceName', 'parentZoneName', 'moduleId', 'activityId', 'lastName', 'dateOfBirth', 'gender', 'height', 'emailAddress', 'firstName', 'createTimestamp', 'status', 'allowLearnMore', 'allowSave', 'allowRemove', 'promptStatusText', 'title', 'bodyCopy', 'tellMeMore', 'dontShowAgain', 'credit', 'creditLabel', 'targetLabel', 'target', 'community', 'maxCredits', 'earnedCredits', 'earnedIncentives', 'rank', 'name', 'completeDate', 'beginDate', 'endDate', 'viewTag', 'viewCategory', 'viewTemplate', 'allowEvent', 'viewStyle', 'activityName', 'image', 'imageUrl', 'recentlySynced', 'style');

mHealth.models.ZoneModel = Spine.Model.sub();
mHealth.models.ZoneModel.configure('ZoneModel', 'participantId', 'parentSpaceName', 'parentZoneName', 'moduleId', 'rank', 'title', 'bodyCopy', 'zoneStyle', 'zoneName', 'recentlySynced', 'disp', 'col', 'isInset', 'hpaIndicator', 'childZones');
