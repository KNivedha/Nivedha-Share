//
//  Devices.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Devices.h"
#import "AlereAppDelegate.h"
#import "AlereViewController.h"
@implementation Devices
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
     AlereAppDelegate* app=(AlereAppDelegate*)[[UIApplication sharedApplication] delegate];
    UIDevice *myDevice=[UIDevice currentDevice];
  //  NSString* deviceName=[myDevice name];
    NSString* osVersion=[myDevice systemVersion];
    [ app.viewController.webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"mHealth.controllers.SettingsController.getDevicesFeature([\"%@\"],[\"%@\"])",@"iPhone" ,osVersion ]];
}
@end
