/**
 * Controller : MessageController
 * This is the controller to do the  logic of message
 **/
mHealth.controllers.MessageController = Spine.Controller.sub({
	el : 'body',
	elements : {},

	tabbarloaded : false,

	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		'pageshow #home' : 'showMessages',
		'click #messageCenter' : 'loadMessageTab',
		'click #displayMessage' : 'loadMessage',
		'pagebeforeshow #detailMessage' : 'renderMessage',
		'pagebeforeshow #showMessage' : 'getMessages',
		'click #submitButton' : 'submitAssessment',
        'click #submit1Button' : 'submitAssessment' ,
       // 'pageshow #detailMessage' : 'processHeightData'  ,
        'click #detailsMessageBack' : 'hightLightMessagetab'    
	},
	/**
	 * Name    : messageSuccess
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	messageSuccess : function(output) {
         var response = output.responseText;
         var bundleMessage = JSON.parse(response);				
         var messages = JSON.stringify(bundleMessage[0].Message);                                                           
         var sortedData = mHealth.MessageControllerObject.getSortData(JSON.parse(messages));                                                             
         mHealth.models.MessageModel.customFromJSON(sortedData);
         $.mobile.changePage("../../home/view/home.html");
         mHealth.HealthDataControllerObject.loadTrackerData();
	},
     /**
      * Name    : hightLightMessagetab
      * Purpose : Method to highlight messages tab
      * Params  : output
      * Return  : --
      **/
     hightLightMessagetab : function(){
        location.href = "tabbar://loadMessages?";
     },
	/**
	 * Name    : showHome
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	showHome : function() {
		$.mobile.changePage("../../home/view/home.html");
		mHealth.HealthDataControllerObject.loadTrackerData();
        location.href = "tabbar://loadHome?";
	},
	/**
	 * Name    : messageServiceFailure
	 * Purpose : Method on failure of message header service
	 * Params  : output
	 * Return  : --
	 **/
	messageServiceFailure : function() {
		$.mobile.changePage("../../home/view/home.html");
		mHealth.util.hideMask();
	},
	/**
	 * Name    : showMessages
	 * Purpose : Load the message from the Model and Show the Result in the Message Center of the Home Tab
	 * Params  : --
	 * Return  : --
	 **/
	showMessages : function() {
		var len = mHealth.models.MessageModel.count();
		var messages_val = mHealth.models.MessageModel.all();
		if(len > 0) {
			$('#messages_div').html(_.template($('#messageList').html(), {
				messages_val : messages_val
			}));
			$('#home').trigger('create');
		} else {
			var message = "There are no messages for you to view at this time.";
			$('#messages_div').text(message);
		}

		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}
	},
	/**
	 * Name    : loadMessage
	 * Purpose : Calls webservice to get message details page
	 * Params  : --
	 * Return  : --
	 **/
	loadMessage : function(event) {		
		var eventTarget = event.target;
		var messageID = $(eventTarget).parents().children('input[type="hidden"]').val();	
		var URL = mHealth.env.messagedetails_url + messageID;
		this.proxy(this.service.getResponse(URL, mHealth.MessageControllerObject.displayMessage, mHealth.MessageControllerObject.loadMessageTab1, true));
	},
	/**
	 * Name    : displayMessage
	 * Purpose : Loads message details in to model
	 * Params  : --
	 * Return  : --
	 **/
	displayMessage : function(output) {
		mHealth.models.MessageQuestionModel.destroyAll();
		mHealth.models.QuestionGroupModel.destroyAll();
		mHealth.models.QuestionnaireModel.destroyAll();
		mHealth.models.MessageDetailsModel.destroyAll();
		var response = output.responseText;		
		var messageResponse = JSON.stringify(response);		
		var messagesData = JSON.parse(messageResponse);		
		mHealth.models.MessageDetailsModel.customFromJSON(messagesData);		
		mHealth.models.MessageDetailsModel.each(function(message) {
			var sectionData = message.cachedPersonalizedMessage.messageContent.sections.section;
			if(sectionData) {
				var questionnaireData = sectionData[0].questionnaire;
				if(questionnaireData) {
					mHealth.models.QuestionnaireModel.customFromJSON(questionnaireData);					
					mHealth.models.QuestionnaireModel.each(function(questionnaire) {
						var groupQuestion = questionnaire.qGroups.qGroup;
						mHealth.models.QuestionGroupModel.customFromJSON(groupQuestion);						
						mHealth.models.QuestionGroupModel.each(function(questionnaire) {
							var questions = questionnaire.questions.question;
							mHealth.models.MessageQuestionModel.customFromJSON(questions);	
							// mHealth.models.MessageQuestionModel.each(function(questionDetail) {
								// var questionDetails = questionDetail.question;
								// alert(questionDetail);
							// });						
						});
					});
				}
			}
		});

		var messagesDetail = mHealth.models.MessageDetailsModel.first();		
		var messageIDValue = messagesDetail.messageID;
		$.mobile.changePage("../../messages/view/displaymessage.html", {
			data : {
				messageID : messageIDValue
			}
		});
	},
	/**
	 *Name   : submitAssessment
	 *Purpose: Method to submit mini assessment
	 *Params : --
	 *Return : --
	 **/
	submitAssessment : function() {
		//if(this.validateParticipantAnswer()) {
		//	$.mobile.changePage("../../home/view/home.html");   
		var oForm = document.forms["messageform"];
		var answers = oForm.elements["form[answers]"];
		var questions = oForm.elements["form[questions]"];		
		var requestData = {
			"saveUserFeedbackRequest" : {
				"transactionID" : 1234,
				"userFeedback" : {
					"messageID" : 9999
				}
			}
		};		
		var messageID_value = $('#messageIDHidden').val();		
		requestData.saveUserFeedbackRequest.userFeedback['messageID'] = messageID_value;
		var questionResponse = new Array();			
		var lenght = mHealth.models.MessageQuestionModel.count();		
		for( i = 1; i <= lenght; i++) {
			var questionId;			
			if(document.getElementById('answerId[' + i + ']')) {
				var answerId = document.getElementById('answerId[' + i + ']').value;
			}
			var setAnswerId = answerId.replace(/\{|\}/gi, '');
			if(document.getElementById('question[' + i + ']')) {
				questionId = document.getElementById('question[' + i + ']').value;
			}
			var simpleQuestionResponse = {};
			var questionResponseMap = {};
			var simpleQuestionResponse = {};
			simpleQuestionResponse["answer"] = setAnswerId;
			simpleQuestionResponse["question"] = questionId;
			questionResponseMap["simpleQuestionResponse"] = simpleQuestionResponse;
			questionResponse.push(questionResponseMap);
		}
		var questionResponseMap = {};
		questionResponseMap["questionResponse"] = questionResponse;
		requestData.saveUserFeedbackRequest.userFeedback['questionResponses'] = questionResponseMap;
        //alert("Your record has been saved successfully.");
        //mHealth.util.customAlert("Your record has been saved successfully.", '', false);
        //TODO : To remove the below lines when post service comes
		$.mobile.changePage("../../home/view/home.html");
        location.href = "tabbar://loadHome?";
		//}
	},
	/**
	 *Name   : validateParticipantAnswer
	 *Purpose: Method to validate Participant Answer
	 *Params : Number of question
	 *Return : --
	 **/
	validateParticipantAnswer : function() {
		var question1 = document.getElementById("questionId[0]").value;
		var question2 = document.getElementById("questionId[1]").value;
		var question3 = document.getElementById("questionId[2]").value;
		if(question1 == "default" && question2 == "default" && question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidAssessment, '', false);
			return false;
		}
		if(question1 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidFirstQuesAssessment, '', false);
			return false;
		}
		if(question2 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidSecondQuesAssessment, '', false);
			return false;
		}
		if(question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidThirdQuesAssessment, '', false);
			return false;
		}
		return true;
	},
	/**
	 * Name    : loadMessageTab1
	 * Purpose : To deal webservice failure scenario
	 * Params  : --
	 * Return  : --
	 **/
	loadMessageTab1 : function() {
		$.mobile.changePage("../../messages/view/showmessage.html");
		location.href = "tabbar://loadMessages?";
	},
	/**
	 * Name    : renderMessage
	 * Purpose : Method to render data on html page
	 * Params  : --
	 * Return  : --
	 **/
	renderMessage : function() {		
		var len = mHealth.models.MessageQuestionModel.count();		
		if(len > 0) {
			var messageType = 1;
			mHealth.models.MessageDetailsModel.each(function(message) {
				messageType = message.msgTypeID;
			});
				
		var displayViewMessages = "";
		   switch(messageType) {
	       		case "1":
					displayViewMessages = mHealth.assessment.generate_assesment("", "");
					break;
	            case "2":
					displayViewMessages = mHealth.assessment.generate_messageDetailsHtml("", "");	
					break;	
	        }						
			$('#messagedetails').append(displayViewMessages);			
			var currentPageURL = $('div[id = "detailMessage"]').attr('data-url');
			var messageData = mHealth.util.getParameterByName('messageID', currentPageURL);		
			var messageIDVal = JSON.parse(messageData);
			$('#messageID_data').html(_.template($('#msgDetails').html(), {
				messageID : messageIDVal
			}));
			$('#messageID_data').trigger('create');
			$('.mobiscroll').scroller({
				dateFormat : 'yyyy-mm-dd',
				preset : 'datetime',
				seconds : true,
				timeFormat : 'hh:ii:ss A',
				theme : 'ios',
				beforeShow : function(input, inst){
				nativeCommunication.callNativeMethod("tabbar://addMask?");
				
				},
				onClose:function(valueText, inst){
				nativeCommunication.callNativeMethod("tabbar://removeMask?");
				},
				onCancel:function(valueText, inst){
				
				nativeCommunication.callNativeMethod("tabbar://removeMask?");
				}
			});
			$('#showmessagecontent').html(_.template($('#showmessagetemplate').html(), {
				loginWorkflow : "true"
			}));
			$('#showmessagecontent').trigger('create');
			$('#showmessagecontent1').html(_.template($('#showmessagetemplate1').html(), {
				loginWorkflow : "true"
			}));
			$('#showmessagecontent1').trigger('create');
		} else {
			var message = "There are no details messages for you to view at this time.";
			$('#messagedetails').text(message);
			$('#showmessagecontent').html(_.template($('#showmessagetemplate').html(), {
				loginWorkflow : "false"
			}));
			$('#showmessagecontent').trigger('create');
			$('#showmessagecontent1').html(_.template($('#showmessagetemplate1').html(), {
				loginWorkflow : "false"
			}));
			$('#showmessagecontent1').trigger('create');
		}
		$('#messagedetails').trigger('create');
		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}
	},
	/**
	 * Name    : setHeight
	 * Purpose : Method to set height units 
	 * Params  : --
	 * Returns : --
	 **/
	setHeight : function(height_unit, index) {	
				var heightResponse = new Array();					
				var heightIncr = 1;			
				var heightUS = 36;			
				var heightMetric = heightUS * 2.54;			
				for( i = 0; i < 61; i++) {
					var feet = parseInt(heightUS / 12);
					var inch = heightUS % 12;
					var options = {};	
					if(height_unit == "ft-inch") {
						options["value"] = feet + " ft. " + inch + " in.";
						options["units"] = heightUS;						
					} else {					
						heightMetric = heightUS * 2.54;		
						options["value"] = Math.round(heightMetric) + " cm";
						options["units"] = heightUS;			
					}
					heightUS += heightIncr;
					heightResponse.push(options);
				}	
				return heightResponse;		
	},
	/**
	 * Name    : processHeightData
	 * Purpose : Method to process height units 
	 * Params  : --
	 * Returns : --
	 **/
	processHeightData : function() {
		var index = "30";
		//mHealth.index = mHealth.models.ParticipantModel.first().height;
		if(mHealth.util.selUnits == undefined || mHealth.util.selUnits == 'ft-inch') {
			// if(mHealth.index != undefined || "") {
				// this.setHeight('ft-inch', (mHealth.index - 36));
			// } else {
				return this.setHeight('ft-inch', index);
			// }
		}
		// if(mHealth.util.selUnits == "cm") {
			// if(mHealth.index != undefined || mHealth.index == "") {
				// setHeight('cm', (mHealth.index - 36));
			// } else {
				// setHeight('cm', index);
			// }
		// }
	},
	/**
	 * Name    : getMessages
	 * Purpose : Load the message from the Model and Show the Result in the  Message Tab
	 * Params  : --
	 * Return  : --
	 **/
	getMessages : function() {
		var len = mHealth.models.MessageModel.count();
		var messages_val = mHealth.models.MessageModel.all();
		if(len < 0) {
			messages_val = "There are no messages for you to view at this time.";
		}
		$('#message').html(_.template($('#messageList1').html(), {
			messages_val : messages_val
		}));
		$('#showMessage').trigger('create');
	},
	/**
	 * Name    : loadMessageTab
	 * Purpose : Highlight the Message when we redirect the shorcut from the Home to message TAB.
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageTab : function() {
		$.mobile.changePage("../../messages/view/showmessage.html");
		location.href = "tabbar://loadMessages?";
	},
 /**
  *Name: getSortData
  *Purpose: sorts the health data based on measurement date.
  *Params: health data to be sorted is passed as param
  *Returns: returns the sorted health data
  **/
 getSortData : function(msgData) {
     var keys = [];
     var sortedData = [];
     for(var i in msgData) {
         keys[i] = [];
         keys[i][0] = msgData[i]["sentDate"];
         keys[i][1] = i;     
     }
     keys.sort();
     keys.reverse();     
     for(var i in keys) {
        sortedData.push(msgData[keys[i][1]]);
     } 
     return sortedData;
 }
});
