/**  
  * Assessment UI generator
  **/
mHealth.assessment = {
/**
	 * Name:generate_html
	 * purpose:to generate dynamic html according to entry
	 * type Params:entrytype and data with question and answers
	 * return : random generated html
	 */
	generate_html : function(data, entryType) {
		switch(entryType) {
			case "Dropdown":
				output_html=get_dropdown_html(data);
				break;
			case "RadioButton":
				get_radio_html(data);
				break;
			case "TwoNumberEdit":
				break;
			case "TextArea":
				break;
			case "NumberEdit":
				output_html = this.get_numberedit_html(data);
				break;
			case "Checkbox":
				output_html = this.get_checkbox_html(data);
				break;
			case "TextEdit":
				break;
			case "Likert":
				break;
			case "Date":
				break;
			case "Time":
				break;
			case "DateTime":
				break;
		}
		return output_html;
	},
/**
  * Name    : get_dropdown_html
  * Purpose : Method to create request body for recommendation Service.
  * Params  : responseType -  recommendation type
  * Returns : bodyContent
  **/
	get_dropdown_html : function(data) {					
			answers=[];
			var disabled = false;
			var answersId = [];				
			var instance_outputHTML ='';				
			var i = 0;	
			var j =0;						
			mHealth.models.ParticipantAnswerModel.each(function(participantAnswer){
				data.section[ 0].question.map(function(question){	
					question.answer.map(function(answer) {
						if(participantAnswer.answerId === answer.answerId && participantAnswer.questionId === answer.questionId) {													
							disabled = true;							
							answersId.push(answer.answerId);						
						}
					});
				 });
			});
			
				if(!disabled) {					
					data.section[0].question.map(function(question){	
						answers=[];					
						instance_outputHTML += "<div data-role='collapsible' data-content-theme='d' ><h1>"+question.theQuestion+"</h1>";		
						instance_outputHTML += "<p>";						
						instance_outputHTML += "<select data-native-menu='true' id='questionId["+j+"]' name='form[dropdown]' class='selectValue'>";
						instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">Please Select One</option>";								
						data.section[0].question[i].answer.map(function(answer) {							
								if(question.questionId == "Question 3"){									
									var medicalDevices = JSON.parse(devices);									
									medicalDevices.map(function(device){										
										instance_outputHTML += "<option name ='form[dropdown]' value='{"+device.sku+"}'>";
									    instance_outputHTML += device.description;
									    instance_outputHTML += "</option>"	;
								    }); 
								    instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">None</option>";
								    instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">Others</option>";	
								}else{
									instance_outputHTML += "<option name ='form[dropdown]' value='{"+answer.answerOptionText+"}'>";
									instance_outputHTML += answer.answerOptionText;
									instance_outputHTML += "</option>";	
							    }
							    answers.push(answer);																				
						});												
						instance_outputHTML += "</select>";
						instance_outputHTML += "</p>";	
						instance_outputHTML += "</div>";
						i++;
						j++;
					});
				}
			   else if(disabled) {
			   	mHealth.LoginControllerObject.updateProgressBar(3);
			   	data.section[0].question.map(function(question){	
						answers=[];					
						instance_outputHTML += "<div data-role='collapsible' data-content-theme='d' ><h1>"+question.theQuestion+"</h1>";		
						instance_outputHTML += "<p>";						
						instance_outputHTML += "<select disabled id='questionId["+j+"]' name='form[dropdown]' class='selectValue'>";														
						question.answer.map(function(answer) {	
							if(answer.answerId == answersId[i]) {
								instance_outputHTML += "<option selected='yes' ";		
							} else if(answer.answerId != answersId[i]) {
								instance_outputHTML += "<option ";		
							}
							if(question.questionId == "Question 3"){									
									var medicalDevices = JSON.parse(devices);									
									medicalDevices.map(function(device){										
										instance_outputHTML += "name ='form[dropdown]' value='{"+device.sku+"}'>";
									    instance_outputHTML += device.description;
									    instance_outputHTML += "</option>"	;
								    });	
							}else{
									instance_outputHTML += "name ='form[dropdown]' value='{"+answer.answerId+"}'>";
									instance_outputHTML += answer.answerOptionText;
									instance_outputHTML += "</option>";	
							}
							answers.push(answer);																			
						});												
						instance_outputHTML += "</select>";
						instance_outputHTML += "</p>";	
						instance_outputHTML += "</div>";
						i++;
						j++;
					});							
				}	
						
			return instance_outputHTML;
	},
    /**
	 * Name:generate_messageDetailsHtml
	 * purpose:to generate dynamic html according to entry
	 * type Params:entrytype and data with question and answers
	 * return : random generated html
	 */
	generate_messageDetailsHtml : function(data) {			
		var messageDesc = "";
		mHealth.models.QuestionnaireModel.each(function(questionnaire1) {
			messageDesc = questionnaire1.introCopy;
		});
		var outputhtml = "";
		var questionCount = 1;	
		var answerCount = 1;
		outputhtml += "<div class='ui-body ui-body-c ui-corner-all'  >";	
		mHealth.models.QuestionGroupModel.each(function(questionnaire) {
						
			if (questionnaire.title != null || messageDesc != null) {
				outputhtml += "<h3>"+messageDesc+"</h3>";	
			}			
			var questions = questionnaire.questions.question;			
			mHealth.models.MessageQuestionModel.destroyAll();			
			mHealth.models.MessageQuestionModel.customFromJSON(questions);																		
				mHealth.models.MessageQuestionModel.each(function(question) {				
            	entryType = question.answerType;            	
                switch(entryType) {
               		case "FixedListSingleSelect":
		                outputhtml += mHealth.assessment.getSingleSelecthtml(question,questionCount,answerCount);						
		                break;
	                case "Date":
			         	outputhtml += mHealth.assessment.getDatehtml(question,questionCount,answerCount);
			            break;
	                case "Float":					
		                outputhtml += mHealth.assessment.getFloathtml(question,questionCount,answerCount);
		                break;	
		            case "decimal":					
		                outputhtml += mHealth.assessment.getFloathtml(question,questionCount,answerCount);
		                break;	
		            case "height":					
			            outputhtml += mHealth.assessment.getHeighthtml(question,questionCount,answerCount);
			            break;	
		            case "Decimal":					
		                outputhtml += mHealth.assessment.getFloathtml(question,questionCount,answerCount);
		                break;	
	                case "Boolean":										
		                outputhtml += mHealth.assessment.getBooleanhtml(question,questionCount,answerCount);
		                break;					
                }
                questionCount++;
				answerCount++;
            });            
         	
       	 });  
       	 outputhtml += "</div>";                            
		return outputhtml;
	},
	
	/**
	 * Name:generate_assesment
	 * purpose:to generate dynamic html according to entry
	 * type Params:entrytype and data with question and answers
	 * return : random generated html
	 */
	generate_assesment : function(data) {		
		var outputhtml = "";
		var questionCount = 1;	
		var answerCount = 1;
		outputhtml += "<div class='ui-body ui-body-c ui-corner-all ' >";
		mHealth.models.QuestionGroupModel.each(function(questionnaire) {
							
			if (questionnaire.title != null) {
				outputhtml += "<b style='font-size:11pt;' >"+questionnaire.title+"</b>";	
			}			
			var questions = questionnaire.questions.question;			
			mHealth.models.QuestionMsgModel.destroyAll();			
			mHealth.models.QuestionMsgModel.customFromJSON(questions);			
				mHealth.models.QuestionMsgModel.each(function(question) {				
	            	entryType = question.answerType;  
	            	//TODO: If answer type comes as height or weight - need to remove if conditions    
	            	if(question.questionText == "Select Height" || question.questionText == "Select Weight"){ 	
	                	outputhtml += mHealth.assessment.getHeighthtml(question,questionCount,answerCount);
	                }else{
		               	switch(entryType) {
		               		case "FixedListSingleSelect":
				                outputhtml += mHealth.assessment.getSingleSelecthtml(question,questionCount,answerCount);						
				                break;
			                case "Date":
					         	outputhtml += mHealth.assessment.getDatehtml(question,questionCount,answerCount);
					            break;
			                case "Float":					
				                outputhtml += mHealth.assessment.getFloathtml(question,questionCount,answerCount);
				                break;	
				            case "decimal":					
				                outputhtml += mHealth.assessment.getFloathtml(question,questionCount,answerCount);
				                break;	
				            case "Decimal":					
				                outputhtml += mHealth.assessment.getFloathtml(question,questionCount,answerCount);
				                break;
				            case "height":					
				                outputhtml += mHealth.assessment.getHeighthtml(question,questionCount,answerCount);
				                break;	
				            case "Weight":					
				                outputhtml += mHealth.assessment.getFloathtml(question,questionCount,answerCount);
				                break;	
			                case "Boolean":										
				                outputhtml += mHealth.assessment.getBooleanhtml(question,questionCount,answerCount);
				                break;					
		                }
	               }
	                questionCount++;
				answerCount++;
            });            
         	
       	 });   
       	 outputhtml += "</div>";                                   
		return outputhtml;
	},
	
	/**
     * Name    : getHeighthtml
     * Purpose : Method to create html for height entry type
     * Params  : responseType -  recommendation type
     * Returns : bodyContent
     **/
	getHeighthtml : function(data,questionCount,answerCount) {	
		if(data.questionText == "Select Weight"){ 
			var disabled = false;
        	var instance_outputHTML = "";         
        	//instance_outputHTML += '<div style="display:inline;weight:bold;font-size:35px;margin-right:10px;vertical-align:-7px;">';
			instance_outputHTML += '/';
			//instance_outputHTML += '</div>';  		    
	        if(!disabled) {	
	           // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";		           	           
	            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value="+data.id+"  name ='form[questions]' />";
	            // if(!data.questionText){				
	            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
	            // } else{
	            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";	
	            // } 
	            // instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  >";
	          //  instance_outputHTML += "<div  >";
	            instance_outputHTML += "<input type='text' style='font-size:11pt;width:50%;'  data-inline='true' id='answerId["+answerCount+"]' placeholder='"+data.questionText+"' value='' name =\"form[dropdown]\" />";				
	           // instance_outputHTML += "</div>";	            	           			
	        }
	        else if(disabled) {
	            // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";		           
	            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value="+data.id+"  name ='form[questions]' />";
	            // if(!data.questionText){				
	            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
	            // } else{
	            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";	
	            // } 
	           // instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  style='margin-top:10px;'>";
	           // instance_outputHTML += "<div  >";
	            instance_outputHTML += "<input type='text' style='font-size:11pt;width:50%;'  data-inline='true'  id='answerId["+answerCount+"]' placeholder='"+data.questionText+"' value='' name =\"form[dropdown]\" />";		            	           	           	
	        }						
	        instance_outputHTML += "</div>";
	        return instance_outputHTML;
	    }else{		
	        var disabled = false;			
	        var instance_outputHTML = "";	
	        instance_outputHTML += "<div style='width:100%;display:inline;'>";        						
	        if(!disabled) {		
	            // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	            	
	            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]' class='selectHeight' value='"+data.questionText+"'  name ='form[questions]' />";
	            instance_outputHTML += "<input type='hidden' id='answerType'  value="+data.answerType+" name ='answerType'/>";	
	            // if(!data.questionText){				
	            	// instance_outputHTML += "<div data-role='collapsible' data-content-theme='d'  ><h1 class='col'></h1>";
	            // } else{
	            	// instance_outputHTML += "<div data-role='collapsible' data-content-theme='d'  ><h1 class='col'>"+data.questionText+"</h1>";		
	            // }
	            // instance_outputHTML += "<p>";	
	            instance_outputHTML += "<select style='font-size:11pt;width:50%;'  data-inline='true'  data-native-menu='true' id='answerId["+answerCount+"]' name='form[answers]' >";
	            instance_outputHTML += "<option style='font-size:11pt;'   value=\"default\">Please Select One</option>";												
	           // var answerValues = data.answerOptions.answerOption;	
	            var answerValues = mHealth.MessageControllerObject.processHeightData();            							
	            answerValues.map(function(answer){							
	                             instance_outputHTML += "<option style='font-size:11pt;'  value='{"+answer.units+"}'>";
	                             instance_outputHTML += answer.value;
	                             instance_outputHTML += "</option>";											
	                             });												
	            instance_outputHTML += "</select>";
	          //  instance_outputHTML += "</p>";	
	            // instance_outputHTML += "</div>";
	            // instance_outputHTML += "</div>";            					
	        }
	        else if(disabled) {
	            // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	          	
	            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value='"+data.questionText+"'  name ='form[questions]' />";
	             instance_outputHTML += "<input type='hidden' id='answerType'  value="+data.answerType+" name ='answerType'/>";	
	            // if(!data.questionText){				
	            	// instance_outputHTML += "<div data-role='collapsible' data-content-theme='d'  ><h1 class='col'></h1>";
	            // } else{
	            	// instance_outputHTML += "<div data-role='collapsible' data-content-theme='d'  ><h1 class='col'>"+data.questionText+"</h1>";		
	            // }	
	            // instance_outputHTML += "<p>";	
	            instance_outputHTML += "<select data-native-menu='true' style='font-size:11pt;width:50%;' data-inline='true'  id='answerId["+answerCount+"]' name='form[answers]' class='selectHeight'>";
	            instance_outputHTML += "<option style='font-size:11pt;'   value=\"default\">Please Select One</option>";											
	            //var answerValues = data.answerOptions.answerOption;	
	            var answerValues = mHealth.MessageControllerObject.processHeightData();																
	            answerValues.map(function(answer){							
	                             instance_outputHTML += "<option  style='font-size:11pt;'  value='{"+answer.units+"}'>";
	                             instance_outputHTML += answer.value;
	                             instance_outputHTML += "</option>";											
	                             });												
	            instance_outputHTML += "</select>";
	            // instance_outputHTML += "</p>";	
	            // instance_outputHTML += "</div>";
	            // instance_outputHTML += "</div>";           	
	        }									
	        return instance_outputHTML;		        
		}
		
	},	
	/**
     * Name    : getBooleanhtml
     * Purpose : Method to create html for boolean entry type
     * Params  : responseType -  recommendation type
     * Returns : bodyContent
     **/
	getBooleanhtml : function(data,questionCount,answerCount) {			
        var disabled = false;			
        var instance_outputHTML = "";	        						
        if(!disabled) {		
            // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	
            instance_outputHTML += "<div  >";	
            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'   value='"+data.questionText+"'  name ='form[questions]' />";	
            if(!data.questionText){				
            	instance_outputHTML += "<div data-role='collapsible' data-content-theme='d'  ><h1 class='col'></h1>";
            } else{
            	instance_outputHTML += "<div data-role='collapsible' data-content-theme='d' style='font-size:11pt;'  ><h1 class='col'>"+data.questionText+"</h1>";		
            }
            instance_outputHTML += "<p>";	
            instance_outputHTML += "<select data-native-menu='true' id='answerId["+answerCount+"]' style='font-size:11pt;'  name='form[answers]' class='selectValue'>";
            instance_outputHTML += "<option style='font-size:11pt;'   value=\"default\">Please Select One</option>";												
            var answerValues = data.answerOptions.answerOption;												
            answerValues.map(function(answer){							
                             instance_outputHTML += "<option style='font-size:11pt;'  value='{"+answer.id+"}'>";
                             instance_outputHTML += answer.Label;
                             instance_outputHTML += "</option>";											
                             });												
            instance_outputHTML += "</select>";
            instance_outputHTML += "</p>";	
            instance_outputHTML += "</div>";
            instance_outputHTML += "</div>";            					
        }
        else if(disabled) {
            // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	
            instance_outputHTML += "<div  >";	
            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value='"+data.questionText+"'  name ='form[questions]' />";
            if(!data.questionText){				
            	instance_outputHTML += "<div data-role='collapsible' data-content-theme='d'  ><h1 class='col'></h1>";
            } else{
            	instance_outputHTML += "<div data-role='collapsible' data-content-theme='d'  style='font-size:11pt;' ><h1 class='col'>"+data.questionText+"</h1>";		
            }	
            instance_outputHTML += "<p>";	
            instance_outputHTML += "<select data-native-menu='true' id='answerId["+answerCount+"]' style='font-size:11pt;'  name='form[answers]' class='selectValue'>";
            instance_outputHTML += "<option  value=\"default\">Please Select One</option>";										
            var answerValues = data.answerOptions.answerOption;																
            answerValues.map(function(answer){							
                             instance_outputHTML += "<option style='font-size:11pt;'   value='{"+answer.id+"}'>";
                             instance_outputHTML += answer.Label;
                             instance_outputHTML += "</option>";											
                             });												
            instance_outputHTML += "</select>";
            instance_outputHTML += "</p>";	
            instance_outputHTML += "</div>";
            instance_outputHTML += "</div>";           	
        }									
        return instance_outputHTML;	
	},	
    /**
     * Name    : getDatehtml
     * Purpose : Method to create html for date entry type
     * Params  : responseType -  recommendation type
     * Returns : bodyContent
     **/
	getDatehtml : function(data,questionCount,answerCount) {			
        var disabled = false;			
        var instance_outputHTML = "";      					
        if(!disabled) {	
             // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	
            instance_outputHTML += "<div  >";	
            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value="+data.id+"  name ='form[questions]' />";
            // if(!data.questionText){				
            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
            // } else{
            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";	
            // }            
           // instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  style='margin-top:10px;'>";
            instance_outputHTML += "<div >";
            instance_outputHTML += "<input type='text' id='answerId["+answerCount+"]' style='font-size:11pt;'   value='' name =\"form[dropdown]\" class='mobiscroll' placeholder='Date' data-theme='c'  readonly/>";				
            instance_outputHTML += "</div>";	
            instance_outputHTML += "</div>";           			
        }
        else if(disabled) { 
             // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	
            instance_outputHTML += "<div  >";	
            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value="+data.id+"  name ='form[questions]' />";
            // if(!data.questionText){				
            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
            // } else{
            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";	
            // } 
           // instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  style='margin-top:10px;'>";
            instance_outputHTML += "<div  >";
            instance_outputHTML += "<input type='text' id='answerId["+answerCount+"]' style='font-size:11pt;'    value='' name =\"form[dropdown]\" class='mobiscroll' placeholder='Date' data-theme='c'  readonly/>";				
            instance_outputHTML += "</div>";	
            instance_outputHTML += "</div>";            	
        }						
        return instance_outputHTML;	
	},	
    /**
     * Name    : getFloathtml
     * Purpose : Method to create html for float entry type
     * Params  : responseType -  recommendation type
     * Returns : bodyContent
     **/
	getFloathtml : function(data,questionCount,answerCount) {			
        var disabled = false;
        var instance_outputHTML = "";        
        if(!disabled) {	
           // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	
            instance_outputHTML += "<div  >";	
            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value="+data.id+"  name ='form[questions]' />";
            // if(!data.questionText){				
            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
            // } else{
            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";	
            // } 
            // instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  >";
            instance_outputHTML += "<div  >";
            instance_outputHTML += "<input type='text' id='answerId["+answerCount+"]' style='font-size:11pt;'   placeholder='"+data.questionText+"' value='' name =\"form[dropdown]\" />";				
            instance_outputHTML += "</div>";
            instance_outputHTML += "</div>";	           			
        }
        else if(disabled) {
            // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	
            instance_outputHTML += "<div  >";	
            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value="+data.id+"  name ='form[questions]' />";
            // if(!data.questionText){				
            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b></b></label>";
            // } else{
            	// instance_outputHTML += "<label for='answerId' style='top:10px;left:10px;'><b>" + data.questionText + "</b></label>";	
            // } 
           // instance_outputHTML += "<div  data-role='fieldcontain' class='ui-body ui-body-c ui-corner-all ui-shadow'  style='margin-top:10px;'>";
            instance_outputHTML += "<div  >";
            instance_outputHTML += "<input type='text' id='answerId["+answerCount+"]' style='font-size:11pt;'   placeholder='"+data.questionText+"' value='' name =\"form[dropdown]\" />";				
            instance_outputHTML += "</div>";
            instance_outputHTML += "</div>";	           	
        }						
        return instance_outputHTML;
	},	
    /**
     * Name    : getSingleSelecthtml
     * Purpose : Method to create html for select entry type
     * Params  : responseType -  recommendation type
     * Returns : bodyContent
     **/
	getSingleSelecthtml : function(data,questionCount,answerCount) {			
        var disabled = false;
        var instance_outputHTML = "";       
        if(!disabled) {		
             // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	
            instance_outputHTML += "<div  >";	
            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value='"+data.id+"'  name ='form[questions]' />";				
            if(!data.questionText){				
            	instance_outputHTML += "<div data-role='collapsible' data-content-theme='d'  ><h1 class='col'></h1>";
            } else{
            	instance_outputHTML += "<div data-role='collapsible' data-content-theme='d' style='font-size:11pt;'   ><h1 class='col'>"+data.questionText+"</h1>";		
            }	
            instance_outputHTML += "<p>";	
            instance_outputHTML += "<select data-native-menu='true' id='answerId["+answerCount+"]' style='font-size:11pt;'   name='form[answers]' class='selectValue'>";
            instance_outputHTML += "<option style='font-size:11pt;' value=\"default\">Please Select One</option>";												
            var answerValues = data.answerOptions.answerOption;												
            answerValues.map(function(answer){	            					
                             instance_outputHTML += "<option style='font-size:11pt;'   value='{"+answer.id+"}'>";
                             instance_outputHTML += answer.label;
                             instance_outputHTML += "</option>";											
                             });												
            instance_outputHTML += "</select>";
            instance_outputHTML += "</p>";	
            instance_outputHTML += "</div>";
            instance_outputHTML += "</div>";         				
        }
        else if(disabled) {
             // instance_outputHTML += "<div class='ui-body ui-body-c ui-corner-all ui-shadow'  >";	
            instance_outputHTML += "<div  >";		
            instance_outputHTML += "<input type='hidden' id='question["+questionCount+"]'  value='"+data.id+"'  name ='form[questions]' />";
            if(!data.questionText){				
            	instance_outputHTML += "<div data-role='collapsible' data-content-theme='d'  ><h1 class='col'></h1>";
            } else{
            	instance_outputHTML += "<div data-role='collapsible' data-content-theme='d' style='font-size:11pt;'   ><h1 class='col'>"+data.questionText+"</h1>";		
            }
            instance_outputHTML += "<p>";	
            instance_outputHTML += "<select data-native-menu='true' id='answerId["+answerCount+"]' style='font-size:11pt;'   name='form[answers]' class='selectValue'>";
            instance_outputHTML += "<option  style='font-size:11pt;'   value=\"default\">Please Select One</option>";										
            var answerValues = data.answerOptions.answerOption;																
            answerValues.map(function(answer){	            							
                             instance_outputHTML += "<option  style='font-size:11pt;'  value='{"+answer.id+"}'>";
                             instance_outputHTML += answer.label;
                             instance_outputHTML += "</option>";											
                             });												
            instance_outputHTML += "</select>";
            instance_outputHTML += "</p>";	
            instance_outputHTML += "</div>";
            instance_outputHTML += "</div>";
        }						
        return instance_outputHTML;
	},

	/**
	 * Name : get_checkbox_html
	 * Purpose :Method to get checkbox .
	 * Params:questions with answers
	 * Returns : checkbox html with question and answers
	 */
	get_checkbox_html : function(question, date) {
		disabled = false;
		id = "";
		var j = 0;
		var k = 0;
		
		class_outputHTML = "";
		class_outputHTML += "<div data-role='fieldcontain'>";
		class_outputHTML += "<fieldset>";
		
		if(!disabled) {
			for(var i = 0; i < question.length; i++) {
				class_outputHTML += "<legend>" + question[i].Title  + "</legend>";
				
					class_outputHTML += "<label for='{" + question[i].ID + "}'>" + question[i].Title + "</label>";
					class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" + question[i].ID + "}' value='{" + question[i].Title + "}' />";
				
			}
		} else if(disabled) {
			for(var i = 0; i < question.length; i++) {
				class_outputHTML += "<legend>" + question[i].theQuestion + "</legend>";
				if(question[i].length > 1) {
					for(var k = 0; k < questions[k].length; k++) {
						class_outputHTML += "<label for='{" + question[k].ID + "}'>" + question[i].Title + "</label>";
						class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" + questions[i].questionId + "}' value='{" + questions[i].answer[k].theAnswer + "}' checked disabled />";
					}

				} else if(question[i].length == 1) {
					class_outputHTML += "<label for='{" + questions[i].questionId + "}'>" + questions[i].theQuestion + "</label>";
					class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" + questions[i].questionId + "}' value='{" + questions[i].answer[0].theAnswer + "}' disabled />";
				}
			}
		}
		class_outputHTML += "</fieldset></div>";
		return class_outputHTML;
	},
	/**
	 * Name : get_numberedit_html
	 * Purpose :Method to get number edit html .
	 * Params:questions with answers
	 * Returns : input type with number edit html with question and answers
	 */
	get_numberedit_html : function(question, date) {
		instance_outputHTML = "";
		instance_outputHTML += "<div data-role='fieldcontain'>";
		var ParticipantAnswer
		if(ParticipantAnswer) {
			
			value = ParticipantAnswer.getby_answer(question.answers[0], date).answerValue1;
			instance_outputHTML += "<label for=" +question[0].Title + ">" + question[0].Title + "</label>";
			instance_outputHTML += "<input type=\"tel\" id=\'{question.questionId}\
			' maxlength=\"3\" value=\"\" class='ui-disabled' style=\"width:50px\" name=\"form[{answer.object}}]\" disabled/>";

		} else {
			instance_outputHTML += "<label for=" +question[0].ID + ">" + question[0].Title + "</label>";
			instance_outputHTML += "<input type=\"tel\" pattern=\"[0-9]*\" style=\"width:50px\"  maxlength=\"3\" id=" + question[0].ID + " name=\"form[number]\"/>";
			instance_outputHTML += "<input type=\"hidden\" name=\"form[number]\" value=\"number\"/>";
		}
		instance_outputHTML += "</div>";
		return instance_outputHTML;

	}
};