mHealth.controllers.HealthDataController = Spine.Controller.sub({
	healthDataTracker : '',
	trackerData : '',
	validForm : false,

	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #viewJournal' : 'getJournalData',
		'click #viewJournalGraph' : 'viewJournalGraph',
		'click #viewNewEntry' : 'viewNewEntry',
		'pagebeforeshow #show_tracker_view' : 'showTracker',
		'pagebeforeshow #show_tracker_track' : 'newEntryTracker',
		'click #track_save' : 'newEntrySave',
		'click .tracker' : 'setTrackerType',
		'pagebeforeshow #show_journal' : 'showJournal',
		'click .chotype' : 'setChoType',
		'click #showTrackerPage' : 'setGlucoseTracker',
		'click #track' : 'setChoPage',
		'click #back' : 'setBackPage',
		'click #save_add_another' : 'newEntrySaveADDAnother'
	},
	/**
	 *Name: setChoPage
	 *Purpose: Sets Cholesterol type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setChoPage : function() {
		if(this.healthDataTracker == 'LDL' || this.healthDataTracker == 'HDL' || this.healthDataTracker == 'Total Cholesterol' || this.healthDataTracker == 'Triglycerides') {
			this.healthDataTracker = "Cholesterol";
			mHealth.GraphControllerObject.healthDataTracker = "Cholesterol";
		}
		this.unloadChart();
	},
	/**
	 *Name: newEntrySaveADDAnother
	 *Purpose: Saves new tracker entry
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	newEntrySaveADDAnother : function() {

		var currentDiv = this.getCurrentContentDiv();
		if(currentDiv.length > 0) {
			var currentForm = $('form', currentDiv);
			if(this.validateForm(currentForm.get(0))) {
				this.validForm = true;
			} else {
				this.validForm = false;
				mHealth.util.customAlert(mHealth.Validation.generic,'');
			}
		}
		if(this.validForm) {

			if(!(this.validateHealthData())) {
				return false;
			}
			this.clearForm(currentForm.get(0));
		}
	},
	/**
	 *Name: clearForm
	 *Purpose: form fields are validated here
	 *Params: html form object
	 *Returns: returns boolean value denoting the valid form
	 **/
	clearForm : function(form) {
		$('#save_add_another').removeClass('ui-btn-active');
		$('#tracker_newEntry')[0].reset();
		$('select').selectmenu('refresh');
	},
	/**
	 *Name: setBackPage
	 *Purpose: Sets Cholesterol type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setBackPage : function() {
		if(this.healthDataTracker != 'LDL' && this.healthDataTracker != 'HDL' && this.healthDataTracker != 'Total Cholesterol' && this.healthDataTracker != 'Triglycerides')
			$.mobile.changePage("detailtracker.html");
		else
			$.mobile.changePage("detailscholesterol.html");
		this.unloadChart();
	},
	loadTrackerData : function() {
		var count = mHealth.models.HealthDataModel.count();

		if(count == 0) {
			URL = mHealth.env.healthdata_url + 'A1c' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'Bloodglucose' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'Weight' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'BMI' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'BPS' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'LDL' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'HDL' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'Cholesterol' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'Triglycerides' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'RetinalExam' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'FootSelfExam' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'FootExam' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
			URL = mHealth.env.healthdata_url + 'MAU' + "?maxdays=45";
			this.proxy(this.service.getResponse(URL, this.proxy(this.setHealthData), null, false));
		}
	},
	/**
	 *Name: unloadChart
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	unloadChart : function(e) {
		location.href = "gyro://unLoadChart?";
	},
	/**
	 *Name: viewJournalGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	viewJournalGraph : function() {
		if(this.healthDataTracker == 'LDL' || this.healthDataTracker == 'HDL' || this.healthDataTracker == 'Total Cholesterol' || this.healthDataTracker == 'Triglycerides') {
			this.healthDataTracker = "Cholesterol";
			mHealth.GraphControllerObject.healthDataTracker = "Cholesterol";
		}
		this.unloadChart();
		this.getJournalData();
	},
	/**
	 *Name: setTrackerType
	 *Purpose: Sets Tracker type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setTrackerType : function(e) {
		this.healthDataTracker = $(e.target).parents(".tracker").attr('name');
	},
	/**
	 *Name: setChoType
	 *Purpose: Sets Cholesterol type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setChoType : function(e) {
		this.healthDataTracker = $(e.target).parents(".chotype").attr('name');
		//this.getGraphData();
	},
	/**
	 *Name: showJournal
	 *Purpose: Renders the showjournal.html page content
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	showJournal : function() {
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#journal_content').html(_.template($('#journal_list').html(), {
			trackerData : this.trackerData,
			trackerType : trackerType
		}));

		$('#journal_content').trigger('create');
		//	mHealth.util.hideMask();
	},
	/**
	 *Name: showTracker
	 *Purpose: renders the showtracker.html page
	 *Params: No params required
	 *Returns: Doesn't return
	 **/
	showTracker : function() {
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#trackviewcontent').html(_.template($('#trackerviewtemplate').html(), {
			trackerType : trackerType
		}));
		$('#headercontent').html(_.template($('#headertemplate').html(), {
			trackerType : trackerType
		}));
		$('#headercontent').trigger('create');
		$('#trackviewcontent').trigger('create');
	},
	/**
	 *Name: newEntryTracker
	 *Purpose: renders the showtrackertrack.html page
	 *Params: None
	 *Returns:Doesn't return
	 **/
	newEntryTracker : function() {
		// healthDataTracker has to change to class level.
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#showtrackertrackcontent').html(_.template($('#showtrackertracktemplate').html(), {
			trackerType : trackerType
		}));

		$('#showtrackertrackcontent').trigger('create');
	},
	/**
	 *Name: newHDataObject
	 *Purpose: Creates new health data object to be saved
	 *Params: measurement date, collected date and value. These are set in json object that is created.
	 *Returns: returns a formatted object to be passed as a param in the postRequest service call
	 **/
	newHDataObject : function(value, type) {
		var comments = "";
		if(this.healthDataTracker != 'Blood Glucose' && this.healthDataTracker != 'Weight & BMI') {
			comments = $('#comments').val();
		}
		// if(comments == mHealth.TrackerNewEntry.recordComments) {
		// comments = "";
		// }
		var measurementDate = this.getMeasurementDate();
		return mHealth.recommendation.HealthDataTypeMapper(measurementDate, comments, value, type)
	},
	/**
	 *Name: getMeasurementDate
	 *Purpose: formats the measurement date to be passed as a parameter for health data object
	 *Params: No params
	 *Returns: returns formatted date object
	 **/
	getMeasurementDate : function() {
		var dateSelected = $('#selectDate').val();
		var dateObject = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate());
		if(dateSelected != "")
			dateObject = new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2));
		if((this.healthDataTracker == 'Blood Pressure' || this.healthDataTracker == 'Blood Glucose' || this.healthDataTracker == 'Weight & BMI')) {
			if(dateSelected != "") {
				var hour = dateSelected.substr(11, 2);
				hour = parseInt(hour, 10);
				if(dateSelected.substr(17, 2) == "PM") {
					if(hour != 12)
						hour = hour + 12;
				} else {
					if(hour == 12)
						hour = 0;
				}
				dateObject = new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2), hour, dateSelected.substr(14, 2));
			} else {
				dateObject = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(),new Date().getHours(),new Date().getMinutes());
			}
		}
		return dateObject.format('yyyymmdd"T"HHMMss".000 GMT"');
	},
	/**
	 *Name: getCurrentContentDiv
	 *Purpose: gets current div of the page
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getCurrentContentDiv : function() {
		var currentDiv = $.mobile.activePage

		if(currentDiv.length == 0) {
			currentDiv = $('body');
		}
		return currentDiv;
	},
	/**
	 *Name: validateForm
	 *Purpose: form fields are validated here
	 *Params: html form object
	 *Returns: returns boolean value denoting the valid form
	 **/
	validateForm : function(form) {
		var e = form.elements;
		var type = document.getElementById('tracker_id').value;
		if(type == 'Cholesterol' || type == 'Blood Pressure' || type == 'A1c' || type == 'Foot Exam - Provider' || type == 'Microalbumin' || type == 'Dilated Retinal Exam') {
			var comments = $('select#comments option:selected').val();
			if(comments == 'I have never had the test completed') {
				return true;
			} else if(comments == "I have had the test but don't remember the values" && $('#selectDate').val() != "") {
				return true;
			}
		}
		if(type == 'Cholesterol') {
			if(document.getElementById('value_Cholesterol').value == '') {
				return false;
			} else {
				return true;
			}
		} else {
			for(var elem, i = 0; ( elem = e[i] ); i++) {
				if(elem.type == 'text' || elem.type == 'tel' || elem.type == 'number') {
					if(elem.value == '') {
						return false;
					}
				}
			}//for each elem
		}
		return true;
	},
	/**
	 *Name: newEntrySave
	 *Purpose: Saves new tracker entry
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	newEntrySave : function() {
		var currentDiv = this.getCurrentContentDiv();
		if(currentDiv.length > 0) {
			var currentForm = $('form', currentDiv);
			if(this.validateForm(currentForm.get(0))) {
				this.validForm = true;
			} else {
				this.validForm = false;
				mHealth.util.customAlert(mHealth.Validation.generic, 'mHealth');
			}
		}
		if(this.validForm) {

			if(!(this.validateHealthData())) {
				return false;
			}
			if(this.healthDataTracker != 'LDL' && this.healthDataTracker != 'HDL' && this.healthDataTracker != 'Total Cholesterol' && this.healthDataTracker != 'Triglycerides') {
				$.mobile.changePage("detailtracker.html");
			} else {
				$.mobile.changePage("detailscholesterol.html");
			}
		}
	},
	setTrackerId : function() {
		var trackerId = '';
		if(this.healthDataTracker == 'Blood Glucose') {
			trackerId = 'Bloodglucose';
		} else if(this.healthDataTracker == 'Dilated Retinal Exam') {
			trackerId = 'RetinalExam';
		} else if(this.healthDataTracker == 'Foot Exam - Self') {
			trackerId = 'FootSelfExam';
		} else if(this.healthDataTracker == 'Foot Exam - Provider') {
			trackerId = 'FootExam';
		} else if(this.healthDataTracker == 'Microalbumin') {
			trackerId = 'MAU';
		} else if(this.healthDataTracker == 'A1c') {
			trackerId = 'A1C';
		} else if(this.healthDataTracker == 'Weight & BMI') {
			trackerId = 'Weight';
		} else if(this.healthDataTracker == 'Blood Pressure') {
			trackerId = 'BPS';
		} else if(this.healthDataTracker == 'Cholesterol') {
			trackerId = 'Cholesterol';
		}
		return trackerId;
	},
	/**
	 *Name: newEntrySave
	 *Purpose: Saves new tracker entry
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	validateHealthData : function() {
		var healthDataResponse = [];
		var trackerId = this.setTrackerId();
		healthDataResponse = this.getHealthTrackerData(trackerId);
		if(this.isExists(healthDataResponse) === true) {
			this.postHealthDataResponse();
			return true;
		} else {
			mHealth.util.customAlert(mHealth.TrackerNewEntry.existingData,'');
			return false;
		}

	},
	isExists : function(healthDataResponse) {
		var formattedDateObject = this.getMeasurementDate();
		var flag = true;
		healthDataResponse.map(function(response) {
			if(response.measurementDate == formattedDateObject) {
				flag = false;
				return flag;
			}
		});
		return flag;
	},
	/**
	 *Name: postHealthDataResponse
	 *Purpose: success callback function for new entry tracker save
	 *Params: output from postRequest as implicit param
	 *Returns: Doesn't return
	 **/
	postHealthDataResponse : function() {

		var formattedDateObject = this.getMeasurementDate();
		var weightModifier = 1;
		var trackerId = this.setTrackerId();
		var hDataObject = null;
		var value = 0;

		if(this.healthDataTracker == 'Foot Exam - Provider' || this.healthDataTracker == 'Dilated Retinal Exam') {
			var trackerId;
			if(this.healthDataTracker == 'Foot Exam - Provider')
				trackerId = 'FootExam';
			else
				trackerId = 'RetinalExam';
			hDataObject = this.newHDataObject("0", trackerId);

		} else if(trackerId == 'FootSelfExam') {
			value = $('select#examOptn option:selected').val();
		} else if(trackerId == "Weight") {
			if(mHealth.util.selWeightUnits == 'Kg') {
				weightModifier = 2.205;
			}
			value = String(parseFloat($('#value_Weight').val(), 10) * weightModifier);
			var bmiHDataObject = this.newHDataObject($('#value_BMI').val(), 'BMI');

			this.service.postRequest((mHealth.env.healthdata_url + "BMI"), bmiHDataObject, null, null, false);
			mHealth.models.HealthDataModel.customFromJSON(bmiHDataObject);

		} else if(trackerId == "BPS") {
			value = $('#value_SYS').val();
			var diaHDataObject = this.newHDataObject($('#value_DIA').val(), 'BPD');
			this.service.postRequest((mHealth.env.healthdata_url + "BPD"), diaHDataObject, null, null, false);
			mHealth.models.HealthDataModel.customFromJSON(diaHDataObject);
		} else if(trackerId == "Cholesterol") {
			var ldlValue = $('#value_LDL').val();
			var hdlValue = $('#value_HDL').val();
			var triValue = $('#value_Tri').val();
			var ldlHDataObject = this.newHDataObject(ldlValue, "LDL");
			var hdlHDataObject = this.newHDataObject(hdlValue, 'HDL');
			var triHDataObject = this.newHDataObject(triValue, 'Triglycerides');
			value = $('#value_Cholesterol').val();
			if(ldlValue != '') {
				this.service.postRequest((mHealth.env.healthdata_url + "LDL"), ldlHDataObject, null, null, false);
				mHealth.models.HealthDataModel.customFromJSON(ldlHDataObject);
			}
			if(hdlValue != '') {
				this.service.postRequest((mHealth.env.healthdata_url + "HDL"), hdlHDataObject, null, null, false);
				mHealth.models.HealthDataModel.customFromJSON(hdlHDataObject);
			}
			if(triValue != '') {
				this.service.postRequest((mHealth.env.healthdata_url + "Triglycerides"), triHDataObject, null, null, false);
				mHealth.models.HealthDataModel.customFromJSON(triHDataObject);
			}
		} else {
			value = $("#value_" + trackerId).val();
		}
		hDataObject = this.newHDataObject(value, trackerId);
		mHealth.models.HealthDataModel.customFromJSON(hDataObject);
		this.service.postRequest((mHealth.env.healthdata_url + trackerId), hDataObject, null, null, false);
		// this.proxy(this.getJournalData());
	},
	/**
	 *Name: getJournalData
	 *Purpose:  gets the Journal Data using getResponse service call. Called on view my journal click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getJournalData : function() {
		//this.unloadChart();
		var hasMultiValue = false;
		var healthDataResponse = [];
		var trackerId = this.setTrackerId();
		var subHealthDataTypes = [];

		if(this.healthDataTracker == "Blood Pressure") {
			hasMultiValue = true;
			subHealthDataTypes = ['BPS', 'BPD'];
		} else if(this.healthDataTracker == "Cholesterol") {
			hasMultiValue = true;
			subHealthDataTypes = ['LDL', 'HDL', 'Cholesterol', 'Triglycerides'];
		} else if(this.healthDataTracker == "Weight & BMI") {
			hasMultiValue = true;
			subHealthDataTypes = ['Weight', 'BMI'];
		}
		if(hasMultiValue === false) {
			healthDataResponse = this.getHealthTrackerData(trackerId);
		} else {
			for(var i = 0; i < subHealthDataTypes.length; i++) {
				healthDataResponse = healthDataResponse.concat(this.getHealthTrackerData(subHealthDataTypes[i]));
			}
		}
		if(healthDataResponse != null) {
			sortedData = this.getSortedData(healthDataResponse);
			this.trackerData = this.getFormattedData(sortedData);
			$.mobile.changePage("showjournal.html");

		} else {
			mHealth.util.showMask();
			if(hasMultiValue === false) {
				var URL = mHealth.env.healthdata_url + trackerId + "?maxdays=45";
				this.service.getResponse(URL, this.proxy(this.processHealthData), this.proxy(this.getJournalFailure), true);
			} else {

				for(var i = 0; i < subHealthDataTypes.length; i++) {
					var URL = mHealth.env.healthdata_url + subHealthDataTypes[i] + "?maxdays=45";
					this.service.getResponse(URL, this.proxy(this.processHealthData), null, false);

				}
			}
		}
		return;
	},
	processHealthData : function(output) {

	},
	getHealthTrackerData : function(healthDataType) {
		var healthDataResponse = [];
		var modelResponse = mHealth.models.HealthDataModel.findAllByAttribute("healthDataType", healthDataType);
		modelResponse.map(function(response) {
			healthDataResponse.push(response);
		});
		return healthDataResponse;
	},
	setHealthData : function(output) {
		var response = JSON.parse(output.responseText);
		var modelData = JSON.stringify(response);
		mHealth.models.HealthDataModel.customFromJSON(modelData);
	},
	/**
	 *Name: getSortedData
	 *Purpose: sorts the health data based on measurement date.
	 *Params: health data to be sorted is passed as param
	 *Returns: returns the sorted health data
	 **/
	getSortedData : function(healthData) {
		var keys = [];
		var sortedData = [];
		for(var i in healthData) {
			keys[i] = [];
			keys[i][0] = healthData[i]["measurementDate"];
			keys[i][1] = i;

		}
		keys.sort();
		keys.reverse();

		for(var i in keys) {
			sortedData.push(healthData[keys[i][1]]);
		}
		return sortedData;
	},
	/**
	 *Name: getFormattedData
	 *Purpose:  formats the sorted health data to key value pairs based on measurement date.
	 *Params: takes sorted health data as parameter
	 *Returns: returns the formatted hash object
	 **/
	getFormattedData : function(sortedData) {
		var healthDataObjects = new Object();
		var len = sortedData.length;
		var child = new Object();
		if(this.healthDataTracker == 'A1c' || this.healthDataTracker == 'Blood Glucose' || this.healthDataTracker == 'Microalbumin' || this.healthDataTracker == 'Foot Exam - Provider' || this.healthDataTracker == 'Dilated Retinal Exam' || this.healthDataTracker == 'Foot Exam - Self') {
			for(var i = 0; i < len; i++) {
				child = new Object();
				child['measurementDate'] = sortedData[i]['measurementDate'];
				child['value'] = sortedData[i]['value'];
				child['comments'] = sortedData[i]['comments'];
				healthDataObjects[sortedData[i].measurementDate] = child;
			}
		} else {
			var key;
			for(var i = 0; i < len; i++) {
				key = sortedData[i].measurementDate;
				if(healthDataObjects.hasOwnProperty(key)) {
					if(child['measurementDate'] == key)
						child[sortedData[i].healthDataType] = sortedData[i].value;
				} else {
					child = new Object();
					child['comments'] = sortedData[i].comments;
					child['measurementDate'] = sortedData[i].measurementDate;
					child[sortedData[i].healthDataType] = sortedData[i].value;
				}
				healthDataObjects[key] = child;
			}
		}
		return healthDataObjects;
	},
	/**
	 *Name: getJournalFailure
	 *Purpose: Failure callback function for get journal data.
	 *Params: Implicit callback function params
	 *Returns:: Doesn't return
	 **/
	getJournalFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.hideMask();
	},
	/**
	 *Name: setGlucoseTracker
	 *Purpose: Opens detailtracker.html when blood glucose icon is clicked on home page. sets the healthDataTracker to Blood Glucose.
	 *Params: No params
	 *Returns::
	 **/
	setGlucoseTracker : function() {
		this.healthDataTracker = 'Blood Glucose';
		location.href = "tabbar://loadTrackers?";
		$.mobile.changePage('../../trackers/view/detailtracker.html');
	},
	/**
	 *Name: viewNewEntry
	 *Purpose: changes page to showtrackertrack.html or profile.html based on trackertype and participant height value.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	viewNewEntry : function() {
		if(this.healthDataTracker == "Weight & BMI") {
			var participant = mHealth.models.ParticipantModel.first();
			if(participant) {
				if(participant.height == "" || participant.height == undefined) {
					mHealth.util.heightFlag = false;
					location.href = "tabbar://loadHome?";
					$.mobile.changePage('../../home/view/profile.html');
				} else {
					$.mobile.changePage('showtrackertrack.html');
				}
			} else
				mHealth.util.customAlert(mHealth.TrackerBmi.enterHeightError, 'mHealth');
		} else
			$.mobile.changePage('showtrackertrack.html');
	},
});
