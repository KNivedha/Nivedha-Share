ParticipantAnswer = Spine.Model.sub();
ParticipantAnswer.Configure('ParticipantAnswer','participantId','assessmentId','sectionId','questionId',
		'answerId','origin','language','answerValue1','answerValue2','comments','longitude','latitude',
		'location','imageResponse','createTimestamp','updateTimestamp','recordingTimestamp','dirty',
		'entryType','indicatorValue');

