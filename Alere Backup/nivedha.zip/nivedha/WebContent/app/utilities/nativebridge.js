/**
 * Native Functions
 **/

/**
 * Name    : setCalendarEvent
 * Purpose : Method to call the native calendar
 * Params  : Start Date, End Date, Title
 * Returns : dateString
 **/
mHealth.util.callCalendar = function(title, sDate, eDate) {
	location.href = "cal://setEvent?eventTitle=" + title + "&startDate=" + sDate + "&endDate=" + eDate;
};
/**
 * Name   : sendEmail
 * Purpose: Method to send email.
 * Params : --
 * Return : --
 **/
mHealth.util.sendEmail = function(to, toCopy, subject) {
	nativeCommunication.callNativeMethod("email://sendEmail?mailto=" + to + "&cc=" + toCopy + "&subject=" + subject);
	$('.ui-btn-active').not('.ui-li-divider').removeClass('ui-btn-active');
};
/**
 * Name   : callNativeBarEvent
 * Purpose: Method to call native bars on login
 * Params : --
 * Return : --
 **/
mHealth.util.callNativeBar = function() {
	location.href = "tabbar://login?";
},
/**
 * Name   : removeNativeBarEvent
 * Purpose: Method to remove native bars on logout
 * Params : --
 * Return : --
 **/
mHealth.util.removeNativeBar = function() {
	location.href = "tabbar://logout?";
};
/**
 * Name   : getDeviceFeatures
 * Purpose: Method to get the device feature like version,device id,...
 * Params : --
 * Return : Device features like version,device id,...
 **/
mHealth.util.getDeviceFeatures = function() {
	location.href = "about://getdevicefeatues?";
};
/**
 * Name   : loadHomeBar
 * Purpose: Method to hightlight home tab
 * Params : --
 * Return : --
 **/
mHealth.util.loadHomeBar = function() {
	location.href = "tabbar://loadHome?";
};
/**
 * Name   : loadMessageBar
 * Purpose: Method to hightlight Message tab
 * Params : --
 * Return : --
 **/
mHealth.util.loadMessageBar = function() {
	location.href = "tabbar://loadMessages?";
};
/**
 *Call back of native functions
 **/

/**
 * Name   : loadHome
 * Purpose: Callback method of native tabbar
 * Params : --
 * Return : --
 **/
loadHome = function() {
	$.mobile.changePage("../../home/view/home.html");
};
/**
 * Name   : loadActivities
 * Purpose: Method to call Activities web view on clicking the activities tab
 * Params : --
 * Return : --
 **/
loadActivities = function() {
	//mHealth.controllers.ActivityController.trigger('getservice');
	//  $.mobile.showPageLoadingMsg();
	mHealth.ActivityControllerObject.getActivity();
	// $.mobile.changePage("../../activities/view/showactivity.html");

};
/**
 * Name   : loadMessages
 * Purpose: Method to call Messages web view on clicking the messages tab
 * Params : --
 * Return : --
 **/
loadMessages = function() {
	$.mobile.changePage("../../messages/view/showmessage.html");
};
/**
 * Name   : loadTrackers
 * Purpose: Method to call trackers web view on clicking the trackers tab
 * Params : --
 * Return : --
 **/
loadTrackers = function() {
	$.mobile.changePage("../../trackers/view/showtracker.html");
};
sessionExpired = function() {
	$('#loginPage').remove();
	mHealth.util.removeNativeBar();
	mHealth.MessageControllerObject.tabbarloaded = false;
	//mHealth.models.AnswerModel.destroyAll();
	//mHealth.models.ParticipantAnswerModel.destroyAll();
	mHealth.models.ConditionModel.destroyAll();
	mHealth.models.MessageModel.destroyAll();
	mHealth.models.MedicationModel.destroyAll();
	mHealth.models.ParticipantModel.destroyAll();
	//mHealth.models.SpaceModel.destroyAll();
	//mHealth.models.ViewModel.destroyAll();
	//mHealth.models.ZoneModel.destroyAll();
	mHealth.models.HealthDataModel.destroyAll();
	$.mobile.changePage("../../rootview/view/login.html", {
		data : {
			splashMessage : mHealth.SettingsController.sessionTimeoutLogout
		}
	});
};
/**
 * Name   : currentOrientationGraph
 * Purpose:
 * Params : --
 * Return : --
 **/
currentOrientationGraph = function(orientation) {
	if(orientation == 'portrait') {
		mHealth.GraphControllerObject.plotOptions.xaxis.labelWidth = 0;
	} else if(orientation == 'landscape') {
		mHealth.GraphControllerObject.plotOptions.xaxis.labelWidth = -25;
	}
};
/**
 * Name   : currentOrientation
 * Purpose:
 * Params : --
 * Return : --
 **/
currentOrientation = function(orientation) {

	if($('body').children().is('#tandcPage') == true) {

		mHealth.util.tcScroll.scroll.stop();

		if(!viewSize[getOrientation()]) {
			viewSize[getOrientation()] = $('#tc').height();
		}

		$('#tandcPage').css({
			'height' : '100%'
		});

	} else {

		$('.ui-page-active').css({
			'height' : document.height
		});

	}

	if(orientation == 'portrait') {
		if($('body').children().is('#tandcPage') == true) {

			$('#tc').height(7400);
			mHealth.util.tcScroll.refresh();

		}

		$('.alertable').css({
			'height' : '460px',
			'width' : '320px'
		});
		$('.back_container').css({
			'height' : '460px',
			'width' : '320px',
			'top' : document.body.scrollTop + 'px'
		});
		$('.ui-alert-wallpaper').css({
			'height' : '460px',
			'width' : '320px',
			'top' : document.body.scrollTop + 'px'
		});

	}

	if(orientation == 'landscape') {
		if($('body').children().is('#tandcPage') == true) {
			$('#tc').height(5240);
			mHealth.util.tcScroll.refresh();

		}
		$('.alertable').css({
			'height' : '300px',
			'width' : '480px'
		});
		$('.back_container').css({
			'height' : '300px',
			'width' : '480px',
			'top' : document.body.scrollTop + 'px'
		});
		$('.ui-alert-wallpaper').css({
			'height' : '300px',
			'width' : '480px',
			'top' : document.body.scrollTop + 'px'
		});

	}
	if($('.ui-page-active').attr('id') == "multiplehealthdatapage" || $('.ui-page-active').attr('id') == "singlehealthdatapage") {
		mHealth.GraphControllerObject.drawMultipleHealthDataGraph();
		$('#daybutton').click(function() {
			mHealth.GraphControllerObject.dayButtonClick();
		});
		$('#weekbutton').click(function() {
			mHealth.GraphControllerObject.weekButtonClick();
		});
		$('#monthbutton').click(function() {
			mHealth.GraphControllerObject.monthButtonClick();
		});
		$('#showLabel').click(function() {
			mHealth.GraphControllerObject.showLabels();
		});
		$('#previousbutton').click(function() {
			mHealth.GraphControllerObject.previousButton();
		});
		$('#nextbutton').click(function() {
			mHealth.GraphControllerObject.nextButton();
		});
		$('#yearbutton').click(function() {
			mHealth.GraphControllerObject.yearButtonClick();
		});
		if(mHealth.GraphControllerObject.showLabel) {
			mHealth.GraphControllerObject.showLabel = false;
			mHealth.GraphControllerObject.showLabels();
		}
	}
};
/**
 * Name   : loadSettings
 * Purpose: Method to call setings web view on clicking the settings tab
 * Params : --
 * Return : --
 **/
loadSettings = function() {
	$.mobile.changePage("../../settings/view/index.html");
};
