  mHealth.Alfresco =
  {
    contentUnavailable : "We're sorry but the content you were trying to view is currently unavailable."
  }
  
  // Assessment Start
  
  mHealth.Assessment =
  {
    noAssessments  : "You've joined all activities that are currently available. Stay with it!",
    join           : "Join",
    myAct          : "Activities",
    myRecomm       : "Recommended",
    plsLogin       : "Please login.",
    inProgress     : "In Progress",
    description    : "Description",
    credits        : "Credits",
    maxCredit      : "Max Credit",
    earnedCredit   : "Earned Credit",
    earned         : "Earned!",
    learnMore      : "Learn More",
    infoUnavailable : "We're sorry but the information page is currently unavailable.",
    pageMissingOrUnsupported : "We're sorry but the page requested is currently unavailable or not supported on your platform.",
    assessmentNotFound : "We're sorry but the activity you were trying to view is currently unavailable at this time."
  }

 //Assessment END

    mHealth.CalendarMonth ={
    January:"January",
    February:"February",
    March:"March",
    April:"April",
    May:"May",
    June:"June",
    July:"July",
    August:"August",
    September:"September",
    October:"October",
    November:"November",
    December:"December"
  }

  // GUI Helper START

  // TODO These shouldn't be in the localization file
  //time class string formats
  mHealth.GuiHelper =
  {
  	alerttitle :"Mya",
    datetime : "%m/%d/%Y %I%M %p",
    date : "%m/%d/%Y",
    time : "%I%M %p",
    monthday : "%b %d", //Jan 19
    monthyear : "%B - %Y", //January 2011
    monthdayyear : "%b %d, %Y", //Jan 19, 2011
    datetimepicker : "%A, %b %d, %Y" //Wednesday, January 19, 2011
  }

  // GUI Helper END

  // MyDevices START
  mHealth.MyDevicesIndex =
  {
    myDevices        : "My Devices",
    add              : "Add",
    addDevice        : "Add Device",
    scale            : "Scale",
    bpm              : "Blood Pressure Monitor",
    lastConnected    : "Last Connected",
    linkWarning      : "You might need to link this device again.",
    noDevices        : "No devices have been linked",
    back             : "Back",
    popupMessage     : "To receive measurements Bluetooth must be on.  Turn Bluetooth on?",
    popupTitle       : "Turn Bluetooth On?",
    yes              : "Yes",
    no               : "No",
    notSupported     : "My Devices is not supported on your device.",
    turnBluetoothOn  : "Turn on Bluetooth",
    warningBluetoothOff : "Bluetooth must be on."
  }

  mHealth.MyDevicesAdd =
  {
    addDevice        : "Add Device",
    back             : "Back",
    next             : "Next",
    done             : "Done",
    addAnother       : "Add Another Device",
    selectDevice     : "What device do you want to use?",
    fairbanksScale   : "Fairbanks Scale",
    myglucohealthMeter : "MyGlucoHealth Glucose Meter",
    andScale           : "AND Weight Scale",
    andBloodPressure   : "AND Blood Pressure",
    withingsAccount    : "Withings Account",
    withingsWeightScale : "Withings Weight Scale",
    withingsBpMonitor   : "Withings Blood Pressure Monitor",
    fitbit              : "Fitbit",
    tryAgain             : "Try Again",
    makeDiscoverable   : "Make your phone discoverable",
//    makeDiscoverableDirections : "Your phone must be discoverable for the <span class='deviceName'></span> to connect.  After you tap next, a
//            &quot;Bluetooth permission request&quot; will open asking you make your phone discoverable by other devices.  When
//            asked, please answer yes.<br/>Tap next to continue.",
    makeDiscoverableButton     : "Make Discoverable",
    myglucohealthDiscoverable  : "Press the up arrow on your MyGlucoHealth glucose meter.",
    myglucohealthDiscoverableDetails : "Push the up button on your MyGlucoHealth glucose meter.<br/>After you push the up button, tap next to continue.",
    myglucohealthSearching           : "Attempting to Connect",
    myglucohealthSearchingDetails    : "The screen on your MyGlucoHealth glucose meter should show a number that is counting up.<br/>Please wait while we work on the connection.",
    myglucohealthNotFound            : "MyGlucoHealth was not found",
    myglucohealthNotFoundDetails     : "We were unable to find the MyGlucoHealth glucose meter.  Please follow these next few steps to see if we can get it connected.",
    myglucohealthPowerOff            : "Turn off your MyGlucoHealth",
    myglucohealthPowerOffDetails     : "Press the power button (the center button) to turn off your MyGlucoHealth meter.",
    myglucohealthFailure             : "Unable to connect",
    myglucohealthFailureDetails      : "Sorry, we were unable to connect to your MyGlucoHealth glucose meter. Please contact support for further assistance.",
    makeDiscoverablePopupDetails     : "Your phone is not discoverable.  Please tap the &quot;Make Discoverable&quot; button below to make your phone discoverable.",
    notDiscoverableDetails           : "Your phone is no longer discoverable.  Please tap the &quot;Make Discoverable&quot; button below to make your phone discoverable.",
    myglucohealthSuccess             : "Success - MyGlucoHealth Added",
//    myglucohealthSuccessDetails      : "Your MyGlucoHealth glucose meter has been added.
//            All measurements stored in your MyGlucoHealth glucose meter have been transfered.<br/>To transfer
//            future measurements follow these directions.<br/>
//            <div style='margin-top2px; margin-left5px;'>
//              1. Start the Alere mHealth application.<br/>
//              2. Press the down arrow (right button) on your MyGlucoHealth glucose meter.<br/>
//              3. Your phone and your MyGlucoHealth glucose meter will connect and transfer any new measurements.<br/>
//            </div>",
    connectionSuccess                : "Success - <span class='deviceName'></span> Added",
//    connectionSuccessDetails         : "Your <span class='deviceName'></span> has been linked to your phone.
//            To transfer future measurements follow these directions.<br/>
//            <div style='margin-top2px; margin-left5px;'>
//              1. Start the Alere mHealth application.<br/>
//              2. Take a measurement.<br/>
//              3. Your phone and <span class='deviceName'></span> will automatically connect and transfer the new measurement.<br/>
//            </div>",
    measurements         : "Measurements",
    withingsEmail        : "Email",
    withingsPassword     : "Withings Password",
    withingsSetupAccount : "Setup Withings Account",
    withingsSetupAccountDirections   : "Follow the directions included with your Withings Scale to create a Withings account and setup your scale.  You will need to use the email address and password used for your Withings account.",
    withingsAccountInfo      : "Enter Your Withings Account Info",
    withingsAccountError : "Withings returned an error when we tried to connect with this account information. Please check your email and password and try again.",
    withingsCommunicating    : "Communicating with Withings",
    withingsVerifingDetails  : "We are getting your Withings account information.",
    withingsSelectUser       : "There is more than one person sharing your Withings account.<br/><br/>Please select yourself from the list below.",
    withingsGettingMeasurements  : "Please wait while we are fetching your measurements from Withings.",
    withingsCommError            : "Unable to connect to Withings",
    withingsCommErrorDetails     : "We were unable to connect to Withings.  If we are still unable to connect please wait until later.",
    withingsSuccess              : "Success - Measurements Imported",
    withingsSuccessDetails       : "Your measurements have been successfully imported from Withings.  Continue to use your scale and the measurements will automatically be imported.",
    withingsDuplicateFound       : "No new measurements were imported because the most current measurement we received from Withings has already been imported."

  }

  mHealth.MyDevicesLink =
  {
    linkDevice        : "Link Device",
    back             : "Back",
    link             : "Link New Device",
    scale            : "Scale",
    bpm              : "Blood Pressure Monitor",
    lastConnected    : "Last Connected",
    noDevices        : "No devices have been connected",

    kilograms        : "kg.",
    save             : "Save"
  }

  //MyDevices END

  // PersonalInfo START

  // TODO Should phone_pattern be in here? It's not a localized value, is it?
  mHealth.PersonalInfo =
  {  	
    personalInfo     : "Personal Info",
    profile			 : "Profile",
    profileInfo      : "Please advise your health plan should there be any incorrect information.",
    back             : "Back",
    goalWeight       : "Goal Weight",
    height           : "Height",
    units            : "Units",
    pounds           : "lbs.",
    kilograms        : "kg.",
    save             : "Save",
    phone            : "Phone",
    phone_pattern    : '^(?(?\+?1\s*(?[.-]\s*)?)?(?\(\s*([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9])\s*\)|([2-9]1[02-9]|[2-9][02-8]1|[2-9][02-8][02-9]))\s*(?[.-]\s*)?)?([2-9]1[02-9]|[2-9][02-9]1|[2-9][02-9]{2})\s*(?[.-]\s*)?([0-9]{4})(?\s*(?//|x\.?|ext\.?|extension)\s*(\d+))?$'
  } 

  // PersonalInfo END

  // Section START

  mHealth.Section =
  {
    invalidDate      : "Invalid Date",
    dateOutOfRange   : "Date selected can't be greater than today's date.",
    pastInvalid      : "You can't record info for dates outside of this activity's range.",
    futureInvalid    : "You can't record info for dates in the future. Please try again.",
    ok               : "Ok",
    info             : "Info",
    join             : "Join",
    back             : "Back",
    information      : "Information",
    noFeedbackRequired   : "There is no feedback needed for this day.",
    home                 : "Home",
    save                 : "Save",
    prev             : "Prev",
    next             : "Next",
    finish           : "Finish",
    dateTimePickerTitle       : "Select Date/Time",
    datePickerTitle : "Select Date",
    timePickerTitle : "Select Time",
    //congratulations  : "Congratulations", //  Congratulations <first name>! 
    //youcompleted     : "You've completed the", //  You've completed the <activity title>!
    of               : "of"
  }
  // Section END
  
  // Settings START

  mHealth.SettingsAbout =
  {
    back              : "Back",
    version           : "Version",
    registeredUser    : "Registered User",
    lastSync          : "Last Sync",
    platform          : "Platform",
    deviceName        : "Device Name",
    deviceModel       : "Device Model",
    uniqueIdentifier  : "Unique Identifier",
    devicePhoneNumber : "Device Phone Number",
    deviceClientId    : "Device Client Id",
    title             : "About"
  }
  
  mHealth.SettingsController =
  {
  	timeOut                : "timeout",
  	unauthorized           : "Unauthorized",
    msgPleaseLogin         : "Please Login",
    msgErrorCommunication  : "An error occurred while communicating with the server.",
    msgBadLogin            : "Invalid login credentials.",
    msgLogout              : "You have been logged out.",
    msgDatabaseReset       : "Database has been reset.",
    msgDatabaseSync        : "Sync has been triggered.",
    msgDisplayInfo         : "Display personal info.",
    msgConnectTryAgain     : "You are not currently connected to the Internet. If you have an account, please connect to the Internet and restart the application.",
    errNetwork             : "The connection was lost while communicating with the server.",
    errUnknownClient       : "Your current session could not be validated. You have been logged out.",
    errTimeout             : "We are currently unable to connect to the server, please try again later.",
    errMissingData         : "We seem to be missing some of the data that is required, please login again.",
    logoutConfirm          : "Are you sure you want to logout?",
    sessionTimeoutPopupTitle : "Session Timeout",
    sessionTimeoutLogout : "For your security, after 15 minutes of inactivity your session has timed out."
  }
 
  mHealth.SettingsIndex =
  {
    settings             : "Settings",
    logout               : "Logout",
    login                : "Login",
    personalInformation  : "Personal Information",
    about                : "About",
    emailFeedback        : "Send Feedback",
    myDevices            : "My Devices"
  }
  
  mHealth.SettingsLogin =
  {
    back                 : "Back",
    title                : "Please Login",
    username             : "User ID",
    password             : "Password",
    termsAndConditions   : "You must accept terms and conditions",
    token                : "Token",
    clientAccess         : "Client Access",
    email                : "service.desk@alere.com",
    emailTitle           : "Alere mHealth",
    logout               : "You have been logged out", 
  }

  
  mHealth.SettingsReset =
  {
    resetDatabase        : "Reset Database",
    cancel               : "Cancel",
    confirm              : "Confirm",
    verify               : "Are you sure?",
    warning              : "Resetting removes all objects from your device."
  }
  
  mHealth.SettingsWait =
  {
    pleaseWait           : "Please Wait"
  }
  
  mHealth.SyncProcessController =
  {
    msgPleaseLogin         : "Please Login",
    msgErrorCommunication  : "An error occurred while communicating with the server.",
    msgBadLogin            : "Invalid login credentials.",
    msgLogout              : "You have been logged out.",
    msgDatabaseReset       : "Database has been reset.",
    msgDatabaseSync        : "Sync has been triggered.",
    msgDisplayInfo         : "Display Personal Info.",
    msgConnectTryAgain     : "You are not currently connected to the Internet. If you have an account, please connect to the Internet and restart the application.",
    msgOfflineMode         : "You are not currently connected to the Internet. Any entries you make will not be saved until you connect to the Internet."
  }
  
  // Settings END
  
  // Trackers - START
  
  mHealth.TrackerBmi = 
  {
    currentWeight      : "Current Weight",
    goalWeight         : "Goal Weight",
    currentBmi         : "Current BMI",
    bmiDefinition      : "BMI = Body Mass Index",
    enterWeightError   : "We currently do not have a weight entered for you so we are unable to calculate your BMI.",
    enterHeightError   : "Unable to get Height information to calculate BMI"
  }
  
  mHealth.TrackerGraph =
  {
    week     : "Week",
    month    : "Month",
    year     : "Year",
    title    : "Graph",
    maxDays  : "365"
  }
  
  mHealth.TrackerIndex =
  { 
    Trackers         : "Trackers",
    NoJournalEntries : "There are no journal entries for this tracker.",
    NoTrackers       : "You have not signed up for any trackers.",
    TrackProgressListDivider : "Track your progress!",
    TrackerInfoText : "Use the trackers to keep yourself on target to achieve your goals. Pick a category to get started!"
  }
  
  mHealth.TrackerMenu =
  {
    back                 : "Back",
    track                : "Track My",
    graph                : "Graph My",
    journal              : "View My",
    trackUsingBluetooth  : "Track Using Bluetooth Device"
  }
  
  mHealth.TrackerNewEntry =
  {
    dateTime             : " Select Date ",
    weightLabel          : " Enter Weight ",
    pounds               : "lbs.",
    kilograms            : "kg.",
    recordComments       : "Record successful strategies or trouble spots.",
    commentsLabel        : "Comments",
    bloodPressureLabel   : "Enter Blood Pressure (Systolic / Diastolic)",
    systolicPlaceholder  : "SYS.",
    diastolicPlaceholder : "DIA.",
    glucoseLabel         : "Enter Glucose ",
    glucosePlaceholder   : "mg/dl",
    peakFlowLabel        : "Enter Peak Flow ",
    peakFlowPlaceholder  : "L / min",
    defaultLabel         : "Enter",
    bilateralAmputation  : "Bilateral Amputation",
    yesBilatAmp          : "Yes",
    noBilatAmp          :  "No",
    microalbuminLabel    : "Enter Microalbumin",
    existingData		 : "Data exist for Selected Date and Time",
    dropdownOption1      : "I have never had the test completed",
    dropdownOption2      : "I have had the test but don&apos;t remember the values",
    dropdownOption3      : "I had the test, remember the approximate date it was done and the result",
    dropdownOption4      : "I have had the test and remember approximately the date it was completed"

  }

  mHealth.TrackerDate =
  {
    futureInvalid    : "Date selected can't be greater than today's date."
  }
  
  mHealth.Login = {
  		msgEmptyField : "Invalid user ID / password combination",
  		emptyCredentials : "Invalid login credentials"
  }
 
  mHealth.TrackerJournal =
  {
    noComment : "There was no comment recorded for this entry.",
    title     : "Journal",
    track     : "Track"
  }
  // Trackers - END

  mHealth.RootView = {
    nothingToInteract : "There is nothing for you to interact with at this time."
  }

  mHealth.Exception = {
    exception :"Exception",
    exceptionTxt : "The Exception is in",
    errorTitle : "System Error",
    errorMsg : "An error has occurred and the system administrator has been notified. We apologize for the inconvenience.",
    errorActionLbl : "Click here to go to the start page"
  }

  
   mHealth.RoundAboutIndex = {
    bloodGlucose : "Blood Glucose",
    bloodPressure : "Blood Pressure",
    weightAndBmi : "Weight and BMI",
    a1c :"A1c",
    cholesterol : "Cholesterol",
    exams :"Exams",
    trackers : "Trackers"
  }
 mHealth.TrackerActionSheet = {
   date : "Date",
   bloodGlucose : "Blood Glucose",
   journal :"Journal",
   save : "Save",
   trackGlucose : "Track Glucose",
   healthType : "HealthType"
  }
  mHealth.JournalActionSheet = {
    recordYourComments : "Record your Journal Entries",
    yourText : "Your Text Appears Here",
    journalDate : "10/11/2011 12.24 PM",
    journalDates : "11/12/2011 1.37 PM"
    
  }

  mHealth.Validation = {
  	emailValidation  : "Please enter valid email address.",
  	invalidDate : "Start date should not be greater than end date",
    invalidAssessment : "Please answer all questions",
    invalidFirstQuesAssessment : "Please answer the first question",
    invalidSecondQuesAssessment : "Please answer the second question",
    invalidThirdQuesAssessment : "Please answer the third question",
    invalidWeight : "Please enter your current weight ",
    invalidNumber : "We didn't recognize one of your responses. Please try again and be sure to enter numbers where indicated.",
    generic : "You are missing a required field. Please try again.",
    invalidGoalWeight : "Please enter in a goal weight",
    invalidBloodPressure : "Please enter your blood pressure",
    invalidGlucose : "Please enter your blood sugar",
    invalidPeakFlow : "Please enter your peak flow",
    invalidBMI :"Please enter your BMI",
    invalidA1C :"Please enter your A1C",
    invalidCARB :"Please enter your Carbohydrates",
    invalidCAL :"Please enter your Calories",
    invalidEM :"Please enter your Exercise Minutes",
    invalidES :"Please enter your Exercise Steps",
    invalidED :"Please enter your Exercise Distance",
    invalidPin : "Invalid Pin",
    invalidA1CErr :"Please enter A1c between 3.2 & 15",
    invalidBGErr :"Please enter Blood Glucose between 20 & 600",
    invalidBPSysErr : "Please enter Blood Pressure between 50 & 230",
    invalidBPDiaErr : "Please enter Blood Pressure between 35 & 140",  
    data_out_of_range : "Data entered is out of range, please correct and tap on Save button",
    invalidLDLErr : "Please enter LDL value between 50 & 500",  
    invalidHDLErr : "Please enter HDL value between 10 & 120",  
    invalidCholesterolErr : "Please enter Cholesterol value between 75 & 600"   
  }
  
  mHealth.MedicalHistory = {
    title : "Medical History",
    info  : "Provider Info",
    provider : "Health Care Provider",
    medications_tab_title : "Medications",
    conditions_tab_title  : "Conditions"
  }
  
  mHealth.Medication = {
    title : "Medication Info",
    name : "Drug Name",
    dosage  : "Dosage",
    route : "Route",
    frequency  : "Frequency",
    source : "Source",
    therapy_class : "Therapy Class",
    entered_date : "Entered Date",
    type : "Type",
    lastfilldate : "Last Fill Date",
    lastsource : "Last Source",
    lastupdated : "Last Updated",
    startdate : "Start Date",
    strength : "Strength",
    strengthandunit : "Strength and Unit",
    strengthunit : "Strength Unit",
    medicationtype : "Medication Type",
    enddate : "End Date",
    currentroute : "Current Route",
    currentform : "Current Form",
    currentdosage : "Current Dosage"
 }

  mHealth.HealthData= {
    title : "Health Data",
    pxcreateddt : "PX Created Datetime",
    source : "Source",
    value : "Value"

  }

                     
  mHealth.Condition = {
    title : "Conditions",
    name  : "Condition Name",
    managed : "Managed?",
    source  : "Source",
    start_date : "Start Date",
    currentCondtion : "Current Conditions",
    diagnosis : "Condition",
    diagnosisDate : "Diagnosis Date",
    add : "Add",
    dataNotAvailable : "Data Not Available",
    condition : "Condition",
    subCondition : "Sub-Condition",
    addCondition : "Add Condition",
    save : "Save",
    back : "Back",
    conditionStatusErrMssg : "Please select Status",
    conditionErrMssg : "Please select Condition",
    informationErrMsg : "Information not available"
      
  }

  mHealth.HttpError ={
    http400 : '400 Bad request for %s. The request had bad syntax or was inherently impossible to be satisfied.',
    http401 : '401 Unauthorized for %s. The parameter to this message gives a specification of authorization schemes which are acceptable. The client should retry the request with a suitable Authorization header.',
    http402 : '402 PaymentRequired for %s. The parameter to this message gives a specification of charging schemes acceptable. The client may retry the request with a suitable ChargeTo header.',
    http403 : '403 Forbidden for %s. The request is for something forbidden. Authorization will not help.',
    http404 : '404 Error for %s. The server has not found anything matching the URI given',
    http500 : '500 Internal Error for %s. The server encountered an unexpected condition which prevented it from fulfilling the request.',
    http501 : '501 Not implemented for %s. The server does not support the facility required.',
    httperror:'Server Error for %s'
    }


