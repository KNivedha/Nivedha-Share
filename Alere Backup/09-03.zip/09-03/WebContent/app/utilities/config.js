//uat
//licensefile: settings/license.key
mHealth = {};
mHealth.models = {};
mHealth.controllers = {};
mHealth.environment= null; //Setting the Environment 
mHealth.service_timeout =100000;//10000 milliseconds = 10 seconds
mHealth.pegadateformat ='yyyymmdd"T"HHMMss".000 GMT"';
mHealth.dateformat ='yyyymmdd'
mHealth.uat = {
	authtoken_get_url : "https://secure.uat.alerehealth.com:13086/api/gettoken",
	authtoken_validate_url : "https://secure.uat.alerehealth.com:13086/api/valtoken",
	healthdata_url : "https://secure.uat.alerehealth.com:13086/api/healthdata/",
	medicaldevices_url : "https://secure.uat.alerehealth.com:13086/api/medicaldevices/",
	message_get_url : "https://secure.uat.alerehealth.com:13086/api/welcome/",
	medication_url : "https://secure.uat.alerehealth.com:13086/api/medications/",
	condition_url : "https://secure.uat.alerehealth.com:13086/api/conditions/",
	assessment_json_url : "https://secure.uat.alerehealth.com:13086/api/assessment/",
	challenge_json_url : "https://secure.uat.alerehealth.com:13086/api/challenge/",
	challenge_details_url:"https://secure.uat.alerehealth.com:13086/api/challengedetails/",
	recommendation_json_url : "https://secure.uat.alerehealth.com:13086/api/recommendation/",
	event_json_url : "https://secure.uat.alerehealth.com:13086/api/events/",
	searchcondition_url : "https://secure.uat.alerehealth.com:13086/api/conditions/search",
    searchindexcondition_url: "https://secure.uat.alerehealth.com:13086/api/masterconditions?filter=",
    profile_url: "https://secure.uat.alerehealth.com:13086/api/profile/",
	dcpappname : 'Mobile Main',
    emailTo : "ameya.thakur@alere.com",
    emailCC : "Scott.Miller@alere.com,Anna.Risman@alere.com,Mark.Mcnally@alere.com",
    emailSubject : "Feedback from MYA UAT",
    messageheaders_url : "https://secure.uat.alerehealth.com:13086/api/mc/message-headers",
    messagedetails_url : "http://secure.uat.alerehealth.com:13085/api/mc/messages/",
    messagefeedback_url : "http://secure.uat.alerehealth.com:13085/api/mc/user-feedback",
    healthwise_url: "http://secure.uat.alerehealth.com:13085/api/health-articles/",
    registration_url: "https://portal.uat.alerehealth.com/portal/MobileRegistration?keycode="
};

mHealth.dev = {
	authtoken_get_url : "http://secure.uat.alerehealth.com:13085/api/gettoken",
	authtoken_validate_url : "http://secure.uat.alerehealth.com:13085/api/valtoken",
	healthdata_url : "http://secure.uat.alerehealth.com:13085/api/healthdata/",
	medicaldevices_url : "http://secure.uat.alerehealth.com:13085/api/medicaldevices/",
	message_get_url : "http://secure.uat.alerehealth.com:13085/api/welcome/",
	condition_url : "http://secure.uat.alerehealth.com:13085/api/conditions/",
	medication_url : "http://secure.uat.alerehealth.com:13085/api/medications/",
	assessment_json_url : "http://secure.uat.alerehealth.com:13085/api/assessment/",
	challenge_json_url : "http://secure.uat.alerehealth.com:13085/api/challenge/",
	challenge_details_url:"http://secure.uat.alerehealth.com:13085/api/challengedetails/",
	recommendation_json_url : "http://secure.uat.alerehealth.com:13085/api/recommendation/",
	event_json_url : "http://secure.uat.alerehealth.com:13085/api/events/",
	searchindexcondition_url: "http://secure.uat.alerehealth.com:13085/api/masterconditions?filter=",
	profile_url: "http://secure.uat.alerehealth.com:13085/api/profile/",
    dcpappname : 'Mobile Main',
    emailTo : "ameya.thakur@alere.com",
    emailCC : "Scott.Miller@alere.com,Anna.Risman@alere.com,Mark.Mcnally@alere.com",
    emailSubject : "Feedback from MYA DEV",
    messageheaders_url : "http://secure.uat.alerehealth.com:13085/api/mc/message-headers",
    messagedetails_url : "http://secure.uat.alerehealth.com:13085/api/mc/messages/",
    messagefeedback_url : "http://secure.uat.alerehealth.com:13085/api/mc/user-feedback",
    healthwise_url: "http://secure.uat.alerehealth.com:13085/api/health-articles/",
    registration_url: "https://portal.uat.alerehealth.com/portal/MobileRegistration?keycode="
};
mHealth.prod = {
	authtoken_get_url : "https://secure.alerehealth.com:13087/api/gettoken",
	authtoken_validate_url : "https://secure.alerehealth.com:13087/api/valtoken",
	healthdata_url : "https://secure.alerehealth.com:13087/api/healthdata/",
	medicaldevices_url : "https://secure.alerehealth.com:13087/api/medicaldevices/",
	message_get_url : "https://secure.alerehealth.com:13087/api/welcome/",
	medication_url : "https://secure.alerehealth.com:13087/api/medications/",
	condition_url : "https://secure.alerehealth.com:13087/api/conditions/",
	assessment_json_url : "https://secure.alerehealth.com:13087/api/assessment/",
	challenge_json_url : "https://secure.alerehealth.com:13087/api/challenge/",
	challenge_details_url:"https://secure.uat.alerehealth.com:13087/api/challengedetails/",
	recommendation_json_url : "https://secure.alerehealth.com:13087/api/recommendation/",
	event_json_url : "https://secure.alerehealth.com:13087/api/events/",
    searchindexcondition_url: "https://secure.uat.alerehealth.com:13087/api/masterconditions?filter=",
	profile_url: "https://secure.uat.alerehealth.com:13087/api/profile/",
    dcpappname : 'Mobile Main',
    emailTo : "corpfeedback@alere.com",
    emailCC : "Marivie.Lanter@Alere.com, Becky.Leatherman@Alere.com, Lesley.Brown@Alere.com",
    emailSubject : "Mya",
    messageheaders_url : "https://secure.uat.alerehealth.com:13087/api/mc/message-headers",
    healthwise_url: "http://secure.uat.alerehealth.com:13085/api/health-articles/",
    registration_url: "https://portal.uat.alerehealth.com/portal/MobileRegistration?keycode="
};
mHealth.local = {
	authtoken_get_url : "http://localhost/api/gettoken",
	authtoken_validate_url : "http://localhost/api/valtoken",
	healthdata_url : "http://localhost/api/healthdata/",
	medicaldevices_url : "http://localhost/api/medicaldevices/",
	message_get_url : "http://localhost/api/welcome/",
	condition_url : "http://localhost/api/conditions/",
	medication_url : "http://localhost/api/medications/",
	assessment_json_url : "http://localhost/api/assessment/",
	challenge_json_url : "http://localhost/api/challenge/",
	challenge_details_url:"http://localhost/api/challengedetails/",
	recommendation_json_url : "http://localhost/api/recommendation/",
	event_json_url : "http://localhost/api/events/",
	searchindexcondition_url: "http://localhost/api/masterconditions?filter=",
	profile_url: "http://localhost/api/profile/",
    dcpappname : 'Mobile Main',
    emailTo : "ameya.thakur@alere.com",
    emailCC : "Scott.Miller@alere.com,Anna.Risman@alere.com,Mark.Mcnally@alere.com",
    emailSubject : "Feedback from MYA DEV",
    messageheaders_url : "http://localhost/api/mc/message-headers",
    messagedetails_url : "http://localhost/api/mc/messages/",
    messagefeedback_url : "http://localhost/api/mc/user-feedback",
    healthwise_url: "http://secure.uat.alerehealth.com:13085/api/health-articles/",
    registration_url: "https://portal.uat.alerehealth.com/portal/MobileRegistration?keycode="
};
mHealth.qa = {
	authtoken_get_url : "https://secure.qa.alerehealth.com:13084/api/gettoken",
	authtoken_validate_url : "http://secure.qa.alerehealth.com:13084/api/valtoken",
	healthdata_url : "https://secure.qa.alerehealth.com:13084/api/healthdata/",
	medicaldevices_url : "https://secure.qa.alerehealth.com:13084/api/medicaldevices/",
	message_get_url : "https://secure.qa.alerehealth.com:13084/api/welcome/",
	medication_url : "https://secure.qa.alerehealth.com:13084/api/medications/",
	condition_url : "https://secure.qa.alerehealth.com:13084/api/conditions/",
	assessment_json_url : "https://secure.qa.alerehealth.com:13084/api/assessment/",
	challenge_json_url : "https://secure.qa.alerehealth.com:13084/api/challenge/",
	challenge_details_url:"https://secure.qa.uat.alerehealth.com:13084/api/challengedetails/",
	recommendation_json_url : "https://secure.qa.alerehealth.com:13084/api/recommendation/",
	event_json_url : "https://secure.qa.alerehealth.com:13084/api/events/",
    searchindexcondition_url: "https://secure.qa.uat.alerehealth.com:13084/api/masterconditions?filter=",
	profile_url: "https://secure.qa.uat.alerehealth.com:13084/api/profile/",
    dcpappname : 'Mobile Main',
    emailTo : "ameya.thakur@alere.com",
    emailCC : "Scott.Miller@alere.com,Anna.Risman@alere.com,Mark.Mcnally@alere.com",
    emailSubject : "Feedback from MYA QA",
    messageheader_url : "https://secure.qa.uat.alerehealth.com:13087/api/mc/message-headers",
    healthwise_url: "https://secure.qa.uat.alerehealth.com:13085/api/health-articles/",
    registration_url: "https://portal.uat.alerehealth.com/portal/MobileRegistration?keycode="
};

