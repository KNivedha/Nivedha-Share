//
//  Calendar.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Calendar.h"
#import <EventKit/EventKit.h>
@implementation Calendar
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    NSDate *startdate ;
    NSDate *enddate ;
    
    //***********setting date format*********
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    dateFormatter.dateStyle=NSDateFormatterNoStyle;
    dateFormatter.timeStyle=NSDateFormatterNoStyle;
    [dateFormatter setAMSymbol:@"AM"];
    [dateFormatter setPMSymbol:@"PM"];
	  [dateFormatter setDateFormat:@"yyyy-MM-dd hh:mm:ss a"];
    [dateFormatter setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_GB"] autorelease]];

    
    //*********** setting event store*********
    
    EKEventStore *eventStore = [[EKEventStore alloc] init];
    
    //************adding events****************
    EKEvent *event  = [EKEvent eventWithEventStore:eventStore];
     NSLog(@"storing in calander startdate : %@ enddate : %@",[parameters objectForKey:@"startDate"],[parameters objectForKey:@"endDate"]);
    event.title =[parameters objectForKey:@"eventTitle"] ;
    startdate =[dateFormatter dateFromString:[parameters objectForKey:@"startDate"]];
    enddate = [dateFormatter dateFromString:[parameters objectForKey:@"endDate"]];
    NSLog(@"after formatting in calander startdate: %@ enddate : %@",startdate,enddate);
    event.startDate =  startdate;
    event.endDate   = enddate;
    
    [event setCalendar:[eventStore defaultCalendarForNewEvents]];
    
    NSError *err;
    [eventStore saveEvent:event span:EKSpanThisEvent error:&err];  
}
@end
