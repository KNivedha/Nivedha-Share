/**
 *Controller : ActivityController
 *Controller to do Activity Tab functionality.
 **/

mHealth.controllers.ActivityController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	subActivityView : "",
	activity : null,
	activityDetailRecord : null,
	spaceviewZone : null,
	events : {
		
		'pagebeforeshow #showActivity'     : 'showActivity',
		'click .detailActivity' 		   : 'getSubActivity',
		'pagebeforeshow #detailActivity'   : 'showDetailActivity',
		'pagebeforeshow #calendarPage'     : 'showCalendar',
		'click #calendarSave'              : 'getCalendarData',
		'click #challengesShortCut' 	   : 'getActivity',
		'pagebeforeshow #displayQuestions' : 'showQuestions',
		'pageshow #displayQuestions' 	   : 'processQuestions',
		'pagebeforeshow #assessNotFound'   : 'showNotFoundPage',
		'click #leftArrow' 				   : 'leftButton',
		'click #rightArrow' 			   : 'rightButton',
		'click #infoButton' 			   : 'showdetailactivity',
		'submit #challengeform' 		   : 'submitAssessment',
		'click #saveAssessment' 		   : 'submitAssessment',
		'click #targetButton' 			   : 'showAssessment',
		'change .checkDate' 			   : 'setAssessmentDate'
	
	},
	
	/**
	 *Name 		: getActivity
	 *Purpose 	: if challenge tab found in tabs model, call recommendation service
	 *Params	: --
	 *Returns	: --
	**/
	
	getActivity : function() {
		// var hasChallengeTab = mHealth.models.TabModel.findByAttribute("id", "Challenges");
		// if(hasChallengeTab != undefined && hasChallengeTab != null) {
			if(this.spaceviewZone != null) {
				$.mobile.changePage("../../activities/view/showactivity.html");
				mHealth.util.loadChallengesBar();
			} else {
				mHealth.util.showMask();
				mHealth.util.loadChallengesBar();
				var body = mHealth.recommendation.RecommendationMapper("", "", "1003");
				this.proxy(this.service.postRequest(mHealth.env.recommendation_json_url, body, this.proxy(this.recommendationSuccess), this.proxy(this.recommendationFailure), false));
			}
		//}
	},
	
	/**
	 *Name		: recommendationSuccess
	 *Purpose	: After getting the response from the recommandation Service, the functon will parse the space, View and ZOne
	 			  Set the value in the respective model.
	 *Params	: output
	 *Returns	: null
	**/
	
	recommendationSuccess : function(output) {
		this.proxy(this.setActivityData(output));
		$.mobile.changePage("../../activities/view/showactivity.html");
		mHealth.util.hideMask();
	},
	
	/**
	 *Name 		: recommendationFailure
	 *Purpose	: On the Failure of the recommandation service call, the function will get executed.
	 *Params	: jqXHR, textStatus, errorThrown
	 *Return	: null
	**/
	
	recommendationFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.hideMask();
		mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');
	},
	
	/**
	 * Name     : setActivityData
	 * Purpose  : Method to set the output to SpaceZoneView Model
	 * Params   : the output returned from thr recommendation success
	 * Return   : returms the record from the model with all challenge data
	**/
	
	setActivityData : function(output) {
		var response, recommandationData, spaceData, zoneData, viewData;
		response = output.responseText;
		recommandationData = JSON.parse(response);
		spaceData = JSON.stringify(recommandationData.Space);
		zoneData = JSON.stringify(recommandationData.Zone);
		viewData = JSON.stringify(recommandationData.View);
		this.spaceviewZone = new mHealth.models.SpaceViewZoneModel({
			pageName : mHealth.Assessment.myChallenge,
			space : mHealth.models.SpaceModel.fromJSON(spaceData),
			view : mHealth.models.ViewModel.fromJSON(viewData),
			zone : mHealth.models.ZoneModel.fromJSON(zoneData)
		});
		this.spaceviewZone.save();
		mHealth.ActivityControllerObject.activity = mHealth.models.SpaceViewZoneModel.select(function(record) {
			if(record.pageName === mHealth.Assessment.myChallenge) {
				return record;
			}
		});
	},
	
	/**
	 *Name 		: showActivity
	 *Purpose	: to show the list of challenges available based on the record returned from recommendation success and setActivityData
	 *Params	:
	 *Returns	:
	**/
	
	showActivity : function() {
		$('#activityTitle').text(this.activity[0].space[0].title);
		if(this.activity[0].zone.length > 1) {
			$('#activity_zone').show();
			var activityZone = this.activity[0].zone[0].isInset;
			$('#activity_zone').html(_.template($('#navDataList').html(), activityZone));
		}
		var activityView = this.activity[0].view;
		$('#activity_div').html(_.template($('#activityDataList').html(), {
			activityView : activityView
		}));
		$('#showActivity').trigger('create');
	},
	
	/**
	 *Name		: getSubActivity
	 *Purpose	: On click the View of the challenge, the Function will be called and service call from challenge detail is made
	 *Params	: the clicked event
	 *Returns	:
	**/
	
	getSubActivity : function(event) {
		mHealth.models.QuestionResponsesModel.destroyAll();
		mHealth.models.ChallengeResponseModel.destroyAll();
		var view = event.target;
		var selectedViewName = $(view).parents('li').children('div').children('div').children('a').children('h3').text();
		mHealth.util.selectedChallengeName = selectedViewName;
		mHealth.models.SpaceViewZoneModel.each(function(record) {
			if(record.pageName === mHealth.Assessment.myChallenge) {
				for( i = 0; i < record.view.length; i++) {
					if(record.view[i].title.trim() === selectedViewName.trim()) {
						this.subActivityView = record.view[i];
						mHealth.ActivityControllerObject.activityDetailRecord = this.subActivityView;
						mHealth.ActivityControllerObject.assesssmentName = mHealth.ActivityControllerObject.activityDetailRecord.name;
						break;
					}
				}
			}
		});
		var URL = mHealth.env.challenge_details_url + mHealth.ActivityControllerObject.assesssmentName + '/';
		mHealth.util.showMask();
		this.service.getResponse(URL, this.proxy(this.getChallengeDetailSuccess), this.proxy(this.getChallengeDetailFailure), false);
	},
	
	/**
	 *Name      : showDetailActivity
	 *Purpose	: Detailed challenge view is processed and shown according to the status of the challenge
	 *Params	:
	 *Returns	:
	**/
	
	showDetailActivity : function() {
		var currentDate = mHealth.util.getCurrentDay();
		if(mHealth.ActivityControllerObject.activityDetailRecord.status == 0 && mHealth.ActivityControllerObject.activityDetailRecord.endDate < currentDate && mHealth.util.checkEngaged == false ) {
			$('.showLabel').show();
			$('#targetButton .ui-btn-text').html(mHealth.ActivityControllerObject.activityDetailRecord.targetLabel);
			$('#targetButton').trigger('create');
		} else {
			$('.showLabel').hide();
		}
		$('#detailActivity_div').html(_.template($('#detailActivityDataList').html(), {
			activityDetailRecord : mHealth.ActivityControllerObject.activityDetailRecord
		}));
		$('#detailActivity').trigger('create');
	},
	
	/**
	 *Name		: showCalendar
	 *Purpose	: Add to Calendar page with the selected challenge name is shown
	 *Params	: --
	 *Returns	: --
	**/
	
	showCalendar : function() {
		//alert(mHealth.util.selectedChallengeName);
		$("#eventName").val(mHealth.util.selectedChallengeName);
		mHealth.util.showCalendar();
	},
	
	/**
	 * Name    	: getCalendarData
	 * Purpose 	: Method to initialise the controller and to do validations of calendar start date and end date
	 * Params  	: --
	 * Return  	: --
	**/
	
	getCalendarData : function() {
		var title, startDate, endDate;
		title = $('#eventName').val();
		startDate = $('#startDate').val();
		endDate = $('#endDate').val();
		if(startDate > endDate) {
			mHealth.util.customAlert(mHealth.Validation.invalidDate, '');
		} else {
			mHealth.util.callCalendar(title, startDate, endDate);
			$.mobile.changePage("../../activities/view/detailactivity.html");
		}
	},
	
	/**
	 *Name 		: showAssessment
	 *Purpose	: on click of the enter button if the status is 0, it should take us to the displayassessment page
	 *Params	:
	 *Returns	:
	**/
	
	showAssessment : function() {
		$.mobile.changePage("../../activities/view/displayassessment.html");
	},
	
	/**
	 *Name 		: getChallengeDetailSuccess
	 *Purpose	: On the Success of the challengedetail service call, the function will get executed.
	 *Params	: Output
	 *Return	: null
	**/
	
	getChallengeDetailSuccess : function(output) {
		var challengeDetailData = output.responseText;
		 //alert(challengeDetailData);
		 mHealth.util.hideMask();
		if(challengeDetailData != '') {
			var response = JSON.parse(challengeDetailData);
			if(JSON.stringify(response[0].Challenge[0]) == null || JSON.stringify(response[0].Challenge[0]) == undefined) {
				$.mobile.changePage('../../activities/view/assessmentnotfound.html');
			}
			else{
			var assessData = response[0].Challenge[0];
			mHealth.util.challengeStartDate=assessData.BeginDate;
			mHealth.util.challengeEndDate=assessData.EndDate;
			mHealth.util.checkEngaged = assessData.IsEngaged;
			var question = response[0].Challenge[0].Question;
			mHealth.models.ChallengeModel.customFromJSON(response[0].Challenge[0]);
			for(var i = 0; i < question.length; i++) {
				if(question[i].EntryType == '1') {
					var entryType = 'Checkbox';
				} else if(question[i].EntryType == '2') {
					var entryType = 'NumberEdit';
				}
			}
			output_html = mHealth.assessment.generate_html(question, entryType);
			var currentDate = mHealth.util.getCurrentDay();
			mHealth.util.earnedPoints = assessData.EarnedPts;
			mHealth.util.nextTierPoints = assessData.NextTierPoints;
			var challengeResponse=response[0].ChallengeResponse;
			if(challengeResponse!=null && challengeResponse!=undefined){
			for(var i=0;i<challengeResponse.length;i++)
			{
				mHealth.models.ChallengeResponseModel.customFromJSON({
				'MeasurementDate' : challengeResponse[i].MeasurementDate,
				'QuestionResponse' : challengeResponse[i].QuestionResponse
				});
			}
			}
			if(mHealth.ActivityControllerObject.activityDetailRecord.status == 0 && mHealth.util.challengeEndDate < currentDate && mHealth.util.checkEngaged == false) {
				$.mobile.changePage("../../activities/view/detailactivity.html");
			}else if(mHealth.ActivityControllerObject.activityDetailRecord.status == 1 && mHealth.util.challengeEndDate < currentDate){
				$.mobile.changePage('../../activities/view/assessmentnotfound.html');
			}
			 else {
				$.mobile.changePage("../../activities/view/displayassessment.html");
			}
			}
		} else if(challengeDetailData == '') {
			$.mobile.changePage('../../activities/view/assessmentnotfound.html');
		}
		
	},
	
	/**
	 *Name 		: getChallengeDetailFailure
	 *Purpose	: On the Failure of the challengedetail service call, the function will get executed.
	 *Params	: jqXHR, textStatus, errorThrown
	 *Return	: null
	**/
	getChallengeDetailFailure : function() {
		mHealth.util.customAlert('The Challenge is not Available', '');
		mHealth.util.hideMask();
	},
	
	/**
	 *Name 		: showQuestions
	 *Purpose 	: to set the value of current date, points earned and info button text
	 *Params	: --
	 *Returns	: --
	 **/
	showQuestions : function() {
		var currentDate = mHealth.util.getCurrentDay();
		var today = mHealth.util.getCurrentDay();
		if(currentDate <= today) {
			$('.showNextDay').hide();
		} else {
			$('.showNextDay').show();
		}
		$('#currentDate').val(currentDate);
		var close = false;
		today = new Date();
		var validDate = today;
		
		$('.currentDate').scroller({
			beforeShow : function(input, inst) {
				var currentDay = $('#currentDate').val();
				currentDay = new Date(currentDay);
				inst.setDate(currentDay);
				nativeCommunication.callNativeMethod("tabbar://hideTabBar?");

			},
			dateFormat : 'DD, M dd, yyyy',
			dayNames : ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
			monthNames : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
			monthNamesShort : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
			preset : 'date',
			theme : 'ios',
			startYear :mHealth.util.parseYear(mHealth.util.challengeStartDate),
			endYear : mHealth.util.parseYear(mHealth.util.challengeEndDate),
			onCancel : function(valueText, inst) {
				close = true;
				//nativeCommunication.callNativeMethod("tabbar://login?");
			},
			onClose : function(valueText, inst) {
				if(!close) {
					//nativeCommunication.callNativeMethod("tabbar://log?");
					return false;
				} else {
					if(inst.getDate() > (new Date())) {
						inst.setDate(validDate);
					} else if(inst.getDate() < mHealth.util.parseDateObj(mHealth.util.challengeStartDate) || inst.getDate() > mHealth.util.parseDateObj(mHealth.util.challengeEndDate)) {
						inst.setDate(validDate);
					}
					nativeCommunication.callNativeMethod("tabbar://showTabBar?");

					return true;
				}
			},
			onSelect : function(valueText, inst) {
				if(inst.getDate() > (new Date())) {
					close = false;
					mHealth.util.customAlert(mHealth.Section.dateOutOfRange, '');
				} else if(inst.getDate() < mHealth.util.parseDateObj(mHealth.util.challengeStartDate) || inst.getDate() > mHealth.util.parseDateObj(mHealth.util.challengeEndDate)) {
					close = false;
					mHealth.util.customAlert(mHealth.Section.pastInvalid, '');
				} else {
					if(inst.getDate().format("m/dd/yy") == today.format("m/dd/yy")) {
						$('.showNextDay').hide();
					} else {
						$('.showNextDay').show();
					}
					validDate = inst.getDate();
					close = true;
				}
			},
		});
		this.setAssessmentDate();
		if(mHealth.util.earnedPoints!= null && mHealth.util.nextTierPoints!= null){
		$('#showPoints').html(mHealth.util.earnedPoints + ' of ' + mHealth.util.nextTierPoints);
		}
		else
		{
			$('.points').hide();
		}
		$('#displayQues').append(output_html);
		$('#infoButton .ui-btn-text').html(mHealth.util.selectedChallengeName);
		$('#displayQuestions').trigger('create');
		$('#infoButton').trigger('create');
	},
	
	/**
	 *Name 		: leftButton
	 *Purpose 	: to check the current day and to show the previous day on click of the left disclosure button
	 *Params	: --
	 *Returns	: --
	 **/

	leftButton : function() {
		var currentDate, previousDay, today;
		var getAnswers = [];
		currentDate = $('#currentDate').val();
		today = mHealth.util.getCurrentDay();
		previousDay = mHealth.util.getPreviousDay(currentDate);
		$('#currentDate').val(previousDay);
		if(previousDay != today) {
			$('.showNextDay').show();
		} else {
			$('.showNextDay').hide();
		}
		this.setAssessmentDate();
	},
	
	/**
	 *Name 		: rightButton
	 *Purpose 	: to check the current day and to show the next day on click of the right disclosure button
	 *Params	: --
	 *Returns	: --
	**/
	
	rightButton : function() {
		var currentDate, nextDay, today;
		var getAnswers = [];
		currentDate = $('#currentDate').val();
		nextDay = mHealth.util.getNextDay(currentDate);
		$('#currentDate').val(nextDay);
		nextDay = dateFormat(nextDay, "default");
		today = mHealth.util.getCurrentDay();
		today = dateFormat(today, "default");
		if(nextDay == today) {
			$('.showNextDay').hide();
		} else {
			$('.showNextDay').show();
		}
		this.setAssessmentDate();
	},
	
	/**
	 *Name 		: setAssessmentDate
	 *Purpose 	: according to the date selected, the values are fetched from the model and set in the UI
	 *Params 	:--
	 *Returns	: --
	 **/
	
	setAssessmentDate : function() {
		var currentDate = $('#currentDate').val();
		var getAnswers = [], getAnswer;
		currentDate = mHealth.util.getFormattedDate(currentDate);
		$.each($('input', '#challengeform'), function(k) {
			if($(this).attr('type') == 'checkbox') {
				$(this).checkboxradio('enable');
				$(this).removeAttr('checked').checkboxradio("refresh");
			} else if($(this).attr('type') == 'tel') {
				$(this).textinput('enable');
				$(this).val('');
			}
		});
		var getChallengeValue = mHealth.models.ChallengeResponseModel.findByAttribute(mHealth.Assessment.measurementDate, currentDate);
		if(getChallengeValue != null) {
			$.each($('input', '#challengeform'), function(k) {
				if($(this).attr('type') == 'tel') {
			if(getChallengeValue.QuestionResponse.length == 1) {
				getAnswer = getChallengeValue.QuestionResponse[0].Answer;
			}
			}
			else  if($(this).attr('type') == 'checkbox') {
				  if(getChallengeValue.QuestionResponse.length >= 1) {	
				for(var i = 0; i < getChallengeValue.QuestionResponse.length; i++) {
					getAnswers[i] = getChallengeValue.QuestionResponse[i].QuestionID;
				}
			}
			}
			});
		
			$.each($('input', '#challengeform'), function(k) {
				if($(this).attr('type') == 'tel') {
					$(this).val(getAnswer);
					$(this).textinput('disable');
				} else if($(this).attr('type') == 'checkbox') {
					for(var j = 0; j < getAnswers.length; j++) {
						if($(this).attr('id').replace(/\{|\}/gi, '') == getAnswers[j].replace(/\{|\}/gi, '')) {
							$(this).attr('checked', true).checkboxradio("refresh");
						}
						$(this).checkboxradio('disable');
					}
				}
			});
		} else {
			$.each($('input', '#challengeform'), function(k) {
				if($(this).attr('type') == 'tel') {
					$(this).val('');
				} else if($(this).attr('type') == 'checkbox') {
					$(this).removeAttr('checked').checkboxradio("refresh");
				}

			});
		}
	},
	
	/**
	 *Name 		: showNotFoundPage
	 *Purpose 	: when the assessment is not found for the particular challenge, this page should be displayed
	 *Params	: --
	 *Returns 	: --
	**/
	showNotFoundPage : function() {
		var assessment = mHealth.Assessment;
		$('#assessmentNotFound').html(_.template($('#assessmentScript').html(), {
			assessment : assessment
		}));
		$('#assessmentNotFound').trigger('create');
	},
	
	
	/**
	 *Name 		: submitAssessment
	 *Purpose	: to submit the assessment and call the challenges post service
	 *Params	: --
	 *Returns	: --
	**/
	submitAssessment : function() {
		var questionId = [], answer = [],questionResponses=[];
		var currentDate = $('#currentDate').val();
		var measurementDate = mHealth.util.getFormattedDate(currentDate);
		$.each($('input', '#challengeform'), function(k) {
			var questionResponse = {};
			if($(this).attr('type') == 'tel') {
				questionId[k] = $(this).attr('id');
				answer[k] = $(this).val();
				questionId[k] = questionId[k].replace(/\{|\}/gi, '');
				questionResponse['QuestionID'] = questionId[k];
				questionResponse['Answer'] = answer[k];
				questionResponse['Comment'] = 'Testing...';
				questionResponses.push(questionResponse);
				$(this).textinput('disable');

			} else if($(this).attr('type') == 'checkbox') {

				if($(this).attr('checked') == 'checked') {
					questionId[k] = $(this).attr('id');
					answer[k] = $(this).val();
					questionId[k] = questionId[k].replace(/\{|\}/gi, '');
					answer[k] = answer[k].replace(/\{|\}/gi, '');
					questionResponse['QuestionID'] = questionId[k];
					questionResponse['Answer'] = '1';
					//questionResponse['Comment'] = 'Testing...';
					questionResponses.push(questionResponse);

				}
				$(this).checkboxradio('disable');
			}
		});
		checkValue = mHealth.models.ChallengeResponseModel.findByAttribute(mHealth.Assessment.measurementDate, measurementDate);
		if(checkValue == null) {
			mHealth.models.QuestionResponsesModel.customFromJSON(questionResponses);
			mHealth.models.ChallengeResponseModel.customFromJSON({
				'MeasurementDate' : measurementDate,
				'QuestionResponse' : questionResponses
			});
		requestJSON = mHealth.recommendation.ChallengePostMapper(mHealth.ActivityControllerObject.assesssmentName,measurementDate,questionResponses);
		var challengePostUrl = mHealth.env.challenge_response_url;
		mHealth.util.showMask();
		this.service.postRequest(challengePostUrl, requestJSON, this.proxy(this.postChallengeResponseSuccess), this.proxy(this.postChallengeResponseFailure), false);
		}
	},
	
	/**
	 *Name 		: processQuestions
	 *Purpose	: checks the date and if challenge end date is met, the displayassessment page , with disabled options should be displayed
	 *Params	: --
	 *Returns	: --
	**/
	
	processQuestions : function() {
		this.setAssessmentDate();
		if(mHealth.ActivityControllerObject.activityDetailRecord.endDate > currentDate) {
			$("input[type='checkbox']").checkboxradio('disable');
			$('.selector').textinput('disable');
			
		}
	},
	
	/**
	 *Name 		: postChallengeResponseSuccess
	 *Purpose	: output from the post service
	 *Params	: --
	 *Returns	: --
	 **/
	postChallengeResponseSuccess : function(output) {
		mHealth.util.hideMask();
	},
	
	/**
	 *Name 		:postChallengeResponseFailure
	 *Purpose	:
	 *Params	: --
	 *Returns	: --
	**/
	postChallengeResponseFailure : function() {
		mHealth.util.customAlert(mHealth.SyncProcessController.msgConnectionError, '');
	}
	
});
