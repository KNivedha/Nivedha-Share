/**
 * Controller : MessageController
 * This is the controller to do the  logic of message
 **/
mHealth.controllers.MessageController = Spine.Controller.sub({
	el : 'body',
	elements : {},
	tabbarloaded : false,
	summarSection : "",
	service : mHealth.util.RemoteServiceProxy.getInstance(),
    gmessageId : "",
	events : {
		'pageshow #home' : 'showMessages',
		'click #messageCenter' : 'loadMessageTab',
		'click #displayMessage' : 'loadMessage',
		'pagebeforeshow #detailMessage' : 'renderMessage',
		'pagebeforeshow #showMessage' : 'getMessages',
		'click #submitButton' : 'submitAssessment',
		'click #submit1Button' : 'submitAssessment',
		'click #detailsMessageBack' : 'hightLightMessagetab',
		'change #answerA1cId' : 'changeFields',
		'change #answerDiaId' : 'changeFields',
		'change #answerDiaFootId' : 'changeFields',
		'change #answerMicroId' : 'changeFields',
		'change #answerChoId' : 'changeFields',
		'pagebeforeshow #messageCalendarPage' : 'showCalendar',
		'click #saveMessageCalendar' : 'saveCalendar',
		'click #cancelMessageCalender' : 'cancelCalendar',
		'click #calendarId' : 'showCalendarPage',
		'pagebeforeshow #summaryMessage' : 'showSummary',
		'click .video' : 'showVideo'
	},
	/**
	 * Name    : showVideo
	 * Purpose : Method to set the id for video and navigate to video page
	 * Params  : --
	 * Return  : --
	 **/
	showVideo : function(event) {
		var target = event.target || event.srcElement
		if(target.href) {
			var targetValue = target.href;
			var videoId = targetValue.substring(3, targetValue.length);
			mHealth.videoLinkId = videoId;
			$.mobile.changePage('../../messages/view/messagesvideo.html');
			event.preventDefault();
		} else {
			mHealth.util.customAlert("No url found to navigate", '');
		}

	},
	updateMessage : function(pmessageId) {
		var url = mHealth.env.messagedetails_url + pmessageId;

		var body = '{}';
        this.service.putRequest(url, body, this.updateMessageSucess);
       	mHealth.models.MessageModel.select(function(msgObj) {
            if(msgObj.messageID == pmessageId) {
                msgObj.isRead = "true";
                }
        }); 
    },
	
    updateMessageSucess : function(sucessObject) {
	},

	/**
	 * Name    : messageServiceFailure
	 * Purpose : Method on failure of message header service
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageTabBar : function() {

		this.proxy(this.service.getResponse(mHealth.env.messageheaders_url, mHealth.MessageControllerObject.loadMessageHeaders));
		$.mobile.changePage("../../messages/view/showmessage.html");
	},
	/**
	 * Name    : messageSuccess
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	messageSuccess : function(output) {
		var response = output.responseText;
		mHealth.MessageControllerObject.loadMessageHeaders(output);
		$.mobile.changePage("../../home/view/home.html");
		mHealth.HealthDataControllerObject.loadTrackerData();
	},
	/**
	 * Name    : messageSuccess
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageHeaders : function(output) {
		var response = output.responseText;
		mHealth.models.MessageModel.destroyAll();
		if(response != null && response.length > 0) {
			var bundleMessage = JSON.parse(response);
			var messages = JSON.stringify(bundleMessage[0].Message);
			var sortedData = mHealth.MessageControllerObject.getSortData(JSON.parse(messages));
			mHealth.models.MessageModel.customFromJSON(sortedData);
		}
	},
	/**
	 * Name    : hightLightMessagetab
	 * Purpose : Method to highlight messages tab
	 * Params  : output
	 * Return  : --
	 **/
	hightLightMessagetab : function() {
		mHealth.util.loadMessageBar();
	},
	/**
	 * Name    : showHome
	 * Purpose : Method to set the data into the message model
	 * Params  : output
	 * Return  : --
	 **/
	showHome : function() {
		$.mobile.changePage("../../home/view/home.html");
		mHealth.HealthDataControllerObject.loadTrackerData();
		mHealth.util.loadHomeBar();
	},
	/**
	 * Name    : messageServiceFailure
	 * Purpose : Method on failure of message header service
	 * Params  : output
	 * Return  : --
	 **/
	messageServiceFailure : function() {
		$.mobile.changePage("../../home/view/home.html");
		mHealth.util.hideMask();
	},
	/**
	 * Name    : showMessages
	 * Purpose : Load the message from the Model and Show the Result in the Message Center of the Home Tab
	 * Params  : --
	 * Return  : --
	 **/
	showMessages : function() {
		this.proxy(this.service.getResponse(mHealth.env.messageheaders_url, mHealth.MessageControllerObject.loadMessageHeaders));

		var len = mHealth.models.MessageModel.count();
		var messages_val = mHealth.models.MessageModel.all();
		if(len > 0) {
			$('#messages_div').html(_.template($('#messageList').html(), {
				messages_val : messages_val
			}));
			$('#messages_div').trigger('create');
		} else {
			var message = "There are no messages for you to view at this time.";
			$('#messages_div').text(message);
		}

		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}
	},
	/**
	 * Name    : loadMessage
	 * Purpose : Calls webservice to get message details page
	 * Params  : --
	 * Return  : --
	 **/
	loadMessage : function(event) {
		mHealth.util.showMask();
		var eventTarget = event.target;
		var messageID = $(eventTarget).parents().children('input[type="hidden"]').val();
		mHealth.util.messageID=messageID;
		var URL = mHealth.env.messagedetails_url + messageID;
		mHealth.util.loadMessageBar();
		this.proxy(this.service.getResponse(URL, mHealth.MessageControllerObject.displayMessage, mHealth.MessageControllerObject.loadMessageTab1, true));
		//Updating the service after the Message is been dispalyed
		this.updateMessage(messageID);
	},
	/**
	 * Name    : displayMessage
	 * Purpose : Loads message details in to model
	 * Params  : --
	 * Return  : --
	 **/
	displayMessage : function(output) {
		mHealth.models.MessageQuestionModel.destroyAll();
		mHealth.models.QuestionGroupModel.destroyAll();
		mHealth.models.QuestionnaireModel.destroyAll();
		mHealth.models.MessageDetailsModel.destroyAll();
		mHealth.models.MessageSectionModel.destroyAll();
		var response = output.responseText;
		var calendarSection = [];
		var calendarDesc = "";
		summarSection = "";
		var messageResponse = JSON.stringify(response);
		var messagesData = JSON.parse(messageResponse);
		mHealth.models.MessageDetailsModel.customFromJSON(messagesData);
		mHealth.models.MessageDetailsModel.each(function(message) {
			if(message.cachedPersonalizedMessage) {
				if(message.cachedPersonalizedMessage.messageContent) {
					if(message.cachedPersonalizedMessage.messageContent.sections) {
						if(message.cachedPersonalizedMessage.messageContent.sections.section) {
							var sectionData = message.cachedPersonalizedMessage.messageContent.sections.section;
							var sectionResponse = JSON.stringify(sectionData);
							var sectionsData = JSON.parse(sectionResponse);
							mHealth.models.MessageSectionModel.customFromJSON(sectionsData);
							var sectionLength = sectionData.length;
							if(message.cachedPersonalizedMessage.messageContent.summary) {
								summarSection = message.cachedPersonalizedMessage.messageContent.summary;
							}
							if(sectionData.length != 0) {
								sectionData.map(function(sections) {
									if(sections) {
										calendarSection = [];
										if(sections.suggestedCalendarEvent) {
											calendarSection.push(sections.suggestedCalendarEvent);
										}
										if(sections.questionnaire) {
											var questionnaireData = sections.questionnaire;
											if(questionnaireData) {
												mHealth.models.QuestionnaireModel.customFromJSON(questionnaireData);
												mHealth.models.QuestionnaireModel.each(function(questionnaire) {
													if(questionnaire.qGroups) {
														if(questionnaire.qGroups.qGroup) {
															var groupQuestion = questionnaire.qGroups.qGroup;
															mHealth.models.QuestionGroupModel.customFromJSON(groupQuestion);
															mHealth.models.QuestionGroupModel.each(function(questionnaires) {
																if(questionnaires.questions) {
																	if(questionnaires.questions.question) {
																		var questions = questionnaires.questions.question;
																		mHealth.models.MessageQuestionModel.customFromJSON(questions);
																	}
																}
															});
														}
													}
												});
											}
										}
									}

								});
							}

						}
					}
					
					var calendarData = '';
					if(calendarSection) {
						calendarData = JSON.stringify(calendarSection);
					}
					mHealth.util.hideMask();
					var messagesDetail = mHealth.models.MessageDetailsModel.first();
					var messageIDValue = messagesDetail.messageID;


					if(summarSection) {
						$.mobile.changePage("../../messages/view/showsummary.html");
					} else {
						$.mobile.changePage("../../messages/view/displayMessage.html", {
						data : {
							messageID : messageIDValue,
							calendarSection : calendarData
						}
					});
					}
					
				}
			} else {
				$.mobile.changePage("../../messages/view/showmessage.html");
				mHealth.util.hideMask();
			}
		});
	},
	/**
	 *Name   : showSummary
	 *Purpose: Method to show summary
	 *Params : --
	 *Return : --
	 **/
	showSummary : function() {
		$('#message_summary').append(summarSection);
	},
	/**
	 *Name   : submitAssessment
	 *Purpose: Method to submit mini assessment
	 *Params : --
	 *Return : --
	 **/
	submitAssessment : function() {
		var mutliPartForm = $('#mutliPart').val();
		if(this.validateAssessment()) {
			var oForm = document.forms["messageform"];
			var answers = oForm.elements["form[answers]"];
			var questions = oForm.elements["form[questions]"];
			var requestData = {
				"saveUserFeedbackRequest" : {
					"transactionID" : '',
					"userFeedback" : {
						"messageID" : '',
						"questionResponses" : {
							"simpleQuestionResponse" : [],
							"multiPartQuestionResponse" : {
								"questionID" : "",
								"responseParts" : {
									"responsePart" : []
								}
							}
						}
					}
				}
			};
			requestData.saveUserFeedbackRequest.userFeedback['messageID'] = mHealth.util.messageID;
			requestData.saveUserFeedbackRequest['transactionID'] = new Date().getTime();
			var questionResponse = new Array();
			var length = mHealth.util.singleQuestionCount;
			for( i = 1; i <= length; i++) {
				var questionId;
				if(document.getElementById('answerId[' + i + ']')) {
					var answerId = document.getElementById('answerId[' + i + ']').value;
				}
				var setAnswerId = answerId.replace(/\{|\}/gi, '');
				if(document.getElementById('question[' + i + ']')) {
					questionId = document.getElementById('question[' + i + ']').value;
				}
				var simpleQuestionResponse = {};
				var questionResponseMap = {};
				simpleQuestionResponse["answer"] = setAnswerId;
				simpleQuestionResponse["questionID"] = questionId;
				questionResponse.push(simpleQuestionResponse);
				requestData.saveUserFeedbackRequest.userFeedback.questionResponses.simpleQuestionResponse.push(simpleQuestionResponse);
			}
			if(mutliPartForm == "true") {

				var multiResponse = this.formMultiRequestBody(requestData);
				requestData.saveUserFeedbackRequest.userFeedback.questionResponses.multiPartQuestionResponse = multiResponse;

			}
			var requestJSON = JSON.stringify(requestData);
			console.debug('requestJSON === ' + requestJSON);
			this.service.postRequest(mHealth.env.messagefeedback_url, requestJSON, this.postMessageSuccess, this.postMessageFailure, false);
		}
	},
	/**
	 *Name   : postMessageSuccess
	 *Purpose: Method on success of post feedback
	 *Params : --
	 *Return : --
	 **/
	postMessageSuccess : function(output) {
		mHealth.util.hideMask();
		$.mobile.changePage("../../home/view/home.html");
		mHealth.util.loadHomeBar();
	},
	/**
	 *Name   : postMessageFailure
	 *Purpose: Method on failure of post feedback
	 *Params : --
	 *Return : --
	 **/
	postMessageFailure : function() {		
		mHealth.util.hideMask();
		$.mobile.changePage("../../home/view/home.html");
		mHealth.util.loadHomeBar();
	},
	/**
	 *Name   : validateAssessment
	 *Purpose: Method to validate submit response
	 *Params : --
	 *Return : --
	 **/
	validateAssessment : function() {
		if(this.validateParticipantAnswer() && this.validateEmpoweredHTWT() && this.validateEmpoweredA1cDia()) {
			return true;
		} else {
			return false;
		}
	},
	/**
	 *Name   : formMultiRequestBody
	 *Purpose: Method to form request body for multi response
	 *Params : --
	 *Return : --
	 **/
	formMultiRequestBody : function(reqData) {
		var requestData = {};
		var mutliPartResponse = new Array();
		requestData["questionID"] = $('#groupHtWtId').val();
		var questionMultiResponseMap = [];
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.HTWTDT';
		var htDate = this.getDateFormat('answerDateId');
		multiQuestionResponse["value"] = htDate;
		questionMultiResponseMap.push(multiQuestionResponse);
                                                             
		var multiQuestionResponse = {};                                                             
		multiQuestionResponse["name"] = 'PT.HD.HT';                                                             
        var totalInches = '' + (Number($('#answerHtFtId').val()) * 12 + Number($('#answerHtInId').val()) );
        multiQuestionResponse["value"] = totalInches;                                                             
//		multiQuestionResponse["value"] = $('#answerHtInId').val();                                                             
		questionMultiResponseMap.push(multiQuestionResponse);
                                                             
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.WT';
		multiQuestionResponse["value"] = $('#answerIdWtId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		requestData["responsePart"] = questionMultiResponseMap;
		mutliPartResponse.push(requestData);

		var requestData = {};
		var questionMultiResponseMap = [];
		var multiQuestionResponse = {};
		requestData["questionID"] = $('#groupA1cId').val();
		multiQuestionResponse["name"] = 'PT.HD.TESTS.A1C.TAKEN';
		multiQuestionResponse["value"] = $('#answerA1cId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.A1C.DATE';
		var a1cDate = this.getDateFormat('answerA1cDateId');
		multiQuestionResponse["value"] = a1cDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.A1C.VALUE';
		multiQuestionResponse["value"] = $('#answerTxtA1cId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		requestData["responsePart"] = questionMultiResponseMap;
		mutliPartResponse.push(requestData);

		var requestData = {};
		var questionMultiResponseMap = [];
		var multiQuestionResponse = {};
		requestData["questionID"] = $('#groupChoId').val();
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.TAKEN';
		multiQuestionResponse["value"] = $('#answerChoId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.DATE';
		var choDate = this.getDateFormat('answerChoDateId');
		multiQuestionResponse["value"] = choDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.LDL';
		multiQuestionResponse["value"] = $('#answerTxtLDLId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.HDL';
		multiQuestionResponse["value"] = $('#answerTxtHDLId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.TRIG';
		multiQuestionResponse["value"] = $('#answerTxtTriId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.CHOL.TOTAL';
		multiQuestionResponse["value"] = $('#answerTxtTotalId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		requestData["responsePart"] = questionMultiResponseMap;
		mutliPartResponse.push(requestData);

		var requestData = {};
		var questionMultiResponseMap = [];
		var multiQuestionResponse = {};
		requestData["questionID"] = $('#groupDiaId').val();
		multiQuestionResponse["name"] = 'PT.HD.TESTS.DIALATED.TAKEN';
		multiQuestionResponse["value"] = $('#answerDiaId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.DIALATED.DATE';
		var diaDate = this.getDateFormat('answerDiaDateId');
		multiQuestionResponse["value"] = diaDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.FOOT.TAKEN';
		multiQuestionResponse["value"] = $('#answerDiaFootId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.FOOT.DATE';
		var footDate = this.getDateFormat('answerFootDateId');
		multiQuestionResponse["value"] = footDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.MICROALBUMIN.TAKEN';
		multiQuestionResponse["value"] = $('#answerMicroId').val();
		questionMultiResponseMap.push(multiQuestionResponse);
		var multiQuestionResponse = {};
		multiQuestionResponse["name"] = 'PT.HD.TESTS.MICROALBUMIN.DATE';
		var microDate = this.getDateFormat('answerMicroDateId');
		multiQuestionResponse["value"] = microDate;
		questionMultiResponseMap.push(multiQuestionResponse);
		requestData["responsePart"] = questionMultiResponseMap;
		mutliPartResponse.push(requestData);
		return mutliPartResponse
	},
	/**
	 *Name: getMeasurementDate
	 *Purpose: formats the measurement date to be passed as a parameter for health data object
	 *Params: Date field id
	 *Returns: returns formatted date object
	 **/
	getDateFormat : function(dateValue) {		
		var dateSelected = $('#' + dateValue + '').val();
		if(dateSelected != "") {
			var hour = dateSelected.substr(12, 2);
			hour = parseInt(hour, 10);
			if(dateSelected != "") {
				var hour = dateSelected.substr(11, 2);
				hour = parseInt(hour, 10);
				if(dateSelected.substr(17, 2) == "PM") {
					if(hour != 12)
						hour = hour + 12;
				} else {
					if(hour == 12)
						hour = 0;
				}
				dateObject = new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2), hour, dateSelected.substr(14, 2));
			}
			
			return dateObject.format('yyyymmdd"T"HHMMss".000 GMT"');	

		}
		
		return '';
	},
	/**
	 *Name   : validateParticipantAnswer
	 *Purpose: Method to validate Participant Answer
	 *Params : Number of question
	 *Return : --
	 **/
	validateParticipantAnswer : function() {
		var question1, question2, question3;
		if(document.getElementById("answerId[1]")){
			question1 = document.getElementById("answerId[1]").value;
		}
		if(document.getElementById("answerId[2]")){
			question2 = document.getElementById("answerId[2]").value;
		}
		if(document.getElementById("answerId[3]")){
			question3 = document.getElementById("answerId[3]").value;
		}
		if(question1 == "default" && question2 == "default" && question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidAssessment, '');
			return false;
		}
		if(question1 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidFirstQuesAssessment, '');
			return false;
		}
		if(question2 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidSecondQuesAssessment, '');
			return false;
		}
		if(question3 == "default") {
			mHealth.util.customAlert(mHealth.Validation.invalidThirdQuesAssessment, '');
			return false;
		}
		return true;
	},
	/**
	 * Name    : loadMessageTab1
	 * Purpose : To deal webservice failure scenario
	 * Params  : --
	 * Return  : --
	 **/
	loadMessageTab1 : function() {
		mHealth.util.hideMask();
		$.mobile.changePage("../../messages/view/showmessage.html");
		mHealth.util.loadMessageBar();
	},
	/**
	 * Name    : renderMessage
	 * Purpose : Method to render data on html page
	 * Params  : --
	 * Return  : --
	 **/
	renderMessage : function() {
		var len = mHealth.models.MessageQuestionModel.count();
		if(len >= 0) {
			var messageType = 1;
			var title = "";
			mHealth.models.MessageDetailsModel.each(function(message) {
				messageType = message.msgTypeID;
				title = message.title;
			});
			var displayViewMessages = "";
			var calendarResponse = "";
			var messageIDVal = "";
			var currentPageURL = $('div[id = "detailMessage"]').attr('data-url');
			var messageData = mHealth.util.getParameterByName('messageID', currentPageURL);
			var calendarData = mHealth.util.getParameterByName('calendarSection', currentPageURL);
			if(calendarData && calendarData != undefined && calendarData != "undefined") {
				calendarResponse = JSON.parse(calendarData);
			}
			switch(messageType) {
				case "3":
					displayViewMessages = mHealth.assessment.generate_assesment("", calendarResponse);
					break;
				case "2":
					displayViewMessages = mHealth.assessment.generate_messageDetailsHtml("", calendarResponse);
					break;
			}
			$('#messagedetails').append(displayViewMessages);
			if(messageIDVal) {
				messageIDVal = JSON.parse(messageData);
			}
			if(messageIDVal) {
				$('#messageID_data').html(_.template($('#msgDetails').html(), {
					messageID : messageIDVal
				}));
				$('#messageID_data').trigger('create');
			}
			//TODO : Commentting the following as length comes a undefined
			//if(calendarResponse != null && calendarResponse.length > 0 && calendarResponse[0] != null) {
			if(calendarResponse) {
				$('#show_calendar').html(_.template($('#calendarList').html(), {
					calendarResponse : calendarResponse
				}));
				$('#show_calendar').trigger('create');
			}
			$('.mobiscroll').scroller({
				preset : 'datetime',
				seconds : true,
				timeFormat : 'hh:ii A',
				theme : 'ios',
				beforeShow : function(input, inst) {
					nativeCommunication.callNativeMethod("tabbar://hideTabBar?");

				},
				onClose : function(valueText, inst) {
					nativeCommunication.callNativeMethod("tabbar://showTabBar?");
				}
			});
			submitFlow = "true";
			if(len == 0) {
				submitFlow = "false";
			}
			$('#showmessagecontent').html(_.template($('#showmessagetemplate').html(), {
				loginWorkflow : submitFlow
			}));
			$('#showmessagecontent').trigger('create');
			$('#showmessagecontent1').html(_.template($('#showmessagetemplate1').html(), {
				loginWorkflow : submitFlow
			}));
			$('#showmessagecontent1').trigger('create');
		} else {
			var message = "There are no details messages for you to view at this time.";
			$('#messagedetails').text(message);
			$('#showmessagecontent').html(_.template($('#showmessagetemplate').html(), {
				loginWorkflow : "false"
			}));
			$('#showmessagecontent').trigger('create');
			$('#showmessagecontent1').html(_.template($('#showmessagetemplate1').html(), {
				loginWorkflow : "false"
			}));
			$('#showmessagecontent1').trigger('create');
		}
		$('#messagedetails').trigger('create');
		if(this.tabbarloaded == false) {
			mHealth.util.callNativeBar();
			this.tabbarloaded = true;
		}
	},
	/**
	 * Name    : setHeight
	 * Purpose : Method to set height units
	 * Params  : --
	 * Returns : --
	 **/
	setHeight : function(height_unit, index) {
		var heightResponse = new Array();
		var heightIncr = 1;
		var heightUS = 36;
		var heightMetric = heightUS * 2.54;
		for( i = 0; i < 61; i++) {
			var feet = parseInt(heightUS / 12);
			var inch = heightUS % 12;
			var options = {};
			if(height_unit == "ft-inch") {
				options["value"] = feet + " ft. " + inch + " in.";
				options["units"] = heightUS;
			} else {
				heightMetric = heightUS * 2.54;
				options["value"] = Math.round(heightMetric) + " cm";
				options["units"] = heightUS;
			}
			heightUS += heightIncr;
			heightResponse.push(options);
		}
		return heightResponse;
	},
	/**
	 * Name    : processHeightData
	 * Purpose : Method to process height units
	 * Params  : --
	 * Returns : --
	 **/
	processHeightData : function() {
		var index = "30";
		if(mHealth.util.selUnits == undefined || mHealth.util.selUnits == 'ft-inch') {
			return this.setHeight('ft-inch', index);
		}
	},
	/**
	 * Name    : getMessages
	 * Purpose : Load the message from the Model and Show the Result in the  Message Tab
	 * Params  : --
	 * Return  : --
	 **/
	getMessages : function() {
		var len = mHealth.models.MessageModel.count();
		var messages_val = mHealth.models.MessageModel.all();
		if(len < 0) {
			messages_val = "There are no messages for you to view at this time.";
		}
		$('#message').html(_.template($('#messageList1').html(), {
			messages_val : messages_val
		}));
		$('#message').trigger('create');
	},
	/**
	 * Name    : loadMessageTab
	 * Purpose : Highlight the Message when we redirect the shorcut from the Home to message TAB.
	 * Params  : output
	 * Return  : --
	 **/
	loadMessageTab : function() {
		$.mobile.changePage("../../messages/view/showmessage.html");
		mHealth.util.loadMessageBar();
	},
	/**
	 *Name: getSortData
	 *Purpose: sorts the health data based on measurement date.
	 *Params: health data to be sorted is passed as param
	 *Returns: returns the sorted health data
	 **/
	getSortData : function(msgData) {
		var keys = [];
		var sortedData = [];
		for(var i in msgData) {
			keys[i] = [];
			keys[i][0] = msgData[i]["sentDate"];
			keys[i][1] = i;
		}
		keys.sort();
		keys.reverse();
		for(var i in keys) {
			sortedData.push(msgData[keys[i][1]]);
		}
		return sortedData;
	},
	/**
	 *Name: changeFields
	 *Purpose: Method to hide/shoe of empowered fields
	 *Params: --
	 *Returns: --
	 **/
	changeFields : function(event) {
		var selectId = event.target.id
		if(selectId == 'answerA1cId') {
			var optvalue = $('select#answerA1cId option:selected').val();
			if(optvalue == mHealth.AssesmentEntry.dropdownOption1Value || optvalue == 'default') {
				$('#answerA1cDateId').hide();
				$('#answerTxtA1cId').hide();

			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption3Value) {
				$('#answerA1cDateId').show();
				$('#answerTxtA1cId').show();

			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption2Value) {
				$('#answerA1cDateId').show();
				$('#answerTxtA1cId').hide();
			}
		} else if(selectId == 'answerChoId') {
			var optvalue = $('select#answerChoId option:selected').val();
			if(optvalue == mHealth.AssesmentEntry.dropdownOption1Value || optvalue == 'default') {
				$('#answerChoDateId').hide();
				$('#answerTxtLDLId').hide();
				$('#answerTxtHDLId').hide();
				$('#answerTxtTriId').hide();
				$('#answerTxtTotalId').hide();
				
			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption2Value) {
				$('#answerChoDateId').show();
				$('#answerTxtLDLId').hide();
				$('#answerTxtHDLId').hide();
				$('#answerTxtTriId').hide();
				$('#answerTxtTotalId').hide();
				
			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption3Value) {
				$('#answerTxtLDLId').show();
				$('#answerTxtHDLId').show();
				$('#answerTxtTriId').show();
				$('#answerTxtTotalId').show();
				$('#answerChoDateId').show();
			}
		} else if(selectId == 'answerDiaId') {
			var optvalue = $('select#answerDiaId option:selected').val();
			if(optvalue == mHealth.AssesmentEntry.dropdownOption1Value || optvalue == 'default') {
				$('#answerDiaDateId').hide();
			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption4Value) {
				$('#answerDiaDateId').show();
			}
		} else if(selectId == 'answerDiaFootId') {
			var optvalue = $('select#answerDiaFootId option:selected').val();
			if(optvalue == mHealth.AssesmentEntry.dropdownOption1Value || optvalue == 'default') {
				$('#answerFootDateId').hide();
			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption4Value) {
				$('#answerFootDateId').show();
			}
		} else if(selectId == 'answerMicroId') {
			var optvalue = $('select#answerMicroId option:selected').val();
			if(optvalue == mHealth.AssesmentEntry.dropdownOption1Value || optvalue == 'default') {
				$('#answerMicroDateId').hide();
			} else if(optvalue == mHealth.AssesmentEntry.dropdownOption4Value) {
				$('#answerMicroDateId').show();
			}
		}
	},
	/**
	 *Name : showCalendarPage
	 *Purpose : Show clendar page
	 *Params: --
	 *Returns: --
	 **/
	showCalendarPage : function(event) {
		var eventTarget = event.target;
		var calendarName = $(eventTarget).parents().parents().children('input[type="hidden"]').val();
		$.mobile.changePage("../../messages/view/messagecalendar.html", {
			data : {
				calendarName : calendarName
			}
		});
		mHealth.util.loadMessageBar();
	},
	/**
	 *Name : showCalendar
	 *Purpose : Show clendar page
	 *Params: --
	 *Returns: --
	 **/
	showCalendar : function() {
		var currentPageURL = $('div[id = "messageCalendarPage"]').attr('data-url');
		var calendarDesc = mHealth.util.getParameterByName('calendarName', currentPageURL);
		$("#reminderName").val(calendarDesc);
		mHealth.util.showCalendar();
	},
	/**
	 * Name    : saveCalendar
	 * Purpose : Method to save the controller
	 * Params  : --
	 * Return  : --
	 **/
	saveCalendar : function(event) {
		var title, startDate, endDate;
		title = $('#reminderName').val();
		startDate = $('#startDate').val();
		endDate = $('#endDate').val();
		if(startDate > endDate) {
			mHealth.util.customAlert(mHealth.Validation.invalidDate, function() {
				event.preventDefault();
			});
		} else {
			mHealth.util.callCalendar(title, startDate, endDate);
			$.mobile.changePage("../../messages/view/showmessage.html");
			mHealth.util.loadMessageBar();
		}

	},
	/**
	 * Name    : saveCalendar
	 * Purpose : Method to save the controller
	 * Params  : --
	 * Return  : --
	 **/
	cancelCalendar : function() {
		mHealth.util.showMask();
		var messagesDetail = mHealth.models.MessageDetailsModel.first();
		var messageID = messagesDetail.messageID;
		var URL = mHealth.env.messagedetails_url + messageID;
		this.proxy(this.service.getResponse(URL, mHealth.MessageControllerObject.displayMessage, mHealth.MessageControllerObject.loadMessageTab1, true));
		mHealth.util.loadMessageBar();
	},
	/**
	 * Name    : validateEmpoweredHTWT
	 * Purpose : Method to validate height empowered fields
	 * Params  : --
	 * Return  : --
	 **/
	validateEmpoweredHTWT : function() {
		if($('#answerDateId').val() == "" || $('#answerHtFtId').val() == "" || $('#answerIdWtId').val() == "") {
			mHealth.util.customAlert("Please enter your Height and Weight", '');
			return false
		} else {
			return true;
		}
	},
	/**
	 * Name    : validateEmpoweredDia
	 * Purpose : Method to validate Diabetes empowered fields
	 * Params  : --
	 * Return  : --
	 **/
	validateEmpoweredA1cDia : function() {
		if($('#answerA1cId').val() == "default" || $('#answerChoId').val() == "default") {
			mHealth.util.customAlert("Please Select one", '');
			return false;
		}

		if($('#answerA1cId').val() == mHealth.AssesmentEntry.dropdownOption2Value) {
			if($('#answerA1cDateId').val() == "") {
				mHealth.util.customAlert("Please select date", '');
				return false;
			}
		} else if($('#answerA1cId').val() == mHealth.AssesmentEntry.dropdownOption3Value) {
			if($('#answerA1cDateId').val() == "" || $('#answerA1cId').val() == "") {
				mHealth.util.customAlert("Please select date and enter value", '');
				return false;
			}
		}

		if($('#answerChoId').val() == mHealth.AssesmentEntry.dropdownOption2Value) {
			if($('#answerChoDateId').val() == "") {
				mHealth.util.customAlert("Please select date", '');
				return false;
			}
		} else if($('#answerChoId').val() == mHealth.AssesmentEntry.dropdownOption3Value) {
			if($('#answerChoDateId').val() == "" || $('#answerTxtLDLId').val() == "" || $('#answerTxtHDLId').val() == "" || $('#answerTxtTriId').val() == "" || $('#answerTxtTotalId').val() == "") {
				mHealth.util.customAlert("Please select date and enter value", '');
				return false;
			}
		}
		if($('#answerDiaId').val() == mHealth.AssesmentEntry.dropdownOption4Value) {
			if($('#answerDiaDateId').val() == "") {
				mHealth.util.customAlert("Please select date", '');
				return false;
			}
		}
		if($('#answerDiaFootId').val() == mHealth.AssesmentEntry.dropdownOption4Value) {
			if($('#answerFootDateId').val() == "") {
				mHealth.util.customAlert("Please select date", '');
				return false;
			}
		}
		if($('#answerMicroId').val() == mHealth.AssesmentEntry.dropdownOption4Value) {
			if($('#answerMicroDateId').val() == "") {
				mHealth.util.customAlert("Please select date", '');
				return false;
			}
		}
		return true;
	},
});
