/**
 * Native Functions
 **/

/**
 * Name    : setCalendarEvent
 * Purpose : Method to call the native calendar
 * Params  : Start Date, End Date, Title
 * Returns : dateString
 **/
mHealth.util.callCalendar = function(title, sDate, eDate) {
	location.href = "cal://setEvent?eventTitle=" + title + "&startDate=" + sDate + "&endDate=" + eDate;
};
/**
 * Name   : sendEmail
 * Purpose: Method to send email.
 * Params : --
 * Return : --
 **/
mHealth.util.sendEmail = function(to, toCopy, subject) {
	location.href = "email://sendEmail?mailto=" + to + "&cc=" + toCopy + "&subject=" + subject;
};
/**
 * Name   : callNativeBarEvent
 * Purpose: Method to call native bars on login
 * Params : --
 * Return : --
 **/
mHealth.util.callNativeBar = function() {
	location.href = "tabbar://login?";
},
/**
 * Name   : removeNativeBarEvent
 * Purpose: Method to remove native bars on logout
 * Params : --
 * Return : --
 **/
mHealth.util.removeNativeBar = function() {
	location.href = "tabbar://logout?";
};
/**
 * Name   : getDeviceFeatures
 * Purpose: Method to get the device feature like version,device id,...
 * Params : --
 * Return : Device features like version,device id,...
 **/
mHealth.util.getDeviceFeatures = function() {
	location.href = "about://getdevicefeatues?";
};
/**
 *Call back of native functions
 **/

/**
 * Name   : loadHome
 * Purpose: Callback method of native tabbar
 * Params : --
 * Return : --
 **/
loadHome = function() {
	$.mobile.changePage("../../home/view/home.html");
};
/**
 * Name   : loadActivities
 * Purpose: Method to call Activities web view on clicking the activities tab
 * Params : --
 * Return : --
 **/
loadActivities = function() {
	//mHealth.controllers.ActivityController.trigger('getservice');
	//  $.mobile.showPageLoadingMsg();
	mHealth.ActivityControllerObject.getActivity();
	// $.mobile.changePage("../../activities/view/showactivity.html");

};
/**
 * Name   : loadMessages
 * Purpose: Method to call Messages web view on clicking the messages tab
 * Params : --
 * Return : --
 **/
loadMessages = function() {
	$.mobile.changePage("../../messages/view/showmessage.html");
};
/**
 * Name   : loadTrackers
 * Purpose: Method to call trackers web view on clicking the trackers tab
 * Params : --
 * Return : --
 **/
loadTrackers = function() {
	$.mobile.changePage("../../trackers/view/showtracker.html");
};
sessionExpired = function() {
	mHealth.util.removeNativeBar();
	mHealth.MessageControllerObject.tabbarloaded = false;
	//mHealth.models.AnswerModel.destroyAll();
	//mHealth.models.ParticipantAnswerModel.destroyAll();
	mHealth.models.ConditionModel.destroyAll();
	mHealth.models.MessageModel.destroyAll();
	mHealth.models.MedicationModel.destroyAll();
	mHealth.models.ParticipantModel.destroyAll();
	//mHealth.models.SpaceModel.destroyAll();
	//mHealth.models.ViewModel.destroyAll();
	//mHealth.models.ZoneModel.destroyAll();
	mHealth.models.HealthDataModel.destroyAll();
	$.mobile.changePage("../../rootview/view/login.html", {
		data : {
			splashMessage : mHealth.SettingsController.sessionTimeoutLogout
		}
	});
};

currentOrientation = function(orientation) {
    alert('orientation'+orientation);
    $('.ui-page-active').css({
                             				'height' : document.height
                             			});
    
//    $(window).bind('orientationchange', function(event) {
                   			if(orientation == 'portrait') {
                                alert('portrait');
                   				$('.alertable').css({
                   					'height' : '460px',
                   					'width' : '320px'
                   				});
                   				$('.back_container').css({
                   					'height' : '460px',
                   					'width' : '320px',
                   					'top' : document.body.scrollTop + 'px'
                   				});
                   				$('.ui-alert-wallpaper').css({
                   					'height' : '460px',
                   					'width' : '320px',
                   					'top' : document.body.scrollTop + 'px'
                   				});
                   
                   			}
                   
                   			if(orientation == 'landscape') {
                                alert('portrait');
                   				$('.alertable').css({
                   					'height' : '300px',
                   					'width' : '480px'
                   				});
                   				$('.back_container').css({
                   					'height' : '300px',
                   					'width' : '480px',
                   					'top' : document.body.scrollTop + 'px'
                   				});
                   				$('.ui-alert-wallpaper').css({
                   					'height' : '300px',
                   					'width' : '480px',
                   					'top' : document.body.scrollTop + 'px'
                   				});
                   
                   			}
                   
                   		});

    
    
	//$(window).trigger('orientationchange');
	mHealth.GraphControllerObject.drawMultipleHealthDataGraph();

};

/**
 * Name   : loadSettings
 * Purpose: Method to call setings web view on clicking the settings tab
 * Params : --
 * Return : --
 **/
loadSettings = function() {
	$.mobile.changePage("../../settings/view/index.html");
};
