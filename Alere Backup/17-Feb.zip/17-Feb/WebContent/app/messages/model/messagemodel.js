mHealth.models.MessageModel =  Spine.Model.sub();
mHealth.models.MessageModel.configure('MessageModel','messageID',
'msgTypeID','title','sentDate','msgFolderID','healthTopicID',
'isRead','isReplied','isUrgent');
