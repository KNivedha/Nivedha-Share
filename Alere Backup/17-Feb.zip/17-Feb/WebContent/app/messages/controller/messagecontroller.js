/**
 * Controller : MessageController
 * This is the controller to do the  logic of message
 **/
mHealth.controllers.MessageController = 
Spine.Controller.sub({
                     el : 'body',
                     elements : {},
                     
                     tabbarloaded : false,
                     
                     service : mHealth.util.RemoteServiceProxy.getInstance(),
                     
                     events : {
                     'pagebeforeshow #home' : 'showMessages',
                     'click #messageCenter' : 'loadMessageTab',
                     'pagebeforeshow #showMessage' : 'getMessages'
                     //'click #messageCenter' : 'loadMessage'                                                     
                     },
                     
                     messageSuccess : function(output) {
                     var response = output.responseText;
                     var bundleMessage = JSON.parse(response);
                     
                     var messages = JSON.stringify(bundleMessage[0].Message);
                     mHealth.models.MessageModel.customFromJSON(messages);
                     
                     },
                     showMessages : function() {
                     var len = mHealth.models.MessageModel.count();
                     
                     var messages_val = mHealth.models.MessageModel.all();
                     
                     if(len > 0) {
                     
                     $('#messages_div').html(_.template($('#messageList').html(), {
                                                        messages_val : messages_val
                                                        }));
                     $('#home').trigger('create');
                     } else {
                     var message = "There are no messages for you to view at this time.";
                     $('#messages_div').text(message);
                     }
                     if(this.tabbarloaded == false) {
                     mHealth.util.callNativeBar();
                     this.tabbarloaded = true;
                     }
                     },
                     getMessages : function() {
                     var len = mHealth.models.MessageModel.count();
                     
                     var messages_val = mHealth.models.MessageModel.all();
                     
                     if(len < 0) {
                     messages_val = "There are no messages for you to view at this time.";
                     }
                     
                     $('#message').html(_.template($('#messageList1').html(), {
                                                   messages_val : messages_val
                                                   }));
                     $('#showMessage').trigger('create');
                     
                     },
                     
                     loadMessage : function() {
                     $.mobile.changePage("../../messages/view/showmessage.html");
                     location.href = "tabbar://loadMessages?";
                     },    
                     loadMessageTab : function() {
                     
                     $.mobile.changePage("../../messages/view/showmessage.html");
                     location.href = "tabbar://loadMessages?";
                     }
                     });
