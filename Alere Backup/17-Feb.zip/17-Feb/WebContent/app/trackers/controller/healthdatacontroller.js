mHealth.controllers.HealthDataController = Spine.Controller.sub({
	healthDataTracker : '',
	trackerData : '',
	validForm : false,
	currentView : "Month",

	currentTime : new Date(),
	cyear : new Date().getFullYear(),
	cmonth : new Date().getMonth() + 1,

	lastDateM : new Date(this.cyear, this.cmonth, 0),
	gTitleM : '',
	xMaxDate : '',
	xMinDate : '',

	currentTimeM : this.currentTime,
	cyearM : this.cyear,
	cmonthM : this.cmonth,

	maxWeekDate : '',
	maxDateW : '',
	minWeekDate : '',
	minDateW : '',
	gTitleW : '',
	gTitleWmax : '',
	gTitleWmin : '',

	maxDayDate : '',
	maxDateD : '',
	minDayDate : '',
	minDateD : '',
	gTitleD : '',

	xMaxDateMonth : '',
	xMaxDateWeek : '',
	xMaxDateDay : '',

	dataPoints : '',
	getPlotOptions : '',

	seriesDataSet1 : '',
	seriesDataSet2 : '',

	glucosePlotOptions : '',
	avgCords : '',
	plotCords : '',
	thresholdMinGlucose : '',
	thresholdMaxGlucose : '',
	maxHealthDataValue : 0,

	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #viewJournal' : 'getJournalData',
		
		'click #viewNewEntry' : 'viewNewEntry',
		'pagebeforeshow #show_tracker_view' : 'showTracker',
		'pagebeforeshow #show_tracker_track' : 'newEntryTracker',
		'click #track_save' : 'newEntrySave',
		'click .tracker' : 'setTrackerType',
		'pagebeforeshow #show_journal' : 'showJournal',
		'pagebeforeshow #graphpage' : 'showGraphHeader',
		'click .chotype' : 'setChoType',
		'click #chographBack' : 'setChoBackPage',
		'click #graphBack' : 'setBackPage',
		'click #trackClick' : 'setChoBackPage',
		'click #glucoseBackButton' : 'setStopRotation',
		'click "#leftbutton' : 'leftButtonClick',
		'click #rightbutton' : 'rightButtonClick',
		'click #monthbutton' : 'monthButtonClick',
		'click #weekbutton' : 'weekButtonClick',
		'click #daybutton' : 'dayButtonClick',
		'pageshow #graphpage' : 'drawGraph',
		
		'click #showTrackerPage' : 'setGlucoseTracker'

	},

	/**
	 *Name: setTrackerType
	 *Purpose: Sets Tracker type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setTrackerType : function(e) {
		this.healthDataTracker = $(e.target).parents(".tracker").attr('name');
	},
	/**
	 *Name: setChoType
	 *Purpose: Sets Cholesterol type
	 *Params: event object is passed implicitly. No params are passed explicitly
	 *Returns: doesn't return
	 **/
	setChoType : function(e) {
		this.healthDataTracker = $(e.target).parents(".chotype").attr('name');
		this.getGraphData();
	},
	/**
	 *Name: showGraphHeader
	 *Purpose: Sets Back button action depending on the tracker type
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	showGraphHeader : function() {
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#graphHeader').html(_.template($('#graphtemplate').html(), {
			trackerType : trackerType
		}));
		$('#graphHeader').trigger('create');
	},
	/**
	 *Name: setChoBackPage
	 *Purpose: Sets Back Page from Cholesterol graph
	 *Params: no params
	 *Returns: doesn't return
	 **/
	setChoBackPage : function(e) {
		this.healthDataTracker = "Cholesterol";
		location.href = "gyro://unLoadChart?";
	},
	/**
	 *Name: setBackPage

	 *Purpose: Sets Back Page from Cholesterol graph
	 *Params: no params
	 *Returns: doesn't return
	 **/
	setBackPage : function(e) {
		location.href = "gyro://unLoadChart?";
	},
	/**
	 *Name: setStopRotation
	 *Purpose: changes the orientation to default
	 *Params: no params
	 *Returns: doesn't return
	 **/
	setStopRotation : function(e) {
		location.href = "gyro://unLoadChart?";
	},
	/**
	 *Name: showGraph
	 *Purpose: Shows graph page
	 *Params: no params
	 *Returns: doesn't return
	 **/
	showGraph : function() {
		//alert($("#trackergraphs").html());
		if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure") {
			this.setWeekView();

		} else {
			this.setMonthView();
		}
	},
	/**
	 *Name: setMonthView
	 *Purpose:sets the month view for the graph when landing on the graph for the first time, and when clicked on the month button
	 *Params:
	 *Returns:
	 **/
	setMonthView : function() {
		this.currentView = "Month";
		this.lastDateM = new Date(this.cyear, this.cmonth, 0);
		this.gTitleM = this.setTitle(this.lastDateM, this.currentView);
		this.xMaxDate = this.calculateDate(this.lastDateM, 2);
		if(this.cmonth <= 9)
			this.cmonth = "0" + parseInt(this.cmonth, 10);
		this.xMinDate = this.cyear + "-" + this.cmonth + "-" + "01" + " " + "00" + ":" + "00";
		this.cyearM = this.cyear;
		this.cmonthM = parseInt(this.cmonth, 10);
		this.xMaxDateMonth = this.xMaxDate;
		this.setGraph(this.currentView, this.xMinDate, this.xMaxDate, this.gTitleM);
	},
	/**
	 *Name: setWeekView
	 *Purpose:sets the week view for the graph
	 *Params:
	 *Returns:
	 **/
	setWeekView : function() {
		this.currentView = "Week";
		var wday = this.currentTime.getDay();
		this.minWeekDate = new Date(this.currentTime.getTime() - (wday * 24 * 60 * 60 * 1000));
		this.minDateW = this.calculateDate(this.minWeekDate, 1);
		this.gTitleWmin = this.setTitle(this.minWeekDate, this.currentView);
		this.maxWeekDate = new Date(this.currentTime.getTime() + ((6 - wday + 1) * 24 * 60 * 60 * 1000));
		this.maxDateW = this.calculateDate(this.maxWeekDate, 1);
		this.gTitleWmax=new Date(this.currentTime.getTime() + ((6 - wday) * 24 * 60 * 60 * 1000));
		this.gTitleWmax = this.setTitle(this.gTitleWmax, this.currentView);
		this.gTitleW = this.gTitleWmin + "-" + this.gTitleWmax;
		this.xMaxDateWeek = this.maxDateW;
		this.setGraph(this.currentView, this.minDateW, this.maxDateW, this.gTitleW);
	},
	/**
	 *Name: setTitle
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setTitle : function(lastDateM, currentView) {
		var months = new Array(12);
		months[0] = "January";
		months[1] = "February";
		months[2] = "March";
		months[3] = "April";
		months[4] = "May";
		months[5] = "June";
		months[6] = "July";
		months[7] = "August";
		months[8] = "September";
		months[9] = "October";
		months[10] = "November";
		months[11] = "December";

		if(currentView == "Month")
			return months[lastDateM.getMonth()] + "-" + lastDateM.getFullYear();
		else if(currentView == "Week")
			return months[lastDateM.getMonth()].substr(0, 3) + " " + lastDateM.getDate();
		else
			return months[lastDateM.getMonth()].substr(0, 3) + lastDateM.getDate() + "," + lastDateM.getFullYear();
	},
	/**
	 *Name: calculateDate
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	calculateDate : function(currentTime, minmax) {
		var month = currentTime.getMonth() + 1;
		var day = currentTime.getDate();
		var year = currentTime.getFullYear();
		var hours = currentTime.getHours();
		var minutes = currentTime.getMinutes();
		var seconds = currentTime.getSeconds();
		if(month <= 9)
			month = "0" + month;
		if(day <= 9)
			day = "0" + day;

		if(minmax == 1)
			return year + "-" + month + "-" + day + " " + "00" + ":" + "00";
		else
			return year + "-" + month + "-" + day + " " + "23" + ":" + "59";
	},
	/**
	 *Name: setGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setGraph : function(currentView, xMinDate, xMaxDate, gTitleM) {
		var xStringFormat = '';
		var yStringFormat = '%.0f';
		var xInterval = '';
		if(currentView == "Month") {
			xStringFormat = '%b %d';
			xInterval = '1 week';
		} else if(currentView == "Week") {
			xStringFormat = '%a';
			xInterval = '1 day';
		} else {
			xStringFormat = '%I %p';
			xInterval = '4 hour';
		}
		if(this.healthDataTracker == "Weight & BMI") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 400, 0, 0, xInterval, 50, xStringFormat, yStringFormat, gTitleM, '', 'Weight', 'BMI', "trackergraphs", "Weight & BMI");
		} else if(this.healthDataTracker == "Blood Pressure") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 200, 80, 40, xInterval, 40, xStringFormat, yStringFormat, gTitleM, '', 'Diastolic', 'Systolic', "trackergraphs", "Blood Pressure");
		} else if(this.healthDataTracker == "A1c") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 3, 10, 6, 1, xInterval, 1, xStringFormat, yStringFormat, gTitleM, '', 'A1c', null, "trackergraphs", "A1c");
			this.seriesDataSet2 = null;
		} else if(this.healthDataTracker == "LDL & HDL") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 200, 0, 0, xInterval, 40, xStringFormat, yStringFormat, gTitleM, '', 'LDL', 'HDL', "trackergraphs", "LDL & HDL");
		} else if(this.healthDataTracker == "Total Cholesterol") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 400, 0, 200, xInterval, 40, xStringFormat, yStringFormat, gTitleM, '', 'Cholesterol', null, "trackergraphs", "Total Cholesterol");
			this.seriesDataSet2 = null;
		} else if(this.healthDataTracker == "Triglycerides") {
			this.getPlotOptions = this.setPlotOptions(xMinDate, xMaxDate, 0, 160, 0, 150, xInterval, 50, xStringFormat, yStringFormat, gTitleM, '', 'Triglycerides', null, "trackergraphs", "Triglycerides");
			this.seriesDataSet2 = null;
		}
		this.dataPoints = this.calculateDataPoints(this.seriesDataSet1, this.seriesDataSet2, xMinDate, xMaxDate);
	},
	/**
	 *Name: setPlotOptions
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	setPlotOptions : function(xMin, xMax, yMin, yMax, threshMin, threshMax, xTickInterval, yTickInterval, xstringFormat, ystringFormat, xLabel, yLabel, series1Label, series2Label, divname, graph_title) {
		var viewOptions = new Object();

		viewOptions['xMin'] = xMin;
		viewOptions['xMax'] = xMax;
		viewOptions['yMin'] = yMin;
		viewOptions['yMax'] = yMax;
		viewOptions['threshMin'] = threshMin;
		viewOptions['threshMax'] = threshMax;
		viewOptions['xTickInterval'] = xTickInterval;
		viewOptions['yTickInterval'] = yTickInterval;
		viewOptions['xstringFormat'] = xstringFormat;
		viewOptions['ystringFormat'] = ystringFormat;
		viewOptions['xLabel'] = xLabel;
		viewOptions['yLabel'] = yLabel;
		viewOptions['series1Label'] = series1Label;
		viewOptions['series2Label'] = series2Label;
		viewOptions['divname'] = divname;
		viewOptions['graph_title'] = graph_title;

		return viewOptions;
	},
	/**
	 *Name: calculateSingleLineDataPoints
	 *Purpose:
	 *Params:
	 *Returns:
	 **/

	calculateSingleLineDataPoints : function(trackerData, xMinDate, xMaxDate) {
		var graphCoordinates = new Array();
		var counterTrackerData = 0;
		if(trackerData) {

			for(var counter = 0; counter < trackerData.length; counter++) {
				var usrtmeYear = parseInt((trackerData[counter].measurementDate).substr(0, 4), 10);
				var usrtmeMonth = parseInt((trackerData[counter].measurementDate).substr(4, 2), 10);
				var usrtmeDay = parseInt((trackerData[counter].measurementDate).substr(6, 2), 10);
				var usrtmeHours = parseInt((trackerData[counter].measurementDate).substr(9, 2), 10);
				var usrtmeMinutes = parseInt((trackerData[counter].measurementDate).substr(11, 2), 10);
				var usrtmeSeconds = parseInt((trackerData[counter].measurementDate).substr(13, 2), 10);

				var hlthData = parseInt(trackerData[counter].value);
				if(usrtmeMonth <= 9)
					usrtmeMonth = "0" + usrtmeMonth;
				if(usrtmeDay <= 9)
					usrtmeDay = "0" + usrtmeDay;
				if(this.healthDataTracker == "A1c" || this.healthDataTracker == "Total Cholesterol")
					usrtmeDay = usrtmeYear + '-' + usrtmeMonth + '-' + usrtmeDay + ' ' +"12:00";
				else
					usrtmeDay = usrtmeYear + '-' + usrtmeMonth + '-' + usrtmeDay + ' ' + usrtmeHours + ':' + usrtmeMinutes;

				if(usrtmeDay >= xMinDate && usrtmeDay <= xMaxDate) {
					graphCoordinates[counterTrackerData] = new Array(2);
					graphCoordinates[counterTrackerData][0] = usrtmeDay;
					graphCoordinates[counterTrackerData][1] = hlthData;
					counterTrackerData = counterTrackerData + 1;
					if(this.maxHealthDataValue < hlthData)
						this.maxHealthDataValue = hlthData;
				}
			}
		}
		return graphCoordinates;
	},
	/**
	 *Name: calculateDataPoints
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	calculateDataPoints : function(trackerData1, trackerData2, xMinDate, xMaxDate) {
		var line1HealthData = this.calculateSingleLineDataPoints(trackerData1, xMinDate, xMaxDate);
		var line2HealthData = this.calculateSingleLineDataPoints(trackerData2, xMinDate, xMaxDate);
		var graphCoordinates = [line1HealthData, line2HealthData];
		return graphCoordinates;
	},
	/**
	 *Name: drawGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	drawGraph : function() {

		$("#rightbutton").css("display", "none");
		if(this.healthDataTracker == "Weight & BMI" || this.healthDataTracker == "Blood Pressure") {
			$("#spantitle span").text(this.gTitleW);
			$("#week").addClass("ui-btn-active");
		} else {
			$("#spantitle span").text(this.gTitleM);
			$("#month").addClass("ui-btn-active");
		}
		//alert("before calling");
		this.plotGraph(this.getPlotOptions, this.dataPoints);

	},
	/**
	 *Name: getGender
	 *Purpose: get gender for geting HDL min max value for graph
	 *Params:
	 *Returns: returns gender
	 **/
	getGender : function() {
		var gend = (mHealth.models.ParticipantModel.first()).gender;
		return gend;

	},
	/**
	 *Name:plotGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	plotGraph : function(graphSettings, dataPoints) {
		var plot1;
		if(dataPoints[0].length == 0 && dataPoints[1].length == 0) {
			$("#trackergraphs").html("<div style='top:33%;width:100%;position:relative;z-index:1000;'><center>NO DATA AVAILIABLE</center></div>");
			plot1 = $.jqplot('trackergraphs', [[]], {
				gridPadding : {
					right : 18
				},
				axes : {
					xaxis : {
						showTicks : false, // wether or not to show the tick labels,
						showTickMarks : false    // wether or not to show the tick marks
					},
					yaxis : {
						showTicks : false, // wether or not to show the tick labels,
						showTickMarks : false    // wether or not to show the tick marks
					}
				},
				grid : {
					drawGridLines : true, // whether to draw lines across the grid or not.
					gridLineColor : '#cccccc',
					background : '#666666',
					borderWidth : 0             // pixel width of border around grid.
				},
				stackSeries : true,
				series : [{

				}, {

				}]
			});

		} else {

			var intervalCount = 0;
			while(this.maxHealthDataValue >= intervalCount) {
				intervalCount = intervalCount + graphSettings['yTickInterval'];
			}
			this.maxHealthDataValue = 0;
			var threshXmax = graphSettings['xMin'];
			threshXmax = new Date(threshXmax.substr(0, 4), threshXmax.substr(5, 2) - 1, 36);
			threshXmax = this.calculateDate(threshXmax, 1);
			if(this.currentView == "Week")
				threshXmax = graphSettings['xMax'];
			if(this.healthDataTracker == "LDL & HDL") {
				var genericSeries = [{
					color : '#9E0516', //red
					showLabel : false,
					showMarker : false,
					lineWidth : .9,
					fill : false
				}, {
					color : '#9E0516', //red
					showLabel : false,
					showMarker : false,
					lineWidth : 2,
					fill : true,
					fillAlpha : 0.25
				}, {
					color : '#CFC4AE', //green
					showLabel : false,
					showMarker : false,
					lineWidth : .9,
					fill : false
				}, {
					color : '#71BF44', //green
					showLabel : false,
					showMarker : false,
					lineWidth : 2,
					fill : true,
					fillAlpha : 0.25
				}, {
					disableStack : true,
					color : '#faa01b', // red
					// showMarker:% if @graph['count'] > 1 %>false % else %>trues% end %>, // original%>
					label : 'HDL',
					showMarker : true,
					lineWidth : 3
				}, {
					disableStack : true,
					color : '#92c83e', //green
					label : 'LDL',
					showMarker : true,
					lineWidth : 2
				}];
				var thresholdMinLDL = [[graphSettings['xMin'], 0], [threshXmax, 0]];
				var thresholdMaxLDL = [[graphSettings['xMin'], 100], [threshXmax, 100]];
				var gend = this.getGender();

				if(gend != null) {
					if(gend == "M") {
						var threshMinHDL = -60;
						var threshMaxHDL = intervalCount - 60;
					} else {
						var threshMinHDL = -50;
						var threshMaxHDL = intervalCount - 50;
					}
					var thresholdMin = [[graphSettings['xMin'], threshMinHDL], [threshXmax, threshMinHDL]];
					var thresholdMax = [[graphSettings['xMin'], threshMaxHDL], [threshXmax, threshMaxHDL]];
				} else {
					var thresholdMin = [[graphSettings['xMin'], graphSettings['threshMin']], [threshXmax, graphSettings['threshMin']]];
					var thresholdMax = [[graphSettings['xMin'], graphSettings['threshMax']], [threshXmax, graphSettings['threshMax']]];
				}
			} else {
				var genericSeries = [{
					color : '#92c83e', //green
					showLabel : false,
					showMarker : false,
					lineWidth : .1,
					fill : false
				}, {
					color : '#333333', //dark gray
					showLabel : false,
					showMarker : false,
					lineWidth : 2,
					fill : true,
					fillAlpha : 0.25
				}, {
					disableStack : true,
					color : '#92c83e', //green
					label : graphSettings['series1Label'],
					showMarker : true,
					lineWidth : 3
				}, {
					disableStack : true,
					color : '#faa01b', // orange
					label : graphSettings['series2Label'],
					showMarker : true,
					lineWidth : 2
				}];

				var thresholdMin = [[graphSettings['xMin'], graphSettings['threshMin']], [threshXmax, graphSettings['threshMin']]];
				var thresholdMax = [[graphSettings['xMin'], graphSettings['threshMax']], [threshXmax, graphSettings['threshMax']]];
			}
			var checkShow = true;
			if(this.healthDataTracker == "A1c" || this.healthDataTracker == "Total Cholesterol" || this.healthDataTracker == "Triglycerides") {
				checkShow = false;

			}
			var plotOptions = {
				title : graphSettings['graph_title'],
				legend : {
					show : checkShow,
					placement : "outsideGrid",
					location : 'nw'
				},

				axes : {
					xaxis : {
						min : graphSettings['xMin'],
						max : graphSettings['xMax'],
						renderer : $.jqplot.DateAxisRenderer,
						tickInterval : graphSettings['xTickInterval'],
						tickOptions : {
							formatString : graphSettings['xstringFormat']
						},
						showTickMarks : false
						// label : graphSettings['xLabel'],
						// showLabel : true
					},
					yaxis : {
						min : graphSettings['yMin'],
						max : intervalCount,
						tickInterval : graphSettings['yTickInterval'],
						tickOptions : {
							formatString : graphSettings['ystringFormat']
						},
						showTickMarks : false
					}
				},
				grid : {
					drawGridLines : true,
					gridLineColor : '#cccccc',
					background : '#666666',
					borderWidth : 0
				},
				stackSeries : true,
				series : genericSeries
			};

			if(this.healthDataTracker == "A1c" || this.healthDataTracker == "Total Cholesterol" || this.healthDataTracker == "Triglycerides")
				plot1 = $.jqplot(graphSettings['divname'], [thresholdMin, thresholdMax, dataPoints[0]], plotOptions).replot();
			else if(this.healthDataTracker == "Blood Pressure")
				plot1 = $.jqplot(graphSettings['divname'], [thresholdMin, thresholdMax, dataPoints[1], dataPoints[0]], plotOptions).replot();
			else if(this.healthDataTracker == "LDL & HDL")
				plot1 = $.jqplot(graphSettings['divname'], [thresholdMinLDL, thresholdMaxLDL, thresholdMin, thresholdMax, dataPoints[0], dataPoints[1]], plotOptions).replot();
			else
				plot1 = $.jqplot(graphSettings['divname'], [thresholdMin, thresholdMax, dataPoints[0], dataPoints[1]], plotOptions).replot();

		}

		// mHealth.util.hideMask();
	},
	/**
	 *Name: changeDatesMonth
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	changeDatesMonth : function(button) {
		if(button == 1)//1 for left button click
			this.currentTimeM = new Date(this.cyearM, parseInt(this.cmonthM, 10) - 1, 0);
		else//2 for right button click
			this.currentTimeM = new Date(this.cyearM, parseInt(this.cmonthM, 10) + 1, 0);

		this.cyearM = this.currentTimeM.getFullYear();
		this.cmonthM = this.currentTimeM.getMonth() + 1;
		this.lastDateM = new Date(this.cyearM, this.cmonthM, 0);
		this.gTitleM = this.setTitle(this.lastDateM, this.currentView);
		this.xMaxDate = this.calculateDate(this.lastDateM, 2);
		if(this.cmonthM <= 9)
			this.cmonthM = "0" + this.cmonthM;
		this.xMinDate = this.cyearM + "-" + this.cmonthM + "-" + "01" + " " + "00" + ":" + "00";
		$("#spantitle span").text(this.gTitleM);

		if(button == 2) {
			if(this.xMaxDate == this.xMaxDateMonth)
				setTimeout("$('#rightbutton').css('display', 'none');", 450);
			else
				$("#rightbutton").css("display", "block");
		}

		this.setGraph(this.currentView, this.xMinDate, this.xMaxDate, this.gTitleM);
	},
	/**
	 *Name: leftButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	leftButtonClick : function() {
		$("#leftbutton").addClass('ui-btn-active');
		$("#rightbutton").css("display", "block");
		if(this.currentView == "Month") {
			this.changeDatesMonth(1);
		} else if(this.currentView == "Week") {
			this.maxWeekDate = this.minWeekDate;
			this.maxDateW = this.calculateDate(this.maxWeekDate, 1);
			this.gTitleWmax=new Date(this.maxWeekDate.getTime() - (1 * 24 * 60 * 60 * 1000));
			this.gTitleWmax = this.setTitle(this.gTitleWmax, this.currentView);
			this.minWeekDate = new Date(this.maxWeekDate.getTime() - (7 * 24 * 60 * 60 * 1000));
			this.minDateW = this.calculateDate(this.minWeekDate, 1);
			this.gTitleWmin = this.setTitle(this.minWeekDate, this.currentView);
			this.gTitleW = this.gTitleWmin + "-" + this.gTitleWmax;
			$("#spantitle span").text(this.gTitleW);
			this.setGraph(this.currentView, this.minDateW, this.maxDateW, this.gTitleW);

		} else {
			this.maxDayDate = this.minDayDate;
			this.maxDateD = this.calculateDate(this.maxDayDate, 1);
			this.minDayDate = new Date(this.maxDayDate.getTime() - (24 * 60 * 60 * 1000));
			this.minDateD = this.calculateDate(this.minDayDate, 1);
			this.gTitleD = this.setTitle(this.minDayDate, this.currentView);
			$("#spantitle span").text(this.gTitleD);

			this.setGraph(this.currentView, this.minDateD, this.maxDateD, this.gTitleD);

		}
		this.plotGraph(this.getPlotOptions, this.dataPoints);
	},
	/**
	 *Name: rightButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	rightButtonClick : function(e) {
		$("#rightbutton").addClass('ui-btn-active');
		if(this.currentView == "Month") {
			this.changeDatesMonth(2);
		} else if(this.currentView == "Week") {
			this.minWeekDate = this.maxWeekDate;
			this.minDateW = this.calculateDate(this.minWeekDate, 1);
			this.gTitleWmin = this.setTitle(this.minWeekDate, this.currentView);
			this.maxWeekDate = new Date(this.minWeekDate.getTime() + (7 * 24 * 60 * 60 * 1000));
			this.maxDateW = this.calculateDate(this.maxWeekDate, 1);
			this.gTitleWmax=new Date(this.maxWeekDate.getTime() - (1 * 24 * 60 * 60 * 1000));
			this.gTitleWmax = this.setTitle(this.gTitleWmax, this.currentView);
			this.gTitleW = this.gTitleWmin + "-" + this.gTitleWmax;
			$("#spantitle span").text(this.gTitleW);
			if(this.maxDateW == this.xMaxDateWeek)
				setTimeout("$('#rightbutton').css('display', 'none');", 450);
			else
				$("#rightbutton").css("display", "block");
			this.setGraph(this.currentView, this.minDateW, this.maxDateW, this.gTitleW);

		} else {
			this.minDayDate = this.maxDayDate;
			this.minDateD = this.calculateDate(this.minDayDate, 1);
			this.gTitleD = this.setTitle(this.minDayDate, this.currentView);
			$("#spantitle span").text(this.gTitleD);
			this.maxDayDate = new Date(this.minDayDate.getTime() + (24 * 60 * 60 * 1000));
			this.maxDateD = this.calculateDate(this.maxDayDate, 1);
			if(this.maxDateD == this.xMaxDateDay)
				setTimeout("$('#rightbutton').css('display', 'none');", 450);
			else
				$("#rightbutton").css("display", "block");
			this.setGraph(this.currentView, this.minDateD, this.maxDateD, this.gTitleD);

		}
		this.plotGraph(this.getPlotOptions, this.dataPoints);
	},
	/**
	 *Name: monthButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	monthButtonClick : function(e) {
		this.setMonthView();
		$("#spantitle span").text(this.gTitleM);
		$("#rightbutton").css("display", "none");
		this.plotGraph(this.getPlotOptions, this.dataPoints);

	},
	/**
	 *Name: weekButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	weekButtonClick : function(e) {
		this.setWeekView();
		$("#spantitle span").text(this.gTitleW);
		$("#rightbutton").css("display", "none");
		this.plotGraph(this.getPlotOptions, this.dataPoints);
	},
	/**
	 *Name: dayButtonClick
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	dayButtonClick : function(e) {
		this.currentView = "Day";
		this.minDayDate = new Date(this.currentTime.getTime());
		this.minDateD = this.calculateDate(this.minDayDate, 1);
		this.gTitleD = this.setTitle(this.minDayDate, this.currentView);
		$("#spantitle span").text(this.gTitleD);
		$("#rightbutton").css("display", "none");
		this.maxDayDate = new Date(this.currentTime.getTime() + (24 * 60 * 60 * 1000));
		this.maxDateD = this.calculateDate(this.maxDayDate, 1);
		this.xMaxDateDay = this.maxDateD;
		this.setGraph(this.currentView, this.minDateD, this.maxDateD, this.gTitleD);
		this.plotGraph(this.getPlotOptions, this.dataPoints);
	},
	/**
	 *Name: plotGlucoseCords
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	plotGlucoseCords : function(glucosedata) {
		var storeCords = new Array();
		var plotData = glucosedata;
		for(var counter = 0; counter < plotData.length; counter++) {
			var userTime = parseInt((plotData[counter].measurementDate).substr(9, 2), 10);
			var healthData = parseInt(plotData[counter].value);
			storeCords[counter] = new Array(2)
			if(userTime >= 6 && userTime < 9)
				storeCords[counter][0] = 2;
			else if(userTime >= 9 && userTime < 11)
				storeCords[counter][0] = 6;
			else if(userTime >= 11 && userTime < 14)
				storeCords[counter][0] = 10;
			else if(userTime >= 14 && userTime < 17)
				storeCords[counter][0] = 14;
			else if(userTime >= 17 && userTime < 20)
				storeCords[counter][0] = 18;
			else if(userTime >= 20 && userTime < 23)
				storeCords[counter][0] = 22;
			else if(userTime >= 23 || userTime < 6)
				storeCords[counter][0] = 26;

			storeCords[counter][1] = healthData;
		}

		var groupSixAm = 0, groupNineAm = 0, groupElevenAm = 0, groupTwoPm = 0, groupSixPm = 0, groupEightPm = 0, groupElevenPm = 0;
		var countGroupSixAm = 0, countGroupNineAm = 0, countGroupElevenAm = 0, countGroupTwoPm = 0, countGroupSixPm = 0, countGroupEightPm = 0, countGroupElevenPm = 0;
		this.plotCords = storeCords;
		var plotCords_length = this.plotCords.length;
		for(var i = 0; i < plotCords_length; i++) {
			if(this.plotCords[i][0] == 2) {
				groupSixAm = groupSixAm + this.plotCords[i][1];
				countGroupSixAm = countGroupSixAm + 1;
			} else if(this.plotCords[i][0] == 6) {
				groupNineAm = groupNineAm + this.plotCords[i][1];
				countGroupNineAm = countGroupNineAm + 1;
			} else if(this.plotCords[i][0] == 10) {
				groupElevenAm = groupElevenAm + this.plotCords[i][1];
				countGroupElevenAm = countGroupElevenAm + 1;
			} else if(this.plotCords[i][0] == 14) {
				groupTwoPm = groupTwoPm + this.plotCords[i][1];
				countGroupTwoPm = countGroupTwoPm + 1;
			} else if(this.plotCords[i][0] == 18) {
				groupSixPm = groupSixPm + this.plotCords[i][1];
				countGroupSixPm = countGroupSixPm + 1;
			} else if(this.plotCords[i][0] == 22) {
				groupEightPm = groupEightPm + this.plotCords[i][1];
				countGroupEightPm = countGroupEightPm + 1;
			} else {
				groupElevenPm = groupElevenPm + this.plotCords[i][1];
				countGroupElevenPm = countGroupElevenPm + 1;
			}
		}
		this.avgCords = [[2, groupSixAm / countGroupSixAm], [6, groupNineAm / countGroupNineAm], [10, groupElevenAm / countGroupElevenAm], [14, groupTwoPm / countGroupTwoPm], [18, groupSixPm / countGroupSixPm], [22, groupEightPm / countGroupEightPm], [26, groupElevenPm / countGroupElevenPm]];
		this.thresholdMinGlucose = [[0, 80], [28, 80]];
		this.thresholdMaxGlucose = [[0, 40], [28, 40]];

		this.glucosePlotOptions = {
			title : "Blood Glucose",
			axes : {
				xaxis : {
					min : 0,
					max : 28,
					//ticks: [[0, "6am-9am"], [4, "9am-11am"], [8, "11am-2pm"], [12,"2pm-5pm"],[16,"5pm-8pm"],[20,"8pm-11pm"],[24,"11pm-6am"],[28," "]],
					ticks : [[0, "6am"], [4, "9am"], [8, "11am"], [12, "2pm"], [16, "5pm"], [20, "8pm"], [24, "11pm"], [28, "6am"]],
					tickInterval : 4,
					showTickMarks : false
				},
				yaxis : {
					min : 0,
					//max : 350,
					tickInterval : 50,
					tickOptions : {
						formatString : '%.0f'
					},
					showTickMarks : false
					//label: 'mg/dL'
				}
			},
			grid : {
				drawGridLines : true,
				gridLineColor : '#FFFFFF',
				background : '#463E41',
				borderWidth : 0
			},
			stackSeries : true,
			series : [{
				color : '#92c83e', //green
				showLabel : false,
				showMarker : false,
				lineWidth : .1,
				fill : false
			}, {
				color : '#C38EC7', //violet
				showLabel : false,
				showMarker : false,
				lineWidth : 2,
				fill : true,
				fillAlpha : 0.25
			}, {
				disableStack : true,
				color : 'cyan',
				label : 'Data',
				showLine : false,
				markerOptions : {
					size : 7,
					style : "x"
				}
			}, {
				disableStack : true,
				color : 'white',
				label : 'Average',
				showLine : false,
				markerOptions : {
					style : "filledSquare",
					size : 10
				}
			}]
		};

		// plot1 = $.jqplot ("monthgraph", [thresholdMin,thresholdMax,plotCords,avgCords],plotOptions).replot();

	},
	/**
	 *Name: drawGlucoseGraph
	 *Purpose:
	 *Params:
	 *Returns:
	 **/
	drawGlucoseGraph : function() {

		$("#graphtitle span").text(this.healthDataTracker);
		var plot1 = $.jqplot("glucosegraph", [this.thresholdMinGlucose, this.thresholdMaxGlucose, this.plotCords, this.avgCords], this.glucosePlotOptions).replot();
		//	mHealth.util.hideMask();
	},
	/**
	 *Name: showJournal
	 *Purpose: Renders the showjournal.html page content
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	showJournal : function() {
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#journal_content').html(_.template($('#journal_list').html(), {
			trackerData : this.trackerData,
			trackerType : trackerType
		}));

		$('#journal_content').trigger('create');
		//	mHealth.util.hideMask();
	},
	/**
	 *Name: showTracker
	 *Purpose: renders the showtracker.html page
	 *Params: No params required
	 *Returns: Doesn't return
	 **/
	showTracker : function() {
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#trackviewcontent').html(_.template($('#trackerviewtemplate').html(), {
			trackerType : trackerType
		}));
		$('#headercontent').html(_.template($('#headertemplate').html(), {
			trackerType : trackerType
		}));
		$('#headercontent').trigger('create');
		$('#trackviewcontent').trigger('create');
	},
	/**
	 *Name: newEntryTracker
	 *Purpose: renders the showtrackertrack.html page
	 *Params: None
	 *Returns:Doesn't return
	 **/
	newEntryTracker : function() {
		// healthDataTracker has to change to class level.
		var trackerType = {
			"name" : this.healthDataTracker
		};
		$('#showtrackertrackcontent').html(_.template($('#showtrackertracktemplate').html(), {
			trackerType : trackerType
		}));

		$('#showtrackertrackcontent').trigger('create');
	},
	/**
	 *Name: newHDataObject
	 *Purpose: Creates new health data object to be saved
	 *Params: measurement date, collected date and value. These are set in json object that is created.
	 *Returns: returns a formatted object to be passed as a param in the postRequest service call
	 **/
	newHDataObject : function(value, type) {
		var comments = $('#comments').val();
		if(comments == mHealth.TrackerNewEntry.recordComments) {
			comments = "";
		}
		var measurementDate = this.getMeasurementDate();
		return mHealth.recommendation.HealthDataTypeMapper(measurementDate, comments, value, type)
	},
	/**
	 *Name: getMeasurementDate
	 *Purpose: formats the measurement date to be passed as a parameter for health data object
	 *Params: No params
	 *Returns: returns formatted date object
	 **/
	getMeasurementDate : function() {
		var dateSelected = $('#selectDate').val();
		var dateObject = new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2));
		if(this.healthDataTracker == 'Blood Pressure' || this.healthDataTracker == 'Blood Glucose' || this.healthDataTracker == 'Weight & BMI') {
			var hour = dateSelected.substr(11, 2);
			hour = parseInt(hour, 10);
			if(dateSelected.substr(17, 2) == "PM") {
				if(hour != 12)
					hour = hour + 12;
			} else {
				if(hour == 12)
					hour = 0;
			}
			dateObject = new Date(dateSelected.substr(6, 4), (dateSelected.substr(0, 2) - 1), dateSelected.substr(3, 2), hour, dateSelected.substr(14, 2));
		}
		return dateObject.format('yyyymmdd"T"HHMMss".000 GMT"');
	},
	/**
	 *Name: getCurrentContentDiv
	 *Purpose: gets current div of the page
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getCurrentContentDiv : function() {
		var currentDiv = $.mobile.activePage

		if(currentDiv.length == 0) {
			currentDiv = $('body');
		}
		return currentDiv;
	},
	/**
	 *Name: validateForm
	 *Purpose: form fields are validated here
	 *Params: html form object
	 *Returns: returns boolean value denoting the valid form
	 **/
	validateForm : function(form) {
		var e = form.elements;
		var type = document.getElementById('tracker_id').value;
		if(type == 'Cholesterol') {
			if(document.getElementById('value_Cholesterol').value == '') {
				return false;
			} else {
				return true;
			}
		} else {
			for(var elem, i = 0; ( elem = e[i] ); i++) {
				if(elem.type == 'text' || elem.type == 'tel') {
					if(elem.value == '') {
						return false;
					}
				}
			}//for each elem
		}
		return true;
	},
	/**
	 *Name: newEntrySave
	 *Purpose: Saves new tracker entry
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	newEntrySave : function() {
		var currentDiv = this.getCurrentContentDiv();
		if(currentDiv.length > 0) {
			var currentForm = $('form', currentDiv);
			if(this.validateForm(currentForm.get(0))) {
				this.validForm = true;
			} else {
				this.validForm = false;
				mHealth.util.customAlert(mHealth.Validation.generic, 'mHealth');
				setTimeout("$('#track_save').removeClass('ui-btn-active')",100);
				return false;
			}
		}
		if(this.validForm) {

			if(!(this.validateHealthData()))
				return false;
		}
	},
	setTrackerId : function() {
		var trackerId = '';
		if(this.healthDataTracker == 'Blood Glucose') {
			trackerId = 'Bloodglucose';
		} else if(this.healthDataTracker == 'Dilated Retinal Exam') {
			trackerId = 'RetinalExam';
		} else if(this.healthDataTracker == 'Foot Exam - Self') {
			trackerId = 'FootSelfExam';
		} else if(this.healthDataTracker == 'Foot Exam - Provider') {
			trackerId = 'FootExam';
		} else if(this.healthDataTracker == 'Microalbumin') {
			trackerId = 'MAU';
		} else if(this.healthDataTracker == 'A1c') {
			trackerId = 'A1C';
		} else if(this.healthDataTracker == 'Weight & BMI') {
			trackerId = 'Weight';
		} else if(this.healthDataTracker == 'Blood Pressure') {
			trackerId = 'BPS';
		} else if(this.healthDataTracker == 'Cholesterol') {
			trackerId = 'Cholesterol';
		}
		return trackerId;
	},
	/**
	 *Name: newEntrySave
	 *Purpose: Saves new tracker entry
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	validateHealthData : function() {
		var healthDataResponse = [];
		var trackerId = this.setTrackerId();
		healthDataResponse = this.getHealthTrackerData(trackerId);
		if(this.isExists(healthDataResponse) === true) {
			this.postHealthDataResponse();
			return true;
		} else {
			mHealth.util.customAlert(mHealth.TrackerNewEntry.existingData, 'mHealth');
			setTimeout("$('#track_save').removeClass('ui-btn-active')",100);
			return false;
		}

	},
	isExists : function(healthDataResponse) {
		var formattedDateObject = this.getMeasurementDate();
		var flag = true;
		healthDataResponse.map(function(response) {
			if(response.measurementDate == formattedDateObject) {
				flag = false;
				return flag;
			}
		});
		return flag;
	},
	/**
	 *Name: postHealthDataResponse
	 *Purpose: success callback function for new entry tracker save
	 *Params: output from postRequest as implicit param
	 *Returns: Doesn't return
	 **/
	postHealthDataResponse : function() {

		var formattedDateObject = this.getMeasurementDate();
		var weightModifier = 1;
		var trackerId = this.setTrackerId();
		var hDataObject = null;
		var value = 0;

		if(this.healthDataTracker == 'Foot Exam - Provider' || this.healthDataTracker == 'Dilated Retinal Exam') {
			var trackerId;
			if(this.healthDataTracker == 'Foot Exam - Provider')
				trackerId = 'FootExam';
			else
                trackerId = 'RetinalExam';
    		hDataObject = this.newHDataObject("0", trackerId);

         } else if (trackerId == 'FootSelfExam') {
             value = $('select#examOptn option:selected').val();       
        } else if(trackerId == "Weight") {
			if(mHealth.util.selWeightUnits == 'Kg') {
				weightModifier = 2.205;
			}
			value = String(Math.round(parseInt($('#value_Weight').val(), 10) * weightModifier));
			var bmiHDataObject = this.newHDataObject($('#value_BMI').val(), 'BMI');
			
			this.service.postRequest((mHealth.env.healthdata_url + "BMI"), bmiHDataObject, null, null, false);
			mHealth.models.HealthDataModel.customFromJSON(bmiHDataObject);

		} else if(trackerId == "BPS") {
			value = $('#value_SYS').val();
			var diaHDataObject = this.newHDataObject($('#value_DIA').val(), 'BPD');
			this.service.postRequest((mHealth.env.healthdata_url + "BPD"), diaHDataObject, null, null, false);
			mHealth.models.HealthDataModel.customFromJSON(diaHDataObject);
		} else if(trackerId == "Cholesterol") {
			var ldlValue = $('#value_LDL').val();
			var hdlValue =$('#value_HDL').val();
			var triValue =$('#value_Tri').val();
			var ldlHDataObject = this.newHDataObject(ldlValue, "LDL");
			var hdlHDataObject = this.newHDataObject(hdlValue, 'HDL');
			var triHDataObject = this.newHDataObject(triValue, 'Triglycerides');
			value = $('#value_Cholesterol').val();
			if(ldlValue != '') {
				this.service.postRequest((mHealth.env.healthdata_url + "LDL"), ldlHDataObject, null, null, false);
				mHealth.models.HealthDataModel.customFromJSON(ldlHDataObject);
			}
			if(hdlValue != '') {
				this.service.postRequest((mHealth.env.healthdata_url + "HDL"), hdlHDataObject, null, null, false);
				mHealth.models.HealthDataModel.customFromJSON(hdlHDataObject);
			}
			if(triValue != '') {
				this.service.postRequest((mHealth.env.healthdata_url + "Triglycerides"), triHDataObject, null, null, false);
				mHealth.models.HealthDataModel.customFromJSON(triHDataObject);
			}
		} else {
			value = parseInt($("#value_" + trackerId).val());
		}
		hDataObject = this.newHDataObject(value, trackerId);
		mHealth.models.HealthDataModel.customFromJSON(hDataObject);
		this.service.postRequest((mHealth.env.healthdata_url + trackerId), hDataObject, null, null, false);
        this.proxy(this.getJournalData());
	},
	/**
	 *Name: getJournalData
	 *Purpose:  gets the Journal Data using getResponse service call. Called on view my journal click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getJournalData : function() {
		var hasMultiValue = false;
		var healthDataResponse = [];
		var trackerId = this.setTrackerId();
		var subHealthDataTypes = [];
       
        if(this.healthDataTracker == "Blood Pressure") {
			hasMultiValue = true;
			subHealthDataTypes = ['BPS', 'BPD'];
		} else if(this.healthDataTracker == "Cholesterol") {
			hasMultiValue = true;
			subHealthDataTypes = ['LDL', 'HDL', 'Cholesterol', 'Triglycerides'];
		} else if(this.healthDataTracker == "Weight & BMI") {
			hasMultiValue = true;
			subHealthDataTypes = ['Weight', 'BMI'];
		}
		if(hasMultiValue === false) {
			healthDataResponse = this.getHealthTrackerData(trackerId);
		} else {
			for(var i = 0; i < subHealthDataTypes.length; i++) {
				healthDataResponse = healthDataResponse.concat(this.getHealthTrackerData(subHealthDataTypes[i]));
			}
		}
		if(healthDataResponse != null) {
			sortedData = this.getSortedData(healthDataResponse);
			this.trackerData = this.getFormattedData(sortedData);
			$.mobile.changePage('showjournal.html');
		} else {
			mHealth.util.showMask();
			if(hasMultiValue === false) {
				var URL = mHealth.env.healthdata_url + trackerId + "?maxdays=45";
				this.service.getResponse(URL, this.proxy(this.processHealthData), this.proxy(this.getJournalFailure), true);
			} else {

				for(var i = 0; i < subHealthDataTypes.length; i++) {
					var URL = mHealth.env.healthdata_url + subHealthDataTypes[i] + "?maxdays=45";
					this.service.getResponse(URL, this.proxy(this.processHealthData), null, false);

				}
			}
		}
		return;
	},
	processHealthData : function(output) {

	},
	getHealthTrackerData : function(healthDataType) {
		var healthDataResponse = [];
		var modelResponse = mHealth.models.HealthDataModel.findAllByAttribute("healthDataType", healthDataType);
		modelResponse.map(function(response) {
			healthDataResponse.push(response);
		});
		return healthDataResponse;
	},
	/**
	 *Name: getGraphData
	 *Purpose:  gets the Graph Data using getResponse service call. Called on view my graph click.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	getGraphData : function() {
		var healthDataResponse = [];
		var healthDataResponseDouble = [];
		var trackerId = this.setTrackerId();
		if(this.healthDataTracker == "Cholesterol") {
			$.mobile.changePage('detailscholesterol.html');
		} else {
			if(trackerId == 'Bloodglucose') {
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotBloodGlocuseGraph(healthDataResponse);
				return;
			} else if(this.healthDataTracker == 'Weight & BMI') {
				trackerId1 = "Weight";
				trackerId2 = "BMI";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotDoubleGraph(healthDataResponse, healthDataResponseDouble);
				return;
			} else if(this.healthDataTracker == 'Blood Pressure') {
				trackerId1 = "BPS";
				trackerId2 = "BPD";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotDoubleGraph(healthDataResponse, healthDataResponseDouble);
				return;
			} else if(this.healthDataTracker == 'LDL & HDL') {
				trackerId1 = "LDL";
				trackerId2 = "HDL";
				healthDataResponse = this.getHealthTrackerData(trackerId1);
				healthDataResponseDouble = this.getHealthTrackerData(trackerId2);
				this.plotDoubleGraph(healthDataResponse, healthDataResponseDouble);
				return;
			} else if(this.healthDataTracker == 'Triglycerides') {
				healthDataResponse = this.getHealthTrackerData(this.healthDataTracker);
				this.plotSingleGraph(healthDataResponse);
				return;
			} else if(this.healthDataTracker == 'Total Cholesterol') {
				trackerId = 'Cholesterol';
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotSingleGraph(healthDataResponse);
				return;
			} else if(this.healthDataTracker == 'A1c') {
				trackerId = 'A1C';
				healthDataResponse = this.getHealthTrackerData(trackerId);
				this.plotSingleGraph(healthDataResponse);
				return;
			}

		}

	},
	setHealthData : function(output) {
		var response = JSON.parse(output.responseText);
		var modelData = JSON.stringify(response);
		mHealth.models.HealthDataModel.customFromJSON(modelData);
	},
	plotBloodGlocuseGraph : function(healthDataValue) {
		this.seriesDataSet1 = healthDataValue;
		location.href = "gyro://startRotation?";
		this.plotGlucoseCords(this.seriesDataSet1);
		$.mobile.changePage('glucosegraph.html');
	},
	plotSingleGraph : function(healthDataValue) {
		this.seriesDataSet1 = healthDataValue;
		this.showGraph();
		location.href = "gyro://loadChart?";
		$.mobile.changePage('showgraph.html');
	},
	plotDoubleGraph : function(healthDataValue1, healthDataValue2) {
		this.seriesDataSet1 = healthDataValue1;
		this.seriesDataSet2 = healthDataValue2;
		this.showGraph();
		location.href = "gyro://loadChart?";
		$.mobile.changePage('showgraph.html');
	},
	/**
	 *Name: getSortedData
	 *Purpose: sorts the health data based on measurement date.
	 *Params: health data to be sorted is passed as param
	 *Returns: returns the sorted health data
	 **/
	getSortedData : function(healthData) {
		var keys = [];
		var sortedData = [];
		for(var i in healthData) {
			keys[i] = [];
			keys[i][0] = healthData[i]["measurementDate"];
			keys[i][1] = i;

		}
		keys.sort();
		keys.reverse();

		for(var i in keys) {
			sortedData.push(healthData[keys[i][1]]);
		}
		return sortedData;
	},
	/**
	 *Name: getFormattedData
	 *Purpose:  formats the sorted health data to key value pairs based on measurement date.
	 *Params: takes sorted health data as parameter
	 *Returns: returns the formatted hash object
	 **/
	getFormattedData : function(sortedData) {
		var healthDataObjects = new Object();
		var len = sortedData.length;
		var child = new Object();
		if(this.healthDataTracker == 'A1c' || this.healthDataTracker == 'Blood Glucose' || this.healthDataTracker == 'Microalbumin' || this.healthDataTracker == 'Foot Exam - Provider' || this.healthDataTracker == 'Dilated Retinal Exam' || this.healthDataTracker == 'Foot Exam - Self') {
			for(var i = 0; i < len; i++) {
				child = new Object();
				child['measurementDate'] = sortedData[i]['measurementDate'];
				child['value'] = sortedData[i]['value'];
				child['comments'] = sortedData[i]['comments'];
				healthDataObjects[sortedData[i].measurementDate] = child;
			}
		} else {
			var key;
			for(var i = 0; i < len; i++) {
				key = sortedData[i].measurementDate;
				if(healthDataObjects.hasOwnProperty(key)) {
					if(child['measurementDate'] == key)
						child[sortedData[i].healthDataType] = sortedData[i].value;
				} else {
					child = new Object();
					child['comments'] = sortedData[i].comments;
					child['measurementDate'] = sortedData[i].measurementDate;
					child[sortedData[i].healthDataType] = sortedData[i].value;
				}
				healthDataObjects[key] = child;
			}
		}
		return healthDataObjects;
	},
	/**
	 *Name: getJournalFailure
	 *Purpose: Failure callback function for get journal data.
	 *Params: Implicit callback function params
	 *Returns:: Doesn't return
	 **/
	getJournalFailure : function(jqXHR, textStatus, errorThrown) {
		mHealth.util.hideMask();
	},
	/**
	 *Name: setGlucoseTracker
	 *Purpose: Opens detailtracker.html when blood glucose icon is clicked on home page. sets the healthDataTracker to Blood Glucose.
	 *Params: No params
	 *Returns::
	 **/
	setGlucoseTracker : function() {
		this.healthDataTracker = 'Blood Glucose';
		location.href = "tabbar://loadTrackers?";
		$.mobile.changePage('../../trackers/view/detailtracker.html');
	},
	/**
	 *Name: viewNewEntry
	 *Purpose: changes page to showtrackertrack.html or profile.html based on trackertype and participant height value.
	 *Params: No params
	 *Returns: Doesn't return
	 **/
	viewNewEntry : function() {
		if(this.healthDataTracker == "Weight & BMI") {
			var participant = mHealth.models.ParticipantModel.first();
			if(participant) {
				if(participant.height == "" || participant.height == undefined) {
					mHealth.util.heightFlag = false;
					location.href = "tabbar://loadHome?";
					$.mobile.changePage('../../home/view/profile.html');
				} else {
					$.mobile.changePage('showtrackertrack.html');
				}
			} else
				mHealth.util.customAlert(mHealth.TrackerBmi.enterHeightError, 'mHealth');
		} else
			$.mobile.changePage('showtrackertrack.html');
	},
});
