/**  
  * Assessment UI generator
  **/
mHealth.assessment = {
/**
	 * Name:generate_html
	 * purpose:to generate dynamic html according to entry
	 * type Params:entrytype and data with question and answers
	 * return : random generated html
	 */
	generate_html : function(data, entryType) {
		switch(entryType) {
			case "Dropdown":
				output_html=get_dropdown_html(data);
				break;
			case "RadioButton":
				get_radio_html(data);
				break;
			case "TwoNumberEdit":
				break;
			case "TextArea":
				break;
			case "NumberEdit":
				output_html = this.get_numberedit_html(data);
				break;
			case "Checkbox":
				output_html = this.get_checkbox_html(data);
				break;
			case "TextEdit":
				break;
			case "Likert":
				break;
			case "Date":
				break;
			case "Time":
				break;
			case "DateTime":
				break;
		}
		return output_html;
	},
/**
  * Name    : get_dropdown_html
  * Purpose : Method to create request body for recommendation Service.
  * Params  : responseType -  recommendation type
  * Returns : bodyContent
  **/
	get_dropdown_html : function(data) {					
			answers=[];
			var disabled = false;
			var answersId = [];	
			var j = 0;	
			var instance_outputHTML ='';				
			var i = 0;	
			var j =0;						
			mHealth.models.ParticipantAnswerModel.each(function(participantAnswer){
				data.section[ 0].question.map(function(question){	
					question.answer.map(function(answer) {
						if(participantAnswer.answerId === answer.answerId && participantAnswer.questionId === answer.questionId) {													
							disabled = true;							
							answersId.push(answer.answerId);						
						}
					});
				 });
			});
			
				if(!disabled) {					
					data.section[0].question.map(function(question){	
						answers=[];					
						instance_outputHTML += "<div data-role='collapsible' data-content-theme='d' ><h1>"+question.theQuestion+"</h1>";		
						instance_outputHTML += "<p>";						
						instance_outputHTML += "<select data-native-menu='true' id='questionId["+j+"]' name='form[dropdown]' class='selectValue'>";
						instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">Please Select One</option>";								
						data.section[0].question[i].answer.map(function(answer) {							
								if(question.questionId == "Question 3"){									
									var medicalDevices = JSON.parse(devices);									
									medicalDevices.map(function(device){										
										instance_outputHTML += "<option name ='form[dropdown]' value='{"+device.sku+"}'>";
									    instance_outputHTML += device.description;
									    instance_outputHTML += "</option>"	;
								    }); 
								    instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">None</option>";
								    instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">Others</option>";	
								}else{
									instance_outputHTML += "<option name ='form[dropdown]' value='{"+answer.answerOptionText+"}'>";
									instance_outputHTML += answer.answerOptionText;
									instance_outputHTML += "</option>";	
							    }
							    answers.push(answer);																				
						});												
						instance_outputHTML += "</select>";
						instance_outputHTML += "</p>";	
						instance_outputHTML += "</div>";
						i++;
						j++;
					});
				}
			   else if(disabled) {
			   	mHealth.LoginControllerObject.updateProgressBar(3);
			   	data.section[0].question.map(function(question){	
						answers=[];					
						instance_outputHTML += "<div data-role='collapsible' data-content-theme='d' ><h1>"+question.theQuestion+"</h1>";		
						instance_outputHTML += "<p>";						
						instance_outputHTML += "<select disabled id='questionId["+j+"]' name='form[dropdown]' class='selectValue'>";														
						question.answer.map(function(answer) {	
							if(answer.answerId == answersId[i]) {
								instance_outputHTML += "<option selected='yes' ";		
							} else if(answer.answerId != answersId[i]) {
								instance_outputHTML += "<option ";		
							}
							if(question.questionId == "Question 3"){									
									var medicalDevices = JSON.parse(devices);									
									medicalDevices.map(function(device){										
										instance_outputHTML += "name ='form[dropdown]' value='{"+device.sku+"}'>";
									    instance_outputHTML += device.description;
									    instance_outputHTML += "</option>"	;
								    });	
							}else{
									instance_outputHTML += "name ='form[dropdown]' value='{"+answer.answerId+"}'>";
									instance_outputHTML += answer.answerOptionText;
									instance_outputHTML += "</option>";	
							}
							answers.push(answer);																			
						});												
						instance_outputHTML += "</select>";
						instance_outputHTML += "</p>";	
						instance_outputHTML += "</div>";
						i++;
						j++;
					});							
				}	
						
			return instance_outputHTML;
	},
	/**
	 * Name : get_checkbox_html
	 * Purpose :Method to get checkbox .
	 * Params:questions with answers
	 * Returns : checkbox html with question and answers
	 */
	get_checkbox_html : function(question, date) {
		disabled = false;
		id = "";
		var j = 0;
		var k = 0;
		// question.map(function(question) {
			// if(mHealth.models.ParticipantAnswerModel.exists(answer)) {
					// disabled = true;
					// id = answer.answerId;
				// }
		// });
		class_outputHTML = "";
		class_outputHTML += "<div data-role='fieldcontain'>";
		class_outputHTML += "<fieldset>";
		alert('Len'+question.length);
		if(!disabled) {
			for(var i = 0; i < question.length; i++) {
				class_outputHTML += "<legend>" + question[i].Title  + "</legend>";
				// alert(question[i].length);
				// if(question[i].length > 1) {
						// class_outputHTML += "<label for='{" + question[i].ID + "}'>" + question[i].Title + "</label>";
						// class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" +  question[i].ID + "}' value='{"+ question[i].Title+ "}' />";
// 					
				// } else if(question[i].length == 1) {
					class_outputHTML += "<label for='{" + question[i].ID + "}'>" + question[i].Title + "</label>";
					class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" + question[i].ID + "}' value='{" + question[i].Title + "}' />";
				//}
			}
		} else if(disabled) {
			for(var i = 0; i < question.length; i++) {
				class_outputHTML += "<legend>" + question[i].theQuestion + "</legend>";
				if(question[i].length > 1) {
					for(var k = 0; k < questions[k].length; k++) {
						class_outputHTML += "<label for='{" + question[k].ID + "}'>" + question[i].Title + "</label>";
						class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" + questions[i].questionId + "}' value='{" + questions[i].answer[k].theAnswer + "}' checked disabled />";
					}

				} else if(question[i].length == 1) {
					class_outputHTML += "<label for='{" + questions[i].questionId + "}'>" + questions[i].theQuestion + "</label>";
					class_outputHTML += "<input type=\"checkbox\" name=\"form[checkbox]+questions[i].questionId+\" id='{" + questions[i].questionId + "}' value='{" + questions[i].answer[0].theAnswer + "}' disabled />";
				}
			}
		}
		class_outputHTML += "</fieldset></div>";
		return class_outputHTML;
	},
	/**
	 * Name : get_numberedit_html
	 * Purpose :Method to get number edit html .
	 * Params:questions with answers
	 * Returns : input type with number edit html with question and answers
	 */
	get_numberedit_html : function(question, date) {
		instance_outputHTML = "";
		instance_outputHTML += "<div data-role='fieldcontain'>";
		var ParticipantAnswer
		if(ParticipantAnswer) {
			//if (ParticipantAnswer.exists(question.answers[0], date)) {
			value = ParticipantAnswer.getby_answer(question.answers[0], date).answerValue1;
			instance_outputHTML += "<label for=" +question[0].Title + ">" + question[0].Title + "</label>";
			instance_outputHTML += "<input type=\"tel\" id=\'{question.questionId}\
			' maxlength=\"3\" value=\"\" class='ui-disabled' style=\"width:50px\" name=\"form[{answer.object}}]\" disabled/>";

		} else {
			instance_outputHTML += "<label for=" +question[0].ID + ">" + question[0].Title + "</label>";
			instance_outputHTML += "<input type=\"tel\" pattern=\"[0-9]*\" style=\"width:50px\"  maxlength=\"3\" id=" + question[0].ID + " name=\"form[number]\"/>";
			instance_outputHTML += "<input type=\"hidden\" name=\"form[number]\" value=\"number\"/>";
		}
		instance_outputHTML += "</div>";
		alert(instance_outputHTML);
		return instance_outputHTML;

	}
};