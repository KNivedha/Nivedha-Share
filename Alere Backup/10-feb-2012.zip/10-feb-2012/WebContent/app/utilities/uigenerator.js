/**  
  * Assessment UI generator
  **/
mHealth.assessment = {

/**
  * Name    : createRecommendationRequestJSON
  * Purpose : Method to create request body for recommendation Service.
  * Params  : responseType -  recommendation type
  * Returns : bodyContent
  **/
	get_dropdown_html : function(data) {					
			answers=[];
			var disabled = false;
			var answersId = [];	
			var j = 0;	
			var instance_outputHTML ='';				
			var i = 0;	
			var j =0;						
			mHealth.models.ParticipantAnswerModel.each(function(participantAnswer){
				data.section[ 0].question.map(function(question){	
					question.answer.map(function(answer) {
						if(participantAnswer.answerId === answer.answerId && participantAnswer.questionId === answer.questionId) {													
							disabled = true;							
							answersId.push(answer.answerId);						
						}
					});
				 });
			});
			
				if(!disabled) {					
					data.section[0].question.map(function(question){	
						answers=[];					
						instance_outputHTML += "<div data-role='collapsible' data-content-theme='d' ><h1>"+question.theQuestion+"</h1>";		
						instance_outputHTML += "<p>";						
						instance_outputHTML += "<select id='questionId["+j+"]' name='form[dropdown]' class='selectValue'>";
						instance_outputHTML += "<option  name =\"form[dropdown]\" value=\"default\">Please Select One</option>";								
						data.section[0].question[i].answer.map(function(answer) {																																		
								if(question.theQuestion == "What glucometer do you predominantly use?"){									
									var medicalDevices = JSON.parse(devices);									
									medicalDevices.map(function(device){										
										instance_outputHTML += "<option name ='form[dropdown]' value='{"+device.sku+"}'>";
									    instance_outputHTML += device.description;
									    instance_outputHTML += "</option>"	;
								    })	
								}else{
									instance_outputHTML += "<option name ='form[dropdown]' value='{"+answer.answerOptionText+"}'>";
									instance_outputHTML += answer.answerOptionText;
									instance_outputHTML += "</option>";	
							    }
							    answers.push(answer);																				
						});												
						instance_outputHTML += "</select>";
						instance_outputHTML += "</p>";	
						instance_outputHTML += "</div>";
						i++;
						j++;
					});
				}
			   else if(disabled) {
			   	mHealth.LoginControllerObject.updateProgressBar(3);
			   	data.section[0].question.map(function(question){	
						answers=[];					
						instance_outputHTML += "<div data-role='collapsible' data-content-theme='d' ><h1>"+question.theQuestion+"</h1>";		
						instance_outputHTML += "<p>";						
						instance_outputHTML += "<select disabled id='questionId["+j+"]' name='form[dropdown]' class='selectValue'>";														
						question.answer.map(function(answer) {	
							if(answer.answerId == answersId[i]) {
								instance_outputHTML += "<option selected='yes' ";		
							} else if(answer.answerId != answersId[i]) {
								instance_outputHTML += "<option ";		
							}
							if(question.theQuestion == "What glucometer do you predominantly use?"){									
									var medicalDevices = JSON.parse(devices);									
									medicalDevices.map(function(device){										
										instance_outputHTML += "name ='form[dropdown]' value='{"+device.sku+"}'>";
									    instance_outputHTML += device.description;
									    instance_outputHTML += "</option>"	;
								    });	
							}else{
									instance_outputHTML += "name ='form[dropdown]' value='{"+answer.answerId+"}'>";
									instance_outputHTML += answer.answerOptionText;
									instance_outputHTML += "</option>";	
							}
							answers.push(answer);																			
						});												
						instance_outputHTML += "</select>";
						instance_outputHTML += "</p>";	
						instance_outputHTML += "</div>";
						i++;
						j++;
					});							
				}	
						
			return instance_outputHTML;
	}
};