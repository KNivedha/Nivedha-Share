Answer=Spine.Model.sub();
Answer.configure('Answer','participantId','answerId','createTimestamp','updateTimestamp','startDate',
		'endDate','learnMore','triggers','assessmentId','sectionId','questionId','language','rank',
		'entryType','theAnswer','imageURL','indicatorValue');




