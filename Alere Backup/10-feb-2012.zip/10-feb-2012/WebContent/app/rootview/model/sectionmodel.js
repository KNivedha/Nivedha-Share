mHealth.models.SectionModel = Spine.Model.sub();
mHealth.models.SectionModel.configure('SectionModel','question', 'participantId', 'assessmentId', 'sectionId', 'language', 'title', 'rank', 'questionsPerPage', 'image', 'imageURL', 'createTimestamp', 'updateTimestamp', 'startDate ', 'endDate', 'learnMore', 'triggers');

mHealth.models.ParticipantAnswerModel = Spine.Model.sub();
mHealth.models.ParticipantAnswerModel.configure('ParticipantAnswerModel', 'participantId', 'assessmentId', 'sectionId', 'questionId', 'answerId', 'origin', 'language', 'answerValue', 'comments', 'longitude', 'latitude', 'location', 'imageResponse', 'createTimestamp', 'updateTimestamp', 'recordingTimestamp', 'dirty', 'entryType', 'indicatorValue');

mHealth.models.AssessmentModel = Spine.Model.sub();
mHealth.models.AssessmentModel.configure('AssessmentModel', 'section', 'assessmentId', 'participantId', 'language', 'title', 'frequencyHours', 'recurringFlag', 'rank', 'dashboardModuleId', 'introCopy', 'maxCredits', 'earnedCredits', 'status ', 'image', 'imageURL', 'createTimestamp', 'updateTimestamp', 'startDate ', 'endDate', 'learnMore', 'triggers', 'nextTierPoints', 'earnedPts ','isEngaged');

mHealth.models.AnswerModel = Spine.Model.sub();
mHealth.models.AnswerModel.configure('AnswerModel', 'participantId', 'answerId', 'createTimestamp', 'updateTimestamp', 'startDate', 'endDate', 'learnMore', 'triggers', 'assessmentId', 'sectionId', 'questionId', 'language', 'rank', 'entryType', 'theAnswer', 'imageURL', 'indicatorValue','answerOptionText');

mHealth.models.QuestionModel = Spine.Model.sub();
mHealth.models.QuestionModel.configure("QuestionModel", "answer", "participantId", "questionId", "createTimestamp", "updateTimestamp", "startDate", "endDate", "learnMore", "triggers", "assessmentId", "sectionId", "language", "rank", "theQuestion", "allowMultipleChoice", "imageURL", "indicatorName");
