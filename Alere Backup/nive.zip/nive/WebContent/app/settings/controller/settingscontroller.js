/**
 * Controller : SettingsController
 * Controller to do logic of settings
 **/
mHealth.controllers.SettingsController = Spine.Controller.sub({
	el : 'body',
	service : mHealth.util.RemoteServiceProxy.getInstance(),
	events : {
		'click #logoutId' : 'doLogout',
		'click #showAbout' : 'getFeatures',
		'click #sendFeedBack' : 'sendMail',
		'pagebeforeshow #aboutsDetail' : 'showDetail',
		'change #HeightUnit' : 'getHeightUnits',
		'change #WeightUnit' : 'getWeightUnits',
		'pagebeforeshow #settingsPage' : 'showSettings',
		'click #debugId' : 'debug',
        'click #alfrescontent' : 'getAlfresco',
        'click #healthwise' : 'getHealthwise',
        'click #overlay': 'getOverlay',
        'click #hw_samepage' : 'getHealthwisePage',
        //'click #directArticle' : 'getdirectArticle' ,
        'pagebeforeshow #articlePage' : 'showArticles',  
        'click .articleLink' : 'openArticleLink'  ,
        'pagebeforeshow #articleContentPage' : 'showArticlesContent',
        'click #brightcove' : 'openVideo',
        'click #localbrightcove' : 'openlocalVideo',
	},
    
    openVideo : function(){
        alert("in OPEN VIDEO");
           $.mobile.changePage('../../settings/view/brightcove.html');
    },
    openlocalVideo : function(){
        alert("in OPEN LOCAL VIDEO");
        $.mobile.changePage('http://localhost/~ameyathakur/brightcove.html');
    },
    /**
	 * Name    : getlocalApache
	 * Purpose : Method to do get Healthwise Contents.
	 * Params  : --
	 * Return  : --
	 **/
	getOverlay : function() {
        //alert("I am in getOverlay"); 
        var url = "http://secure.uat.alerehealth.com:13085/api/health-articles/aa20968";    
        this.service.getResponse( url,this.proxy(this.healthwiseSuccess),this.proxy(this.healthwiseError), true);  
	},
     /**
	 * Name    : healthwiseSuccess
	 * Purpose : Method to do get Alfreco Contents.
	 * Params  : --
	 * Return  : --
	 **/
	healthwiseSuccess : function(output) {
        var healthwiseContent;       
		healthwiseContent = output.responseText;	
		articlecontents = healthwiseContent;						
		 
        $.mobile.changePage('../../settings/view/dummyarticle.html');			
	}, 
    /**
     * Name    : healthwiseError
     * Purpose : Method to do get Alfreco Contents.
     * Params  : --
     * Return  : --
    **/
	healthwiseError : function(errorMessage) {
        alert("Failure"+errorMessage);
        //$.mobile.changePage('../../settings/view/aa20968.html' );
	},
	/**
	 * Name    : showArticles
	 * Purpose : Method to render Healthwise Article Content.
	 * Params  : --
	 * Return  : --
	 **/ 
	showArticles:function(){	
        //This is the regular Expression for the replacement g- global i-ignorecase
        var re = /hwMCnt\?id=healthwise:\/\//gi;
     	articlecontents = articlecontents.replace(re, mHealth.env.healthwise_url);	
        
        //str.replace(/src='(?:[^'\/]*\/)*([^']+)'/g, "src='newPath/$1'");
        
        $('#articlePage').html(articlecontents);	
		//$('[data-role=header]').first().height()	
		$('div[data-role="header"]').unwrap();	
		
        alert("AFTER REMOVING DATA-ROLE HEADER  "+$('#articlePage').html());
	},
	/**
	 * Name    : openArticleLink
	 * Purpose : Method to do handle hyperlink click on article
	 * Params  : --
	 * Return  : --
	 **/
	openArticleLink : function(event){		
		event = event || window.event;
        var target = event.target || event.srcElement
        if (target.href){
                var targetValue = target.href;
                var healthWiseValue = targetValue.split("//",3);                
                var healthWiseId = healthWiseValue[2];              
                target.href  = "http://secure.uat.alerehealth.com:13085/api/health-articles/"+healthWiseId;    
                event.preventDefault();
                var url = target.href;   
                this.service.getResponse(url, this.proxy(this.articleLinkSuccess), this.proxy(this.articleLinkFailure), true); 
        } else {
        	alert("No url found to navigate");
        }       
	},	
	/**
	 * Name    : showArticlesContent
	 * Purpose : Method on render link on articles
	 * Params  : --
	 * Return  : --
	 **/
	showArticlesContent:function(){			
		$('#articleContent_div').append(articleContent);
		$('#articleContent_div').trigger('create');
	},
	/**
	 * Name    : articleLinkSuccess
	 * Purpose : Method on success of Article link
	 * Params  : --
	 * Return  : --
	 **/
	articleLinkSuccess : function(output) {	               
			articleContent = output.responseText;			
			$.mobile.changePage( "../../settings/view/dummyarticlecontent.html", { role: "dialog"} );			
	},
	/**
	 * Name    : articleLinkFailure
	 * Purpose : Method on failure of Article link
	 * Params  : --
	 * Return  : --
	 **/
	articleLinkFailure : function(){
		alert('No data found to display');
	},
    /**
	 * Name    : getHealthwisePage
	 * Purpose : Method to do get Healthwise Contents.
	 * Params  : --
	 * Return  : --
	 **/
	getdirectArticle : function() {
       // healthwiseContent = '<div data-role="header" data-theme="b" data-backbtn="false">' + '<h1>Diabetes: Preventing High Blood Sugar Emergencies</h1>' + '</div>' + '<div data-role="content">' + '<div>' + '  <p>' + ' <span class="QuestionLabel">Question: </span>If I have symptoms of mild high blood sugar, I should:</p>' + ' <p>' + ' <span class="QuestionLabel">Answer: </span>Follow the steps for dealing with high blood sugar.</p>' + '<p>' + '<span class="QuestionLabel">Explanation: </span>This answer is correct.</p>' + '<p>If you think you are having symptoms of mild high blood sugar, follow the steps for dealing with high blood sugar. Treat high blood sugar levels early to prevent an emergency situation from developing.</p>' + '</div>' + '</div>';
		//$.mobile.changePage('../../settings/view/dummyarticle.html');
	},  
	 
	/**
	 * Name    : getHealthwisePage
	 * Purpose : Method to do get Healthwise Contents.
	 * Params  : --
	 * Return  : --
	 **/
	getHealthwisePage : function() {
        alert("I am in getHealthwisePage ../../settings/view/healthwise.html ");
        $.mobile.changePage('../../settings/view/localApache.html');
	},

	/**
	 * Name    : getHealthwise Content
	 * Purpose : Method to do get Healthwise Contents.
	 * Params  : --
	 * Return  : --
	 **/
	getHealthwise : function() {
          alert("I am in getHealthwise http://10.75.205.206/~ameyathakur/aa20968.html ");
        //healthwise_url: "http://secure.uat.alerehealth.com:13085/api/health-articles/aa20968"
        //var article_id = "aa20968";
		//var URL = mHealth.env.healthwise_url+article_id;
        //this.service.getResponse("http://secure.uat.alerehealth.com:13085/api/health-articles/aa20968",
        // this.service.getResponse("http://10.75.205.206/~ameyathakur/aa20968.html",
        // this.proxy(this.healthwiseSuccess),
        // this.proxy(this.healthwiseError), true);
        //$.mobile.changePage('../../settings/view/aa20968.html');
	},
   
    /**
	 * Name    : getAlfreco
	 * Purpose : Method to do get Alfreco Contents.
	 * Params  : --
	 * Return  : --
	 **/
	getAlfresco : function() {
        $.mobile.changePage('../../settings/view/healthwise1.html');
	},
    /**
	 * Name    : debug
	 * Purpose : Method to do Debug.
	 * Params  : --
	 * Return  : --
	 **/
	debug : function() {

        $.mobile.changePage('../../settings/view/debugindex.html');
	},
	/**
	 * Name    : doLogout
	 * Purpose : Method to do required actions while logout.
	 * Params  : --
	 * Return  : --
	 **/
	doLogout : function() {
		mHealth.util.customPrompt(mHealth.SettingsController.logoutConfirm,  function() {
			location.href = "tabbar://removeMask?";
		}, function() {
			
			var splashMessage = mHealth.SettingsLogin.logout;
			//mHealth.models.AnswerModel.destroyAll();
			//mHealth.models.ParticipantAnswerModel.destroyAll();
			mHealth.models.ConditionModel.destroyAll();
			mHealth.models.MessageModel.destroyAll();
			mHealth.models.MedicationModel.destroyAll();
			mHealth.models.ParticipantModel.destroyAll();
			//mHealth.models.SpaceModel.destroyAll();
			//mHealth.models.ViewModel.destroyAll();
			//mHealth.models.ZoneModel.destroyAll();
			mHealth.models.HealthDataModel.destroyAll();

			$.mobile.changePage("../../rootview/view/login.html", {
				data : {
					splashMessage : splashMessage
				}
			});

			mHealth.util.removeNativeBar();
			mHealth.MessageControllerObject.tabbarloaded= false;
		});
	},
	/**
	 * Name    : getHeightUnits
	 * Purpose : Method to get the selected value of height units field on change of the select menu
	 * Params  : --
	 * Return  : --
	 **/
	getHeightUnits : function() {
		mHealth.util.selUnits = $('select#HeightUnit option:selected').val();
	},
	/**
	 * Name:WeightUnits
	 *Purpose:Method to get the selected value of weight units field
	 on change of the select menu
	 **/

	getWeightUnits : function() {
		mHealth.util.selWeightUnits = $('select#WeightUnit option:selected').val();
	},
	/**
	 * Name    : showSettings
	 * Purpose : Method to render the selected value of height units field on load of the page
	 * Params  : --
	 * Return  : --
	 **/
	showSettings : function() {
		if(mHealth.util.selUnits == 'cm') {
			$("select#HeightUnit option[value='cm']").attr("selected", "selected");
			$('select').selectmenu('refresh');

		}

		if(mHealth.util.selWeightUnits == 'Kg') {
			$("select#WeightUnit option[value='Kg']").attr("selected", "selected");
			$('select').selectmenu('refresh');

		}
	},
	/**
	 * Name    : showDetail
	 * Purpose : Method to render the values of device details
	 * Params  : --
	 * Return  : settingsDetail, deviceInfo
	 **/
	showDetail : function() {
		var settingsDetail;
		settingsDetail = mHealth.SettingsAbout;
		$('#settingsHeader').html(_.template($('#headerScript').html(), {
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').html(_.template($('#deviceDetails').html(), {
			deviceInfo : deviceInfo,
			settingsDetail : settingsDetail
		}));
		$('#aboutDevices').trigger('create');
		$('#settingsHeader').trigger('create');

	},
	/**
	 * Name    : getFeatures
	 * Purpose : Method to call the webview to get Device Features
	 * Params  : --
	 * Return  : --
	 **/
	getFeatures : function() {
		mHealth.util.getDeviceFeatures();
		$.mobile.changePage("about.html");
	},
	/**
	 * Name    : sendMail
	 * Purpose : Method to call the webview to call native email
	 * Params  : --
	 * Return  : --
	 **/
	sendMail : function() {
        mHealth.util.sendEmail(mHealth.env.emailTo,mHealth.env.emailCC , mHealth.env.emailSubject);
	}
});

mHealth.controllers.SettingsController.extend({

	/**
	 * Name    : getDevicesFeature
	 * Purpose : Method to call from webview to get device features
	 * Params  : --
	 * Return  : --
	 **/
	getDevicesFeature : function(device, osversion) {
		mHealth.util.osversion = osversion;
		mHealth.util.device = device;
		deviceInfo = [{
			'regUser' : mHealth.util.participantEmail,
			'version' : mHealth.util.version,
			'platform' : 'APPLE',
			'deviceName' : mHealth.util.device,
			'deviceModel' : mHealth.util.osversion
		}];

	}
});
