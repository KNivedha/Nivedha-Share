//
//  PList.m
//  Alere
//
//  Created by AlereMobility on 17/02/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "PList.h"

@implementation PList

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
  if ([action isEqualToString:@"Accepted"] )
  {
    NSString *pListPath = [[NSBundle mainBundle] pathForResource:@"forceQuit" ofType:@"plist"];
		NSMutableDictionary* dicObj=[[NSMutableDictionary alloc]init];
		[dicObj setObject:@"YES" forKey:@"Accepted"];
		[dicObj writeToFile:pListPath atomically:YES];
		//dicObj 
		 NSDictionary *dict = [[NSDictionary alloc] initWithContentsOfFile:pListPath];

     NSLog(@"plist content set YES: %@",dict);

		NSLog(@"stored in plist");

  }
}
@end
