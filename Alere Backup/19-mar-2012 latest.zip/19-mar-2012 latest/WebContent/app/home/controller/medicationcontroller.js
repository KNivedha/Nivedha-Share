/**
 * Controller : MedicationController
 * This is the controller to do the  logic of medications
 **/
mHealth.controllers.MedicationController = Spine.Controller.sub({
	el : 'body',
	showremoveimage : false,
	showremovebutton : false,
	elements : {},

	service : mHealth.util.RemoteServiceProxy.getInstance(),

	events : {
		'click #show_medication' : 'getMedicationList',
		'pagebeforeshow #medication_index' : 'showMedicationList',
		'click .medicationUniqueId' : 'getDetailedMedication',
		'pagebeforeshow #detail_medication' : 'showDetailedMedication',
		'click #removeMedication' : 'removeMedication',
		'click .deletesource' : 'confirmRemoveMedication',
		'click .deletebutton' : 'removeMedicationModel',
		'click .cancelBut':'showMedicationList',
        'click .doneBut':'showMedicationList'

	},
	
	
	medicationRemoveSuccess : function(jqXHR)
	{		
	},
	medicationRemoveFailure : function(errorThrown)
	{		
	},

	removeMedicationModel : function(event) {
		var eventTarget = event.target;
		var medication_ID = $(eventTarget).parents().children('input[type="hidden"]').val();
		
		mHealth.util.customPrompt('Are you sure you want to remove this medication from your record?', function(){}, function(){
			
        var medicationObject = mHealth.models.MedicationModel.findByAttribute('medicationId',medication_ID);
        var url = mHealth.env.medication_url +medicationObject.partMedId;
        
            var currentDate =(new Date()).format(mHealth.dateformat);
            
        var body = '{"endDate":"'+currentDate+'","medicationType":"discontinued","medicationID":"'+medication_ID+'"}';
        mHealth.MedicationControllerObject.service.putRequest(url, body, mHealth.MedicationControllerObject.medicationRemoveSuccess, mHealth.MedicationControllerObject.medicationRemoveFailure, true);
		mHealth.models.MedicationModel.destroy(medicationObject.id);
		mHealth.MedicationControllerObject.renderMedication();
		});
		//event.preventDefault1();
	},
	confirmRemoveMedication : function(event) {
		var etarget = event.target;
		var image = $(etarget).attr('src');
		if(image == "../../../assets/images/delete.png") {
			$(etarget).attr('src', '../../../assets/images/confirm_delete.png');			
			$('.dosecontainer').css({'margin-left':'auto', 'margin-right':'auto'});
			$(etarget).parents('.deleteicon').siblings('.ui-block-c').children('.deletebutton').show();
			$(etarget).parents('.deleteicon').siblings('.ui-block-c').children('.dose').hide();			
		} else {
			$(etarget).attr('src', '../../../assets/images/delete.png');
			$(etarget).parents('.deleteicon').siblings('.ui-block-c').children('.deletebutton').hide();
			$(etarget).parents('.deleteicon').siblings('.ui-block-c').children('.dose').show();				
		}
	},
	removeMedication : function() {
		$('#removeMedication').hide();
		$('.doneBut').show();
        $('.backBut').hide();
        $('.cancelBut').show();
		mHealth.MedicationControllerObject.showremoveimage = true;
		$('.dosecontainer').css({'width':'25%'});
		this.proxy(this.renderMedication());
		$('.deletebutton').hide();
		
	
	},
	/**
	 * Name    : getMedicationList
	 * Purpose : Method to fetch the medication history
	 * Params  : --
	 * Returns : --
	 **/
	getMedicationList : function() {

		var modelCount;
		modelCount = mHealth.models.MedicationModel.count();

		if(modelCount === 0) {
			mHealth.util.showMask();
			this.service.getResponse(mHealth.env.medication_url, this.proxy(this.medicationSuccess), this.proxy(this.medicationFailure), true);
		} else {
			$.mobile.changePage("../view/medicationindex.html");
		}
	},
	/**
	 * Name    : medicationSuccess
	 * Purpose : Success callback of medication service call
	 * Params  : output - response from the server
	 * Returns : --
	 **/
	medicationSuccess : function(output) {

		var response = output.responseText;
		this.proxy(this.setMedicationData(response));
		$.mobile.changePage("../view/medicationindex.html");
		mHealth.util.hideMask();
	},
	/**
	 * Name    : medicationFailure
	 * Purpose : Error callback of medication service call
	 * Params  : jqXHR - XMLHttpRequestObject,
	 textStatus - Status text message of the response,
	 errorThrown - Error message recieved from the server
	 * Returns : Alerts 'Information not available'
	 **/
	medicationFailure : function(jqXHR, textStatus, errorThrown) {
                                                                mHealth.util.hideMask();
		mHealth.util.customAlert(mHealth.Condition.informationErrMsg, '');
		
	},
	renderMedication : function() {
		var medicationData;
		medicationData = mHealth.models.MedicationModel.all();
		$('#data_div').html(_.template($('#medicationDataList').html(), {
			medicationData : medicationData
		}));
		if(mHealth.MedicationControllerObject.showremoveimage==false){
		$('.dosecontainer').css({'width':'45%'});
		}else{
			$('.dosecontainer').css({'width':'25%'});
		}
		
		$('#medication_index').trigger('create');
	},
	/**
	 * Name    : showMedicationList
	 * Purpose : Method to render the medication history in the view
	 * Params  : --
	 * Returns : medicationData
	 **/
	showMedicationList : function() {
		$('.cancelBut').hide();
		
		$('.backBut').show();
        $('.doneBut').hide();
        $('#removeMedication').show();
		mHealth.MedicationControllerObject.showremoveimage = false;

		this.proxy(this.renderMedication());

	},
	/**
	 * Name    : getDetailedMedication
	 * Purpose : Method to get the detailed view of medication data
	 * Params  : event object
	 * Returns : detailedMedications
	 **/
	getDetailedMedication : function(event) {
		var detailedMedication;
		var eventTarget = event.target;		
		var medication_ID ="";
		if(($(eventTarget).hasClass("medicationUniqueId"))){
			medication_ID = $(eventTarget).children('input[type="hidden"]').val();			
		} else if(!($(eventTarget).hasClass("del-text"))&&!($(eventTarget).hasClass("deletesource"))){			
			medication_ID = $(eventTarget).parents().children('input[type="hidden"]').val();
		} 
		if(medication_ID){
			mHealth.models.MedicationModel.select(function(record) {
				if(record.medicationId == medication_ID) {
					detailedMedication = record;
				}
			});
			var detailedMedicationstring = JSON.stringify(detailedMedication);	
			var encodeMedicationData = $.base64Encode(detailedMedicationstring);			
			$.mobile.changePage("../view/displaymedication.html", {
				data : {
					detailedMedicationstring : encodeMedicationData
				}
			});
		}
	},
	/**
	 * Name    : showDetailedMedication
	 * Purpose : Method to render the detailed view of medication data
	 * Params  : --
	 * Returns : detailedMedications
	 **/
	showDetailedMedication : function() {		
		var currentPageURL, medicationData, detailedMedications;
		currentPageURL = $('div[id = "detail_medication"]').attr('data-url');		
		medicationData = mHealth.util.getParameterByName('detailedMedicationstring', currentPageURL);
		medicationData = $.base64Decode(medicationData);
		detailedMedications = JSON.parse(medicationData);		
		$('#detailed_data').html(_.template($('#medicationDetails').html(), {
			detailedMedications : detailedMedications
		}));
		$('#detail_medication').trigger('create');

	},
	/**
	 * Name    : setMedicationData
	 * Purpose : Method to set the data from server to the medication model
	 * Params  : response - response data from the server
	 * Returns : --
	 **/
	setMedicationData : function(response) {
		mHealth.models.MedicationModel.customFromJSON(response);
	}
});
