//
//  OrientationConstants.h
//  Alere
//
//  Created by virtusa5 on 20/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OrientationConstants : NSObject
+(void)setRotated:(BOOL)value;
+(BOOL)rotated;
+(void)setLandscp:(BOOL)value;
+(BOOL)landscp;
@end
