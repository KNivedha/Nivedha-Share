//
//  AlereViewController.h
//  Alere
//
//  Created by Virtusa1 on 04/01/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OpenUrl;
@class Calendar;
@class EMail;
@class Devices;
@class TabBar;
@class Orientation;
@class Reachability;
@protocol DeviceDelegate; 

@interface AlereViewController : UIViewController <UIWebViewDelegate,UIGestureRecognizerDelegate>
{
    IBOutlet UITabBar* baseTabBar;
    IBOutlet UIWebView* webView;
    IBOutlet UIImageView* logoImage;
    NSMutableData* responseData;
    NSString* token;
    NSString* eventname;
    NSMutableDictionary* pluginObjects;
    Reachability* reachability;
    BOOL landscp;
    BOOL returnType;
    BOOL rotated;
    BOOL login;
    BOOL cameBack;
    BOOL enteredGraph;
    BOOL resized;
    BOOL enteredGlucose;
   
    //**********plugin objects***************
}
@property(nonatomic,retain)IBOutlet UIWebView* webView;
@property(nonatomic,retain)IBOutlet UITabBar* baseTabBar;
@property(nonatomic,assign) UIImageView* logoImage;
@property(nonatomic)BOOL rotated;
@property(nonatomic)BOOL landscp;
@property(nonatomic)BOOL insideTabBar;
@property(nonatomic)BOOL enteredGlucose;
@property(nonatomic)BOOL enteredGraph;
@property(nonatomic)BOOL resized;
@property(nonatomic)BOOL login;
-(void) resetAppIdleTimer ;
-(void)cancelTimer;



@end

