//
//  EMail.m
//  Alere
//
//  Created by virtusa5 on 19/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "EMail.h"

@implementation EMail
-(void)accessDeviceFeature:(NSMutableDictionary*)parameters forAction:(NSString*)action
{
    NSArray* keys=[parameters allKeys];
    NSLog(@"keys : %@",keys);
    NSString* toAddress=[parameters objectForKey:@"mailto"];
    NSString* toCopy=[parameters objectForKey:@"cc"];
    
    NSString* subject=[parameters objectForKey:@"subject"];
    NSString* urlString=[NSString stringWithFormat:@"mailto:?to=%@&cc=%@&subject=%@",toAddress,toCopy,subject];
   	urlString=[urlString stringByAddingPercentEscapesUsingEncoding:NSStringEncodingConversionAllowLossy];
		NSLog(@"final url : %@",urlString);
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlString]];

}
@end
